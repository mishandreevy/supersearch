"""Local configuration and dictionary translations."""
import json
import os
from copy import deepcopy
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = Path(os.environ.get('SUPERSEARCH_DATA', ROOT / 'data'))
DATA.mkdir(parents=True,exist_ok=True)
DEFAULTS = dict(language='en', search='DuckDuckGo', homepage='supersearch:start',
                suggestions=None, theme='light', colors={}, font='Sans Serif', radius=18,
                spacing=8, dark_sites=False, preset='standard', block_ads=True,
                fingerprint=True, webrtc=True, geolocation=True, javascript=False,
                https_only=True, strip_params=True, third_party=True, doh='Off',
                proxy='', tor=False, wallpaper='', bookmark_bar=True,
                config_version=3, onboarding_complete=False, tour_pending=False, tour_completed=False, terms_version='', titlebar_height=38,
                titlebar_show_title=True, titlebar_accent=False, ephemeral_profile=True, remember_history=False,
                titlebar_show_expand=False,window_expand_mode='maximized',titlebar_system_status=True,
                block_referrers=True, gpc=True, webgl=True, canvas=True,
                userscripts_private=False, allow_popups=False, animations=True,
                ui_scale=100, page_zoom=100, sidebar_width=240, sidebar_height=210, sidebar_collapsed=False,
                tab_height=48, icon_size=24, toolbar_size=38, shape='rounded',
                home_columns=6, home_tile_size=120, home_width=960, home_logo=True,
                home_search=True, home_stats=True, home_ip=True, home_align='center',
                layout_state='', window_geometry='', layout_locked=True,
                nav_order=['back','forward','reload','address','shield','split','passwords','bookmark','menu'],
                nav_hidden=[], extension_enabled=[], confirm_close=True, restore_tabs=False)

PRESETS = {
    'standard': dict(block_ads=True, fingerprint=True, webrtc=True, geolocation=True,
                     javascript=False, https_only=True, strip_params=True, third_party=True, tor=False, doh='Off', webgl=True, canvas=True),
    'strict': dict(block_ads=True, fingerprint=True, webrtc=True, geolocation=True,
                   javascript=False, https_only=True, strip_params=True, third_party=True,
                   doh='Quad9', tor=False, ephemeral_profile=True, remember_history=False, webgl=False, canvas=False),
    'paranoia': dict(block_ads=True, fingerprint=True, webrtc=True, geolocation=True,
                     javascript=True, https_only=True, strip_params=True, third_party=True,
                     tor=True, doh='Off', ephemeral_profile=True, remember_history=False, webgl=False, canvas=False, suggestions=False),
}
PALETTES = {
    'dark': dict(bg='#16181f', panel='#222530', fg='#eceef5', accent='#8bafff'),
    'light': dict(bg='#f5f6fa', panel='#ffffff', fg='#182033', accent='#2459b8'),
    'oled': dict(bg='#000000', panel='#101010', fg='#eeeeee', accent='#91b4ff'),
}
# English is the fallback for technical labels; all navigation is translated.
WORDS = {
    'en': dict(settings='Settings', privacy='Privacy', appearance='Appearance', general='General',
               extensions='Extensions', statistics='Statistics', about='About', new_tab='New tab',
               history='History', bookmarks='Bookmarks', blocked='Blocked trackers', close='Close',
               restart='requires restart', language='Language', search='Search engine', homepage='Homepage',
               suggestions='Search suggestions', dark_sites='Dark websites', update='Update filters',
               test='Test proxy', install='Install UserScript', private='Private window', total='Total',
               daily='Daily blocks (last 14 days)', top='Top blocked domains', remove='Remove'),
    'ru': dict(settings='Настройки', privacy='Приватность', appearance='Оформление', general='Общие',
               extensions='Расширения', statistics='Статистика', about='О программе', new_tab='Новая вкладка',
               history='История', bookmarks='Закладки', blocked='Заблокировано трекеров', close='Закрыть',
               restart='нужен перезапуск', language='Язык', search='Поисковик', homepage='Домашняя страница',
               suggestions='Подсказки поиска', dark_sites='Тёмные сайты', update='Обновить фильтры',
               test='Проверить прокси', install='Установить UserScript', private='Приватное окно', total='Всего',
               daily='Блокировки за 14 дней', top='Чаще блокируемые домены', remove='Удалить'),
    'de': dict(settings='Einstellungen', privacy='Datenschutz', appearance='Darstellung', general='Allgemein',
               extensions='Erweiterungen', statistics='Statistik', about='Über', new_tab='Neuer Tab',
               history='Verlauf', bookmarks='Lesezeichen', blocked='Blockierte Tracker', close='Schließen',
               restart='Neustart erforderlich', language='Sprache', search='Suchmaschine', homepage='Startseite',
               suggestions='Suchvorschläge', dark_sites='Dunkle Webseiten', update='Filter aktualisieren',
               test='Proxy testen', install='UserScript installieren', private='Privates Fenster', total='Gesamt',
               daily='Letzte 14 Tage', top='Häufigste Domains', remove='Entfernen'),
    'fr': dict(settings='Paramètres', privacy='Confidentialité', appearance='Apparence', general='Général',
               extensions='Extensions', statistics='Statistiques', about='À propos', new_tab='Nouvel onglet',
               history='Historique', bookmarks='Favoris', blocked='Traqueurs bloqués', close='Fermer',
               restart='redémarrage requis', language='Langue', search='Moteur de recherche', homepage='Accueil',
               suggestions='Suggestions', dark_sites='Sites sombres', update='Actualiser les filtres',
               test='Tester le proxy', install='Installer UserScript', private='Fenêtre privée', total='Total',
               daily='14 derniers jours', top='Domaines bloqués', remove='Supprimer'),
    'es': dict(settings='Ajustes', privacy='Privacidad', appearance='Apariencia', general='General',
               extensions='Extensiones', statistics='Estadísticas', about='Acerca de', new_tab='Nueva pestaña',
               history='Historial', bookmarks='Marcadores', blocked='Rastreadores bloqueados', close='Cerrar',
               restart='requiere reinicio', language='Idioma', search='Buscador', homepage='Inicio',
               suggestions='Sugerencias', dark_sites='Sitios oscuros', update='Actualizar filtros',
               test='Probar proxy', install='Instalar UserScript', private='Ventana privada', total='Total',
               daily='Últimos 14 días', top='Dominios bloqueados', remove='Eliminar'),
}


def read_json(path, default):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return default


def write_json(path, value):
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(str(temp), str(path))


class Config(dict):
    def __init__(self):
        super().__init__(deepcopy(DEFAULTS))
        saved = read_json(DATA / 'settings.json', {})
        if isinstance(saved, dict):
            self.update(saved)
            if saved.get('config_version', 0) < 3:
                self.update(theme='light', colors={}, dark_sites=False, config_version=3)
        self['dark_sites'] = False

    def save(self):
        write_json(DATA / 'settings.json', self)

    def palette(self):
        return dict(PALETTES.get(self['theme'], PALETTES['dark']), **self['colors'])


config = Config()
LANGUAGE = config['language']


def tr(key):
    return WORDS.get(config['language'], WORDS['en']).get(key, WORDS['en'].get(key, key))
