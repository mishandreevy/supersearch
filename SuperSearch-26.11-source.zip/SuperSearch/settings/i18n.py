"""English source text with explicit dictionaries and immediate widget relabeling."""
import json
from pathlib import Path
from settings.config import config, WORDS

LANGUAGES = {'en':'English','ru':'Русский','de':'Deutsch','fr':'Français','es':'Español'}
CATALOG_DIR = Path(__file__).resolve().parent / 'translations'
_catalogs = {}
_reverse_sources = None
_word_keys = {value:key for key,value in WORDS['en'].items()}


def catalog(language):
    if language not in _catalogs:
        path=CATALOG_DIR/(language+'.json')
        try:
            _catalogs[language]=json.loads(path.read_text(encoding='utf-8'))
        except (OSError,ValueError):
            _catalogs[language]={}
    return _catalogs[language]


def english(text):
    global _reverse_sources
    for words in WORDS.values():
        suffix=' ('+words.get('restart','requires restart')+')'
        if text.endswith(suffix):
            return english(text[:-len(suffix)])+' (requires restart)'
    if _reverse_sources is None:
        reverse={}
        for words in WORDS.values():
            for key,value in words.items():reverse.setdefault(value,WORDS['en'].get(key,value))
        for language in LANGUAGES:
            if language=='en':continue
            for source,localized in catalog(language).items():reverse.setdefault(localized,source)
        _reverse_sources=reverse
    return _reverse_sources.get(text,text)


def translate(text):
    source=english(text)
    language=config['language']
    suffix=' (requires restart)'
    if source.endswith(suffix):
        return translate(source[:-len(suffix)])+' ('+WORDS.get(language,WORDS['en'])['restart']+')'
    if language=='en':
        return source
    if source in _word_keys:
        return WORDS.get(language,{}).get(_word_keys[source],source)
    return catalog(language).get(source,source)

