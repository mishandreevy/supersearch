"""Plain-data privacy descriptions and presets for the browser interface."""
PRESET_LABELS={'standard':'Balanced','strict':'Stronger','paranoia':'Maximum'}

PRESET_HELP={
 'standard':'Recommended for everyday browsing. Blocks known trackers and keeps most websites working.',
 'strict':'Adds tighter website restrictions. Some graphics and sign-in features may not work.',
 'paranoia':'Requires a running Tor service and turns off website JavaScript. Many websites will not work.'}

PRIVACY_OPTIONS={
 'block_ads':('Block ads and trackers','Stop requests to known advertising and tracking services.'),
 'https_only':('Use secure connections only','Upgrade HTTP addresses to HTTPS. Websites without HTTPS will not open.'),
 'strip_params':('Remove tracking tags from links','Clean common advertising parameters from website addresses.'),
 'third_party':('Limit tracking between websites','Block third-party cookies and storage. Some embedded sign-ins may not work.'),
 'block_referrers':('Hide the previous website address','Do not send websites the address of the page you came from.'),
 'gpc':('Ask websites not to track me','Send privacy preference signals. Websites decide whether to honor them.'),
 'ephemeral_profile':('Forget website data when I close SuperSearch','Cookies stay in memory, so you may need to sign in again after a restart. Bookmarks and saved passwords are kept.'),
 'fingerprint':('Reduce browser fingerprinting','Make some device details harder to read. This cannot prevent every form of fingerprinting.'),
 'webrtc':('Restrict direct browser connections','Limits WebRTC network exposure. Voice and video calls may not work.'),
 'geolocation':('Extra location blocking','Block the location API in website scripts. Website permissions are already denied by default.'),
 'javascript':('Turn off website JavaScript','Many websites and sign-in forms stop working. Leave this off for everyday browsing.'),
 'webgl':('Allow 3D graphics on websites','Needed by some maps, games and visual tools. It can reveal graphics-device details.'),
 'canvas':('Allow sites to read drawn images','Needed by some drawing and verification tools. It can reveal device details.'),
 'allow_popups':('Let websites open new windows','Links and scripts that open another window may be blocked when this is off.'),
 'tor':('Use Tor for connections','Start Tor on this device first. Uses 127.0.0.1:9050 and takes priority over the proxy address.'),
}
