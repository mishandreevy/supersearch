# Changelog

## 26.11 — 2026-11-03

Source release of SuperSearch with a single Electron/Chromium implementation.
The application displays `26.11`; Electron package metadata uses `26.11.0`.

- Chromium 156.0.8078.75 through the verified Electron 45.2.1 runtime.
- Configurable panels, compact horizontal tabs, persistent pins, split view,
  rounded controls and the original supplied start-page logo.
- English, Russian, German, French and Spanish dictionaries; first-run setup,
  optional guided tour and a returning-user backup restore flow.
- Tracker filtering, private sessions, optional search suggestions, permission
  controls and configurable proxy/Tor/secure DNS preferences.
- Local bookmarks/history/statistics, master-password vault, password-save cards,
  automatic downloads and reviewed local extensions/UserScripts.
- Password-protected `.supersearch` export and validated restore after restart.
- Complete source archives, per-file SHA-256 manifest and archive checksum.

The backup format version remains `1`, so existing supported SuperSearch exports
remain readable. Existing local profiles and the user's logo are not replaced by
this application-version update. Python 3.10+ is required; Qt/PySide6 is not used.

For scope and limitations of privacy controls, see [SECURITY.md](SECURITY.md).
