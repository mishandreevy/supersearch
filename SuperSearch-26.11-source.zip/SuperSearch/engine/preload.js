'use strict';
const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('supersearch',Object.freeze({
  call:(operation,data={})=>ipcRenderer.invoke('ss:ui',operation,data),
  subscribe:callback=>{const listener=(_event,state)=>callback(state);ipcRenderer.on('ss:state',listener);return ()=>ipcRenderer.removeListener('ss:state',listener);},
  event:callback=>{const listener=(_event,message)=>callback(message);ipcRenderer.on('ss:event',listener);return ()=>ipcRenderer.removeListener('ss:event',listener);}
}));
