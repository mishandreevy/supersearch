'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {dialog}=require('electron');
const {until,delay}=require('./smoke');

async function run({owner,action,backend,config,createWindow}){
  const ui=code=>owner.ui.executeJavaScript(code),mode=process.env.SUPERSEARCH_TEST_MODE;
  const profile=process.env.SUPERSEARCH_DATA,file=process.env.SUPERSEARCH_TEST_BACKUP_PATH;
  await until(()=>owner.tabs.length&&owner.area,'initial backup UI');
  if(mode==='restored'){
    if(fs.existsSync(path.join(profile,'session.json')))assert.ok(owner.tabs.some(tab=>tab.panes[0].url==='about:blank'));
    assert.equal(config().onboarding_complete,true);assert.equal(config().theme,'oled');assert.equal(config().tour_pending,false);
    const state=await backend.call('state');assert.equal(state.bookmarks[0].title,'Portable bookmark');
    await action(owner,'settings',{});await until(()=>ui("!!document.getElementById('settings-content')"),'restored settings');
    await ui("settingsCategory='About';renderSettingsContent();true");assert.equal(await ui("!!document.querySelector('[data-rollback]')"),false);
    assert.equal(await ui(`document.querySelector('.engine-version').textContent.includes(${JSON.stringify(require('./package.json').displayVersion)})`),true);
    console.log('RESTORE RESTART CHECKS OK: validated file installed by the launcher after old process exit, libraries and theme loaded, onboarding complete, no Qt action');return;
  }
  const originalOpen=dialog.showOpenDialog,originalSave=dialog.showSaveDialog;
  dialog.showOpenDialog=async()=>({canceled:false,filePaths:[file]});dialog.showSaveDialog=async()=>({canceled:false,filePath:file});
  try{
    if(mode==='returning'){
      await until(()=>ui("!!document.querySelector('[data-returning=yes]')"),'returning-user choice');
      await ui("document.querySelector('[data-returning=yes]').click();document.getElementById('wizard-continue').click();true");
      await until(()=>ui("!!document.getElementById('agreement')"),'returning agreement');
      assert.equal(await ui("document.getElementById('wizard-continue').disabled"),true);
      await ui("document.getElementById('agreement').click();document.getElementById('wizard-continue').click();true");
      await until(()=>ui("!!document.querySelector('[data-wizard-restore]')"),'restore branch');
      assert.equal(await ui("!!document.getElementById('wizard-tour')"),false);
      await ui("document.querySelector('[data-wizard-restore]').click();true");
    }else{
      await action(owner,'bookmarks_save',{url:'https://example.org',title:'Portable bookmark',folder:'Work'});
      await action(owner,'new_tab',{url:'about:blank'});
      await action(owner,'settings_apply',{theme:'oled'});await action(owner,'settings',{});
      await until(()=>ui("!!document.getElementById('settings-content')"),'storage settings');
      await ui("settingsCategory='Storage';renderSettingsContent();true");
      await delay(200);fs.writeFileSync('/tmp/supersearch-storage-backup.png',(await owner.ui.capturePage()).toPNG());
      await ui("document.querySelector('[data-backup-export]').click();true");
      await until(()=>ui("!!document.querySelector('input[name=repeat]')"),'export password dialog');
      await ui("(()=>{const form=document.querySelector('#modal-layer form');form.elements.password.value='fixture backup password';form.elements.repeat.value='fixture backup password';form.requestSubmit();return true})()");
      await until(()=>fs.existsSync(file)&&fs.statSync(file).size>100,'encrypted export');
      await until(()=>ui("document.getElementById('modal-layer').hidden"),'export finished');
      assert.ok(!fs.readFileSync(file).includes(Buffer.from('Portable bookmark')));
      await action(owner,'bookmarks_remove',{url:'https://example.org'});
      await ui("document.querySelector('[data-backup-restore]').click();true");
      const privateOwner=await createWindow(true);await until(()=>privateOwner.tabs.length,'private backup guard');
      await assert.rejects(action(privateOwner,'backup_choose',{}));await action(privateOwner,'close_confirm',{save:false});
    }
    await until(()=>ui("!!document.querySelector('input[name=confirm]')"),'restore confirmation');
    const before=fs.existsSync(path.join(profile,'bookmarks.json'))?fs.readFileSync(path.join(profile,'bookmarks.json')):null;
    await ui("(()=>{const form=document.querySelector('#modal-layer form');form.elements.password.value='wrong backup password';form.elements.confirm.checked=true;form.requestSubmit();return true})()");
    await until(()=>ui("!document.querySelector('[data-dialog-error]').hidden"),'wrong password shown');assert.equal(owner.testRestoreToken,undefined);
    if(before)assert.deepEqual(fs.readFileSync(path.join(profile,'bookmarks.json')),before);
    await ui("(()=>{const form=document.querySelector('#modal-layer form');form.elements.password.value='fixture backup password';form.requestSubmit();return true})()");
    await until(()=>!!owner.testRestoreToken,'restore prepared for next process');
    if(before)assert.deepEqual(fs.readFileSync(path.join(profile,'bookmarks.json')),before);
    assert.ok(fs.existsSync(path.join(profile,'.restore-plan.json')));
    console.log('BACKUP UI CHECKS OK: '+mode+', native file selection, encrypted export, wrong-password protection, explicit replacement and deferred restore');
  }finally{dialog.showOpenDialog=originalOpen;dialog.showSaveDialog=originalSave;}
}
module.exports={run};
