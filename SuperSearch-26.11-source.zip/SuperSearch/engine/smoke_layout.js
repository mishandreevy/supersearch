'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {until,delay}=require('./smoke');

async function run({owner,action,config}){
  const ui=code=>owner.ui.executeJavaScript(code);
  await until(()=>owner.tabs.length&&owner.area,'initial layout');
  await action(owner,'navigate',{text:'supersearch:start'});
  await until(()=>ui("(()=>{const image=document.querySelector('.home-logo');return !!image&&image.complete&&image.naturalHeight>0&&Math.abs(image.naturalWidth/image.naturalHeight-1271/158)<.05})()"),'original homepage logo');
  assert.equal(await ui("new URL(document.querySelector('.home-logo').src).pathname"),'/logo.svg');
  const svg=fs.readFileSync(path.join(__dirname,'../assets/logo.svg'),'utf8');assert.ok(svg.includes('viewBox="0 0 1271.000000 158.000000"'));
  assert.equal(await ui("new URL(document.querySelector('.home-logo').src).search"),'');
  fs.writeFileSync('/tmp/supersearch-electron-home-logo.png',(await owner.ui.capturePage()).toPNG());
  for(let index=0;index<12;index++)await action(owner,'new_tab',{url:'supersearch:start'});
  for(const tab of owner.tabs)tab.panes[0].title='A long website title that should stay inside the tab panel';
  // Cover both edges, scale extremes, icon-only mode and the smallest supported window.
  const cases=[
    ['top',false,100,1250,850,'en',210],['bottom',false,100,1250,850,'de',120],
    ['top',true,100,1250,850,'ru',210],['bottom',true,75,720,540,'fr',210],
    ['top',false,175,720,540,'de',600],['bottom',false,175,720,540,'es',120],
    ['top',true,175,720,540,'ru',210],['bottom',true,175,720,540,'en',210],
    ['top',false,75,720,540,'fr',120],['bottom',false,100,720,540,'ru',210],
    ['left',false,175,720,540,'en',210],['right',false,175,720,540,'en',210],
  ];
  for(const [edge,collapsed,scale,width,height,language,panelHeight] of cases){
    owner.window.setSize(width,height);
    await action(owner,'settings_apply',{sidebar_position:edge,sidebar_collapsed:collapsed,ui_scale:scale,language,sidebar_height:panelHeight});
    await until(()=>ui(`S.config.sidebar_position===${JSON.stringify(edge)}&&S.config.ui_scale===${scale}&&S.config.language===${JSON.stringify(language)}`),'panel settings');
    await delay(160);
    const result=await ui(`(()=>{
      const rect=selector=>document.querySelector(selector).getBoundingClientRect();
      const panel=rect('#sidebar'),viewport=rect('#viewport');
      const within=(a,b)=>a.left>=b.left-1&&a.top>=b.top-1&&a.right<=b.right+1&&a.bottom<=b.bottom+1;
      const controls=['#collapse','#new-tab','#bookmarks-button','#downloads-button','#settings-button'];
      const failures=controls.filter(selector=>!within(rect(selector),panel));
      const menu=rect('#collapse'),plus=rect('#new-tab');
      return {failures,adjacent:Math.abs(menu.top-plus.top)<1&&plus.left>=menu.right-1&&plus.left-menu.right<8,
        activeRect:rect('.tab.active').toJSON(),tabsRect:rect('#tabs').toJSON(),activeInside:within(rect('.tab.active'),rect('#tabs')),tabsInside:within(rect('#tabs'),panel),viewportInside:within(viewport,{left:0,top:0,right:innerWidth,bottom:innerHeight}),
        viewportHeight:viewport.height,viewportWidth:viewport.width,headerHeight:rect('.sidebar-top').height,
        stripHeight:panel.height,titlebarTop:rect('#titlebar').top,panelTop:panel.top,
        windowControlsSeparate:rect('.sidebar-bottom').right<=rect('.window-buttons').left+1,
        singleRow:[...document.querySelectorAll('.tab')].every(node=>Math.abs(node.getBoundingClientRect().top-rect('.tab').top)<1),
        hiddenLabels:[...document.querySelectorAll('.tab .title')].every(node=>getComputedStyle(node).display==='none'),
        toolbarInside:within(rect('#navigation'),{left:0,top:0,right:innerWidth,bottom:innerHeight}),
        addressInside:within(rect('#address'),rect('#navigation'))};
    })()`);
    if(!result.activeInside)console.log('Layout geometry: '+JSON.stringify(result));
    const label=[edge,collapsed?'collapsed':'expanded',scale+'%',width+'×'+height,language].join(' ');
    assert.deepEqual(result.failures,[],label+' controls overflow');assert.ok(result.adjacent,label+' menu and plus separated');
    assert.ok(result.tabsInside,label+' tab scroller overflow');assert.ok(result.activeInside,label+' active tab is hidden after moving/resizing the panel');assert.ok(result.viewportInside,label+' viewport overflow');
    assert.ok(result.viewportHeight>60&&result.viewportWidth>80,label+' page has no usable area');
    assert.ok(result.toolbarInside&&result.addressInside,label+' address toolbar overflow');
    if(['top','bottom'].includes(edge)){assert.ok(result.headerHeight<=32,label+' header buttons stretch');assert.ok(result.stripHeight<=42,label+' strip is taller than one tab row');assert.ok(result.singleRow,label+' tabs wrap to more than one row');}
    if(edge==='top'){assert.ok(Math.abs(result.titlebarTop-result.panelTop)<1,label+' extra titlebar row above tabs');assert.ok(result.windowControlsSeparate,label+' panel actions overlap window controls');}
    if(collapsed)assert.ok(result.hiddenLabels,label+' collapsed tabs show text');
    const native=owner.area,bounds=owner.window.getContentBounds();
    assert.ok(native.x>=0&&native.y>=0&&native.x+native.width<=bounds.width&&native.y+native.height<=bounds.height,label+' native bounds overflow');
    console.log('PASS: '+label);
  }
  await action(owner,'settings_apply',{sidebar_position:'top',sidebar_collapsed:false,ui_scale:100,language:'en',sidebar_height:140});
  owner.window.setSize(1250,850);await delay(150);
  fs.writeFileSync('/tmp/supersearch-electron-top-panel.png',(await owner.ui.capturePage()).toPNG());
  await action(owner,'settings_apply',{theme:'dark'});await until(()=>ui("document.querySelector('.home-logo').complete&&document.body.classList.contains('dark-logo')"),'original logo visible in dark mode');
  assert.equal(await ui("new URL(document.querySelector('.home-logo').src).pathname"),'/logo.svg');
  await action(owner,'settings_apply',{titlebar_show_expand:true});owner.window.setFullScreen(true);
  await until(()=>owner.window.isFullScreen(),'true fullscreen');await delay(250);
  assert.equal(await ui("(()=>{const actions=document.querySelector('.sidebar-bottom').getBoundingClientRect(),bar=document.getElementById('titlebar').getBoundingClientRect();return actions.right<=bar.left+1})()"),true);owner.window.setFullScreen(false);
  assert.equal(config().theme,'dark');
  console.log('ELECTRON LAYOUT CHECKS OK: original supplied logo, compact single-row strips, shared top window-control row, both horizontal edges, bounded controls, adjacent menu/plus, 75–175% scale, long labels, collapsed icons and clipped native bounds');
}
module.exports={run};
