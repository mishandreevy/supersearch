'use strict';
const {spawn}=require('node:child_process');
const path=require('node:path');
const readline=require('node:readline');

class Backend {
  constructor(root,data) {
    this.sequence=0;this.pending=new Map();
    this.process=spawn(process.env.SUPERSEARCH_PYTHON||'python3',[path.join(root,'engine/service.py')],{
      cwd:root,env:{...process.env,SUPERSEARCH_DATA:data,PYTHONUNBUFFERED:'1'},stdio:['pipe','pipe','pipe']
    });
    readline.createInterface({input:this.process.stdout}).on('line',line=>{
      let message;try{message=JSON.parse(line);}catch{return;}
      const task=this.pending.get(message.id);if(!task)return;
      this.pending.delete(message.id);clearTimeout(task.timer);
      if(message.error)task.reject(new Error(message.error));else task.resolve(message.result);
    });
    // Service errors never contain request bodies or passwords.
    this.process.stderr.on('data',()=>{});
    this.process.on('error',()=>this.fail());this.process.on('exit',()=>this.fail());
  }
  fail(){for(const task of this.pending.values()){clearTimeout(task.timer);task.reject(new Error('The local data service stopped.'));}this.pending.clear();}
  call(operation,data={}) {
    return new Promise((resolve,reject)=>{
      const id=++this.sequence;
      const timer=setTimeout(()=>{this.pending.delete(id);reject(new Error('The local operation timed out.'));},30000);
      this.pending.set(id,{resolve,reject,timer});
      this.process.stdin.write(JSON.stringify({id,operation,data})+'\n',error=>{if(error){clearTimeout(timer);this.pending.delete(id);reject(new Error('The local data service is unavailable.'));}});
    });
  }
  close(){
    if(this.closing)return this.closing;
    this.closing=new Promise(resolve=>{
      if(this.process.exitCode!==null){resolve();return;}
      const timer=setTimeout(()=>this.process.kill(),5000);timer.unref();
      this.process.once('exit',()=>{clearTimeout(timer);this.fail();resolve();});this.process.stdin.end();
    });
    return this.closing;
  }
}
module.exports={Backend};
