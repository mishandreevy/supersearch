'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const http=require('node:http');
const https=require('node:https');
const {session,dialog}=require('electron');
const {once}=require('node:events');
const {delay,until}=require('./smoke');

async function run(context){
  const {app,owner,backend,action,createWindow,normalSession,configureProxy,config,filters}=context;
  const DATA=process.env.SUPERSEARCH_DATA,checks=[];
  const mark=name=>{checks.push(name);console.log('PASS: '+name);};
  const ui=code=>owner.ui.executeJavaScript(code);
  const pane=()=>owner.tabs.find(tab=>tab.id===owner.active).panes[owner.tabs.find(tab=>tab.id===owner.active).active];
  const loaded=async()=>{await until(()=>pane().view&&!pane().loading,'page load');return pane().view.webContents;};
  let trackerHits=0,proxyHits=0;
  function fixture(request,response){
    if(request.url.startsWith('/fixture-tracker')){trackerHits++;response.end('tracker');return;}
    if(request.url.startsWith('/proxy-probe'))proxyHits++;
    if(request.url.startsWith('/file')){response.writeHead(200,{'content-type':'application/octet-stream','content-disposition':'attachment; filename="report.txt"'});response.end('local download fixture');return;}
    response.writeHead(200,{'content-type':'text/html'});
    if(request.url.startsWith('/login')&&request.method!=='POST'){response.end('<!doctype html><title>Login fixture</title><form method="post" action="/login"><input name="user" autocomplete="username"><input name="pass" type="password"><button>Sign in</button></form>');return;}
    if(request.url.startsWith('/login')){request.resume();response.end('<!doctype html><title>Signed in</title><h1 id="signed-in">Welcome</h1>');return;}
    response.end('<!doctype html><title>Local fixture</title><h1 id="fixture">Chromium 156</h1><input id="text"><script>window.scriptRan=true</script><img src="/fixture-tracker"><a href="/file">Download</a>');
  }
  const server=http.createServer(fixture),certificate=fs.readFileSync(path.join(DATA,'fixture-cert.pem'));
  const tls=https.createServer({cert:certificate,key:fs.readFileSync(path.join(DATA,'fixture-key.pem'))},fixture);
  server.listen(0,'127.0.0.1');tls.listen(0,'127.0.0.1');await Promise.all([once(server,'listening'),once(tls,'listening')]);
  const url='http://127.0.0.1:'+server.address().port,secure='https://127.0.0.1:'+tls.address().port;
  const fingerprint=new crypto.X509Certificate(certificate).fingerprint256;
  function trustFixture(ses){ses.setCertificateVerifyProc((request,callback)=>{let trusted=false;try{trusted=request.hostname==='127.0.0.1'&&new crypto.X509Certificate(request.certificate.data).fingerprint256===fingerprint;}catch{}callback(trusted?0:-3);});}
  trustFixture(normalSession);filters.blocks.push({text:'/fixture-tracker'});
  try{
    await action(owner,'navigate',{text:url+'/?utm_source=fixture&safe=1'});let contents=await loaded();
    await until(()=>contents.executeJavaScript("!!document.getElementById('fixture')"),'fixture DOM');
    assert.equal(new URL(pane().url).search,'?safe=1');assert.equal(trackerHits,0);
    assert.equal(await contents.executeJavaScript("typeof require+'|'+typeof process+'|'+typeof window.supersearch"),'undefined|undefined|undefined');
    assert.equal(contents.getLastWebPreferences().sandbox,true);assert.equal(contents.getLastWebPreferences().contextIsolation,true);assert.ok(!pane().securityError);
    if(process.platform==='linux'){const status=fs.readFileSync('/proc/'+contents.getOSProcessId()+'/status','utf8');assert.match(status,/NoNewPrivs:\s+1/);assert.match(status,/Seccomp:\s+2/);}
    assert.equal(await contents.executeJavaScript("typeof RTCPeerConnection"),'undefined');
    assert.equal(await contents.executeJavaScript("window.scriptRan"),true);
    assert.equal(await contents.executeJavaScript("window.open('https://example.org')===null"),true);
    assert.equal(await contents.executeJavaScript("fetch('ss-app://browser/index.html').then(()=>false,()=>true)"),true);
    assert.equal((await backend.call('state')).history.length,0);
    mark('OS sandbox, no Node/IPC in sites, tracker blocking, clean URLs and no default history');

    const probe=session.fromPartition('proxy-probe-'+crypto.randomUUID());
    await configureProxy(probe,{tor:true,proxy:'http://unused.example:123'});assert.match(await probe.resolveProxy(url),/SOCKS5 127\.0\.0\.1:9050/);
    await configureProxy(probe,{tor:false,proxy:'http://127.0.0.1:9'});
    await assert.rejects(probe.fetch(url+'/proxy-probe',{signal:AbortSignal.timeout(5000)}));assert.equal(proxyHits,0);await probe.closeAllConnections();
    mark('Tor takes priority; an unavailable proxy has no direct or loopback fallback');

    await action(owner,'settings',{});assert.equal(pane().view.getVisible(),false);
    await until(()=>ui("!!document.getElementById('settings-content')"),'embedded settings');
    await ui("document.querySelector('[data-category=General]').click();const field=document.querySelector('[data-setting=remember_history]');field.click();true");
    assert.equal(config().remember_history,false);assert.equal(await ui("dirtySettings().includes('remember_history')"),true);
    await ui("document.querySelector('[data-settings=apply]').click();true");await until(()=>config().remember_history===true,'Apply saves settings');
    await action(owner,'settings_apply',{remember_history:false});await action(owner,'web',{});
    mark('settings stage changes until Apply and use the native data service');

    const downloadDirectory=app.getPath('downloads');fs.writeFileSync(path.join(downloadDirectory,'report.txt'),'original');contents.downloadURL(url+'/file');
    await until(()=>fs.existsSync(path.join(downloadDirectory,'report (1).txt'))&&fs.readFileSync(path.join(downloadDirectory,'report (1).txt'),'utf8')==='local download fixture','automatic download');
    assert.equal(fs.readFileSync(path.join(downloadDirectory,'report.txt'),'utf8'),'original');await until(()=>fs.existsSync(path.join(DATA,'download_files.json')),'download ownership index');
    mark('automatic downloads preserve existing files and track owned completed downloads');

    await action(owner,'navigate',{text:secure+'/login'});contents=await loaded();await until(()=>contents.executeJavaScript("!!document.querySelector('input[type=password]')"),'HTTPS login form');
    assert.equal(await contents.executeJavaScript("Notification.requestPermission()"),'denied');
    await contents.executeJavaScriptInIsolatedWorld(1001,[{code:"document.querySelector('[name=user]').value='alice';document.querySelector('[name=pass]').value='fixture-secret';document.querySelector('form').requestSubmit();true"}]);
    await until(()=>!!owner.offer,'native password offer after login');assert.equal(owner.offer.origin,secure);
    await action(owner,'vault_create',{password:'fixture master password'});await action(owner,'password_save',{});assert.equal(owner.offer,null);
    assert.ok(!fs.readFileSync(path.join(DATA,'passwords.vault'),'utf8').includes('fixture-secret'));
    await action(owner,'navigate',{text:secure+'/login'});contents=await loaded();await until(()=>contents.executeJavaScript("!!document.querySelector('input[type=password]')"),'login form for filling');
    await action(owner,'vault_lock',{});await assert.rejects(action(owner,'password_fill',{origin:secure,username:'alice'}));
    await action(owner,'vault_unlock',{password:'fixture master password'});await action(owner,'password_fill',{origin:secure,username:'alice'});
    assert.equal(await contents.executeJavaScript("document.querySelector('input[type=password]').value==='fixture-secret'"),true);
    await action(owner,'navigate',{text:url});contents=await loaded();await assert.rejects(action(owner,'password_fill',{origin:secure,username:'alice'}));
    mark('HTTPS login offers, encrypted saves, locked-vault checks and origin-bound filling');

    const privateOwner=await createWindow(true);await until(()=>privateOwner.tabs.length,'private window');trustFixture(privateOwner.session);
    assert.notEqual(privateOwner.session,owner.session);assert.equal(privateOwner.session.getStoragePath(),null);
    await action(privateOwner,'pin_active',{});assert.equal(JSON.parse(fs.readFileSync(path.join(DATA,'pinned-tabs.json'))).tabs.length,1);
    await assert.rejects(action(privateOwner,'vault_list',{}));await action(privateOwner,'navigate',{text:secure+'/login'});
    const privatePane=privateOwner.tabs[0].panes[0];await until(()=>privatePane.view&&!privatePane.loading,'private login');
    await privatePane.view.webContents.executeJavaScript("document.querySelector('[name=user]').value='private';document.querySelector('[name=pass]').value='private-fixture';document.querySelector('form').requestSubmit();true");
    await delay(1200);assert.equal(privateOwner.offer,null);assert.ok(!fs.readFileSync(path.join(DATA,'passwords.vault'),'utf8').includes('private-fixture'));
    await action(privateOwner,'close_confirm',{save:false});mark('private sessions save neither pins nor credentials and cannot access the vault');

    for(const position of ['right','top','bottom','left']){await action(owner,'settings_apply',{sidebar_position:position});await delay(60);assert.ok(owner.area.width>100&&owner.area.height>100);}
    await action(owner,'settings_apply',{theme:'dark',titlebar_system_status:true});await action(owner,'settings',{});await until(()=>ui("!!document.getElementById('settings-content')"),'settings after layout');
    await ui("settingsCategory='About';renderSettingsContent();true");assert.equal(await ui("document.querySelector('[data-source]').href"),'https://github.com/mishandreevy/supersearch');
    assert.equal(await ui("document.getElementById('system-status').hidden"),true);owner.window.maximize();await delay(100);assert.equal(await ui("document.getElementById('system-status').hidden"),true);
    owner.window.setFullScreen(true);await until(()=>ui("!document.getElementById('system-status').hidden"),'fullscreen clock');owner.window.setFullScreen(false);await until(()=>ui("document.getElementById('system-status').hidden"),'clock hidden on exit');
    fs.writeFileSync('/tmp/supersearch-electron-about.png',(await owner.ui.capturePage()).toPNG());mark('four panel positions, source link, dark theme and fullscreen-only status');

    if(!config().ephemeral_profile){
      const extension=path.join(DATA,'fixture-extension');fs.mkdirSync(extension);fs.writeFileSync(path.join(extension,'manifest.json'),JSON.stringify({manifest_version:3,name:'Local fixture extension',version:'1.0',action:{default_popup:'popup.html'}}));fs.writeFileSync(path.join(extension,'popup.html'),'<h1>Local extension</h1>');
      const original=dialog.showOpenDialog;dialog.showOpenDialog=async()=>({canceled:false,filePaths:[extension]});
      try{const choice=await action(owner,'extension_choose',{kind:'folder'});const loaded=await action(owner,'extension_install',{token:choice.token});assert.equal((await action(owner,'extensions_list',{}))[0].name,'Local fixture extension');await action(owner,'extension_remove',{id:loaded.id});assert.equal((await action(owner,'extensions_list',{})).length,0);}finally{dialog.showOpenDialog=original;}
      mark('real local Manifest V3 extension installation and removal');
    }
    console.log('EXTENDED ELECTRON CHECKS OK: '+checks.length+' groups');
  }finally{server.close();tls.close();}
}
module.exports={run};
