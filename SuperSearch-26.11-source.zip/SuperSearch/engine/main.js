'use strict';
const {app,BrowserWindow,WebContentsView,ipcMain,session,protocol,net,dialog,shell,Menu,clipboard,nativeImage}=require('electron');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {spawn}=require('node:child_process');
const {Backend}=require('./backend');
const {origin,target,cleaned,sameParty,Filters,validSender}=require('./policy');
const ROOT=path.dirname(__dirname),DATA=path.resolve(process.env.SUPERSEARCH_DATA||path.join(ROOT,'data/electron'));
const RUNTIME=require('./runtime.json'),RELEASE=require('./package.json');
const TEST=process.argv.includes('--self-test');
if(TEST&&(!fs.existsSync(path.join(DATA,'.supersearch-test-profile'))||process.env.SUPERSEARCH_SKIP_MIGRATION!=='1'))throw Error('Run tests/gui_electron.py to use an isolated test profile.');
if(TEST){app.commandLine.appendSwitch('ozone-platform','headless');app.disableHardwareAcceleration();}
if(process.versions.electron!==RUNTIME.electron||process.versions.chrome!==RUNTIME.chromium)throw Error('Unexpected browser runtime');
fs.mkdirSync(DATA,{recursive:true});
if(TEST){fs.mkdirSync(path.join(DATA,'test-downloads'),{recursive:true});app.setPath('downloads',path.join(DATA,'test-downloads'));}
app.setName('SuperSearch');app.setPath('userData',path.join(DATA,'chromium'));app.setPath('sessionData',path.join(DATA,'chromium'));app.setPath('crashDumps',path.join(DATA,'crashes'));
app.enableSandbox();
let initial={webrtc:true,tor:false};try{initial={...initial,...JSON.parse(fs.readFileSync(path.join(DATA,'settings.json'),'utf8'))};}catch{}
if(initial.webrtc){for(const flag of ['disable-webrtc','disable-webrtc-hw-encoding','disable-webrtc-hw-decoding'])app.commandLine.appendSwitch(flag);app.commandLine.appendSwitch('force-webrtc-ip-handling-policy','disable_non_proxied_udp');}
if(initial.tor)app.commandLine.appendSwitch('host-resolver-rules','MAP * ~NOTFOUND, EXCLUDE 127.0.0.1, EXCLUDE localhost');
if(process.platform==='linux')app.commandLine.appendSwitch('disable-setuid-sandbox');
for(const flag of ['disable-quic','disable-background-networking','disable-sync','disable-component-update','no-pings','dns-prefetch-disable'])app.commandLine.appendSwitch(flag);
protocol.registerSchemesAsPrivileged([{scheme:'ss-app',privileges:{standard:true,secure:true,supportFetchAPI:true}}]);
let backend,bootstrap,config,startup,normalSession,filters,quitting=false;
let backendStopped=false,backupBusy=false;
const windows=new Map(),remote=new Map(),downloads=[],reserved=new Set(),blocks={};
let ip={address:'',state:'idle',expires:0,generation:0},ipController=null,statsTimer=null;
let ipLastAttempt=0;
const UI_URL='ss-app://browser/index.html';
const extensionChoices=new Map();
const RESTART=['webrtc','javascript','tor','doh','proxy','ephemeral_profile'];

function writeJSON(name,value){const file=path.join(DATA,name),temporary=file+'.tmp';fs.writeFileSync(temporary,JSON.stringify(value));fs.renameSync(temporary,file);}
function laterError(error){console.error(error?.name||'Browser operation failed');}
function safeURL(url){if(url==='about:blank'||url==='supersearch:start'||origin(url))return true;try{const parsed=new URL(url);return parsed.protocol==='chrome-extension:'&&!!normalSession?.extensions.getExtension(parsed.hostname);}catch{return false;}}
function background(){return config.theme==='light'?'#ffffff':'#000000';}
function activeTab(owner){return owner.tabs.find(tab=>tab.id===owner.active)||owner.tabs[0];}
function activePane(owner){const tab=activeTab(owner);return tab?.panes[tab.active]||null;}
function browserVisible(owner){return !owner.page&&!owner.modal&&!owner.uiModal&&!owner.closing&&config.onboarding_complete;}
function paneRecord(pane){return {url:pane.url,title:pane.title,icon:pane.icon,loading:pane.loading,error:pane.error,canBack:pane.view?.webContents.navigationHistory.canGoBack()||false,canForward:pane.view?.webContents.navigationHistory.canGoForward()||false};}
function tabRecord(tab){return {id:tab.id,pinned:tab.pinned,active_pane:tab.active,panes:tab.panes.map(pane=>pane.url)};}
function state(owner){return {config,private:owner.private,tabs:owner.tabs.map(tab=>({id:tab.id,pinned:tab.pinned,active:tab.active,panes:tab.panes.map(paneRecord)})),active:owner.active,
  bookmarks:bootstrap.bookmarks,history:owner.private?[]:bootstrap.history,shortcuts:bootstrap.shortcuts,stats:owner.private?owner.stats:bootstrap.stats,
  downloads:downloads.filter(record=>record.private?record.owner===owner.id:!owner.private).map(({item,...record})=>record),ip,
  page:owner.page,modal:owner.modal,passwordOffer:owner.offer?{origin:owner.offer.origin,username:owner.offer.username}:null,
  fullscreen:owner.window.isFullScreen(),maximized:owner.window.isMaximized(),battery:owner.battery,
  restart:RESTART.some(key=>config[key]!==startup[key]),vault:bootstrap.vault,
  versions:{SuperSearch:RELEASE.displayVersion,Electron:process.versions.electron,Chromium:process.versions.chrome,Node:process.versions.node},
  source:'https://github.com/mishandreevy/supersearch',route:{tor:startup.tor,proxy:startup.proxy,ephemeral:startup.ephemeral_profile},lastClick:owner.lastClick};}
function publish(owner){if(!owner.window.isDestroyed()&&!owner.ui.isDestroyed())owner.ui.send('ss:state',state(owner));}
function publishAll(){for(const owner of windows.values())publish(owner);}
function event(owner,type,data={}){if(!owner.ui.isDestroyed())owner.ui.send('ss:event',{type,...data});}
function persistPins(owner){return owner.private?Promise.resolve(true):backend.call('pins',owner.tabs.filter(tab=>tab.pinned).map(tabRecord)).catch(error=>{event(owner,'error',{message:error.message});return false;});}
function disposePane(pane){if(!pane.view)return;remote.delete(pane.view.webContents.id);if(!pane.view.webContents.isDestroyed())pane.view.webContents.close();pane.view=null;}
function cancelOffer(owner){if(owner.offer){owner.offer.password='';owner.offer=null;}if(owner.candidate)owner.candidate.password='';clearTimeout(owner.offerTimer);clearTimeout(owner.candidateTimer);clearTimeout(owner.candidateExpiry);owner.candidate=null;}

async function configureProxy(ses,settings){
  const proxy=settings.tor?'socks5://127.0.0.1:9050':settings.proxy.trim();
  await ses.setProxy(proxy?{mode:'fixed_servers',proxyRules:proxy,proxyBypassRules:'<-loopback>'}:{mode:'direct'});
}
function installPolicy(ses,isPrivate){
  ses.setPermissionRequestHandler((contents,permission,callback)=>callback(permission==='fullscreen'&&!!contents&&remote.has(contents.id)));
  ses.setPermissionCheckHandler((contents,permission)=>permission==='fullscreen'&&!!contents&&remote.has(contents.id));ses.setDevicePermissionHandler(()=>false);
  ses.setDisplayMediaRequestHandler((_request,callback)=>callback(null));
  ses.webRequest.onBeforeRequest({urls:['http://*/*','https://*/*']},(details,callback)=>{
    if(config.block_ads&&filters.blocked(details.url)){
      const host=new URL(details.url).hostname,entry=remote.get(details.webContentsId);
      if(entry?.owner.private){entry.owner.stats.total++;entry.owner.stats.today++;entry.owner.blockedDomains.add(host);entry.owner.stats.domains=entry.owner.blockedDomains.size;publish(entry.owner);}
      else if(!isPrivate)blocks[host]=(blocks[host]||0)+1;
      callback({cancel:true});return;
    }
    const next=cleaned(details.url,config);callback(next===details.url?{}:{redirectURL:next});
  });
  ses.webRequest.onBeforeSendHeaders((details,callback)=>{
    const headers={...details.requestHeaders};
    for(const key of Object.keys(headers)){
      if(config.block_referrers&&key.toLowerCase()==='referer')delete headers[key];
      if(config.third_party&&key.toLowerCase()==='cookie'&&details.resourceType!=='mainFrame'&&!sameParty(details.url,remote.get(details.webContentsId)?.pane.url||details.initiator||''))delete headers[key];
    }
    if(config.gpc){headers['Sec-GPC']='1';headers.DNT='1';}
    callback({requestHeaders:headers});
  });
  ses.webRequest.onHeadersReceived((details,callback)=>{
    const headers={...details.responseHeaders};
    if(config.third_party&&details.resourceType!=='mainFrame'&&!sameParty(details.url,remote.get(details.webContentsId)?.pane.url||details.initiator||''))for(const key of Object.keys(headers))if(key.toLowerCase()==='set-cookie')delete headers[key];
    callback({responseHeaders:headers});
  });
  ses.on('will-download',(downloadEvent,item,contents)=>{
    const entry=remote.get(contents?.id);if(!entry){downloadEvent.preventDefault();return;}
    try{receiveDownload(entry.owner,item);}catch{downloadEvent.preventDefault();event(entry.owner,'error',{message:'Could not save the file to the Downloads folder.'});}
  });
}
async function makeSession(isPrivate=false){
  const partition=!isPrivate&&!startup.ephemeral_profile?'persist:supersearch':'session-'+crypto.randomUUID();
  const ses=session.fromPartition(partition,{cache:false});await configureProxy(ses,startup);installPolicy(ses,isPrivate);return ses;
}
function privacyOptions(owner){return Object.fromEntries(['fingerprint','webrtc','geolocation','third_party','canvas'].map(key=>[key,config[key]]).concat([['private',owner.private],['javascript_disabled',startup.javascript]]));}

function layout(owner){
  if(owner.window.isDestroyed())return;
  const tab=activeTab(owner),area=owner.area;
  for(const entry of owner.tabs)for(const pane of entry.panes)if(pane.view){
    const visible=browserVisible(owner)&&entry===tab&&pane.url!=='supersearch:start'&&!pane.error&&area;
    pane.view.setVisible(!!visible);
    if(visible){
      const index=entry.panes.indexOf(pane),count=entry.panes.length;
      const left=count===2?Math.round(area.width*config.split_ratio/100):area.width,gap=Math.round(4*owner.ui.getZoomFactor());
      const popup=Math.min(owner.popupHeight||0,Math.max(0,area.height-80));
      pane.view.setBounds({x:area.x+(index?left+gap:0),y:area.y+popup,width:Math.max(1,count===1?area.width:index?area.width-left-gap:left-gap),height:Math.max(1,area.height-popup)});
      pane.view.setBackgroundColor(background());
    }
  }
}
function select(owner,id){
  const tab=owner.tabs.find(tab=>tab.id===id);if(!tab)return;
  cancelOffer(owner);owner.active=id;owner.page=null;owner.suggestionGeneration++;
  for(const pane of tab.panes)if(!pane.view&&pane.url!=='supersearch:start')attachPane(owner,tab,pane);
  layout(owner);publish(owner);maybeIP();
  if(browserVisible(owner)){const pane=tab.panes[tab.active];if(pane.view&&!pane.error)pane.view.webContents.focus();else owner.ui.focus();}
}
function newPane(url){return {url,title:url==='supersearch:start'?'SuperSearch':url,icon:'',loading:false,error:null,view:null};}
function newTab(owner,url=config.homepage,record=null){
  const tab={id:record?.id||crypto.randomUUID(),pinned:!!record?.pinned,active:record?.active_pane||0,panes:(record?.panes||[url]).map(value=>newPane(safeURL(value)?value:'supersearch:start'))};
  owner.tabs.push(tab);owner.tabs.sort((a,b)=>Number(b.pinned)-Number(a.pinned));select(owner,tab.id);persistPins(owner);return tab;
}
function removeTabs(owner,ids){
  const selected=new Set(ids);cancelOffer(owner);
  for(const tab of owner.tabs)if(selected.has(tab.id))for(const pane of tab.panes)disposePane(pane);
  const index=owner.tabs.findIndex(tab=>tab.id===owner.active);owner.tabs=owner.tabs.filter(tab=>!selected.has(tab.id));
  if(!owner.tabs.length)newTab(owner);else select(owner,owner.tabs[Math.min(index,owner.tabs.length-1)].id);
  persistPins(owner);
}
function navigate(owner,text,pane=activePane(owner)){
  const url=target(text,config.search);if(!url||!pane){if(text?.trim())event(owner,'error',{message:'Use an HTTP or HTTPS address without embedded credentials.'});return;}
  cancelOffer(owner);owner.suggestionGeneration++;pane.url=url;pane.error=null;pane.title=url==='supersearch:start'?'SuperSearch':url;
  if(url==='supersearch:start'){disposePane(pane);pane.loading=false;layout(owner);publish(owner);maybeIP();}
  else if(pane.view)pane.view.webContents.loadURL(cleaned(url,config)).catch(()=>{});
  else attachPane(owner,activeTab(owner),pane);
  layout(owner);if(pane.view&&!pane.error)pane.view.webContents.focus();
  persistPins(owner);
}
function attachPane(owner,tab,pane){
  const encoded=Buffer.from(JSON.stringify(privacyOptions(owner))).toString('base64');
  const view=new WebContentsView({webPreferences:{session:owner.session,preload:path.join(__dirname,'content-preload.js'),additionalArguments:['--ss-options='+encoded],
    nodeIntegration:false,nodeIntegrationInSubFrames:false,nodeIntegrationInWorker:false,contextIsolation:true,sandbox:true,webSecurity:true,
    allowRunningInsecureContent:false,webviewTag:false,devTools:TEST,javascript:!startup.javascript,webgl:config.webgl,plugins:false,spellcheck:false,
    backgroundThrottling:true,navigateOnDragDrop:false,safeDialogs:true,autoplayPolicy:'user-gesture-required'}});
  pane.view=view;view.setBackgroundColor(background());owner.window.contentView.addChildView(view);view.setVisible(false);
  const contents=view.webContents;remote.set(contents.id,{owner,tab,pane});contents.setZoomFactor(config.page_zoom/100);
  contents.on('preload-error',(_event,_file,error)=>{pane.securityError=error.message;pane.error={code:0,description:'The privacy preload could not start. Restart SuperSearch.',url:pane.url};contents.stop();layout(owner);publish(owner);if(TEST)console.error('PRELOAD ERROR: '+error.message);});
  contents.setWindowOpenHandler(({url})=>{if(origin(url)&&config.allow_popups)newTab(owner,url);return {action:'deny'};});
  contents.on('will-navigate',(event,url)=>{if(!safeURL(url)||url==='supersearch:start')event.preventDefault();});
  contents.on('will-redirect',(event,url)=>{if(!safeURL(url)||url==='supersearch:start')event.preventDefault();});
  contents.on('did-start-navigation',(_event,url,_same,inMain)=>{if(inMain){pane.loading=true;pane.error=null;pane.securityError=null;pane.url=url;owner.suggestionGeneration++;publish(owner);}});
  contents.on('did-navigate',(_event,url)=>{pane.url=url;if(!pane.securityError)pane.error=null;persistPins(owner);settleCredential(owner);publish(owner);});
  contents.on('did-navigate-in-page',(_event,url,isMain)=>{if(isMain){pane.url=url;persistPins(owner);publish(owner);}});
  contents.on('did-start-loading',()=>{pane.loading=true;publish(owner);});
  contents.on('did-stop-loading',()=>{pane.loading=false;publish(owner);});
  contents.on('page-title-updated',(_event,title)=>{pane.title=title;publish(owner);});
  contents.on('page-favicon-updated',(_event,urls)=>{updateFavicon(owner,pane,urls[0]).catch(()=>{});});
  contents.on('did-fail-load',(_event,code,description,url,isMain)=>{if(!isMain||code===-3||contents.isDestroyed()||url!==pane.url)return;pane.loading=false;pane.error={code,description,url};layout(owner);publish(owner);});
  contents.on('render-process-gone',()=>{pane.loading=false;pane.error={code:0,description:'The page process stopped. Reload to continue.',url:pane.url};layout(owner);publish(owner);});
  contents.on('did-finish-load',()=>{
    pane.loading=false;layout(owner);publish(owner);settleCredential(owner);
    if(!owner.private&&config.remember_history&&origin(pane.url))backend.call('visit',{url:pane.url,title:pane.title}).then(()=>{bootstrap.history=[{url:pane.url,title:pane.title},...bootstrap.history.filter(e=>e.url!==pane.url)].slice(0,3000);}).catch(laterError);
    installUserscripts(owner,pane).catch(()=>{});
  });
  contents.on('focus',()=>{if(activeTab(owner)===tab){tab.active=tab.panes.indexOf(pane);owner.suggestionGeneration++;publish(owner);}});
  contents.on('before-input-event',(event,input)=>shortcut(owner,event,input));
  contents.on('enter-html-full-screen',()=>owner.window.setFullScreen(true));
  contents.on('leave-html-full-screen',()=>owner.window.setFullScreen(false));
  contents.on('context-menu',(_event,params)=>{
    const template=[{label:'Back',enabled:contents.navigationHistory.canGoBack(),click:()=>contents.navigationHistory.goBack()},
      {label:'Reload',click:()=>contents.reload()},{type:'separator'},
      {label:'Copy',enabled:!!params.selectionText,click:()=>contents.copy()}];
    if(origin(params.linkURL)){template.push({label:'Open link in new tab',click:()=>newTab(owner,params.linkURL)},{label:'Copy link address',click:()=>clipboard.writeText(params.linkURL)});}
    Menu.buildFromTemplate(template).popup({window:owner.window});
  });
  contents.loadURL(cleaned(pane.url,config)).catch(()=>{});layout(owner);
}
async function installUserscripts(owner,pane){
  if(owner.private&&!config.userscripts_private||!pane.view||!origin(pane.url))return;
  const directory=path.join(DATA,'userscripts');if(!fs.existsSync(directory))return;
  const sourceURL=pane.url;
  for(const name of fs.readdirSync(directory).sort()){
    const file=path.join(directory,name);if(!fs.statSync(file).isFile()||!['.js','.css'].includes(path.extname(name).toLowerCase()))continue;
    const text=fs.readFileSync(file,'utf8');
    if(!pane.view||pane.url!==sourceURL)return;
    if(name.toLowerCase().endsWith('.css'))await pane.view.webContents.insertCSS(text);
    else await pane.view.webContents.executeJavaScript(text);
  }
}
async function bytes(response,maximum=1000000){
  if(!response.ok)throw Error('The server returned an error.');
  const reader=response.body.getReader(),parts=[];let size=0;
  while(true){const {value,done}=await reader.read();if(done)break;size+=value.byteLength;if(size>maximum){await reader.cancel();throw Error('Response too large');}parts.push(Buffer.from(value));}
  return Buffer.concat(parts);
}
async function updateFavicon(owner,pane,url){
  if(!origin(url)||!pane.view)return;
  const current=pane.url,controller=new AbortController(),timer=setTimeout(()=>controller.abort(),8000);
  try{
    const response=await owner.session.fetch(url,{credentials:'omit',signal:controller.signal});
    const image=nativeImage.createFromBuffer(await bytes(response));if(image.isEmpty()||pane.url!==current)return;
    const png=image.resize({width:64,height:64}).toPNG();pane.icon='data:image/png;base64,'+png.toString('base64');
    if(!owner.private){const directory=path.join(DATA,'favicons');fs.mkdirSync(directory,{recursive:true});fs.writeFileSync(path.join(directory,crypto.createHash('sha256').update(origin(current)).digest('hex')+'.png'),png);}
    if(!owner.private){const local=await backend.call('state');bootstrap.shortcuts=local.shortcuts;}
    publish(owner);
  }finally{clearTimeout(timer);}
}

async function createWindow(isPrivate=false){
  const ses=isPrivate?await makeSession(true):normalSession;
  const uiSession=session.fromPartition('ui-'+crypto.randomUUID(),{cache:false});
  uiSession.setPermissionRequestHandler((_contents,_permission,callback)=>callback(false));uiSession.setPermissionCheckHandler(()=>false);
  uiSession.protocol.handle('ss-app',async request=>{
    const url=new URL(request.url),name=decodeURIComponent(url.pathname);
    let file;
    if(url.hostname==='browser'&&['/index.html','/ui.js','/ui.css'].includes(name))file=path.join(__dirname,name);
    else if(url.hostname==='assets'&&/^\/(logo\.svg|site-icons\/[a-z]+\.svg)$/.test(name))file=path.join(ROOT,'assets',name);
    else return new Response('Not found',{status:404});
    let content=fs.readFileSync(file);
    if(name==='/index.html'){const palette={...bootstrap.palettes[config.theme],...config.colors};const declarations=Object.entries(palette).filter(([_key,value])=>/^#[0-9a-fA-F]{6}$/.test(value)).map(([key,value])=>'--'+key+':'+value).join(';');content=Buffer.from(content.toString().replace('<html lang="en">',`<html lang="${config.language}" style="${declarations};color-scheme:${config.theme==='light'?'light':'dark'}">`));}
    if(name==='/logo.svg'){const text=content.toString();content=Buffer.from(text.slice(text.indexOf('<svg')));}
    return new Response(content,{headers:{'content-type':name.endsWith('.html')?'text/html; charset=utf-8':name.endsWith('.js')?'text/javascript':name.endsWith('.css')?'text/css':'image/svg+xml','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' ss-app: data:; connect-src 'none'; object-src 'none'; frame-src 'none'; base-uri 'none'; form-action 'none'",'X-Content-Type-Options':'nosniff'}});
  });
  const win=new BrowserWindow({width:1250,height:850,minWidth:720,minHeight:540,frame:false,show:false,backgroundColor:background(),
    webPreferences:{session:uiSession,preload:path.join(__dirname,'preload.js'),contextIsolation:true,sandbox:true,nodeIntegration:false,webSecurity:true,webviewTag:false,devTools:TEST,spellcheck:false}});
  const owner={id:win.id,window:win,ui:win.webContents,session:ses,private:isPrivate,tabs:[],active:null,page:null,modal:null,offer:null,candidate:null,suggestionGeneration:0,
    stats:{total:0,today:0,domains:0,top:[],daily:[]},blockedDomains:new Set(),battery:null,closing:false,lastClick:{x:500,y:200},area:null};
  windows.set(win.id,owner);win.setMenu(null);
  if(TEST)owner.ui.on('console-message',(_event,...args)=>{const message=typeof _event.message==='string'?_event.message:args[1];if(typeof message==='string'&&/Uncaught/.test(message))console.error('UI SCRIPT ERROR: '+message);});
  owner.ui.setWindowOpenHandler(()=>({action:'deny'}));owner.ui.on('will-navigate',event=>event.preventDefault());owner.ui.on('before-input-event',(event,input)=>shortcut(owner,event,input));
  owner.ui.once('did-finish-load',()=>{
    owner.ui.setZoomFactor(config.ui_scale/100);
    owner.ui.send('ss:event',{type:'bootstrap',data:bootstrap});
    if(config.onboarding_complete&&!isPrivate&&bootstrap.session?.tabs?.length){
      for(const record of bootstrap.session.tabs){const tab={id:record.id,pinned:record.pinned,active:record.active_pane,panes:record.panes.map(newPane)};owner.tabs.push(tab);}
      select(owner,owner.tabs[Math.min(bootstrap.session.active_tab,owner.tabs.length-1)].id);
    }else newTab(owner,config.onboarding_complete?config.homepage:'supersearch:start');
    publish(owner);if(owner.uiReady)win.show();
  });
  win.on('resize',()=>{layout(owner);publish(owner);});
  win.on('enter-full-screen',()=>{systemStatus(owner);publish(owner);});
  win.on('leave-full-screen',()=>{clearInterval(owner.systemTimer);owner.systemTimer=null;owner.battery=null;publish(owner);});
  win.on('maximize',()=>publish(owner));win.on('unmaximize',()=>publish(owner));win.on('restore',()=>maybeIP());
  win.on('close',event=>{
    if(owner.closing||quitting)return;
    event.preventDefault();
    if(config.confirm_close){owner.modal={type:'close',save:config.restore_tabs};layout(owner);publish(owner);}
    else closeWindow(owner,config.restore_tabs).catch(laterError);
  });
  win.on('closed',()=>{cancelOffer(owner);clearInterval(owner.systemTimer);for(const tab of owner.tabs)for(const pane of tab.panes)disposePane(pane);windows.delete(win.id);if(!windows.size)app.quit();});
  await owner.ui.loadURL(UI_URL);return owner;
}
async function closeWindow(owner,save){
  if(!owner.private){config=await backend.call('settings',{restore_tabs:!!save});await backend.call('pins',owner.tabs.filter(tab=>tab.pinned).map(tabRecord));await backend.call('session',save?{tabs:owner.tabs.map(tabRecord),active_tab:owner.tabs.findIndex(tab=>tab.id===owner.active)}:{tabs:[]});}
  owner.closing=true;owner.window.close();
}
async function systemStatus(owner){
  clearInterval(owner.systemTimer);owner.systemTimer=null;
  if(!owner.window.isFullScreen()||!config.titlebar_system_status){owner.battery=null;return;}
  const read=async()=>{const battery=await backend.call('system_status');if(!owner.window.isDestroyed()&&owner.window.isFullScreen()){owner.battery=battery;publish(owner);}};
  await read();owner.systemTimer=setInterval(()=>read().catch(()=>{}),30000);
}
function expand(owner){if(config.window_expand_mode==='fullscreen')owner.window.setFullScreen(!owner.window.isFullScreen());else if(owner.window.isFullScreen())owner.window.setFullScreen(false);else owner.window.isMaximized()?owner.window.unmaximize():owner.window.maximize();}
function shortcut(owner,keyEvent,input){
  if(input.type!=='keyDown')return;
  const ctrl=input.control||input.meta,key=input.key.toLowerCase();let command=null;
  if(!config.onboarding_complete){if(key==='f11'){keyEvent.preventDefault();owner.window.setFullScreen(!owner.window.isFullScreen());}if(ctrl&&input.shift&&key==='w')owner.window.close();return;}
  if(ctrl&&!input.shift){command={t:'new_tab',w:'close_active',l:'focus_address',d:'bookmark',h:'history',',':'settings',j:'downloads','\\':'split',tab:'next',pagedown:'next',pageup:'previous',f4:'close_active','+':'zoom_in','=':'zoom_in','-':'zoom_out','0':'zoom_reset',f:'find'}[key];}
  if(ctrl&&input.shift){command={n:'private',tab:'previous',k:'pin_active',p:'passwords',b:'bookmark_bar',w:'close_window',u:'customize'}[key];}
  if(ctrl&&/^[1-9]$/.test(key)){const index=key==='9'?owner.tabs.length-1:Math.min(Number(key)-1,owner.tabs.length-1);select(owner,owner.tabs[index]?.id);keyEvent.preventDefault();return;}
  if(key==='f11')command='fullscreen';if(key==='f5')command='reload';if(key==='f1')command='keyboard_help';if(input.alt&&key==='arrowleft')command='back';if(input.alt&&key==='arrowright')command='forward';
  if(command){keyEvent.preventDefault();if(['focus_address','bookmark','find','pin_active','customize','keyboard_help'].includes(command)){owner.ui.focus();eventToUI(owner,command==='pin_active'?'pin_selection':command==='find'&&owner.page==='settings'?'settings_find':command);}else action(owner,command,{}).catch(error=>event(owner,'error',{message:error.message}));}
}
function eventToUI(owner,type){event(owner,type);}

async function maybeIP(force=false){
  const visible=[...windows.values()].find(owner=>browserVisible(owner)&&activeTab(owner)?.panes.some(pane=>pane.url==='supersearch:start')&&owner.window.isVisible()&&!owner.window.isMinimized());
  if(!config.home_ip||!config.home_stats||!config.onboarding_complete||!visible||ip.state==='loading'||Date.now()-ipLastAttempt<5000||(!force&&Date.now()<ip.expires))return;
  ipLastAttempt=Date.now();
  const generation=++ip.generation;ipController=new AbortController();const timer=setTimeout(()=>ipController?.abort(),15000);
  ip={address:'',state:'loading',expires:Date.now()+600000,generation};publishAll();
  try{
    const response=await visible.session.fetch('https://api64.ipify.org?format=json',{credentials:'omit',redirect:'error',signal:ipController.signal});
    const data=JSON.parse((await bytes(response,1024)).toString());
    if(!require('node:net').isIP(data.ip)||data.ip.includes('%'))throw Error('Invalid IP response');
    if(ip.generation===generation){ip.address=data.ip;ip.state='ready';}
  }catch{if(ip.generation===generation){ip.address='';ip.state='error';}}
  finally{clearTimeout(timer);if(ip.generation===generation)ipController=null;publishAll();}
}
async function suggest(owner,data){
  const query=String(data.query||''),generation=++owner.suggestionGeneration;
  if(owner.private||!config.suggestions||!query.trim()||query.length>160||query.includes('://')||query.includes('@'))return [];
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),5000);
  try{const response=await owner.session.fetch('https://duckduckgo.com/ac/?q='+encodeURIComponent(query)+'&type=list',{credentials:'omit',signal:controller.signal});
    const raw=JSON.parse((await bytes(response,64000)).toString());
    if(generation!==owner.suggestionGeneration||owner.private||!config.suggestions)return [];
    const values=Array.isArray(raw?.[1])?raw[1]:Array.isArray(raw)?raw.map(item=>item.phrase):[];
    return values.filter(value=>typeof value==='string').slice(0,10);
  }finally{clearTimeout(timer);}
}

function safeFilename(name){let value=path.basename(String(name).replaceAll('\\','/')).replace(/[<>:"/\\|?*\x00-\x1f\u202a-\u202e\u2066-\u2069]/g,'_').replace(/[. ]+$/,'').slice(0,180)||'download';if(/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(value))value='_'+value;return value;}
function receiveDownload(owner,item){
  const directory=app.getPath('downloads');fs.mkdirSync(directory,{recursive:true});
  const filename=safeFilename(item.getFilename()),extension=path.extname(filename),stem=path.basename(filename,extension);let destination=path.join(directory,filename),index=0;
  while(fs.existsSync(destination)||reserved.has(destination))destination=path.join(directory,`${stem} (${++index})${extension}`);
  reserved.add(destination);item.setSavePath(destination);
  const record={id:crypto.randomUUID(),owner:owner.id,private:owner.private,name:path.basename(destination),path:destination,url:item.getURL(),received:0,total:item.getTotalBytes(),state:'progressing',paused:false,item};downloads.unshift(record);
  event(owner,'download-start',{click:owner.lastClick});
  const update=()=>{record.received=item.getReceivedBytes();record.total=item.getTotalBytes();record.paused=item.isPaused();publishAll();};
  item.on('updated',(_event,state)=>{record.state=state;update();});
  item.once('done',async(_event,state)=>{record.state=state;update();reserved.delete(destination);if(!owner.private&&!quitting)try{await backend.call('downloads',downloads.filter(e=>!e.private).map(({item,url,...entry})=>entry));if(state==='completed')await backend.call('download_owned',{path:destination});}catch(error){laterError(error);}});
  publishAll();
}
function credential(event,data){
  const entry=remote.get(event.sender.id);if(!entry||entry.owner.private||event.senderFrame!==event.sender.mainFrame||typeof data?.origin!=='string'||!data.origin.startsWith('https://')||origin(event.senderFrame.url)!==data.origin||typeof data.password!=='string'||!data.password||data.password.length>4096||typeof data.username!=='string'||data.username.length>1000)return;
  const owner=entry.owner;if(activePane(owner)!==entry.pane)return;
  cancelOffer(owner);owner.candidate={...data,pane:entry.pane,expires:Date.now()+30000};
  owner.candidateExpiry=setTimeout(()=>{if(owner.candidate)cancelOffer(owner);},30000);
  owner.candidateTimer=setTimeout(()=>settleCredential(owner),850);
}
async function settleCredential(owner){
  const candidate=owner.candidate;if(!candidate||candidate.expires<Date.now()||activePane(owner)!==candidate.pane){if(candidate)cancelOffer(owner);return;}
  const contents=candidate.pane.view?.webContents;if(!contents||contents.isDestroyed())return;
  if(candidate.pane.loading){clearTimeout(owner.candidateTimer);owner.candidateTimer=setTimeout(()=>settleCredential(owner),500);return;}
  let formRemains=false;
  if(origin(contents.getURL())===candidate.origin)try{formRemains=await contents.executeJavaScriptInIsolatedWorld(1001,[{code:"!!document.querySelector('form input[type=password]')"}]);}catch{return;}
  if(owner.candidate!==candidate)return;
  if(formRemains){clearTimeout(owner.candidateTimer);owner.candidateTimer=setTimeout(()=>settleCredential(owner),500);return;}
  owner.candidate=null;clearTimeout(owner.candidateExpiry);owner.offer=candidate;delete owner.offer.pane;
  if(bootstrap.vault.unlocked)try{const entry=await backend.call('vault_get',candidate);if(entry?.password===candidate.password){cancelOffer(owner);return;}}catch{}
  owner.offerTimer=setTimeout(()=>{cancelOffer(owner);layout(owner);publish(owner);},90000);layout(owner);publish(owner);
}

async function chooseFile(owner,kind){
  const options={properties:[kind==='profile'?'openDirectory':'openFile']};
  if(kind==='wallpaper')options.filters=[{name:'Images',extensions:['png','jpg','jpeg','webp']}];
  if(kind==='script')options.filters=[{name:'UserScripts',extensions:['js','css']}];
  if(kind==='csv')options.filters=[{name:'Passwords CSV',extensions:['csv']}];
  const result=await dialog.showOpenDialog(owner.window,options);return result.canceled?null:result.filePaths[0];
}
async function restart(token=null,restoreToken=null){
  const args=[path.join(ROOT,'main.py'),'--wait-for-pid',String(process.pid)];if(token)args.push('--maintenance-token',token);if(restoreToken)args.push('--restore-token',restoreToken);
  const env={...process.env,SUPERSEARCH_ENGINE_DATA:DATA};delete env.SUPERSEARCH_DATA;
  const child=spawn(process.env.SUPERSEARCH_PYTHON||'python3',args,{cwd:ROOT,env,stdio:'ignore',detached:true});
  child.on('error',()=>publishAll());child.unref();quitting=true;for(const owner of windows.values())owner.closing=true;app.quit();
}
async function action(owner,operation,data){
  const pane=activePane(owner),tab=activeTab(owner),contents=pane?.view?.webContents;
  switch(operation){
    case 'bootstrap':return {bootstrap,state:state(owner)};
    case 'ui_ready':owner.uiReady=true;if(owner.tabs.length)owner.window.show();return true;
    case 'bounds':{
      if(!data||!['x','y','width','height'].every(key=>Number.isFinite(data[key])))return false;
      const bounds=owner.window.getContentBounds(),scale=owner.ui.getZoomFactor(),x=Math.max(0,Math.min(bounds.width-1,Math.round(data.x*scale))),y=Math.max(0,Math.min(bounds.height-1,Math.round(data.y*scale)));
      owner.area={x,y,width:Math.max(1,Math.min(bounds.width-x,Math.round(data.width*scale))),height:Math.max(1,Math.min(bounds.height-y,Math.round(data.height*scale)))};layout(owner);return true;}
    case 'overlay':owner.popupHeight=Math.max(0,Math.min(400,Number(data.height)||0))*owner.ui.getZoomFactor();layout(owner);return true;
    case 'ui_modal':owner.uiModal=!!data.open;layout(owner);return true;
    case 'navigate':owner.page=null;navigate(owner,data.text);break;
    case 'new_tab':newTab(owner,data.url||config.homepage);owner.ui.focus();eventToUI(owner,'focus_address');break;
    case 'select':select(owner,data.id);break;
    case 'close_tabs':removeTabs(owner,Array.isArray(data.ids)?data.ids:[]);break;
    case 'close_active':removeTabs(owner,[owner.active]);break;
    case 'next':case 'previous':{const index=owner.tabs.findIndex(tab=>tab.id===owner.active),delta=operation==='next'?1:-1;select(owner,owner.tabs[(index+delta+owner.tabs.length)%owner.tabs.length].id);break;}
    case 'pin_active':case 'pin':{const ids=new Set(data.ids||[owner.active]);const selected=owner.tabs.filter(tab=>ids.has(tab.id)),pinned=!selected.every(tab=>tab.pinned);for(const entry of selected)entry.pinned=pinned;owner.tabs.sort((a,b)=>Number(b.pinned)-Number(a.pinned));await persistPins(owner);break;}
    case 'split':cancelOffer(owner);if(tab.panes.length===1){const second=newPane(config.homepage);tab.panes.push(second);tab.active=1;if(second.url!=='supersearch:start')attachPane(owner,tab,second);}else{disposePane(tab.panes.pop());tab.active=0;}persistPins(owner);break;
    case 'pane':if(data.index>=0&&data.index<tab.panes.length){tab.active=data.index;owner.suggestionGeneration++;}break;
    case 'home':navigate(owner,'supersearch:start');break;
    case 'back':if(contents?.navigationHistory.canGoBack())contents.navigationHistory.goBack();break;
    case 'forward':if(contents?.navigationHistory.canGoForward())contents.navigationHistory.goForward();break;
    case 'reload':case 'retry':if(pane?.url==='supersearch:start')maybeIP(true);else if(contents){pane.error=null;contents.reload();}break;
    case 'zoom_in':case 'zoom_out':case 'zoom_reset':if(contents)contents.setZoomFactor(operation==='zoom_reset'?1:Math.max(.25,Math.min(2.5,contents.getZoomFactor()+(operation==='zoom_in'?.1:-.1))));break;
    case 'find':if(contents)contents.findInPage(String(data.text||''));break;
    case 'stop_find':contents?.stopFindInPage('clearSelection');break;
    case 'private':await createWindow(true);break;
    case 'settings':case 'downloads':case 'history':case 'bookmarks':case 'passwords':cancelOffer(owner);owner.page=operation;owner.suggestionGeneration++;break;
    case 'web':owner.page=null;break;
    case 'minimize':owner.window.minimize();break;
    case 'expand':expand(owner);break;
    case 'fullscreen':owner.window.setFullScreen(!owner.window.isFullScreen());break;
    case 'close_window':owner.window.close();break;
    case 'close_cancel':owner.modal=null;break;
    case 'close_confirm':await closeWindow(owner,!!data.save);return true;
    case 'bookmark_bar':config=await backend.call('settings',{bookmark_bar:!config.bookmark_bar});break;
    case 'settings_apply':{
      const old=config;config=await backend.call('settings',data);bootstrap.config=config;
      if(!config.home_ip||!config.home_stats){ipController?.abort();ip={address:'',state:'idle',expires:0,generation:ip.generation+1};}
      for(const current of windows.values()){
        current.ui.setZoomFactor(config.ui_scale/100);
        current.suggestionGeneration++;current.window.setBackgroundColor(background());
        for(const entry of current.tabs)for(const view of entry.panes)if(view.view){view.view.webContents.setZoomFactor(config.page_zoom/100);view.view.setBackgroundColor(background());if(old.webgl!==config.webgl||old.fingerprint!==config.fingerprint||old.webrtc!==config.webrtc||old.geolocation!==config.geolocation||old.third_party!==config.third_party)replacePane(current,entry,view);}
        systemStatus(current).catch(()=>{});layout(current);
      }
      publishAll();maybeIP();return {config,restart:RESTART.some(key=>config[key]!==startup[key])};}
    case 'suggest':return suggest(owner,data);
    case 'ip_refresh':await maybeIP(true);return ip;
    case 'source':newTab(owner,'https://github.com/mishandreevy/supersearch');owner.page=null;break;
    case 'bookmarks_save':bootstrap.bookmarks=await backend.call('bookmarks_save',data);publishAll();return bootstrap.bookmarks;
    case 'bookmarks_remove':bootstrap.bookmarks=await backend.call('bookmarks_remove',data);publishAll();return bootstrap.bookmarks;
    case 'shortcuts':bootstrap.shortcuts=await backend.call('shortcuts',data);publishAll();return bootstrap.shortcuts;
    case 'backup_export':{
      if(owner.private)throw Error('Backups are unavailable in private windows.');
      if(backupBusy)throw Error('Another backup operation is in progress.');backupBusy=true;
      try{
        const destination=await dialog.showSaveDialog(owner.window,{title:'Export SuperSearch data',defaultPath:path.join(app.getPath('documents'),'SuperSearch-'+new Date().toISOString().slice(0,10)+'.supersearch'),filters:[{name:'SuperSearch encrypted backup',extensions:['supersearch']}]});
        if(destination.canceled||!destination.filePath)return null;
        await persistPins(owner);await backend.call('session',{tabs:owner.tabs.map(tabRecord),active_tab:owner.tabs.findIndex(tab=>tab.id===owner.active)});
        const pending={...blocks};if(Object.keys(pending).length){for(const key of Object.keys(pending))delete blocks[key];bootstrap.stats=await backend.call('blocks',pending);}
        return await backend.call('backup_export',{path:destination.filePath,password:data.password});
      }finally{backupBusy=false;}}
    case 'backup_choose':{
      if(owner.private)throw Error('Backups are unavailable in private windows.');
      const selected=await dialog.showOpenDialog(owner.window,{title:'Restore SuperSearch data',properties:['openFile'],filters:[{name:'SuperSearch encrypted backup',extensions:['supersearch']}]});
      if(selected.canceled)return null;
      owner.backupChoice={path:selected.filePaths[0],token:crypto.randomUUID(),expires:Date.now()+300000};
      return {token:owner.backupChoice.token,name:path.basename(owner.backupChoice.path)};}
    case 'backup_restore':{
      if(owner.private)throw Error('Backups are unavailable in private windows.');
      if(data.confirmation!=='Replace')throw Error('Confirm replacement of current browser data.');
      if(!config.onboarding_complete&&data.accepted_terms!=='2026-11-02')throw Error('Accept the User Agreement before restoring data.');
      const selected=owner.backupChoice;
      if(!selected||selected.token!==data.token||selected.expires<Date.now())throw Error('Choose the backup file again.');
      if(backupBusy)throw Error('Another backup operation is in progress.');backupBusy=true;
      try{
        const token=await backend.call('backup_restore',{path:selected.path,password:data.password,include_scripts:data.include_scripts===true});
        owner.backupChoice=null;for(const current of windows.values())cancelOffer(current);
        if(TEST){owner.testRestoreToken=token;return {prepared:true};}
        await restart(null,token);return {prepared:true};
      }finally{if(!quitting)backupBusy=false;}}
    case 'profiles':return backend.call('profiles');
    case 'choose_profile':return chooseFile(owner,'profile');
    case 'choose_csv':return chooseFile(owner,'csv');
    case 'import':{
      if(owner.private&&data.csv)throw Error('Private windows do not access the password vault.');
      const result=await backend.call('import',data);
      for(const cookie of result.cookies){const value={url:(cookie.secure?'https://':'http://')+cookie.domain.replace(/^\./,'')+cookie.path,name:cookie.name,value:cookie.value,domain:cookie.domain,path:cookie.path,secure:cookie.secure,httpOnly:cookie.http_only};if(cookie.expires)value.expirationDate=cookie.expires;await owner.session.cookies.set(value);}
      const state=await backend.call('state');Object.assign(bootstrap,state);config=state.config;publishAll();return {counts:result.counts,notices:result.notices};}
    case 'legal':return backend.call('legal',data);
    case 'wallpaper':{
      const file=await chooseFile(owner,'wallpaper');if(!file)return null;if(fs.statSync(file).size>30*1024*1024)throw Error('Choose an image smaller than 30 MB.');
      await backend.call('wallpaper_validate',{path:file});
      const image=nativeImage.createFromPath(file);if(image.isEmpty())throw Error('Could not read the image.');
      const size=image.getSize(),resized=Math.max(size.width,size.height)>2560?image.resize(size.width>=size.height?{width:2560}:{height:2560}):image;
      fs.mkdirSync(path.join(DATA,'wallpapers'),{recursive:true});fs.writeFileSync(path.join(DATA,'wallpapers/home.png'),resized.toPNG());config=await backend.call('settings',{wallpaper:'home.png'});publishAll();return 'data:image/png;base64,'+resized.toPNG().toString('base64');}
    case 'wallpaper_data':{const file=path.join(DATA,'wallpapers/home.png');return config.wallpaper&&fs.existsSync(file)?'data:image/png;base64,'+fs.readFileSync(file).toString('base64'):'';}
    case 'wallpaper_reset':config=await backend.call('settings',{wallpaper:''});publishAll();return true;
    case 'scripts':{const directory=path.join(DATA,'userscripts');fs.mkdirSync(directory,{recursive:true});return fs.readdirSync(directory).filter(name=>/\.(js|css)$/i.test(name));}
    case 'script_install':{
      const file=await chooseFile(owner,'script');if(!file)return null;if(!/\.(js|css)$/i.test(file)||fs.statSync(file).size>2000000)throw Error('Choose a .js or .css file smaller than 2 MB.');
      const directory=path.join(DATA,'userscripts');fs.mkdirSync(directory,{recursive:true});const destination=path.join(directory,path.basename(file));
      if(fs.existsSync(destination)&&!data.replace)throw Error('A script with this name already exists. Remove it first.');fs.copyFileSync(file,destination);return path.basename(file);}
    case 'script_remove':{if(path.basename(data.name)!==data.name||! /\.(js|css)$/i.test(data.name))throw Error('Invalid script name');fs.unlinkSync(path.join(DATA,'userscripts',data.name));return true;}
    case 'extensions_list':return startup.ephemeral_profile||owner.private?[]:normalSession.extensions.getAllExtensions().map(extension=>({id:extension.id,name:extension.name,popup:extension.manifest.action?.default_popup||extension.manifest.browser_action?.default_popup||''}));
    case 'extension_choose':{
      if(owner.private||startup.ephemeral_profile)throw Error('Extensions require a persistent profile and a restart.');
      const result=await dialog.showOpenDialog(owner.window,{properties:[data.kind==='folder'?'openDirectory':'openFile'],filters:data.kind==='folder'?undefined:[{name:'Extensions',extensions:['zip']}]});
      if(result.canceled)return null;const file=result.filePaths[0],manifest=await backend.call('extension_info',{path:file}),token=crypto.randomUUID();extensionChoices.set(token,{owner:owner.id,path:file,expires:Date.now()+120000});
      return {token,name:manifest.name,permissions:[...(manifest.permissions||[]),...(manifest.host_permissions||[])]};}
    case 'extension_install':{
      const choice=extensionChoices.get(data.token);extensionChoices.delete(data.token);if(!choice||choice.owner!==owner.id||choice.expires<Date.now()||owner.private||startup.ephemeral_profile)throw Error('Choose the extension again.');
      const directory=await backend.call('extension_prepare',{path:choice.path});
      const extension=await normalSession.extensions.loadExtension(directory,{allowFileAccess:false});let saved=[];try{saved=JSON.parse(fs.readFileSync(path.join(DATA,'extensions.json')));}catch{}
      saved.push({id:extension.id,directory});writeJSON('extensions.json',saved);return {id:extension.id,name:extension.name};}
    case 'extension_remove':{
      if(owner.private||startup.ephemeral_profile)throw Error('Extensions are unavailable in this window.');normalSession.extensions.removeExtension(data.id);let saved=[];try{saved=JSON.parse(fs.readFileSync(path.join(DATA,'extensions.json')));}catch{}
      const removed=saved.find(entry=>entry.id===data.id);writeJSON('extensions.json',saved.filter(entry=>entry.id!==data.id));if(removed&&path.dirname(removed.directory)===path.join(DATA,'extensions'))fs.rmSync(removed.directory,{recursive:true,force:true});return true;}
    case 'extension_open':{
      if(owner.private)throw Error('Extensions are unavailable in private windows.');const extension=normalSession.extensions.getExtension(data.id),popup=extension?.manifest.action?.default_popup||extension?.manifest.browser_action?.default_popup;
      if(!popup)throw Error('This extension has no popup.');newTab(owner,'chrome-extension://'+extension.id+'/'+popup);owner.page=null;break;}
    case 'filters_update':{
      for(const [name,url] of [['easylist','https://easylist.to/easylist/easylist.txt'],['easyprivacy','https://easylist.to/easylist/easyprivacy.txt']]){
        const response=await owner.session.fetch(url,{credentials:'omit',signal:AbortSignal.timeout(30000)}),text=(await bytes(response,20000000)).toString();if(!text.startsWith('[Adblock')||text.length<1000)throw Error('Invalid filter list');
        fs.mkdirSync(path.join(DATA,'filters'),{recursive:true});fs.writeFileSync(path.join(DATA,'filters',name+'.txt.tmp'),text);fs.renameSync(path.join(DATA,'filters',name+'.txt.tmp'),path.join(DATA,'filters',name+'.txt'));
      }
      filters.reload();return {rules:filters.blocks.length,skipped:filters.skipped};}
    case 'proxy_test':{
      const draft={...config,...data};if(draft.proxy){const u=new URL(draft.proxy);if(!['http:','socks4:','socks5:'].includes(u.protocol)||!u.hostname||!u.port||u.username||u.password)throw Error('Invalid proxy address');}
      if(!draft.tor&&!draft.proxy.trim())throw Error('Configure a proxy or enable Tor first.');
      const ses=session.fromPartition('proxy-test-'+crypto.randomUUID(),{cache:false});await configureProxy(ses,draft);
      try{const response=await ses.fetch('https://api64.ipify.org?format=json',{credentials:'omit',redirect:'error',signal:AbortSignal.timeout(15000)}),value=JSON.parse((await bytes(response,1024)).toString());if(!require('node:net').isIP(value.ip))throw Error('Invalid response');return value.ip;}finally{await ses.closeAllConnections();}}
    case 'vault_status':bootstrap.vault=await backend.call('vault_status');return bootstrap.vault;
    case 'vault_create':case 'vault_unlock':case 'vault_change':case 'vault_lock':case 'vault_list':case 'vault_remove':{
      if(owner.private)throw Error('The password manager is unavailable in private windows.');
      const result=await backend.call(operation,data);bootstrap.vault=await backend.call('vault_status');publishAll();return result;}
    case 'vault_save':{
      if(owner.private)throw Error('Private windows do not save passwords.');await backend.call('vault_save',data);return true;}
    case 'vault_get':if(owner.private)throw Error('Private windows do not access saved passwords.');return backend.call('vault_get',data);
    case 'password_decline':cancelOffer(owner);break;
    case 'password_save':{
      if(owner.private||!owner.offer)throw Error('There is no password offer.');await backend.call('vault_save',owner.offer);cancelOffer(owner);break;}
    case 'password_fill':{
      if(owner.private||!contents||origin(contents.getURL())!==data.origin)throw Error('Select the matching website first.');
      const entry=await backend.call('vault_get',data);if(!entry)throw Error('No matching saved login.');
      const code=`(()=>{const value=${JSON.stringify(entry)};if(location.origin!==value.origin)return false;const fields=[...document.querySelectorAll('input')],password=fields.find(e=>e.type==='password'),username=fields.find(e=>e.autocomplete==='username')||fields.find(e=>['email','text'].includes(e.type));const set=(field,text)=>{if(field){Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(field,text);field.dispatchEvent(new Event('input',{bubbles:true}));field.dispatchEvent(new Event('change',{bubbles:true}));}};if(!password)return false;set(username,value.username);set(password,value.password);return true;})()`;
      const filled=await contents.executeJavaScriptInIsolatedWorld(1001,[{code}]);if(!filled)throw Error('No password field was found.');owner.page=null;break;}
    case 'download_action':{
      const record=downloads.find(entry=>entry.id===data.id&&(!entry.private||entry.owner===owner.id));if(!record)throw Error('Unknown download');
      if(data.action==='folder')shell.showItemInFolder(record.path);else if(record.item){if(data.action==='pause')record.item.pause();if(data.action==='resume')record.item.resume();if(data.action==='cancel')record.item.cancel();}break;}
    case 'maintenance':{
      if(!Array.isArray(data.categories)||!data.categories.length)throw Error('Choose data to remove.');
      if(data.categories.includes('reset')&&data.confirmation!=='Delete')throw Error('Type Delete to reset the browser.');
      const sessions=[...new Set([...windows.values()].map(value=>value.session))];
      if(data.categories.some(value=>['cookies','reset'].includes(value)))await Promise.all(sessions.map(ses=>ses.clearStorageData()));
      if(data.categories.some(value=>['cache','reset'].includes(value)))await Promise.all(sessions.map(ses=>ses.clearCache()));
      const token=await backend.call('maintenance',data);await restart(token);return true;}
    case 'tour':event(owner,'tour');return true;
    case 'restart':await restart();return true;
    default:throw Error('Unknown browser action');
  }
  layout(owner);publishAll();return true;
}
function replacePane(owner,tab,pane){disposePane(pane);if(pane.url!=='supersearch:start')attachPane(owner,tab,pane);}

ipcMain.handle('ss:ui',async(event,operation,data)=>{
  const owner=[...windows.values()].find(value=>validSender(event,value.ui));
  if(!owner)throw Error('Untrusted UI request');
  if(typeof operation!=='string'||JSON.stringify(data||{}).length>4000000)throw Error('Invalid request');
  if(!config.onboarding_complete&&!['bootstrap','ui_ready','bounds','overlay','ui_modal','settings_apply','profiles','choose_profile','choose_csv','import','legal','wallpaper','wallpaper_data','wallpaper_reset','backup_choose','backup_restore','vault_status','vault_create','vault_unlock','vault_lock','proxy_test','filters_update','minimize','close_window','close_cancel','close_confirm'].includes(operation))throw Error('Finish setup before browsing.');
  return action(owner,operation,data||{});
});
ipcMain.on('ss:credential',credential);
ipcMain.on('ss:click',(event,data)=>{const entry=remote.get(event.sender.id);if(entry&&event.senderFrame===event.sender.mainFrame&&Number.isFinite(data.x)&&Number.isFinite(data.y)){const bounds=entry.pane.view.getBounds();entry.owner.lastClick={x:Math.max(0,bounds.x+data.x*event.sender.getZoomFactor()),y:Math.max(0,bounds.y+data.y*event.sender.getZoomFactor())};}});
app.on('certificate-error',(event,_contents,_url,_error,_certificate,callback)=>{event.preventDefault();callback(false);});
app.on('before-quit',event=>{if(backend&&!backendStopped){event.preventDefault();quitting=true;clearInterval(statsTimer);ipController?.abort();for(const owner of windows.values())owner.closing=true;(async()=>{try{if(Object.keys(blocks).length)await backend.call('blocks',{...blocks});await backend.call('downloads',downloads.filter(entry=>!entry.private).map(({item,url,...entry})=>entry));}finally{await backend.close();backendStopped=true;app.quit();}})().catch(()=>{backendStopped=true;app.quit();});}});
app.on('will-quit',()=>{clearInterval(statsTimer);ipController?.abort();backend?.close();});
app.on('window-all-closed',()=>app.quit());

async function start(){
  backend=new Backend(ROOT,DATA);bootstrap=await backend.call('bootstrap');config=bootstrap.config;startup={...config};
  await app.whenReady();
  if(!app.requestSingleInstanceLock()){backend.close();app.quit();return;}
  app.on('second-instance',()=>{const owner=[...windows.values()][0];if(owner){owner.window.restore();owner.window.focus();}});
  const providers={Cloudflare:'https://cloudflare-dns.com/dns-query',Quad9:'https://dns.quad9.net/dns-query',Google:'https://dns.google/dns-query'};
  if(!startup.tor&&providers[startup.doh])app.configureHostResolver({enableBuiltInResolver:true,secureDnsMode:'secure',secureDnsServers:[providers[startup.doh]]});
  filters=new Filters(path.join(DATA,'filters'));normalSession=await makeSession();
  if(!startup.ephemeral_profile){let saved=[];try{saved=JSON.parse(fs.readFileSync(path.join(DATA,'extensions.json')));}catch{}
    for(const entry of saved)if(path.dirname(entry.directory)===path.join(DATA,'extensions'))try{await normalSession.extensions.loadExtension(entry.directory,{allowFileAccess:false});}catch{}
  }
  for(const record of bootstrap.downloads||[])downloads.push({...record,id:record.id||crypto.randomUUID(),private:false,state:record.state==='completed'?'completed':'interrupted'});
  let statusTick=0;
  statsTimer=setInterval(async()=>{try{
    const entries={...blocks};for(const key of Object.keys(entries))delete blocks[key];
    if(Object.keys(entries).length){bootstrap.stats=await backend.call('blocks',entries);publishAll();}
    if(++statusTick%30===0){const status=await backend.call('vault_status');if(bootstrap.vault.unlocked&&!status.unlocked)for(const owner of windows.values())cancelOffer(owner);bootstrap.vault=status;publishAll();}
    maybeIP().catch(()=>{});
  }catch{}},1000);
  const owner=await createWindow();
  if(TEST){const module=['backup','returning','restored'].includes(process.env.SUPERSEARCH_TEST_MODE)?'./smoke_backup':process.env.SUPERSEARCH_TEST_MODE==='layout'?'./smoke_layout':['onboarding','javascript-off'].includes(process.env.SUPERSEARCH_TEST_MODE)?'./smoke_modes':'./smoke';require(module).run({app,owner,windows,remote,backend,action,createWindow,normalSession,configureProxy,config:()=>config,filters}).then(async()=>{quitting=true;clearInterval(statsTimer);for(const value of windows.values())value.closing=true;await backend.close();app.exit(0);}).catch(async error=>{console.error(error.stack);quitting=true;clearInterval(statsTimer);for(const value of windows.values())value.closing=true;await backend.close();app.exit(1);});}
}
start().catch(error=>{console.error(error.stack||error.message);process.exitCode=1;app.quit();});
