'use strict';
const {contextBridge,ipcRenderer}=require('electron');
const argument=process.argv.find(value=>value.startsWith('--ss-options='));
const options=argument?JSON.parse(atob(argument.slice(13))):{};

function protect(settings) {
  'use strict';
  const override=(object,key,value)=>{try{Object.defineProperty(object,key,{get:()=>value,configurable:true});}catch{}};
  if(settings.webrtc)for(const name of ['RTCPeerConnection','webkitRTCPeerConnection','RTCDataChannel'])override(window,name,undefined);
  if(settings.geolocation){const deny=(_success,error)=>{if(error)queueMicrotask(()=>error({code:1,message:'Location blocked'}));return 0;};override(navigator,'geolocation',{getCurrentPosition:deny,watchPosition:deny,clearWatch:()=>{}});}
  if(settings.third_party&&window.top!==window){let third=true;try{third=window.top.location.origin!==location.origin;}catch{}
    if(third)for(const key of ['localStorage','sessionStorage','indexedDB','caches'])try{Object.defineProperty(window,key,{get(){throw new DOMException('Third-party storage blocked','SecurityError');},configurable:true});}catch{}
  }
  if(settings.canvas===false){const deny=()=>{throw new DOMException('Canvas reading is blocked','SecurityError');};
    if(window.CanvasRenderingContext2D)CanvasRenderingContext2D.prototype.getImageData=deny;
    if(window.HTMLCanvasElement){HTMLCanvasElement.prototype.toDataURL=deny;HTMLCanvasElement.prototype.toBlob=deny;}
  }
  if(!settings.fingerprint)return;
  for(const [key,value] of Object.entries({hardwareConcurrency:4,deviceMemory:8,language:'en-US',languages:Object.freeze(['en-US','en']),platform:'Linux x86_64'}))override(Navigator.prototype,key,value);
  for(const [key,value] of Object.entries({width:1920,height:1080,availWidth:1920,availHeight:1080,colorDepth:24,pixelDepth:24}))override(Screen.prototype,key,value);
  Date.prototype.getTimezoneOffset=()=>0;
  const NativeFormat=Intl.DateTimeFormat;
  function Format(locales,options){return new NativeFormat(locales,{...options,timeZone:'UTC'});}
  Format.prototype=NativeFormat.prototype;Format.supportedLocalesOf=NativeFormat.supportedLocalesOf.bind(NativeFormat);Intl.DateTimeFormat=Format;
  for(const key of ['FullYear','Month','Date','Day','Hours','Minutes','Seconds','Milliseconds'])Date.prototype['get'+key]=Date.prototype['getUTC'+key];
  const seed=crypto.getRandomValues(new Uint8Array(1))[0];
  if(window.CanvasRenderingContext2D){const original=CanvasRenderingContext2D.prototype.getImageData;CanvasRenderingContext2D.prototype.getImageData=function(...args){const result=original.apply(this,args);for(let i=0;i<result.data.length;i+=64)result.data[i]^=seed&1;return result;};}
  if(window.HTMLCanvasElement)for(const key of ['toDataURL','toBlob']){const original=HTMLCanvasElement.prototype[key];HTMLCanvasElement.prototype[key]=function(...args){const copy=document.createElement('canvas');copy.width=this.width;copy.height=this.height;try{const ctx=copy.getContext('2d');ctx.drawImage(this,0,0);ctx.putImageData(ctx.getImageData(0,0,copy.width,copy.height),0,0);return original.apply(copy,args);}catch{return original.apply(this,args);}};}
  for(const cls of [window.WebGLRenderingContext,window.WebGL2RenderingContext])if(cls){const original=cls.prototype.getParameter;cls.prototype.getParameter=function(value){if(value===37445)return 'Intel Inc.';if(value===37446)return 'Intel Iris OpenGL Engine';return original.call(this,value);};}
  if(window.AudioBuffer){const original=AudioBuffer.prototype.getChannelData,seen=new WeakSet();AudioBuffer.prototype.getChannelData=function(...args){const data=original.apply(this,args);if(!seen.has(data)){for(let i=0;i<data.length;i+=100)data[i]+=(seed-128)*1e-9;seen.add(data);}return data;};}
}
// Runs before website scripts; no Node or IPC capabilities are copied into the page.
if(!options.javascript_disabled)contextBridge.executeInMainWorld({func:protect,args:[options]});

if(process.isMainFrame){
  document.addEventListener('mousedown',event=>ipcRenderer.send('ss:click',{x:event.clientX,y:event.clientY}),true);
  if(!options.private&&!options.javascript_disabled&&location.protocol==='https:')document.addEventListener('submit',event=>{
    const form=event.target;if(!(form instanceof HTMLFormElement))return;
    try{if(new URL(form.action||location.href,location.href).origin!==location.origin)return;}catch{return;}
    const fields=[...form.querySelectorAll('input')];
    if(fields.some(field=>field.autocomplete==='new-password'))return;
    const password=fields.find(field=>field.type==='password'&&field.value);
    const username=fields.find(field=>field.autocomplete==='username')||fields.find(field=>['email','text'].includes(field.type)&&field.value);
    if(password)ipcRenderer.send('ss:credential',{origin:location.origin,username:username?.value||'',password:password.value});
  },true);
}
