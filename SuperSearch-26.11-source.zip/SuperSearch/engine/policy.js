'use strict';
const fs=require('node:fs');
const path=require('node:path');
const BUILTIN='||doubleclick.net^\n||google-analytics.com^\n||googlesyndication.com^\n||facebook.net^\n||scorecardresearch.com^\n||hotjar.com^';
const TRACKING=new Set(['fbclid','gclid','dclid','msclkid','mc_cid','mc_eid','igshid','yclid','_ga','_gl']);
const SEARCH={DuckDuckGo:'https://duckduckgo.com/?q=',Google:'https://www.google.com/search?q=',Brave:'https://search.brave.com/search?q=',Wikipedia:'https://en.wikipedia.org/w/index.php?search='};

function origin(value){try{const u=new URL(value);return ['http:','https:'].includes(u.protocol)&&!u.username&&!u.password?u.origin:'';}catch{return '';}}
function target(text,search='DuckDuckGo') {
  text=String(text||'').trim();if(!text)return null;
  if(['supersearch:start','about:blank'].includes(text))return text;
  if(/^(javascript|data|file|chrome|chrome-extension|ss-app|about):/i.test(text))return null;
  if(text.includes('://')){try{const explicit=new URL(text);return origin(explicit.href)&&! /\s/.test(text)?explicit.href:null;}catch{return null;}}
  try{
    const candidate=new URL(text.includes('://')?text:'https://'+text);
    if(!/\s/.test(text)&&(candidate.hostname.includes('.')||candidate.hostname==='localhost'||candidate.hostname.includes(':'))&&origin(candidate.href))return candidate.href;
  }catch{}
  return (SEARCH[search]||SEARCH.DuckDuckGo)+encodeURIComponent(text);
}
function cleaned(value,config){try{const u=new URL(value);if(!['http:','https:'].includes(u.protocol))return value;
  if(config.https_only&&u.protocol==='http:')u.protocol='https:';
  if(config.strip_params)for(const key of [...u.searchParams.keys()])if(key.toLowerCase().startsWith('utm_')||TRACKING.has(key.toLowerCase()))u.searchParams.delete(key);
  return u.href;
}catch{return value;}}
function sameParty(first,second){try{const a=new URL(first).hostname,b=new URL(second).hostname;return a===b||a.endsWith('.'+b)||b.endsWith('.'+a);}catch{return false;}}
class Filters {
  constructor(directory){this.directory=directory;this.reload();}
  reload(){let source=BUILTIN;try{for(const name of fs.readdirSync(this.directory))if(name.endsWith('.txt'))source+='\n'+fs.readFileSync(path.join(this.directory,name),'utf8');}catch{}
    this.blocks=[];this.exceptions=[];this.skipped=0;this.indexSize=null;
    for(let line of source.split(/\r?\n/)){line=line.trim();if(!line||line.startsWith('!')||line.startsWith('['))continue;
      const exception=line.startsWith('@@');if(exception)line=line.slice(2);
      const match=/^\|\|([a-zA-Z0-9._-]+)\^$/.exec(line);
      if(!match&&(/[$#*|^]/.test(line)||line.startsWith('/'))){this.skipped++;continue;}
      (exception?this.exceptions:this.blocks).push(match?{domain:match[1].toLowerCase()}:{text:line});
    }
  }
  blocked(url){let host;try{host=new URL(url).hostname.toLowerCase();}catch{return false;}
    const size=this.blocks.length+':'+this.exceptions.length;
    if(this.indexSize!==size){this.indexSize=size;this.blockDomains=new Set(this.blocks.filter(rule=>rule.domain).map(rule=>rule.domain));this.allowDomains=new Set(this.exceptions.filter(rule=>rule.domain).map(rule=>rule.domain));this.blockTexts=this.blocks.filter(rule=>!rule.domain).map(rule=>rule.text);this.allowTexts=this.exceptions.filter(rule=>!rule.domain).map(rule=>rule.text);}
    const labels=host.split('.'),suffixes=labels.map((_value,index)=>labels.slice(index).join('.'));
    return !suffixes.some(value=>this.allowDomains.has(value))&&!this.allowTexts.some(text=>url.includes(text))&&(suffixes.some(value=>this.blockDomains.has(value))||this.blockTexts.some(text=>url.includes(text)));
  }
}
function validSender(event,contents){return event.sender===contents&&event.senderFrame===contents.mainFrame&&event.senderFrame.url==='ss-app://browser/index.html';}
module.exports={origin,target,cleaned,sameParty,Filters,validSender};
