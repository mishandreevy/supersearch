'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const http=require('node:http');
const {once}=require('node:events');
const {until,delay}=require('./smoke');

async function run({owner,action,backend,config}){
  const ui=code=>owner.ui.executeJavaScript(code);
  await until(()=>owner.tabs.length&&owner.area,'initial mode UI');
  if(process.env.SUPERSEARCH_TEST_MODE==='javascript-off'){
    const server=http.createServer((_request,response)=>{response.writeHead(200,{'content-type':'text/html'});response.end('<h1 id="plain">Plain HTML still works</h1><script>document.getElementById("plain").textContent="WRONG"</script>');});
    server.listen(0,'127.0.0.1');await once(server,'listening');
    try{
      await action(owner,'navigate',{text:'http://127.0.0.1:'+server.address().port});const pane=owner.tabs[0].panes[0];await until(()=>pane.view&&!pane.loading,'no-JavaScript page');
      const contents=pane.view.webContents;assert.equal(contents.getLastWebPreferences().javascript,false);assert.ok(!pane.securityError);
      contents.debugger.attach('1.3');const document=await contents.debugger.sendCommand('DOM.getDocument',{depth:-1});const html=await contents.debugger.sendCommand('DOM.getOuterHTML',{nodeId:document.root.nodeId});contents.debugger.detach();
      assert.ok(html.outerHTML.includes('<h1 id="plain">Plain HTML still works</h1>'));
      await action(owner,'settings',{});await until(()=>ui("!!document.getElementById('settings-content')"),'settings with site JS disabled');
      console.log('ELECTRON NO-JS CHECKS OK: site scripts disabled, HTML renders, trusted UI stays functional');
    }finally{server.close();}
    return;
  }
  await until(()=>ui("!!document.getElementById('wizard-continue')"),'welcome wizard');
  for(const language of ['de','fr','es','ru','en']){
    await ui(`(()=>{const select=document.getElementById('wizard-language');select.value=${JSON.stringify(language)};select.dispatchEvent(new Event('change',{bubbles:true}));return true})()`);
    await until(()=>config().language===language,'language applied');await until(()=>ui('document.documentElement.lang==='+JSON.stringify(language)),'live UI language');
  }
  assert.equal(await ui("document.getElementById('wizard-continue').disabled"),true);
  await delay(200);fs.writeFileSync('/tmp/supersearch-welcome.png',(await owner.ui.capturePage()).toPNG());
  await ui("document.querySelector('[data-returning=no]').click();document.getElementById('wizard-continue').click();true");await until(()=>ui("!!document.getElementById('agreement')"),'agreement step');
  assert.equal(await ui("document.getElementById('wizard-continue').disabled"),true);await ui("document.getElementById('wizard-continue').click();true");assert.equal(await ui('wizardStep'),1);
  await ui("document.getElementById('agreement').click();document.getElementById('wizard-continue').click();true");await until(()=>ui("!!document.getElementById('wizard-tour')"),'optional tour choice');
  assert.equal(await ui("document.getElementById('wizard-tour').checked"),true);
  await ui("document.getElementById('wizard-continue').click();true");await until(()=>ui("!!document.getElementById('settings-content')"),'setup preferences');
  await ui("document.querySelector('[data-category=Appearance]').click();const select=document.querySelector('[data-setting=theme]');select.value='dark';select.dispatchEvent(new Event('change',{bubbles:true}));true");
  await until(()=>config().theme==='dark','live dark theme');assert.equal(await ui("document.documentElement.style.getPropertyValue('--bg')"),'#16181f');
  await ui("document.getElementById('wizard-continue').click();true");await until(()=>ui("!!document.getElementById('wizard-import')"),'profile import step');
  await ui("document.getElementById('wizard-continue').click();true");await until(()=>config().onboarding_complete,'setup complete');
  await until(()=>ui("!!document.getElementById('tour-layer')"),'automatic optional tour');
  await delay(200);fs.writeFileSync('/tmp/supersearch-tour.png',(await owner.ui.capturePage()).toPNG());
  for(let index=0;index<6;index++)await ui("document.querySelector('[data-tour-next]').click();true");
  await ui("document.querySelector('[data-tour-next]').click();true");await until(()=>config().tour_completed&&!config().tour_pending,'tour complete');
  await action(owner,'new_tab',{url:'about:blank'});const preserved=owner.active,count=owner.tabs.length;
  await action(owner,'settings',{});await until(()=>ui("!!document.getElementById('settings-content')"),'settings to replay tour');
  await ui("settingsCategory='About';renderSettingsContent();document.querySelector('[data-tour]').click();true");await until(()=>ui("!!document.getElementById('tour-layer')"),'manual tour');
  assert.equal(owner.tabs.length,count+1);assert.ok(owner.tabs.some(tab=>tab.id===preserved&&tab.panes[0].url==='about:blank'));
  await ui("document.querySelector('[data-tour-skip]').click();true");await until(()=>ui("!document.getElementById('tour-layer')"),'skip tour');
  assert.equal(config().suggestions,false);assert.equal(config().terms_version,'2026-11-02');assert.equal((await backend.call('state')).config.onboarding_complete,true);
  console.log('ELECTRON SETUP CHECKS OK: five languages, agreement gates Continue, immediate theme preview, new-user choice, optional seven-step tour, replay/skip, optional import and suggestions off by default');
}
module.exports={run};
