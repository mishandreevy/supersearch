'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const http=require('node:http');
const {once}=require('node:events');
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function until(predicate,label){for(let index=0;index<150;index++){if(await predicate())return;await delay(40);}throw Error('Timed out: '+label);}

async function run(context){
  const {app,owner,windows,backend,action,createWindow,config,filters}=context;
  const errors=[];owner.ui.on('console-message',(_event,...args)=>{const message=typeof _event.message==='string'?_event.message:args[1];if(typeof message==='string'&&/Uncaught|Error invoking remote method/.test(message))errors.push(message);});
  await until(()=>owner.tabs.length&&owner.area,'initial browser UI');
  assert.equal(process.versions.chrome,'156.0.8078.75');
  assert.equal(await owner.ui.executeJavaScript("document.querySelector('.home')!==null"),true);
  const shot=await owner.ui.capturePage();fs.writeFileSync('/tmp/supersearch-electron-home.png',shot.toPNG());
  const server=http.createServer((request,response)=>{
    if(request.url.startsWith('/file')){response.writeHead(200,{'content-type':'application/octet-stream','content-disposition':'attachment; filename="report.txt"'});response.end('local download fixture');return;}
    response.writeHead(200,{'content-type':'text/html'});response.end('<!doctype html><title>Local fixture</title><h1 id="fixture">Chromium 156</h1><input id="text"><a href="/file">Download</a>');
  });
  server.listen(0,'127.0.0.1');await once(server,'listening');const url='http://127.0.0.1:'+server.address().port;
  try{
    await action(owner,'navigate',{text:url});
    await until(()=>owner.tabs[0].panes[0].view&&!owner.tabs[0].panes[0].loading,'fixture page');
    const contents=owner.tabs[0].panes[0].view.webContents;
    await until(async()=>await contents.executeJavaScript("!!document.getElementById('fixture')"),'fixture DOM');
    assert.equal(await contents.executeJavaScript("typeof require+'|'+typeof process+'|'+typeof window.supersearch"),'undefined|undefined|undefined');
    assert.equal(contents.getLastWebPreferences().sandbox,true);assert.equal(contents.getLastWebPreferences().contextIsolation,true);
    assert.ok(!owner.tabs[0].panes[0].securityError);
    assert.equal(await contents.executeJavaScript("typeof RTCPeerConnection"),'undefined');
    await action(owner,'settings',{});assert.equal(owner.page,'settings');assert.equal(owner.tabs[0].panes[0].view.getVisible(),false);
    await action(owner,'web',{});await action(owner,'split',{});assert.equal(owner.tabs[0].panes.length,2);
    await action(owner,'split',{});assert.equal(owner.tabs[0].panes.length,1);
    await action(owner,'pin_active',{});const pins=JSON.parse(fs.readFileSync(path.join(process.env.SUPERSEARCH_DATA,'pinned-tabs.json')));assert.equal(pins.tabs.length,1);
    const privateOwner=await createWindow(true);await until(()=>privateOwner.tabs.length,'private window');assert.notEqual(privateOwner.session,owner.session);assert.equal(privateOwner.session.getStoragePath(),null);
    await action(privateOwner,'new_tab',{url:'about:blank'});await action(privateOwner,'pin_active',{});assert.equal(JSON.parse(fs.readFileSync(path.join(process.env.SUPERSEARCH_DATA,'pinned-tabs.json'))).tabs.length,1);
    await action(privateOwner,'close_confirm',{save:false});
    await action(owner,'settings_apply',{theme:'dark'});assert.equal(config().theme,'dark');
    await action(owner,'settings',{});await until(async()=>await owner.ui.executeJavaScript("!!document.getElementById('settings-content')"),'settings content');
    await owner.ui.executeJavaScript("settingsCategory='About';renderSettingsContent();true");
    assert.equal(await owner.ui.executeJavaScript("document.querySelector('[data-source]').href"),'https://github.com/mishandreevy/supersearch');
    const about=await owner.ui.capturePage();fs.writeFileSync('/tmp/supersearch-electron-about.png',about.toPNG());
    await require('./smoke_extended').run(context);
    assert.deepEqual(errors,[]);
    console.log('ELECTRON CHECKS OK: Chromium '+process.versions.chrome+', sandboxed isolated sites, privacy preload, embedded settings, split view, persistent pins, private session isolation, dark theme and source link');
  }finally{server.close();}
}
module.exports={run,until,delay};
