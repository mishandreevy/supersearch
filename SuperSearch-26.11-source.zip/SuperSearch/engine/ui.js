'use strict';
const api=window.supersearch;
const $=selector=>document.querySelector(selector);
const $$=selector=>[...document.querySelectorAll(selector)];
const esc=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
let B,S,previousActive=null,settingsDraft=null,settingsCategory='General',settingsQuery='',settingsStatus='',selected=new Set(),anchor=0,modalResolve=null,wallpaper='',paneSignature='',screenSignature='',offerSignature='',clockTimer=null;
let settingsEdited=new Set(),customizing=false;
let wizardRevision=0,tabLayoutSignature='';
function revealActiveTab(){requestAnimationFrame(()=>document.querySelector('.tab.active')?.scrollIntoView({block:'nearest',inline:'nearest'}));}
let returningUser=null,showTour=true,tourIndex=0,tourRunning=false;
let wizardStep=0,agreement=false,wizardLegal='',detectedProfiles=null,manualProfile='',passwordCSV='',suggestionGeneration=0,tabSignature='';
const RESTART=new Set(['webrtc','javascript','tor','doh','proxy','ephemeral_profile']);
const t=source=>B?.translations[S?.config.language||'en']?.[source]||source;
const icon=name=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${B?.icons[name]||B?.icons.globe||''}</svg>`;
const logoURL=()=> 'ss-app://assets/logo.svg';
const button=(name,label,attributes='')=>`<button ${attributes}>${icon(name)}<span class="label">${esc(t(label))}</span></button>`;
const invoke=async(operation,data={})=>{try{return await api.call(operation,data);}catch(error){toast(error.message||'The operation failed.');throw error;}};
function toast(message){const element=document.createElement('div');element.className='toast';element.textContent=t(message);$('#toasts').append(element);setTimeout(()=>element.remove(),5000);}
function titleFor(tab){const pane=tab.panes[tab.active]||tab.panes[0];return pane.title||pane.url||t('New tab');}
function currentTab(){return S?.tabs.find(tab=>tab.id===S.active)||S?.tabs[0];}
function currentPane(){const tab=currentTab();return tab?.panes[tab.active]||null;}
function colors(config){return {...B.palettes[config.theme],...config.colors};}
function luminance(hex){const value=parseInt(hex.slice(1),16),channels=[value>>16,(value>>8)&255,value&255].map(value=>{value/=255;return value<=.04045?value/12.92:((value+.055)/1.055)**2.4;});return channels[0]*.2126+channels[1]*.7152+channels[2]*.0722;}
function applyTheme(config){
  const palette=colors(config),style=document.documentElement.style;
  style.setProperty('--ui-scale',config.ui_scale/100);
  for(const [key,value] of Object.entries(palette))style.setProperty('--'+key,value);
  style.setProperty('--on-accent',luminance(palette.accent)>.179?'#000000':'#ffffff');
  for(const [name,value] of Object.entries({radius:config.shape==='square'?0:config.shape==='pill'?40:config.radius,space:config.spacing,sidebar:config.sidebar_width,'sidebar-height':config.sidebar_height,titlebar:config.titlebar_height,toolbar:config.toolbar_size,tab:config.tab_height,icon:config.icon_size,'home-width':config.home_width,tile:config.home_tile_size}))style.setProperty('--'+name,value+'px');
  style.setProperty('--columns',config.home_columns);style.setProperty('--split',config.split_ratio+'%');style.setProperty('--home-align',config.home_align==='top'?'flex-start':'center');
  document.body.style.fontFamily=config.font==='Sans Serif'?'system-ui,sans-serif':config.font;
  document.documentElement.style.colorScheme=config.theme==='light'?'light':'dark';
  document.body.classList.toggle('dark-logo',config.theme!=='light');
  document.body.classList.toggle('collapsed',config.sidebar_collapsed);document.body.classList.toggle('no-animation',!config.animations);
  document.body.classList.toggle('onboarding',!config.onboarding_complete);
  document.body.classList.toggle('sidebar-right',config.sidebar_position==='right');document.body.classList.toggle('sidebar-top-panel',config.sidebar_position==='top');document.body.classList.toggle('sidebar-bottom-panel',config.sidebar_position==='bottom');document.body.classList.toggle('nav-bottom',config.navigation_position==='bottom');
  document.documentElement.lang=config.language;
  updateResponsive();
  const layoutKey=JSON.stringify([config.sidebar_position,config.sidebar_collapsed,config.sidebar_width,config.sidebar_height,config.ui_scale,config.tab_height,config.icon_size]);
  if(layoutKey!==tabLayoutSignature){tabLayoutSignature=layoutKey;revealActiveTab();}
}
function updateResponsive(){
  if(!S)return;
  const width=window.innerWidth;
  document.body.classList.toggle('compact-horizontal',width<860);
  document.body.classList.toggle('compact-toolbar',width<700);
  document.body.classList.toggle('auto-collapsed',width<700&&['left','right'].includes(S.config.sidebar_position));
}
window.addEventListener('resize',()=>{updateResponsive();revealActiveTab();});
function updateBounds(){document.documentElement.style.setProperty('--window-controls-width',Math.ceil($('#titlebar').getBoundingClientRect().width)+'px');const rect=$('#viewport').getBoundingClientRect();api.call('bounds',{x:rect.x,y:rect.y,width:rect.width,height:rect.height}).catch(()=>{});}
new ResizeObserver(updateBounds).observe($('#viewport'));
new ResizeObserver(updateBounds).observe($('#titlebar'));
new ResizeObserver(revealActiveTab).observe($('#tabs'));

function render(state){
  if(!B)return;const wasUnlocked=S?.vault?.unlocked;S=state;if(wasUnlocked&&!S.vault.unlocked&&$('#modal-layer input[type=password]'))closeDialog(null);applyTheme(state.config);
  if(settingsDraft)for(const [key,value] of Object.entries(S.config))if(!settingsEdited.has(key))settingsDraft[key]=structuredClone(value);
  const changed=previousActive!==S.active;if(changed){selected=new Set([S.active]);closeSuggestions();previousActive=S.active;}
  const pane=currentPane();if(changed||!document.hasFocus()||document.activeElement!==$('#address'))$('#address').value=pane?.url||'';
  $('#window-title').textContent=S.config.titlebar_show_title?'SuperSearch'+(S.private?' · '+t('Private window'):''):'';
  $('#titlebar').style.background=S.config.titlebar_accent?'var(--panel)':'var(--bg)';
  $('#expand').hidden=!S.config.titlebar_show_expand;$('#expand').innerHTML=icon(S.fullscreen?'restore':S.config.window_expand_mode==='fullscreen'?'fullscreen':S.maximized?'restore':'maximize');
  for(const [id,name] of Object.entries({minimize:'minimize',close:'close',collapse:'menu','new-tab':'plus',back:'back',forward:'forward',reload:'reload',shield:'shield',split:'split',passwords:'key',menu:'more','find-close':'close'}))$('#'+id).innerHTML=icon(name);
  $('#bookmark').innerHTML=icon(S.bookmarks.some(entry=>entry.url===pane?.url)?'star-filled':'star');
  $('#back').disabled=!pane?.canBack;$('#forward').disabled=!pane?.canForward;$('#reload').classList.toggle('loading',!!pane?.loading);
  const nav={back:$('#back'),forward:$('#forward'),reload:$('#reload'),address:$('#address-form'),shield:$('#shield'),split:$('#split'),passwords:$('#passwords'),bookmark:$('#bookmark'),menu:$('#menu')};
  const order=[...new Set([...S.config.nav_order,...Object.keys(nav)])];for(const key of order)if(nav[key]){$('#navigation').append(nav[key]);nav[key].hidden=S.config.nav_hidden.includes(key)&&!['address','menu'].includes(key);}
  $('#downloads-button').innerHTML=icon('download')+`<span class="label">${esc(t('Downloads'))}</span>`+(S.downloads.some(entry=>entry.state==='progressing')?'<span class="badge">'+S.downloads.filter(entry=>entry.state==='progressing').length+'</span>':'');
  $('#settings-button').innerHTML=icon('settings')+`<span class="label">${esc(t('Settings'))}</span>`;
  for(const [id,label] of [['settings-button','Settings'],['downloads-button','Downloads'],['bookmarks-button','Bookmarks']])$('#'+id).title=t(label);
  $('#bookmarks-button').innerHTML=icon('star')+`<span class="label">${esc(t('Bookmarks'))}</span>`;
  renderTabs();renderBookmarks();renderOffer();renderPanes();renderScreen();renderClock();
  for(const image of $$('.home-logo'))if(image.src!==logoURL())image.src=logoURL();
  for(const image of $$('.about-logo,.wizard-header img'))if(image.src!==logoURL())image.src=logoURL();
  if(S.modal?.type==='close'&&!$('#modal-layer [data-close-dialog]'))showClose();
  requestAnimationFrame(updateBounds);
  if(S.config.onboarding_complete&&S.config.tour_pending&&!S.private&&!tourRunning)startTour();
}
function renderTabs(){
  const signature=JSON.stringify([S.tabs,S.active,S.config.language,S.config.sidebar_collapsed,[...selected]]);if(signature===tabSignature)return;tabSignature=signature;
  const listing=$('#tabs'),scrollTop=listing.scrollTop,scrollLeft=listing.scrollLeft,changed=listing.dataset.active!==S.active;
  listing.dataset.active=S.active;listing.innerHTML=S.tabs.map(tab=>{
    const pane=tab.panes[tab.active],favicon=pane.icon?`<img src="${esc(pane.icon)}" alt="">`:`<span class="favicon">${icon('globe')}</span>`;
    return `<button class="tab ${tab.id===S.active?'active':''} ${selected.has(tab.id)?'selected':''}" data-tab="${esc(tab.id)}" role="tab" aria-selected="${tab.id===S.active}" title="${esc((tab.pinned?t('Pinned tab')+' · ':'')+titleFor(tab))}">${favicon}<span class="title">${esc(titleFor(tab))}</span>${tab.pinned?icon('pin').replace('<svg ','<svg class="pin" '):''}<span class="close-tab" data-close="${esc(tab.id)}" title="${esc(t('Close'))}">${icon('close')}</span></button>`;
  }).join('');
  listing.scrollTop=scrollTop;listing.scrollLeft=scrollLeft;
  if(changed)listing.querySelector('.tab.active')?.scrollIntoView({block:'nearest',inline:'nearest'});
  for(const element of listing.querySelectorAll('[data-tab]')){
    element.onclick=event=>{
      if(event.target.closest('[data-close]')){invoke('close_tabs',{ids:[element.dataset.tab]});return;}
      const index=S.tabs.findIndex(tab=>tab.id===element.dataset.tab);
      if(event.shiftKey){const low=Math.min(anchor,index),high=Math.max(anchor,index);if(!event.ctrlKey&&!event.metaKey)selected.clear();for(let i=low;i<=high;i++)selected.add(S.tabs[i].id);renderTabs();}
      else if(event.ctrlKey||event.metaKey){selected.has(element.dataset.tab)?selected.delete(element.dataset.tab):selected.add(element.dataset.tab);anchor=index;renderTabs();}
      else{anchor=index;selected=new Set([element.dataset.tab]);invoke('select',{id:element.dataset.tab});}
      listing.focus();
    };
    element.oncontextmenu=async event=>{event.preventDefault();if(!selected.has(element.dataset.tab))selected=new Set([element.dataset.tab]);renderTabs();const result=await showDialog(t('Tabs'),`<div class="actions">${button('pin','Pin / unpin selected tabs','data-option="pin"')}${button('close','Close selected tabs','data-option="close"')}</div>`,null,{submit:false,setup:form=>{form.querySelector('[data-option=pin]').onclick=()=>{invoke('pin',{ids:[...selected]});closeDialog(true);};form.querySelector('[data-option=close]').onclick=()=>{invoke('close_tabs',{ids:[...selected]});closeDialog(true);};}});};
  }
}
$('#tabs').addEventListener('keydown',event=>{if(event.key==='Delete'){event.preventDefault();invoke('close_tabs',{ids:[...selected]});}});
function renderBookmarks(){
  const bar=$('#bookmark-bar');bar.hidden=!S.config.bookmark_bar||!S.config.onboarding_complete;
  const signature=JSON.stringify(S.bookmarks);if(bar.dataset.signature===signature)return;bar.dataset.signature=signature;
  bar.innerHTML=button('folder','Bookmarks','data-library')+S.bookmarks.filter(entry=>entry.folder==='Bookmarks toolbar').slice(0,8).map(entry=>`<button data-url="${esc(entry.url)}" title="${esc(entry.url)}">${esc(entry.title)}</button>`).join('');
  bar.querySelector('[data-library]').onclick=()=>invoke('bookmarks');for(const element of bar.querySelectorAll('[data-url]'))element.onclick=()=>invoke('new_tab',{url:element.dataset.url});
}
function renderPanes(){
  const tab=currentTab();if(!tab)return;
  const signature=JSON.stringify([tab.id,tab.active,tab.panes.map(pane=>[pane.url,pane.error]),S.shortcuts,S.config.home_columns,S.config.home_width,S.config.home_logo,S.config.home_search,S.config.home_stats,S.config.home_ip,S.config.home_tile_size,S.config.home_align,S.config.wallpaper,S.config.language]);
  if(signature!==paneSignature){
    paneSignature=signature;$('#panes').innerHTML=tab.panes.map((pane,index)=>`<div class="pane ${index===tab.active?'focused':''}" data-pane="${index}" style="flex:${tab.panes.length===2?(index?100-S.config.split_ratio:S.config.split_ratio):1}">${pane.url==='supersearch:start'?homeHTML():pane.error?errorHTML(pane.error):''}</div>`).join('')+(tab.panes.length===2?'<div class="divider" tabindex="0" role="separator" aria-label="Resize split view"></div>':'');
    for(const element of $$('.pane')){element.addEventListener('pointerdown',()=>{if(Number(element.dataset.pane)!==currentTab().active)api.call('pane',{index:Number(element.dataset.pane)});});if(element.querySelector('.home'))bindHome(element);if(element.querySelector('.error-card'))bindError(element);}
    const divider=$('.divider');if(divider)divider.onpointerdown=event=>{event.preventDefault();divider.setPointerCapture(event.pointerId);api.call('ui_modal',{open:true});divider.onpointermove=move=>{const rect=$('#viewport').getBoundingClientRect(),ratio=Math.max(20,Math.min(80,Math.round((move.clientX-rect.x)/rect.width*100)));document.documentElement.style.setProperty('--split',ratio+'%');divider.dataset.ratio=ratio;};divider.onpointerup=()=>{divider.onpointermove=null;api.call('ui_modal',{open:false});invoke('settings_apply',{split_ratio:Number(divider.dataset.ratio||50)});};};
    if(S.config.wallpaper&&!wallpaper)api.call('wallpaper_data').then(value=>{wallpaper=value;applyWallpaper();});else applyWallpaper();
  }
  for(const element of $$('.pane')){const index=Number(element.dataset.pane);element.style.flex=tab.panes.length===2?(index?100-S.config.split_ratio:S.config.split_ratio):1;}
  for(const element of $$('.home'))updateHomeStats(element);
}
function homeHTML(){
  return `<div class="home"><div class="home-tools">${button('settings','Customize start page','data-home="customize"')}${button('image','Wallpaper','data-home="wallpaper"')}${button('reload','Reset background','data-home="reset-wallpaper"')}</div><div class="home-center">${S.config.home_logo?`<img class="home-logo" src="${logoURL()}" alt="SuperSearch">`:""}${S.config.home_search?`<form class="home-search"><input name="q" aria-label="${esc(t('Search'))}" placeholder="${esc(t('Search the web or enter an address'))}" autocomplete="off" required><button type="submit" class="primary">${esc(t('Search'))}${icon('forward')}</button></form>`:''}<div class="tiles">${S.shortcuts.map(entry=>`<div class="shortcut"><button class="tile" data-shortcut="${esc(entry.id)}"><span class="tile-icon"><img src="${esc(entry.icon)}" alt=""></span>${esc(entry.title)}</button><div class="shortcut-tools"><button data-edit="${esc(entry.id)}" title="${esc(t('Edit'))}">${icon('edit')}</button><button data-remove="${esc(entry.id)}" title="${esc(t('Delete'))}">${icon('close')}</button></div></div>`).join('')}<button class="tile add" data-home="add-shortcut"><span class="tile-icon">${icon('plus')}</span>${esc(t('Add'))}</button></div></div>${S.config.home_stats?`<footer class="privacy-card"><div class="privacy-totals"><span class="shield">${icon('shield')}</span><div class="privacy-lead"><strong>${esc(t('Blocked trackers'))}</strong><small>${esc(S.private?t('Private window'):S.route.ephemeral?t('Session profile'):t('Persistent profile'))} · ${esc(S.route.tor?'Tor':S.route.proxy?t('Proxy'):t('Direct connection — IP address is visible'))}</small></div><div class="stat"><strong data-stat="total">0</strong><small>${esc(t('Total'))}</small></div><div class="stat"><strong data-stat="today">0</strong><small>${esc(t('Today'))}</small></div><div class="stat"><strong data-stat="domains">0</strong><small>${esc(t('Domains'))}</small></div></div>${S.config.home_ip?`<div class="ip-row"><div class="ip-symbol">${icon('globe')}</div><div class="ip-details"><small>${esc(t('Your public IP'))}</small><code data-ip dir="ltr" aria-live="polite"></code><small data-ip-status></small></div><button data-home="refresh-ip" title="${esc(t('Refresh IP address'))}">${icon('reload')}</button></div>`:''}</footer>`:''}</div>`;
}
function updateHomeStats(home){
  const values={total:S.stats.total,today:S.private?S.stats.today:S.stats.daily?.at(-1)?.[1]||0,domains:S.stats.domains};for(const [key,value] of Object.entries(values)){const element=home.querySelector(`[data-stat=${key}]`);if(element)element.textContent=Number(value||0).toLocaleString();}
  const ip=home.querySelector('[data-ip]');if(ip)ip.textContent=S.ip.address||t(S.ip.state==='loading'?'Checking…':S.ip.state==='error'?'Unavailable':'Not checked yet');
  const status=home.querySelector('[data-ip-status]');if(status)status.textContent=t(S.ip.state==='error'?'Could not check the address. Check your connection and try again.':'Public connection address · provided by ipify');
  const refresh=home.querySelector('[data-home=refresh-ip]');if(refresh){refresh.disabled=S.ip.state==='loading';refresh.classList.toggle('loading',S.ip.state==='loading');}
}
function applyWallpaper(){for(const element of $$('.home')){element.classList.toggle('with-wallpaper',!!wallpaper&&!!S.config.wallpaper);element.style.setProperty('--wallpaper',wallpaper&&S.config.wallpaper?`url("${wallpaper}")`:'none');}}
function bindHome(element){
  const form=element.querySelector('.home-search');if(form){form.onsubmit=event=>{event.preventDefault();invoke('navigate',{text:form.elements.q.value});};suggestions(form.elements.q,text=>invoke('navigate',{text}));}
  for(const button of element.querySelectorAll('[data-shortcut]'))button.onclick=()=>invoke('navigate',{text:S.shortcuts.find(entry=>entry.id===button.dataset.shortcut).url});
  for(const button of element.querySelectorAll('[data-edit]'))button.onclick=()=>editShortcut(button.dataset.edit);
  for(const button of element.querySelectorAll('[data-remove]'))button.onclick=()=>invoke('shortcuts',S.shortcuts.filter(entry=>entry.id!==button.dataset.remove).map(({icon,...entry})=>entry));
  for(const button of element.querySelectorAll('[data-home]'))button.onclick=async()=>{
    const action=button.dataset.home;if(action==='refresh-ip')invoke('ip_refresh');if(action==='customize')customizeHome();if(action==='add-shortcut')editShortcut();
    if(action==='wallpaper'){wallpaper=await invoke('wallpaper')||wallpaper;applyWallpaper();}if(action==='reset-wallpaper'){await invoke('wallpaper_reset');wallpaper='';applyWallpaper();}
  };
}
function errorHTML(error){
  let title='This page is out of reach',description='The connection could not be completed. Check your internet connection or try again in a moment.',symbol='wifi-off';
  if(error.code<=-200&&error.code>=-299||[-107,-112,-113,-117,-123,-129].includes(error.code)){title='Secure connection unavailable';description='The website could not provide a valid secure connection. Check your device clock or try again later.';symbol='shield';}
  else if(S.config.proxy||S.config.tor||[-111,-115,-130,-136].includes(error.code)){title='Check your private connection';description='Your proxy or Tor service may be unavailable. Check that it is running and review your network settings.';symbol='shield';}
  else if(error.code===-105){title='We could not find this website';description='Check the address and your DNS or internet connection, then try again.';symbol='globe';}
  else if([-106,-109].includes(error.code)){title='You are offline';description='Connect to Wi-Fi or your wired network, then try this page again.';}
  else if([-7,-118].includes(error.code)){title='This website took too long';description='The website did not respond in time. Give it a moment and try again.';symbol='globe';}
  return `<div class="network-error"><div class="error-card"><div class="symbol">${icon(symbol)}</div><h1>${esc(t(title))}</h1><p>${esc(t(description))}</p><code>${esc(error.url)}</code><div class="actions">${button('reload','Try again','data-error="retry" class="primary"')}${button('settings','Network settings','data-error="settings"')}${button('home','Start page','data-error="home"')}</div><details><summary>${esc(t('Technical details'))}</summary><p>${esc(error.description)} · ${error.code}</p></details></div></div>`;
}
function bindError(element){for(const button of element.querySelectorAll('[data-error]'))button.onclick=()=>{if(button.dataset.error==='settings'){settingsCategory='Privacy';invoke('settings');}else invoke(button.dataset.error);};}

function closeSuggestions(){suggestionGeneration++;$$('.suggestions').forEach(element=>element.remove());api.call('overlay',{height:0}).catch(()=>{});}
function suggestions(input,choose){
  let timer=null,list=null,selection=-1,values=[];
  function hide(){clearTimeout(timer);if(list)list.remove();list=null;selection=-1;input.setAttribute('aria-expanded','false');input.removeAttribute('aria-activedescendant');if(input.id==='address')api.call('overlay',{height:0}).catch(()=>{});}
  input.setAttribute('role','combobox');input.setAttribute('aria-autocomplete','list');input.setAttribute('aria-expanded','false');
  input.addEventListener('input',()=>{hide();const generation=++suggestionGeneration,query=input.value,tab=S.active;if(!S.config.suggestions||S.private||!query.trim()||query.length>160||query.includes('://')||query.includes('@'))return;
    timer=setTimeout(async()=>{if(generation!==suggestionGeneration||!document.hasFocus()||document.activeElement!==input)return;try{const result=await api.call('suggest',{query});if(generation!==suggestionGeneration||tab!==S.active||!document.hasFocus()||document.activeElement!==input||query!==input.value||!S.config.suggestions||S.private)return;values=result;if(!values.length)return;
      list=document.createElement('div');list.className='suggestions';list.id='suggestions-'+generation;list.setAttribute('role','listbox');
      for(const [index,text] of values.entries()){const button=document.createElement('button');button.type='button';button.id=list.id+'-'+index;button.innerHTML=icon('search');const span=document.createElement('span');span.textContent=text;button.append(span);button.setAttribute('role','option');button.onmousedown=event=>event.preventDefault();button.onclick=()=>{input.value=text;hide();choose(text);};list.append(button);}
      input.parentElement.append(list);input.setAttribute('aria-controls',list.id);input.setAttribute('aria-expanded','true');
      if(input.id==='address'){const rect=list.getBoundingClientRect(),area=$('#viewport').getBoundingClientRect();api.call('overlay',{height:Math.max(0,rect.bottom-area.top+8)});}
    }catch{}},200);
  });
  input.addEventListener('keydown',event=>{
    if(event.key==='Escape'||event.key==='Tab'){hide();return;}
    if(!list||!values.length)return;
    if(['ArrowDown','ArrowUp'].includes(event.key)){event.preventDefault();selection=selection<0?(event.key==='ArrowDown'?0:values.length-1):(selection+(event.key==='ArrowDown'?1:-1)+values.length)%values.length;[...list.children].forEach((element,index)=>{element.classList.toggle('selected',index===selection);element.setAttribute('aria-selected',String(index===selection));});input.setAttribute('aria-activedescendant',list.children[selection].id);list.children[selection].scrollIntoView({block:'nearest'});}
    else if(event.key==='Enter'&&selection>=0){event.preventDefault();const text=values[selection];input.value=text;hide();choose(text);}
  });
  input.addEventListener('blur',()=>{suggestionGeneration++;hide();});input.form?.addEventListener('submit',()=>{suggestionGeneration++;hide();});
}

function showDialog(title,content,onSubmit,{submit=true,submitLabel='Save',setup=null}={}){
  if(modalResolve)closeDialog(null);
  const layer=$('#modal-layer');layer.hidden=false;layer.innerHTML=`<form class="dialog"><h2>${esc(title)}</h2>${content}<p class="error" data-dialog-error hidden></p><div class="actions"><button type="button" data-cancel>${esc(t('Cancel'))}</button>${submit?`<button type="submit" class="primary">${esc(t(submitLabel))}</button>`:''}</div></form>`;
  api.call('ui_modal',{open:true}).catch(()=>{});const form=layer.querySelector('form');
  form.querySelector('[data-cancel]').onclick=()=>closeDialog(null);
  form.onsubmit=async event=>{event.preventDefault();const error=form.querySelector('[data-dialog-error]'),button=form.querySelector('[type=submit]');if(button)button.disabled=true;form.dataset.busy='true';form.querySelector('[data-cancel]').disabled=true;error.hidden=true;
    try{const result=onSubmit?await onSubmit(form):true;if(result!==false)closeDialog(result);}catch(problem){error.textContent=problem.message;error.hidden=false;}finally{delete form.dataset.busy;if(button)button.disabled=false;form.querySelector('[data-cancel]').disabled=false;}};
  if(setup)setup(form);setTimeout(()=>form.querySelector('input:not([type=checkbox]),select,button')?.focus(),0);
  return new Promise(resolve=>{modalResolve=resolve;});
}
function closeDialog(value){const layer=$('#modal-layer');for(const input of layer.querySelectorAll('input[type=password]'))input.value='';layer.hidden=true;layer.replaceChildren();api.call('ui_modal',{open:false}).catch(()=>{});const resolve=modalResolve;modalResolve=null;resolve?.(value);}
async function confirm(title,message,submitLabel='Continue'){return !!await showDialog(t(title),`<p>${esc(t(message))}</p>`,()=>true,{submitLabel});}
async function bookmarkDialog(entry=null){const pane=currentPane();if(!entry&&!/^https?:/.test(pane?.url||'')){toast(t('Open a website before adding a bookmark.'));return;}
  const existing=entry||S.bookmarks.find(value=>value.url===pane.url)||{url:pane.url,title:pane.title,folder:'Bookmarks toolbar'};
  return showDialog(t('Bookmark'),`<label class="field">${esc(t('Name'))}<input name="title" value="${esc(existing.title)}" required></label><label class="field">${esc(t('Address'))}<input name="url" value="${esc(existing.url)}" required></label><label class="field">${esc(t('Folder'))}<input name="folder" list="bookmark-folders" value="${esc(existing.folder||'Bookmarks toolbar')}"><datalist id="bookmark-folders"><option>Bookmarks toolbar</option><option>Other bookmarks</option>${[...new Set(S.bookmarks.map(value=>value.folder))].map(value=>`<option>${esc(value)}</option>`).join('')}</datalist></label>`,async form=>{await api.call('bookmarks_save',{url:form.elements.url.value,title:form.elements.title.value,folder:form.elements.folder.value,original_url:existing.url});return true;});
}
async function editShortcut(id=null){const entry=S.shortcuts.find(value=>value.id===id)||{id:crypto.randomUUID(),title:'',url:'https://'};
  await showDialog(t('Shortcut'),`<label class="field">${esc(t('Name'))}<input name="title" required value="${esc(entry.title)}"></label><label class="field">${esc(t('Address'))}<input name="url" required value="${esc(entry.url)}"></label>`,async form=>{const value={id:entry.id,title:form.elements.title.value,url:form.elements.url.value};const entries=S.shortcuts.map(({icon,...entry})=>entry);const index=entries.findIndex(entry=>entry.id===value.id);if(index>=0)entries[index]=value;else entries.push(value);await api.call('shortcuts',entries);return true;});
}
async function customizeHome(){
  await showDialog(t('Customize the start page'),`<div class="shortcut-editor">${S.shortcuts.map(entry=>`<div class="list-row"><img src="${esc(entry.icon)}" alt=""><span class="list-label">${esc(entry.title)}</span><button type="button" data-up="${esc(entry.id)}" title="${esc(t('Move up'))}">${icon('chevron-up')}</button><button type="button" data-down="${esc(entry.id)}" title="${esc(t('Move down'))}">${icon('chevron-down')}</button></div>`).join('')}</div><div class="note">${esc(t('Use the edit and remove buttons on each shortcut to change it.'))}</div><label class="field">${esc(t('Columns'))}<input name="columns" type="number" min="2" max="8" value="${S.config.home_columns}"></label><label class="field">${esc(t('Tile size'))}<input name="size" type="number" min="72" max="200" value="${S.config.home_tile_size}"></label>${[['logo','Logo'],['search','Search field'],['stats','Privacy counters'],['ip','Show public IP (contacts ipify)']].map(([key,label])=>`<label><input name="${key}" type="checkbox" ${S.config['home_'+key]?'checked':''}>${esc(t(label))}</label>`).join('')}`,async form=>{await api.call('settings_apply',{home_columns:Number(form.elements.columns.value),home_tile_size:Number(form.elements.size.value),home_logo:form.elements.logo.checked,home_search:form.elements.search.checked,home_stats:form.elements.stats.checked,home_ip:form.elements.ip.checked});return true;},{submitLabel:'Apply',setup:form=>{
    for(const element of form.querySelectorAll('[data-up],[data-down]'))element.onclick=async()=>{const id=element.dataset.up||element.dataset.down,delta=element.dataset.up?-1:1,entries=S.shortcuts.map(({icon,...entry})=>entry),index=entries.findIndex(entry=>entry.id===id),next=index+delta;if(next<0||next>=entries.length)return;[entries[index],entries[next]]=[entries[next],entries[index]];await api.call('shortcuts',entries);const row=element.closest('.list-row'),sibling=delta<0?row.previousElementSibling:row.nextElementSibling;if(sibling)delta<0?sibling.before(row):sibling.after(row);};
  }});
}

const META={
 General:[
  ['Search and language',[['language','Language','', 'select'],['search','Search engine','', 'select'],['suggestions','Search suggestions','Typed queries are sent to DuckDuckGo when this is on. Suggestions stay off in private windows.']]],
  ['Startup and tabs',[['homepage','Open new tabs with','Enter supersearch:start for the built-in start page.'],['restore_tabs','Restore saved tabs on the next launch','Reopen saved ordinary tabs. Pinned tabs are remembered separately; private tabs are not saved.'],['confirm_close','Confirm before closing a window']]],
  ['History and bookmarks',[['remember_history','Save browsing history','Keep a local list of visited pages. Private windows are never recorded.'],['bookmark_bar','Show the bookmarks toolbar']]],
 ],
 Privacy:[],
 Appearance:[
  ['Theme',[['theme','Theme','The theme changes browser controls. Websites keep their own colors.','select']]],
  ['Text and size',[['font','Font'],['ui_scale','Size of browser controls','', 'number',75,175],['page_zoom','Website zoom','', 'number',25,250],['animations','Interface animations']]],
  ['Window and full screen',[['titlebar_show_expand','Show the expand button in the title bar'],['window_expand_mode','Expand button and title bar double-click','Maximize keeps system panels visible. Full screen hides them. F11 always enters full screen.','select'],['titlebar_system_status','Show time and battery only in full screen','Hidden in normal and maximized windows. Charge is shown only when a battery is detected.'],['titlebar_show_title','Show the title in the title bar'],['titlebar_accent','Use the surface color for the title bar'],['titlebar_height','Title bar height','', 'number',28,64]]],
  ['Start page',[['home_logo','Show the logo'],['home_search','Show the search field'],['home_stats','Show privacy counters'],['home_ip','Show public IP on the start page','Contacts ipify through your current proxy or Tor when the start page is visible. The address stays in memory. Turn this off to avoid these requests.']]],
  ['Start page layout',[['home_align','Content alignment','', 'select'],['home_columns','Shortcut columns','', 'number',2,8],['home_tile_size','Shortcut tile size','', 'number',72,200],['home_width','Start page content width','', 'number',600,1600]],true],
  ['Panels and toolbar',[['sidebar_position','Tab panel position','', 'select'],['navigation_position','Address bar position','', 'select'],['sidebar_width','Tab panel width','', 'number',160,640],['sidebar_collapsed','Collapse tab panel'],['tab_height','Tab height','', 'number',32,88],['icon_size','Icon size','', 'number',16,48],['toolbar_size','Address bar height','', 'number',24,64],['split_ratio','Split view size','', 'number',20,80]],true],
  ['Fine-tune spacing and corners',[['shape','Control shape','', 'select'],['radius','Corner roundness','', 'number',0,40],['spacing','Spacing','', 'number',0,24]],true],
 ]
};
const CATEGORIES=[['General','settings','Search, language, startup and everyday browsing.'],['Privacy','shield','Choose how SuperSearch protects your browsing.'],['Appearance','image','Make the browser comfortable to look at and use.'],['Storage','storage','Import your data, clean up or start over.'],['Extensions','puzzle','Manage optional tools and trusted website customizations.'],['Statistics','chart','See which tracking requests have been blocked.'],['About','info','Version, browser engine and privacy documents.']];
function options(key){return {language:Object.entries(B.languages),search:['DuckDuckGo','Google','Brave','Wikipedia'],theme:[['light','Light'],['dark','Dark'],['oled','Pure black']],doh:['Off','Cloudflare','Quad9','Google'],preset:Object.entries(B.preset_labels),window_expand_mode:[['maximized','Maximize window'],['fullscreen','Full screen']],home_align:[['center','Centered'],['top','Near the top']],shape:[['rounded','Rounded'],['pill','Pill'],['square','Square']],sidebar_position:[['left','Left'],['right','Right'],['top','Top'],['bottom','Bottom']],navigation_position:[['top','Top'],['bottom','Bottom']]}[key]||[];}
function settingRow(entry){
  const [key,label,description='',type,min,max]=entry,value=settingsDraft[key],isBoolean=typeof value==='boolean'||key==='suggestions';let control;
  if(isBoolean)control=`<input type="checkbox" class="switch" data-setting="${key}" id="setting-${key}" ${value?'checked':''} aria-label="${esc(t(label))}">`;
  else if(type==='select')control=`<select data-setting="${key}" id="setting-${key}">${options(key).map(option=>{const [value,title]=Array.isArray(option)?option:[option,option];return `<option value="${esc(value)}" ${settingsDraft[key]===value?'selected':''}>${esc(key==='language'?title:t(title))}</option>`;}).join('')}</select>`;
  else control=`<input data-setting="${key}" id="setting-${key}" type="${type==='number'?'number':'text'}" value="${esc(value)}" ${min!==undefined?`min="${min}" max="${max}"`:''}>`;
  return `<div class="setting-row ${isBoolean?'toggle':''}" data-search="${esc((key+' '+label+' '+description+' '+t(label)+' '+t(description)).toLowerCase())}"><label class="setting-caption" for="setting-${key}">${esc(t(label))}${description?`<small>${esc(t(description))}</small>`:''}${RESTART.has(key)?`<span class="restart">${esc(t('Restart required'))}</span>`:''}</label>${control}</div>`;
}
function settingsHTML(wizard=false){
  settingsDraft??=structuredClone(S.config);
  return `${wizard?'':`<div class="screen-title">${button('back','Back','data-screen-back')}<h1>${esc(t('Settings'))}</h1></div>`}<input class="settings-search" id="settings-search" placeholder="${esc(t('Find a setting'))}" value="${esc(settingsQuery)}"><div class="settings-body"><nav class="settings-nav">${CATEGORIES.map(([name,symbol])=>`<button data-category="${name}" class="${settingsCategory===name?'active':''}" title="${esc(t(name))}">${icon(symbol)}<span class="label">${esc(t(name))}</span></button>`).join('')}</nav><div class="settings-content" id="settings-content"></div></div>${wizard?'':`<footer class="settings-footer"><span class="status" id="settings-status"></span><button data-settings="restart" ${S.restart?'':'hidden'}>${esc(t('Restart'))}</button><button data-settings="cancel">${esc(t('Cancel'))}</button><button class="primary" data-settings="apply">${esc(t('Apply'))}</button></footer>`}`;
}
function categoryCards(name){
  if(name==='Privacy'){
    const keys=group=>group.map(key=>[key,...B.privacy_options[key]]);
    return [['Protection level',[['preset','Protection level',B.preset_help[settingsDraft.preset],'select']]],
      ['Everyday protection',keys(['block_ads','https_only','strip_params','block_referrers','gpc'])],
      ['Website data',keys(['ephemeral_profile','third_party'])],
      ['Connection details',[...keys(['tor']),['doh','Secure DNS provider','', 'select'],['proxy','Proxy address','socks5://127.0.0.1:1080']],true],
      ['Advanced website protections',keys(['fingerprint','webrtc','geolocation','javascript','webgl','canvas','allow_popups']),true]];
  }
  return META[name]||[];
}
function renderSettingsContent(){
  const host=$('#settings-content');if(!host)return;
  const summary=CATEGORIES.find(entry=>entry[0]===settingsCategory)?.[2]||'';
  const cards=categoryCards(settingsCategory);
  host.innerHTML=`<h2>${esc(t(settingsCategory))}</h2><p class="summary">${esc(t(summary))}</p>`+cards.map(([heading,entries,advanced])=>{
    const body=entries.map(settingRow).join('');return advanced?`<details class="settings-card" data-settings-card><summary>${esc(t(heading))}</summary>${body}</details>`:`<section class="settings-card" data-settings-card><h3>${esc(t(heading))}</h3>${body}</section>`;
  }).join('');
  if(settingsCategory==='Privacy')host.insertAdjacentHTML('beforeend',`<section class="settings-card"><p>${esc(t('Website permissions are denied by default.'))}</p><div class="actions">${button('shield','Update filters','data-setting-action="filters"')}${button('globe','Test proxy','data-setting-action="proxy"')}</div><p class="note" data-operation-result hidden></p></section>`);
  if(settingsCategory==='General')host.insertAdjacentHTML('beforeend',`<section class="settings-card"><h3>${esc(t('Passwords and shortcuts'))}</h3><div class="actions">${button('key','Password manager','data-setting-action="passwords"')}${button('info','Keyboard shortcuts','data-setting-action="shortcuts"')}</div></section>`);
  if(settingsCategory==='Appearance'){
    const palette={...B.palettes[settingsDraft.theme],...settingsDraft.colors};
    host.insertAdjacentHTML('beforeend',`<details class="settings-card"><summary>${esc(t('Custom colors'))}</summary><div class="color-controls">${[['bg','Background'],['panel','Surface'],['fg','Text'],['accent','Accent']].map(([key,label])=>`<label>${esc(t(label))}<input type="color" data-color="${key}" value="${esc(palette[key])}"></label>`).join('')}</div></details><section class="settings-card"><h3>${esc(t('Start page'))}</h3><div class="actions">${button('settings','Edit shortcuts and wallpaper','data-setting-action="home"')}${button('image','Choose wallpaper','data-setting-action="wallpaper"')}${button('reload','Reset background','data-setting-action="wallpaper-reset"')}${button('settings','Move panels with the mouse','data-setting-action="move-panels"')}</div></section><details class="settings-card"><summary>${esc(t('Address bar buttons'))}</summary><p>${esc(t('Drag rows to change the order. Uncheck a button to hide it.'))}</p><div class="toolbar-order">${settingsDraft.nav_order.map(key=>`<button type="button" draggable="true" data-nav="${key}" class="${settingsDraft.nav_hidden.includes(key)?'off':''}">${esc(t(key==='address'?'Address':key[0].toUpperCase()+key.slice(1)))}</button>`).join('')}</div></details>`);
  }
  if(settingsCategory==='Storage')renderStorage(host);
  if(settingsCategory==='Extensions')renderExtensions(host);
  if(settingsCategory==='Statistics')renderStatistics(host);
  if(settingsCategory==='About')renderAbout(host);
  bindSettings(host);filterSettings(false);updateSettingsFooter();
}
function bindSettings(host){
  for(const element of host.querySelectorAll('[data-setting]'))element.onchange=async()=>{
    const key=element.dataset.setting;settingsEdited.add(key);settingsDraft[key]=element.type==='checkbox'?element.checked:element.type==='number'?Number(element.value):element.value;settingsStatus='';
    if(key==='preset'){Object.assign(settingsDraft,B.presets[settingsDraft.preset]);Object.keys(B.presets[settingsDraft.preset]).forEach(key=>settingsEdited.add(key));}if(key==='theme'){settingsDraft.colors={};settingsEdited.add('colors');}
    if(!S.config.onboarding_complete){try{await api.call('settings_apply',{[key]:settingsDraft[key],...(key==='theme'?{colors:{}}:key==='preset'?B.presets[settingsDraft.preset]:{})});}catch(error){settingsStatus=error.message;}}
    if(key==='preset'||key==='theme')renderSettingsContent();else updateSettingsFooter();
  };
  for(const input of host.querySelectorAll('[data-color]'))input.onchange=()=>{settingsEdited.add('colors');settingsDraft.colors={...settingsDraft.colors,[input.dataset.color]:input.value};updateSettingsFooter();};
  for(const element of host.querySelectorAll('[data-setting-action]'))element.onclick=async()=>{
    const action=element.dataset.settingAction;try{
      if(action==='passwords')invoke('passwords');if(action==='shortcuts')keyboardHelp();if(action==='home')customizeHome();if(action==='move-panels'){await invoke('web');beginCustomization();}
      if(action==='wallpaper'){wallpaper=await invoke('wallpaper')||wallpaper;settingsDraft.wallpaper=S.config.wallpaper;applyWallpaper();}
      if(action==='wallpaper-reset'){await invoke('wallpaper_reset');wallpaper='';settingsDraft.wallpaper='';applyWallpaper();}
      if(action==='filters'||action==='proxy'){
        element.disabled=true;const result=host.querySelector('[data-operation-result]');result.hidden=false;result.textContent=t('Connecting…');
        try{const value=await api.call(action==='filters'?'filters_update':'proxy_test',action==='proxy'?{proxy:settingsDraft.proxy,tor:settingsDraft.tor}:{});result.textContent=action==='proxy'?'IP: '+value:`${value.rules.toLocaleString()} ${t('blocking rules')} · ${value.skipped.toLocaleString()} ${t('unsupported rules skipped')}`;}catch(error){result.textContent=error.message;}finally{element.disabled=false;}
      }
    }catch(error){toast(error.message);}
  };
  let dragKey=null;for(const button of host.querySelectorAll('[data-nav]')){
    button.ondragstart=()=>{dragKey=button.dataset.nav;};button.ondragover=event=>event.preventDefault();button.ondrop=event=>{event.preventDefault();if(!dragKey)return;const values=settingsDraft.nav_order.filter(key=>key!==dragKey),index=values.indexOf(button.dataset.nav);values.splice(index,0,dragKey);settingsDraft.nav_order=values;settingsEdited.add('nav_order');renderSettingsContent();};
    button.onclick=()=>{const key=button.dataset.nav;if(['address','menu'].includes(key))return;settingsEdited.add('nav_hidden');settingsDraft.nav_hidden=settingsDraft.nav_hidden.includes(key)?settingsDraft.nav_hidden.filter(value=>value!==key):[...settingsDraft.nav_hidden,key];button.classList.toggle('off',settingsDraft.nav_hidden.includes(key));updateSettingsFooter();};
  }
}
function dirtySettings(){return settingsDraft?[...settingsEdited].filter(key=>JSON.stringify(settingsDraft[key])!==JSON.stringify(S.config[key])):[];}
function updateSettingsFooter(){const label=$('#settings-status');if(!label)return;const dirty=dirtySettings();label.textContent=settingsStatus||t(dirty.length===1?'1 unsaved change':dirty.length?'{count} unsaved changes':S.restart?'Saved. Restart to finish applying these changes.':'All changes saved.').replace('{count}',dirty.length);const apply=$('[data-settings=apply]');if(apply)apply.disabled=!dirty.length;$('[data-settings=restart]').hidden=!S.restart;}
function bindSettingsShell(){
  for(const element of $$('[data-category]'))element.onclick=()=>{settingsCategory=element.dataset.category;renderSettingsContent();$$('[data-category]').forEach(value=>value.classList.toggle('active',value===element));};
  $('#settings-search').oninput=event=>{settingsQuery=event.target.value;filterSettings(true);};
  $('[data-screen-back]')?.addEventListener('click',()=>invoke('web'));
  $('[data-settings=cancel]')?.addEventListener('click',()=>{settingsDraft=null;settingsEdited.clear();settingsStatus='';invoke('web');});
  $('[data-settings=apply]')?.addEventListener('click',async()=>{try{const changes=Object.fromEntries(dirtySettings().map(key=>[key,settingsDraft[key]]));const result=await api.call('settings_apply',changes);S.config=result.config;settingsDraft=structuredClone(result.config);settingsEdited.clear();settingsStatus='';renderSettingsContent();updateSettingsFooter();}catch(error){settingsStatus=error.message;updateSettingsFooter();}});
  $('[data-settings=restart]')?.addEventListener('click',()=>invoke('restart'));
}
function filterSettings(jump){
  const normalize=value=>String(value).toLowerCase().normalize('NFD').replace(/\p{Diacritic}/gu,'');
  const query=normalize(settingsQuery.trim()),terms=query.split(/\s+/).filter(Boolean),matches=text=>terms.every(term=>normalize(text).includes(term));
  const extras={General:['Passwords and shortcuts','Password manager','Keyboard shortcuts'],Privacy:['Test proxy','Update filters'],Appearance:['Custom colors','Wallpaper','Address bar buttons'],Storage:['Storage','Export browser data','Restore browser data','Backup password','Import from another browser','Reset browser',...CLEANUP.flatMap(([,label,help])=>[label,help])],Extensions:['Extensions','User scripts and styles','JavaScript CSS UserScripts','Local extensions'],Statistics:['Statistics','Tracking requests blocked','Top blocked domains'],About:['About','Source code','GitHub Chromium Electron version','Privacy Policy','User Agreement','Browser tour']};
  const extraText=name=>(extras[name]||[]).map(text=>text+' '+t(text)).join(' ');
  const searchable=name=>[name,t(name),extraText(name),...categoryCards(name).flatMap(([heading,entries])=>[heading,t(heading),...entries.flatMap(([key,label,help=''])=>[key,label,t(label),help,t(help)])])].join(' ');
  if(query&&jump&&!matches(searchable(settingsCategory))){const next=CATEGORIES.find(([name])=>matches(searchable(name)));if(next){settingsCategory=next[0];renderSettingsContent();$$('[data-category]').forEach(button=>button.classList.toggle('active',button.dataset.category===settingsCategory));return;}}
  const host=$('#settings-content');if(!host)return;host.querySelector('[data-no-settings]')?.remove();
  let count=0;const context=settingsCategory+' '+t(settingsCategory);
  for(const row of host.querySelectorAll('.setting-row[data-search]')){row.hidden=!!query&&!matches(row.dataset.search+' '+context);if(!row.hidden){count++;if(query){const details=row.closest('details');if(details){if(!details.hasAttribute('data-before-search'))details.dataset.beforeSearch=String(details.open);details.open=true;}}}}
  for(const card of host.querySelectorAll('[data-settings-card]'))card.hidden=!!query&&![...card.querySelectorAll('.setting-row')].some(row=>!row.hidden);
  for(const card of host.querySelectorAll('.settings-card:not([data-settings-card])'))card.hidden=!!query&&!matches(card.textContent+' '+extraText(settingsCategory)+' '+context);
  if(!query)for(const details of host.querySelectorAll('details[data-before-search]')){details.open=details.dataset.beforeSearch==='true';delete details.dataset.beforeSearch;}
  if(query&&!count&&!matches(extraText(settingsCategory)+' '+context))host.insertAdjacentHTML('beforeend',`<div class="empty" data-no-settings>${esc(t('No settings found. Try another word or clear the search.'))}</div>`);
}

const CLEANUP=[['cookies','Cookies and website data','Signs you out of websites. Your online accounts are not deleted.'],['cache','Temporary files (cache)','Remove saved page resources. Websites may load more slowly at first.'],['accounts','Saved passwords','Delete the local password vault and its master password.'],['history','History and statistics','Remove browsing history, saved tab sessions and blocking totals.'],['bookmarks','Bookmarks','Remove saved website bookmarks.'],['pinned_tabs','Pinned tabs','Forget tabs pinned for future launches.'],['downloads','Download history','Remove the list of downloads. Files are kept.'],['download_files','Downloaded files','Delete only files recorded as unchanged SuperSearch downloads.']];
function renderStorage(host){host.insertAdjacentHTML('beforeend',`<section class="settings-card"><h3>${esc(t('Backup and transfer'))}</h3><p>${esc(t('Keep an encrypted copy of your SuperSearch data or move it to another device.'))}</p><p>${esc(t('Includes bookmarks, the encrypted password vault, history, saved settings, tabs, statistics, shortcuts and wallpaper. Website sessions, cache, extensions and downloaded files are not transferred.'))}</p><div class="actions">${button('download','Export browser data','data-backup-export')}${button('import','Restore browser data','data-backup-restore')}</div></section><section class="settings-card"><h3>${esc(t('Clean up local data'))}</h3><p>${esc(t('Choose what to remove. Deletion happens only after you confirm.'))}</p><p>${esc(t('The browser restarts after cleanup so cookies and cached files can be removed safely.'))}</p>${CLEANUP.map(([key,label,help])=>`<label class="setting-row"><span class="setting-caption">${esc(t(label))}<small>${esc(t(help))}</small></span><input type="checkbox" data-clean="${key}"></label>`).join('')}<button class="danger" data-clean-button disabled>${esc(t('Delete selected data'))}</button></section><section class="settings-card"><h3>${esc(t('Import from another browser'))}</h3><p>${esc(t('Bring bookmarks and supported data from a Chromium browser.'))}</p>${button('import','Import data','data-import-button')}</section><section class="settings-card"><h3>${esc(t('Start over'))}</h3><p>${esc(t('Remove data from this browser profile and start setup again.'))}</p><button class="danger" data-reset>${esc(t('Reset browser'))}</button></section>`);
  host.querySelector('[data-backup-export]').onclick=exportBackup;
  host.querySelector('[data-backup-restore]').onclick=restoreBackup;
  for(const element of host.querySelectorAll('[data-clean]'))element.onchange=()=>host.querySelector('[data-clean-button]').disabled=!host.querySelector('[data-clean]:checked');
  host.querySelector('[data-clean-button]').onclick=async()=>{const categories=[...host.querySelectorAll('[data-clean]:checked')].map(element=>element.dataset.clean),names=categories.map(key=>t(CLEANUP.find(row=>row[0]===key)[1]));if(await showDialog(t('Delete selected data'),`<p>${esc(t('The following data will be deleted:'))}</p><ul>${names.map(name=>'<li>'+esc(name)+'</li>').join('')}</ul>`,()=>true,{submitLabel:'Delete'}))invoke('maintenance',{categories});};
  host.querySelector('[data-reset]').onclick=()=>showDialog(t('Reset browser'),`<p>${esc(t('This deletes bookmarks, saved passwords, history, shortcuts, scripts, settings and website data in this engine profile. The browser will restart as a first launch.'))}</p><label class="field">${esc(t('Type Delete to confirm'))}<input name="confirmation" autocomplete="off" required></label>`,async form=>{if(form.elements.confirmation.value!=='Delete')throw Error(t('Type Delete to confirm'));await api.call('maintenance',{categories:['reset','download_files'],confirmation:'Delete'});return true;},{submitLabel:'Delete'});
  host.querySelector('[data-import-button]').onclick=()=>importDialog();
}
async function exportBackup(){
  await showDialog(t('Export browser data'),`<p>${esc(t('The export is encrypted with a backup password. Keep this password somewhere safe; it cannot be recovered.'))}</p><p class="note">${esc(t('Only saved settings are exported. Your password vault keeps its existing master password.'))}</p><label class="field">${esc(t('Backup password'))}<input name="password" type="password" minlength="12" maxlength="1024" autocomplete="new-password" required></label><label class="field">${esc(t('Repeat backup password'))}<input name="repeat" type="password" minlength="12" maxlength="1024" autocomplete="new-password" required></label>`,async form=>{if(form.elements.password.value!==form.elements.repeat.value)throw Error(t('Passwords do not match.'));const result=await api.call('backup_export',{password:form.elements.password.value});if(!result)return false;toast(t('Encrypted backup saved.'));return true;},{submitLabel:'Choose where to save'});
}
async function restoreBackup(){
  const choice=await invoke('backup_choose');if(!choice)return;
  await showDialog(t('Restore browser data'),`<p><strong>${esc(choice.name)}</strong></p><p>${esc(t('Restoring replaces your current browser data and restarts SuperSearch. Existing website sessions will be cleared. Export your current data first if you want to keep it.'))}</p><p class="note">${esc(t('Saved passwords still need the original vault master password. Extensions must be installed again.'))}</p><label class="field">${esc(t('Backup password'))}<input name="password" type="password" maxlength="1024" autocomplete="off" required></label><label><input name="scripts" type="checkbox">${esc(t('Restore trusted UserScripts and styles too'))}</label><label><input name="confirm" type="checkbox" required>${esc(t('I understand that my current browser data will be replaced.'))}</label>`,async form=>{if(!form.elements.confirm.checked)return false;await api.call('backup_restore',{token:choice.token,password:form.elements.password.value,include_scripts:form.elements.scripts.checked,confirmation:'Replace',accepted_terms:agreement?'2026-11-02':''});return true;},{submitLabel:'Restore and restart'});
}
async function importHTML(){detectedProfiles??=await api.call('profiles');return `<label class="field">${esc(t('Browser profile'))}<select name="profile"><option value="">${esc(t('Choose a detected browser'))}</option>${detectedProfiles.map(([name,value])=>`<option value="${esc(value)}">${esc(name)}</option>`).join('')}</select></label><div class="actions">${button('folder','Choose profile folder','type="button" data-pick-profile')}${button('file','Choose password CSV','type="button" data-pick-csv')}</div><p data-import-path class="muted">${esc(manualProfile||passwordCSV)}</p><div class="inline-options">${[['bookmarks','Bookmarks'],['history','History'],['downloads','Downloads'],['cookies','Cookies'],['preferences','Settings']].map(([key,label])=>`<label><input type="checkbox" name="import-${key}" checked>${esc(t(label))}</label>`).join('')}</div><p class="note">${esc(t('Protected cookies and passwords cannot be read automatically. Password CSV files can be imported into the master-password vault.'))}</p><p data-import-report></p>`;}
function bindImport(form){
  form.querySelector('[data-pick-profile]').onclick=async()=>{manualProfile=await invoke('choose_profile')||manualProfile;form.querySelector('[data-import-path]').textContent=manualProfile;};
  form.querySelector('[data-pick-csv]').onclick=async()=>{passwordCSV=await invoke('choose_csv')||passwordCSV;form.querySelector('[data-import-path]').textContent=passwordCSV;};
}
async function executeImport(form){
  if(passwordCSV&&!await ensureVault())return false;
  const profile=manualProfile||form.querySelector('[name=profile]').value;if(!profile&&!passwordCSV)throw Error(t('Choose a browser profile or a password CSV.'));
  const selected=[...form.querySelectorAll('input[name^="import-"]:checked')].map(element=>element.name.slice(7));
  const result=await api.call('import',{profile:profile||null,csv:passwordCSV||null,selected});
  const report=Object.entries(result.counts).map(([key,value])=>t(key[0].toUpperCase()+key.slice(1))+': '+value).join(' · ')+'\n'+result.notices.join('\n');
  form.querySelector('[data-import-report]').textContent=report;toast(t('Import complete'));return result;
}
async function importDialog(){await showDialog(t('Import from another browser'),await importHTML(),async form=>{await executeImport(form);return false;},{submitLabel:'Import',setup:bindImport});}
function renderExtensions(host){host.insertAdjacentHTML('beforeend',`<section class="settings-card"><h3>${esc(t('Built-in protection'))}</h3><p>${esc(t('Ad blocking, secure connections and link cleanup are already included.'))}</p><p>${icon('check')} ${esc(t('Tracker blocking'))} · ${esc(t('Built-in'))}</p><p>${icon('check')} ${esc(t('Encrypted password vault'))} · ${esc(t('Built-in'))}</p><p>${icon('check')} ${esc(t('Private windows'))} · ${esc(t('Built-in'))}</p></section><section class="settings-card"><h3>${esc(t('User scripts and styles'))}</h3><p>${esc(t('Install only code you trust. Installation and removal apply immediately.'))}</p><div data-script-list></div>${button('import','Install UserScript','data-install-script')}${settingRow(['userscripts_private','Run UserScripts in private windows','Trusted scripts can also read information on private pages when this is on.'])}</section><section class="settings-card"><h3>${esc(t('Local extensions'))}</h3><p>${esc(t('Compatible local extensions require a persistent profile. Chrome Web Store does not install directly into SuperSearch.'))}</p>${button('puzzle','Manage local extensions','data-extensions')}</section>`);
  const scripts=async()=>{const values=await api.call('scripts'),listing=host.querySelector('[data-script-list]');if(!listing)return;listing.innerHTML=values.map(name=>`<div class="list-row"><span class="list-label">${esc(name)}</span><button data-remove-script="${esc(name)}">${icon('trash')}</button></div>`).join('');for(const button of listing.querySelectorAll('[data-remove-script]'))button.onclick=async()=>{await invoke('script_remove',{name:button.dataset.removeScript});scripts();};};scripts();host.querySelector('[data-install-script]').onclick=async()=>{await invoke('script_install');scripts();};host.querySelector('[data-extensions]').onclick=()=>extensionsDialog();
}
async function extensionsDialog(){
  if(S.config.ephemeral_profile){toast(t('Switch to a persistent profile and restart before loading extensions.'));return;}
    const entries=await invoke('extensions_list');
  await showDialog(t('Local extensions'),`<div data-extension-list>${entries.map(entry=>`<div class="list-row"><span class="list-label">${esc(entry.name)}<small>${esc(entry.id)}</small></span>${entry.popup?`<button type="button" data-extension-open="${esc(entry.id)}">${icon('forward')}</button>`:''}<button type="button" data-extension-remove="${esc(entry.id)}">${icon('trash')}</button></div>`).join('')}</div><div class="actions">${button('folder','Install folder','type="button" data-extension-folder')}${button('file','Install ZIP','type="button" data-extension-zip')}</div><p class="note">${esc(t('Extensions may read visited pages and send data over the network. Install only extensions you trust.'))}</p>`,null,{submit:false,setup:form=>{
    for(const [selector,kind] of [['[data-extension-folder]','folder'],['[data-extension-zip]','zip']])form.querySelector(selector).onclick=async()=>{try{const info=await api.call('extension_choose',{kind});if(!info)return;closeDialog(null);if(await confirm('Install this extension?',info.name+'\n'+info.permissions.join(', '),'Install')){await invoke('extension_install',{token:info.token});extensionsDialog();}}catch(error){toast(error.message);}};
    for(const button of form.querySelectorAll('[data-extension-open]'))button.onclick=()=>{closeDialog(null);invoke('extension_open',{id:button.dataset.extensionOpen});};for(const button of form.querySelectorAll('[data-extension-remove]'))button.onclick=async()=>{await invoke('extension_remove',{id:button.dataset.extensionRemove});closeDialog(null);extensionsDialog();};
  }});
}
function renderStatistics(host){const stats=S.stats,maximum=Math.max(1,...stats.daily.map(row=>row[1]));host.insertAdjacentHTML('beforeend',`<section class="settings-card"><h3>${esc(t('Tracking requests blocked'))}</h3><div class="metric">${Number(stats.total).toLocaleString()}</div><div class="chart">${stats.daily.map(([day,count])=>`<div class="chart-day" title="${esc(day)}: ${count}"><small>${count}</small><div class="chart-bar" style="height:${Math.max(2,count/maximum*115)}px"></div><small>${esc(day.slice(8))}</small></div>`).join('')}</div><h3>${esc(t('Top blocked domains'))}</h3><table class="data-table">${stats.top.map(([domain,count])=>`<tr><td>${esc(domain)}</td><td>${count.toLocaleString()}</td></tr>`).join('')}</table></section>`);}
function renderAbout(host){host.insertAdjacentHTML('beforeend',`<section class="settings-card"><div class="about-title"><img class="about-logo" src="${logoURL()}" alt="SuperSearch"><div><h2>SuperSearch ${esc(S.versions.SuperSearch)}</h2><p>${esc(t('Private by choice. Comfortable by design.'))}</p></div></div><h3>${esc(t('Source code'))}</h3><a class="source-link" href="https://github.com/mishandreevy/supersearch" data-source>https://github.com/mishandreevy/supersearch</a><p>${esc(t('SuperSearch brings your everyday web into a personal workspace, with thoughtful privacy controls, secure local storage and an interface that adapts to you.'))}</p><table class="data-table engine-version">${Object.entries(S.versions).map(([key,value])=>`<tr><td>${esc(key)}</td><td>${esc(value)}</td></tr>`).join('')}</table><p class="copyright">MIT · Python + Electron / Chromium · ${esc(t('User data stays on your device.'))}</p></section><section class="settings-card"><h3>${esc(t('Privacy documents'))}</h3><div class="actions">${button('shield','Read Privacy Policy','data-legal="PRIVACY.md"')}${button('file','Read User Agreement','data-legal="TERMS.md"')}</div></section>`);
  host.querySelector('[data-source]').onclick=event=>{event.preventDefault();invoke('source');};for(const button of host.querySelectorAll('[data-legal]'))button.onclick=()=>showLegal(button.dataset.legal);host.insertAdjacentHTML('beforeend',`<section class="settings-card"><h3>${esc(t('Browser tour'))}</h3><p>${esc(t('A short guided tour of tabs, search, privacy and your browser settings.'))}</p>${button('info','Show me around','data-tour')}</section>`);host.querySelector('[data-tour]').onclick=()=>startTour();
}
async function showLegal(name){const text=await invoke('legal',{name});await showDialog(t(name==='TERMS.md'?'User Agreement':'Privacy Policy'),`<div class="legal">${esc(text)}</div>`,null,{submit:false});}

function renderScreen(){
  const screen=$('#screen');if(!S.config.onboarding_complete){screen.hidden=false;const signature='wizard-'+wizardStep+'-'+S.config.language;if(screenSignature!==signature){screenSignature=signature;renderWizard();}return;}
  if(!S.page){screen.hidden=true;screenSignature='';return;}screen.hidden=false;
  const signature=JSON.stringify([S.page,S.config.language,S.page==='downloads'?S.downloads:S.page==='bookmarks'?S.bookmarks:S.page==='history'?S.history:S.page==='passwords'?S.vault:null]);
  if(signature===screenSignature){if(S.page==='settings')updateSettingsFooter();return;}screenSignature=signature;
  if(S.page==='settings'){screen.innerHTML=settingsHTML();bindSettingsShell();renderSettingsContent();return;}
  screen.innerHTML=`<div class="screen-title">${button('back','Back','data-screen-back')}<h1>${esc(t(S.page[0].toUpperCase()+S.page.slice(1)))}</h1><span class="spacer"></span></div><div id="page-content"></div>`;screen.querySelector('[data-screen-back]').onclick=()=>invoke('web');const host=$('#page-content');
  if(S.page==='downloads')renderDownloads(host);if(S.page==='bookmarks'||S.page==='history')renderLibrary(host,S.page==='bookmarks');if(S.page==='passwords')renderPasswords(host);
}
function renderDownloads(host){host.innerHTML=S.downloads.length?S.downloads.map(entry=>`<div class="list-row">${icon('file')}<div class="list-label"><strong>${esc(entry.name||entry.path.split(/[\\/]/).at(-1))}</strong><small>${esc(t(entry.state||'interrupted'))} · ${formatBytes(entry.received||0)} / ${formatBytes(entry.total||0)}</small>${entry.state==='progressing'?`<progress value="${entry.received}" max="${Math.max(1,entry.total)}"></progress>`:''}</div><div class="actions">${entry.state==='progressing'?`<button data-download="${esc(entry.id)}" data-action="${entry.paused?'resume':'pause'}">${icon(entry.paused?'play':'pause')}</button><button data-download="${esc(entry.id)}" data-action="cancel">${icon('close')}</button>`:''}<button data-download="${esc(entry.id)}" data-action="folder" title="${esc(t('Show in folder'))}">${icon('folder')}</button></div></div>`).join(''):`<div class="empty">${esc(t('No downloads yet.'))}</div>`;for(const button of host.querySelectorAll('[data-download]'))button.onclick=()=>invoke('download_action',{id:button.dataset.download,action:button.dataset.action});}
function formatBytes(value){if(value<1024)return value+' B';if(value<1048576)return (value/1024).toFixed(1)+' KB';return (value/1048576).toFixed(1)+' MB';}
function renderLibrary(host,bookmarks){
  const entries=bookmarks?S.bookmarks:S.history;host.innerHTML=`<input class="settings-search" placeholder="${esc(t('Search'))}" data-library-search>`+(entries.length?entries.map((entry,index)=>`<div class="list-row" data-library-row><div class="list-label"><strong>${esc(entry.title)}</strong><small>${esc(entry.url)}${bookmarks?' · '+esc(entry.folder||''):''}</small></div><div class="actions"><button data-open="${index}">${icon('forward')}</button>${bookmarks?`<button data-edit-bookmark="${index}">${icon('edit')}</button><button data-remove-bookmark="${index}">${icon('trash')}</button>`:''}</div></div>`).join(''):`<div class="empty">${esc(t('Nothing saved here yet.'))}</div>`);
  host.querySelector('[data-library-search]').oninput=event=>{const query=event.target.value.toLowerCase();for(const row of host.querySelectorAll('[data-library-row]'))row.hidden=!row.textContent.toLowerCase().includes(query);};for(const button of host.querySelectorAll('[data-open]'))button.onclick=()=>invoke('navigate',{text:entries[button.dataset.open].url});for(const button of host.querySelectorAll('[data-edit-bookmark]'))button.onclick=()=>bookmarkDialog(entries[button.dataset.editBookmark]);for(const button of host.querySelectorAll('[data-remove-bookmark]'))button.onclick=()=>invoke('bookmarks_remove',{url:entries[button.dataset.removeBookmark].url});
}
async function ensureVault(){
  if(S.private){toast(t('The password manager is unavailable in private windows.'));return false;}
  const status=await api.call('vault_status');if(status.unlocked)return true;
  return !!await showDialog(t(status.exists?'Unlock passwords':'Create a master password'),`<p>${esc(t(status.exists?'Enter your master password to unlock locally saved passwords.':'Choose at least 12 characters. Your master password protects the local password vault.'))}</p><label class="field">${esc(t('Master password'))}<input name="master" type="password" minlength="${status.exists?1:12}" autocomplete="off" required></label>${status.exists?'':`<label class="field">${esc(t('Repeat master password'))}<input name="repeat" type="password" autocomplete="off" required></label>`}`,async form=>{if(!status.exists&&form.elements.master.value!==form.elements.repeat.value)throw Error(t('Passwords do not match.'));await api.call(status.exists?'vault_unlock':'vault_create',{password:form.elements.master.value});form.elements.master.value='';if(form.elements.repeat)form.elements.repeat.value='';return true;},{submitLabel:status.exists?'Unlock':'Create'});
}
function renderPasswords(host){
  if(S.private){host.innerHTML=`<p class="note">${esc(t('The password manager is unavailable in private windows.'))}</p>`;return;}
  host.innerHTML=`<div class="actions">${button('key','Unlock passwords','data-unlock')}${button('lock','Lock vault','data-lock')}${button('plus','Add password','data-add-password')}${button('key','Change master password','data-change-master')}</div><p class="note">${esc(t('Passwords are encrypted locally. Filling checks the complete website origin.'))}</p><div data-password-list></div>`;
  const refresh=async()=>{const status=await api.call('vault_status'),listing=host.querySelector('[data-password-list]');if(!listing)return;if(!status.unlocked){listing.innerHTML=`<div class="empty">${esc(t('The vault is locked.'))}</div>`;return;}
    const entries=await api.call('vault_list');listing.innerHTML=entries.length?entries.map((entry,index)=>`<div class="list-row"><div class="list-label"><strong>${esc(entry.origin)}</strong><small>${esc(entry.username)}</small></div><div class="actions"><button data-fill-password="${index}" title="${esc(t('Fill password'))}">${icon('key')}</button><button data-edit-password="${index}" title="${esc(t('Edit'))}">${icon('edit')}</button><button data-delete-password="${index}" title="${esc(t('Delete'))}">${icon('trash')}</button></div></div>`).join(''):`<div class="empty">${esc(t('No saved passwords yet.'))}</div>`;
    for(const button of listing.querySelectorAll('[data-fill-password]'))button.onclick=()=>invoke('password_fill',entries[button.dataset.fillPassword]);for(const button of listing.querySelectorAll('[data-edit-password]'))button.onclick=async()=>{await editPassword(await api.call('vault_get',entries[button.dataset.editPassword]));refresh();};for(const button of listing.querySelectorAll('[data-delete-password]'))button.onclick=async()=>{if(await confirm('Delete password?','This removes the saved login from the local vault.','Delete')){await invoke('vault_remove',entries[button.dataset.deletePassword]);refresh();}};
  };
  host.querySelector('[data-unlock]').onclick=async()=>{await ensureVault();refresh();};host.querySelector('[data-lock]').onclick=async()=>{await invoke('vault_lock');refresh();};host.querySelector('[data-add-password]').onclick=async()=>{if(await ensureVault()){await editPassword();refresh();}};host.querySelector('[data-change-master]').onclick=async()=>{if(!await ensureVault())return;await showDialog(t('Change master password'),`<label class="field">${esc(t('New master password'))}<input name="password" type="password" minlength="12" required></label><label class="field">${esc(t('Repeat master password'))}<input name="repeat" type="password" required></label>`,async form=>{if(form.elements.password.value!==form.elements.repeat.value)throw Error(t('Passwords do not match.'));await api.call('vault_change',{password:form.elements.password.value});return true;});};refresh();
}
async function editPassword(entry=null){const previous=entry?[entry.origin,entry.username]:null;
  await showDialog(t('Saved password'),`<label class="field">${esc(t('Website'))}<input name="origin" required value="${esc(entry?.origin||'https://')}"></label><label class="field">${esc(t('Username'))}<input name="username" value="${esc(entry?.username||'')}"></label><label class="field">${esc(t('Password'))}<input name="password" type="password" required autocomplete="off"></label>`,async form=>{await api.call('vault_save',{origin:form.elements.origin.value,username:form.elements.username.value,password:form.elements.password.value,previous});return true;},{setup:form=>{if(entry)form.elements.password.value=entry.password;}});if(entry)entry.password='';
}
function renderOffer(){
  const signature=JSON.stringify(S.passwordOffer);if(signature===offerSignature)return;offerSignature=signature;const host=$('#password-offer');host.hidden=!S.passwordOffer;if(!S.passwordOffer){host.replaceChildren();return;}
  host.innerHTML=`<h3>${icon('key')} ${esc(t('Save password?'))}</h3><p>${esc(S.passwordOffer.origin)} · ${esc(S.passwordOffer.username)}</p><div class="actions"><button data-offer="decline">${esc(t('Not now'))}</button><button class="primary" data-offer="save">${esc(t('Save'))}</button></div>`;
  host.querySelector('[data-offer=decline]').onclick=()=>invoke('password_decline');host.querySelector('[data-offer=save]').onclick=async()=>{if(await ensureVault())invoke('password_save');};requestAnimationFrame(updateBounds);
}
function showClose(){showDialog(t('Close SuperSearch?'),`<div data-close-dialog><p>${esc(t('Are you sure you want to close this window?'))}</p><label><input name="save" type="checkbox" ${S.modal.save?'checked':''}>${esc(t('Keep my tabs for the next launch'))}</label>${S.private?`<p class="muted">${esc(t('Private tabs are never saved.'))}</p>`:''}</div>`,async form=>{await api.call('close_confirm',{save:form.elements.save.checked});return true;},{submitLabel:'Close',setup:form=>{form.querySelector('[data-cancel]').onclick=()=>{closeDialog(null);invoke('close_cancel');};}});}

async function renderWizard(){
  const revision=++wizardRevision;
  const screen=$('#screen'),languageOptions=Object.entries(B.languages).map(([key,label])=>`<option value="${key}" ${S.config.language===key?'selected':''}>${label}</option>`).join('');
  let content='';
  if(wizardStep===0)content=`<div class="symbol">${icon('shield')}</div><h1 class="wizard-hero">${esc(t('Your web. Your choices.'))}</h1><p class="wizard-lead">${esc(t('Discover a calmer, more personal way to browse. SuperSearch brings privacy controls, secure local password storage and a flexible workspace together in one thoughtfully designed browser. Keep your everyday web close, your choices in your hands, and your interface exactly the way you like it.'))}</p><h2>${esc(t('Have you used SuperSearch before?'))}</h2><div class="welcome-choices" role="group" aria-label="${esc(t('Have you used SuperSearch before?'))}">${[['yes','import','Yes, I am returning','Restore my data from a SuperSearch backup.'],['no','globe','No, this is my first time','Set up my browser and choose an optional tour.']].map(([value,symbol,title,help])=>`<button type="button" data-returning="${value}" aria-pressed="${returningUser===(value==='yes')}" class="welcome-choice ${returningUser===(value==='yes')?'chosen':''}">${icon(symbol)}<span><strong>${esc(t(title))}</strong><small>${esc(t(help))}</small></span>${returningUser===(value==='yes')?icon('check'):''}</button>`).join('')}</div>${returningUser===null?`<p class="muted">${esc(t('Choose an option to continue.'))}</p>`:''}`;
  if(wizardStep===1){wizardLegal||=await api.call('legal',{name:'TERMS.md'});content=`<h1>${esc(t('User Agreement'))}</h1><div class="legal">${esc(wizardLegal)}</div><p><button data-wizard-policy>${esc(t('Read Privacy Policy'))}</button></p><label class="setting-row"><span>${esc(t('I accept the User Agreement'))}</span><input id="agreement" type="checkbox" ${agreement?'checked':''}></label>`;}
  if(wizardStep===2)content=returningUser?`<div class="symbol">${icon('import')}</div><h1>${esc(t('Welcome back'))}</h1><p class="wizard-lead">${esc(t('Choose the encrypted file you exported from Settings → Storage. Your data will be restored after a restart.'))}</p><section class="settings-card"><h3>${esc(t('Restore browser data'))}</h3><p>${esc(t('You will need your backup password and, for saved passwords, your original vault master password.'))}</p>${button('folder','Choose SuperSearch backup','data-wizard-restore')}</section><p>${esc(t('No backup file? You can continue with a fresh setup.'))}</p>`:`<div class="symbol">${icon('info')}</div><h1>${esc(t('Let us show you around'))}</h1><p class="wizard-lead">${esc(t('Discover where to search, manage tabs, control privacy and customize your workspace.'))}</p><label class="settings-card tour-choice"><input id="wizard-tour" type="checkbox" ${showTour?'checked':''}><span><strong>${esc(t('Show a short tour after setup'))}</strong><small>${esc(t('You can skip it at any time or open it later in Settings → About.'))}</small></span></label>`;
  if(wizardStep===3){settingsDraft??=structuredClone(S.config);settingsDraft.suggestions??=false;content=`<h1>${esc(t('Make it yours'))}</h1><p>${esc(t('Changes preview immediately. Network settings may require a restart.'))}</p>${settingsHTML(true)}`;}
  if(wizardStep===4)content=`<h1>${esc(t('Bring your browser data'))}</h1><p>${esc(t('Import what you need, or skip this step.'))}</p><form id="wizard-import">${await importHTML()}<button class="primary" type="submit">${esc(t('Import'))}</button></form>`;
  if(revision!==wizardRevision||S.config.onboarding_complete)return;
  const nextLabel=wizardStep===4?'Start browsing':wizardStep===2&&returningUser?'Continue without a backup':'Continue';
  screen.innerHTML=`<div class="wizard"><header class="wizard-header"><img src="${logoURL()}" alt="SuperSearch"><select id="wizard-language" aria-label="Language">${languageOptions}</select></header><div class="steps">${[0,1,2,3,4].map(step=>`<span class="step ${step===wizardStep?'active':''}">${step+1}</span>`).join('')}</div>${content}<footer class="wizard-footer"><button data-wizard-back ${wizardStep===0?'hidden':''}>${esc(t('Back'))}</button><span class="spacer"></span><button class="primary" id="wizard-continue" ${wizardStep===0&&returningUser===null||wizardStep===1&&!agreement?'disabled':''}>${esc(t(nextLabel))}${icon('forward')}</button></footer></div>`;
  $('#wizard-language').onchange=async event=>{await api.call('settings_apply',{language:event.target.value});if(settingsDraft)settingsDraft.language=event.target.value;screenSignature='';renderScreen();};
  for(const choice of $$('[data-returning]'))choice.onclick=()=>{returningUser=choice.dataset.returning==='yes';showTour=!returningUser;screenSignature='';renderScreen();};
  $('[data-wizard-back]').onclick=()=>{wizardStep--;screenSignature='';renderScreen();};
  $('#agreement')?.addEventListener('change',event=>{agreement=event.target.checked;$('#wizard-continue').disabled=!agreement;});
  $('[data-wizard-policy]')?.addEventListener('click',()=>showLegal('PRIVACY.md'));
  $('[data-wizard-restore]')?.addEventListener('click',restoreBackup);
  $('#wizard-tour')?.addEventListener('change',event=>{showTour=event.target.checked;});
  if(wizardStep===3){bindSettingsShell();renderSettingsContent();}
  if(wizardStep===4){const form=$('#wizard-import');bindImport(form);form.onsubmit=async event=>{event.preventDefault();try{await executeImport(form);}catch(error){toast(error.message);}};}
  $('#wizard-continue').onclick=async()=>{try{
    if(wizardStep===0&&returningUser===null||wizardStep===1&&!agreement)return;
    if(wizardStep===3){await api.call('settings_apply',settingsDraft);settingsDraft=null;}
    if(wizardStep<4){wizardStep++;screenSignature='';renderScreen();}
    else{await api.call('settings_apply',{onboarding_complete:true,terms_version:'2026-11-02',suggestions:S.config.suggestions??false,tour_pending:!returningUser&&showTour,tour_completed:!showTour||!!returningUser});screenSignature='';renderScreen();if(S.restart)await api.call('restart');else api.call('home');}
  }catch(error){toast(error.message);}};
}
const TOUR=[
  ['#address','Search and navigate','Type a website address or a search here. Search suggestions stay optional.'],
  ['#tabs','Your tabs','Open tabs with the plus button. Pin tabs, select several with Ctrl or Shift, and close selected tabs with Delete.'],
  ['#shield','Privacy at hand','Open privacy settings here to choose your protection and connection preferences.'],
  ['#bookmark','Keep useful pages','Save the current page with the star or Ctrl+D. Organize bookmarks into folders.'],
  ['#downloads-button','Your downloads','Downloaded files arrive in your Downloads folder. Follow their progress here.'],
  ['#settings-button','Make SuperSearch yours','Change appearance and panels, manage passwords, or export your data in Storage.'],
  ['.home-tools','Your start page','Choose wallpaper and edit shortcuts. Your original logo and privacy statistics stay close at hand.']
];
async function startTour(){
  if(tourRunning||S.private||!S.config.onboarding_complete)return;
  tourRunning=true;tourIndex=0;
  try{if(modalResolve)closeDialog(null);if(currentPane()?.url==='supersearch:start')await api.call('home');else await api.call('new_tab',{url:'supersearch:start'});await api.call('ui_modal',{open:true});drawTour();}catch(error){tourRunning=false;toast(error.message);}
}
function drawTour(){
  if(!tourRunning)return;
  let layer=$('#tour-layer');if(!layer){layer=document.createElement('div');layer.id='tour-layer';layer.setAttribute('role','dialog');layer.setAttribute('aria-modal','true');document.body.append(layer);}
  const [selector,title,description]=TOUR[tourIndex];
  layer.innerHTML=`<div class="tour-focus" aria-hidden="true"></div><section class="tour-card"><small>${tourIndex+1} / ${TOUR.length}</small><h2>${esc(t(title))}</h2><p>${esc(t(description))}</p><div class="actions"><button data-tour-skip>${esc(t('Skip tour'))}</button><span class="spacer"></span><button data-tour-back ${tourIndex===0?'disabled':''}>${esc(t('Back'))}</button><button class="primary" data-tour-next>${esc(t(tourIndex===TOUR.length-1?'Finish tour':'Next'))}</button></div></section>`;
  layer.querySelector('[data-tour-skip]').onclick=finishTour;
  layer.querySelector('[data-tour-back]').onclick=()=>{tourIndex--;drawTour();};
  layer.querySelector('[data-tour-next]').onclick=()=>{if(tourIndex===TOUR.length-1)finishTour();else{tourIndex++;drawTour();}};
  positionTour();layer.querySelector('[data-tour-next]').focus();
}
function positionTour(){
  if(!tourRunning)return;const layer=$('#tour-layer');if(!layer)return;
  const target=$(TOUR[tourIndex][0]),focus=layer.querySelector('.tour-focus');
  if(!target||!target.getBoundingClientRect().width){focus.hidden=true;return;}
  const rect=target.getBoundingClientRect();focus.hidden=false;
  Object.assign(focus.style,{left:Math.max(2,rect.x-4)+'px',top:Math.max(2,rect.y-4)+'px',width:Math.min(innerWidth-8,rect.width+8)+'px',height:Math.min(innerHeight-8,rect.height+8)+'px'});
}
async function finishTour(){
  tourRunning=false;$('#tour-layer')?.remove();await api.call('ui_modal',{open:false});await invoke('settings_apply',{tour_pending:false,tour_completed:true});
}
window.addEventListener('resize',positionTour);
document.addEventListener('keydown',event=>{if(!tourRunning)return;if(event.key==='Escape'){event.preventDefault();finishTour();}if(event.key==='Tab'){const buttons=[...$('#tour-layer').querySelectorAll('button:not(:disabled)')],index=buttons.indexOf(document.activeElement);event.preventDefault();buttons[(index+(event.shiftKey?-1:1)+buttons.length)%buttons.length].focus();}});

function renderClock(){
  const host=$('#system-status'),show=S.fullscreen&&S.config.titlebar_system_status;host.hidden=!show;
  if(!show){if(clockTimer)clearInterval(clockTimer);clockTimer=null;host.replaceChildren();return;}
  const update=()=>{host.innerHTML=`<span>${new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',hour12:false})}</span>`+(S.battery?`${icon(S.battery.charging?'battery-charging':'battery')}<span>${S.battery.percent}%</span>`:'');};update();if(!clockTimer)clockTimer=setInterval(update,1000);
}
async function keyboardHelp(){const keys=[['Ctrl+T','New tab'],['Ctrl+W / Ctrl+F4','Close tab'],['Ctrl+L','Address and search'],['Ctrl+D','Bookmark'],['Ctrl+H','History'],['Ctrl+,','Settings'],['Ctrl+J','Downloads'],['Ctrl+Shift+N','New private window'],['Ctrl+\\','Split view'],['Ctrl+Shift+K','Pin selected tabs'],['Ctrl+Tab / Ctrl+Shift+Tab','Switch tabs'],['Ctrl+1…9','Select tab'],['Ctrl+F','Find on page'],['F11','Full screen'],['F5','Reload'],['Ctrl / Shift + click','Select multiple tabs'],['Delete','Close selected tabs']];await showDialog(t('Keyboard shortcuts'),`<table class="data-table">${keys.map(([key,label])=>`<tr><td><code>${esc(key)}</code></td><td>${esc(t(label))}</td></tr>`).join('')}</table>`,null,{submit:false});}
async function browserMenu(){
  await showDialog(t('Menu'),`<div class="actions">${[['settings','Customize interface','appearance'],['image','Customize start page','home-editor'],['lock','New private window','private'],['download','Downloads','downloads'],['key','Saved passwords','passwords'],['split','Split view','split'],['info','Keyboard shortcuts','keys'],['home','Start page','home'],['fullscreen','Full screen','fullscreen']].map(([symbol,label,action])=>button(symbol,label,`type="button" data-menu-action="${action}"`)).join('')}</div>`,null,{submit:false,setup:form=>{for(const button of form.querySelectorAll('[data-menu-action]'))button.onclick=()=>{const action=button.dataset.menuAction;closeDialog(null);if(action==='appearance'){settingsCategory='Appearance';invoke('settings');}else if(action==='home-editor')customizeHome();else if(action==='keys')keyboardHelp();else invoke(action);};}});
}

$('#address-form').onsubmit=event=>{event.preventDefault();closeSuggestions();invoke('navigate',{text:$('#address').value});};suggestions($('#address'),text=>invoke('navigate',{text}));
for(const [id,action] of Object.entries({minimize:'minimize',expand:'expand',close:'close_window','new-tab':'new_tab',back:'back',forward:'forward',reload:'reload',split:'split','settings-button':'settings','downloads-button':'downloads','bookmarks-button':'bookmarks',passwords:'passwords'}))$('#'+id).onclick=()=>invoke(action);
$('#collapse').onclick=()=>invoke('settings_apply',{sidebar_collapsed:!S.config.sidebar_collapsed});$('#shield').onclick=()=>{settingsCategory='Privacy';invoke('settings');};$('#bookmark').onclick=()=>bookmarkDialog();$('#menu').onclick=()=>browserMenu();
$('#titlebar').ondblclick=event=>{if(!event.target.closest('button'))invoke('expand');};
$('#sidebar').ondblclick=event=>{if(S.config.sidebar_position==='top'&&!event.target.closest('button'))invoke('expand');};
$('#tabs').addEventListener('wheel',event=>{if(['top','bottom'].includes(S.config.sidebar_position)&&Math.abs(event.deltaY)>Math.abs(event.deltaX)){$('#tabs').scrollLeft+=event.deltaY;event.preventDefault();}},{passive:false});
$('#find-text').oninput=event=>api.call('find',{text:event.target.value});$('#find-close').onclick=()=>{$('#find-bar').hidden=true;api.call('stop_find');updateBounds();};
$('#sidebar-resizer').onpointerdown=event=>{
  const handle=event.currentTarget,position=S.config.sidebar_position,horizontal=['top','bottom'].includes(position);
  if(horizontal)return;
  const start=horizontal?event.clientY:event.clientX,key=horizontal?'sidebar_height':'sidebar_width',initial=S.config[key];let value=initial;
  handle.setPointerCapture(event.pointerId);
  handle.onpointermove=move=>{const delta=((horizontal?move.clientY:move.clientX)-start)*(position==='right'||position==='bottom'?-1:1);value=Math.round(Math.max(horizontal?120:160,Math.min(horizontal?600:640,initial+delta)));document.documentElement.style.setProperty(horizontal?'--sidebar-height':'--sidebar',value+'px');updateBounds();};
  handle.onpointerup=()=>{handle.onpointermove=null;invoke('settings_apply',{[key]:value});};
};
function finishCustomization(){customizing=false;document.body.removeAttribute('data-drop-edge');$$('[data-panel-grip]').forEach(element=>element.remove());api.call('ui_modal',{open:false});}
function beginCustomization(){
  if(customizing)return;customizing=true;api.call('ui_modal',{open:true});
  toast(t('Drag a panel handle to a window edge. Press Escape to finish.'));
  for(const [selector,kind] of [['.sidebar-top','sidebar'],['#navigation','navigation']]){
    const grip=document.createElement('button');grip.dataset.panelGrip=kind;grip.innerHTML=icon('menu');grip.title=t('Move panel');$(selector).append(grip);
    grip.onpointerdown=event=>{event.preventDefault();grip.setPointerCapture(event.pointerId);let edge=kind==='sidebar'?S.config.sidebar_position:S.config.navigation_position;
      grip.onpointermove=move=>{const rect=$('#workspace').getBoundingClientRect(),distances={left:move.clientX-rect.left,right:rect.right-move.clientX,top:move.clientY-rect.top,bottom:rect.bottom-move.clientY};edge=Object.keys(distances).filter(key=>kind==='sidebar'||['top','bottom'].includes(key)).sort((a,b)=>distances[a]-distances[b])[0];document.body.dataset.dropEdge=edge;};
      grip.onpointerup=()=>{finishCustomization();invoke('settings_apply',{[kind==='sidebar'?'sidebar_position':'navigation_position']:edge});};
    };
  }
}
document.addEventListener('keydown',event=>{
  if(event.key==='Escape'&&customizing)finishCustomization();
  if(event.key==='Escape'&&modalResolve&&$('#modal-layer form')?.dataset.busy!=='true'){closeDialog(null);if(S.modal)invoke('close_cancel');}
  if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='f'&&$('#settings-search')&&(!S.config.onboarding_complete||S.page==='settings')){event.preventDefault();$('#settings-search')?.focus();}
});
window.addEventListener('blur',closeSuggestions);
api.subscribe(render);
api.event(message=>{
  if(message.type==='error')toast(message.message);
  if(message.type==='settings_find'){$('#settings-search')?.focus();$('#settings-search')?.select();}
  if(message.type==='customize'){invoke('web').then(beginCustomization);}
  if(message.type==='keyboard_help')keyboardHelp();if(message.type==='tour')startTour();
  if(message.type==='focus_address'){$('#address').focus();$('#address').select();}
  if(message.type==='bookmark')bookmarkDialog();if(message.type==='pin_selection')invoke('pin',{ids:selected.size?[...selected]:[S.active]});
  if(message.type==='find'){$('#find-bar').hidden=false;$('#find-text').focus();updateBounds();}
  if(message.type==='download-start'){
    const target=$('#downloads-button'),end=target.getBoundingClientRect(),flight=$('#download-flight');target.classList.add('download-pulse');setTimeout(()=>target.classList.remove('download-pulse'),650);
    if(S.config.animations){flight.innerHTML=icon('file');flight.hidden=false;const animation=flight.animate([{left:(message.click.x/(S.config.ui_scale/100))+'px',top:(message.click.y/(S.config.ui_scale/100))+'px',transform:'scale(1)',opacity:1},{left:(end.x+end.width/2)+'px',top:(end.y+end.height/2)+'px',transform:'scale(.3)',opacity:.2}],{duration:650,easing:'cubic-bezier(.3,.5,.2,1)'});animation.onfinish=()=>flight.hidden=true;}
  }
});
api.call('bootstrap').then(value=>{B=value.bootstrap;render(value.state);api.call('ui_ready');}).catch(error=>{$('#screen').hidden=false;$('#screen').textContent=error.message;});
