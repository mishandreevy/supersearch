"""Private stdio service for the Electron engine. No HTTP server or listening socket."""
import json
import os
import sys
import threading
from pathlib import Path
from urllib.parse import urlsplit
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from settings.config import DATA,ROOT,config,DEFAULTS,PRESETS,PALETTES,WORDS,read_json,write_json
from core.storage import Store
from core.vault import Vault,origin_of
from core.shortcuts import Shortcuts
from core.pins import PinStore
from core.session import load,normalize_tab
from core.importer import discover_profiles,read_profile
from core.maintenance import record_download,schedule
from settings.i18n import LANGUAGES,catalog
from core.icons import PATHS

EXTRA={'sidebar_position':'left','navigation_position':'top','split_ratio':50}


class Service:
    def __init__(self):
        DATA.mkdir(parents=True,exist_ok=True)
        for key,value in EXTRA.items():config.setdefault(key,value)
        self.store=Store();self.vault=Vault();self.shortcuts=Shortcuts(DATA);self.lock=threading.RLock()
        self.vault_timer=None
        self.restore_once=(DATA/'.restore-tabs-once').is_file()

    def arm_vault(self):
        if self.vault_timer:self.vault_timer.cancel()
        def expire():
            with self.lock:self.vault.lock()
        self.vault_timer=threading.Timer(300,expire);self.vault_timer.daemon=True;self.vault_timer.start()

    def state(self):
        total,top,daily=self.store.stats()
        domains=self.store.db.execute('SELECT count(DISTINCT domain) FROM blocks').fetchone()[0]
        return dict(config=dict(config),bookmarks=self.store.bookmarks,history=self.store.history,
                    shortcuts=[dict(entry,icon=self.shortcuts.icon_data(entry,config.palette()['fg'])) for entry in self.shortcuts.entries],
                    stats=dict(total=total,top=top,daily=daily,domains=domains),
                    downloads=read_json(DATA/'downloads.json',[]),
                    vault=dict(exists=self.vault.exists,unlocked=self.vault.unlocked),
                    session=PinStore(DATA).startup(load(DATA) if config['restore_tabs'] or self.restore_once else None))

    def validate_settings(self,changes,base=None):
        if not isinstance(changes,dict):raise ValueError('Invalid settings')
        allowed=dict(DEFAULTS,**EXTRA)
        candidate=dict(config) if base is None else dict(base)
        for key,value in changes.items():
            if key not in allowed:raise ValueError('Unknown setting')
            default=allowed[key]
            if key=='suggestions':valid=isinstance(value,bool) or value is None
            else:valid=type(value) is type(default)
            if not valid:raise ValueError('Invalid value for '+key)
            candidate[key]=value
        if candidate['language'] not in LANGUAGES or candidate['theme'] not in PALETTES:raise ValueError('Invalid language or theme')
        if candidate['search'] not in ('DuckDuckGo','Google','Brave','Wikipedia'):raise ValueError('Invalid search engine')
        if candidate['doh'] not in ('Off','Cloudflare','Quad9','Google'):raise ValueError('Invalid DNS provider')
        proxy=candidate['proxy'].strip();parts=urlsplit(proxy)
        if proxy and (parts.scheme not in ('http','socks4','socks5') or not parts.hostname or not parts.port or parts.username or parts.password or parts.path not in ('','/') or parts.query or parts.fragment or any(c.isspace() for c in proxy)):
            raise ValueError('Enter a proxy address such as socks5://127.0.0.1:1080, without a username or password.')
        candidate['proxy']=proxy
        if candidate['homepage']!='supersearch:start' and not origin_of(candidate['homepage']):raise ValueError('Enter a complete HTTP or HTTPS homepage address.')
        bounds={'ui_scale':(75,175),'page_zoom':(25,250),'radius':(0,40),'spacing':(0,24),'sidebar_width':(160,640),'sidebar_height':(120,600),'tab_height':(32,88),'icon_size':(16,48),'toolbar_size':(24,64),'titlebar_height':(28,64),'home_columns':(2,8),'home_tile_size':(72,200),'home_width':(600,1600),'split_ratio':(20,80)}
        for key,(low,high) in bounds.items():
            if not low<=candidate[key]<=high:raise ValueError('Out-of-range setting: '+key)
        if candidate['shape'] not in ('rounded','pill','square') or candidate['home_align'] not in ('center','top'):raise ValueError('Invalid layout')
        if candidate['sidebar_position'] not in ('left','right','top','bottom') or candidate['navigation_position'] not in ('top','bottom'):raise ValueError('Invalid panel position')
        if candidate['window_expand_mode'] not in ('fullscreen','maximized'):raise ValueError('Invalid window mode')
        import re
        if any(k not in ('bg','panel','fg','accent') or not isinstance(v,str) or not re.fullmatch(r'#[0-9a-fA-F]{6}',v) for k,v in candidate['colors'].items()):raise ValueError('Use hexadecimal theme colors')
        colors=dict(PALETTES[candidate['theme']],**candidate['colors'])
        def luminance(color):
            channels=[int(color[index:index+2],16)/255 for index in (1,3,5)]
            return sum(weight*(channel/12.92 if channel<=.04045 else ((channel+.055)/1.055)**2.4) for channel,weight in zip(channels,(.2126,.7152,.0722)))
        fg=luminance(colors['fg'])
        if any((max(fg,luminance(colors[key]))+.05)/(min(fg,luminance(colors[key]))+.05)<4.5 for key in ('bg','panel')):raise ValueError('Choose colors with enough contrast to keep text readable.')
        nav={'back','forward','reload','address','shield','split','passwords','bookmark','menu'}
        if any(not isinstance(key,str) or key not in nav for key in candidate['nav_order']+candidate['nav_hidden']):raise ValueError('Invalid address-bar buttons.')
        candidate['dark_sites']=False
        return candidate

    def settings(self,changes):
        candidate=self.validate_settings(changes)
        old=dict(config)
        try:
            config.clear();config.update(candidate);config.save()
        except OSError:
            config.clear();config.update(old);raise
        return dict(config)

    def handle(self,operation,data):
        if operation=='bootstrap':
            from settings.metadata import PRIVACY_OPTIONS,PRESET_HELP,PRESET_LABELS
            dictionaries={lang:dict(catalog(lang),**{WORDS['en'][key]:value for key,value in words.items()}) for lang,words in WORDS.items()}
            for language in dictionaries:
                dictionaries[language].update(read_json(ROOT/'engine/translations'/(language+'.json'),{}))
            result=dict(self.state(),defaults=dict(DEFAULTS,**EXTRA),presets=PRESETS,palettes=PALETTES,languages=LANGUAGES,translations=dictionaries,icons=PATHS,privacy_options=PRIVACY_OPTIONS,preset_help=PRESET_HELP,preset_labels=PRESET_LABELS)
            if self.restore_once:(DATA/'.restore-tabs-once').unlink(missing_ok=True);self.restore_once=False
            return result
        if operation=='state':return self.state()
        if operation=='backup_export':
            from core.backup import export_data
            return export_data(DATA,data['path'],data['password'],self.store.db)
        if operation=='backup_restore':
            from core.backup import prepare_restore
            return prepare_restore(data['path'],data['password'],DATA,lambda saved:self.validate_settings(saved,dict(DEFAULTS,**EXTRA)),data.get('include_scripts') is True)
        if operation=='settings':return self.settings(data)
        if operation=='bookmarks_save':
            if not origin_of(data['url']):raise ValueError('Only HTTP and HTTPS bookmarks are supported')
            self.store.save_bookmark(data['url'],data.get('title') or data['url'],data.get('folder','Bookmarks toolbar'),data.get('original_url'));return self.store.bookmarks
        if operation=='bookmarks_remove':self.store.remove_bookmark(data['url']);return self.store.bookmarks
        if operation=='visit':
            if config['remember_history'] and origin_of(data['url']):self.store.visit(data['url'],data.get('title') or data['url'])
            return True
        if operation=='blocks':
            from datetime import date
            with self.store.lock:
                self.store.db.executemany('INSERT INTO blocks VALUES(?,?,?) ON CONFLICT(day,domain) DO UPDATE SET n=n+excluded.n',[(date.today().isoformat(),host,int(count)) for host,count in data.items() if isinstance(host,str) and isinstance(count,int) and count>0])
                self.store.db.commit()
            return self.state()['stats']
        if operation=='shortcuts':self.shortcuts.commit(data);return self.state()['shortcuts']
        if operation=='extension_info':
            from core.extensions import extension_manifest
            return extension_manifest(data['path'])
        if operation=='wallpaper_validate':
            from PIL import Image
            file=Path(data['path'])
            if file.stat().st_size>30*1024*1024:raise ValueError('Choose an image smaller than 30 MB.')
            with Image.open(file) as image:
                if image.width*image.height>80_000_000:raise ValueError('Choose a readable image smaller than 80 megapixels.')
                image.verify()
            return True
        if operation=='extension_prepare':
            import shutil
            from uuid import uuid4
            from zipfile import ZipFile
            from core.extensions import extension_manifest
            source=Path(data['path']);extension_manifest(source)
            destination=DATA/'extensions'/uuid4().hex;destination.parent.mkdir(exist_ok=True)
            if source.is_dir():
                if any(file.is_symlink() for file in source.rglob('*')):raise ValueError('Extension folders must not contain symbolic links')
                shutil.copytree(source,destination)
            else:
                destination.mkdir()
                with ZipFile(source) as archive:archive.extractall(destination)
            return str(destination)
        if operation=='pins':
            records=[normalize_tab(value) for value in data[:100]]
            if any(record is None for record in records):raise ValueError('Invalid pinned tab')
            PinStore(DATA).commit(records);return True
        if operation=='session':
            records=[normalize_tab(value) for value in data.get('tabs',[])[:100]]
            if records and all(records):write_json(DATA/'session.json',dict(tabs=records,active_tab=max(0,min(data.get('active_tab',0),len(records)-1))))
            else:(DATA/'session.json').unlink(missing_ok=True)
            return True
        if operation=='vault_status':return dict(exists=self.vault.exists,unlocked=self.vault.unlocked)
        if operation in ('vault_create','vault_unlock'):
            getattr(self.vault,'create' if operation=='vault_create' else 'unlock')(data['password']);self.arm_vault();return True
        if operation=='vault_lock':self.vault.lock();return True
        if operation=='vault_list':
            self.arm_vault();return [dict(origin=e['origin'],username=e['username']) for e in self.vault.entries()]
        if operation=='vault_get':
            self.arm_vault();return next((e for e in self.vault.entries(data['origin']) if e['username']==data['username']),None)
        if operation=='vault_save':
            self.vault.save(data['origin'],data['username'],data['password'],tuple(data['previous']) if data.get('previous') else None);self.arm_vault();return True
        if operation=='vault_remove':self.vault.remove(data['origin'],data['username']);return True
        if operation=='vault_change':self.vault.change_password(data['password']);self.arm_vault();return True
        if operation=='profiles':return discover_profiles(os.environ.get('SUPERSEARCH_TEST_PROFILE_HOME'))
        if operation=='import':
            result=read_profile(data.get('profile'),data.get('selected',['bookmarks','history','downloads','cookies','preferences']),data.get('csv'))
            if result['passwords'] and not self.vault.unlocked:raise ValueError('Unlock or create the password vault before importing passwords')
            for key in ('bookmarks','history'):
                entries={e['url']:e for e in getattr(self.store,key)};entries.update((e['url'],e) for e in result[key]);setattr(self.store,key,list(entries.values()));write_json(DATA/(key+'.json'),list(entries.values()))
            if result['passwords']:self.vault.import_entries(result['passwords']);self.arm_vault()
            if result['preferences']:self.settings(result['preferences'])
            if result['downloads']:write_json(DATA/'downloads.json',result['downloads'])
            return dict(counts={key:len(result[key]) for key in ('bookmarks','history','passwords','cookies','downloads')},cookies=result['cookies'],notices=result['notices'])
        if operation=='downloads':write_json(DATA/'downloads.json',data);return True
        if operation=='download_owned':record_download(data['path'],DATA);return True
        if operation=='maintenance':return schedule(data['categories'],DATA)
        if operation=='legal':
            if data['name'] not in ('TERMS.md','PRIVACY.md'):raise ValueError('Unknown document')
            return (ROOT/'docs'/data['name']).read_text()
        if operation=='system_status':
            from core.system_status import read_battery
            battery=read_battery()
            return dict(percent=battery.percent,charging=battery.charging) if battery else None
        raise ValueError('Unknown operation')


def main():
    service=Service()
    try:
        for line in sys.stdin:
            request=None
            try:
                if len(line)>4_000_000:raise ValueError('Request too large')
                request=json.loads(line)
                with service.lock:result=service.handle(request['operation'],request.get('data',{}))
                response=dict(id=request['id'],result=result)
            except Exception as error:
                response=dict(id=request.get('id') if isinstance(request,dict) else None,error=str(error))
            print(json.dumps(response,ensure_ascii=True),flush=True)
    finally:
        if service.vault_timer:service.vault_timer.cancel()
        service.vault.lock();service.store.db.close()


if __name__=='__main__':main()
