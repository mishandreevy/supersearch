#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if [ ! -x .venv/bin/python ]; then
    python3 -m venv .venv
fi
if ! .venv/bin/python tools/check_runtime.py; then
    .venv/bin/python -c 'import sys; sys.exit("Python 3.10 or newer is required for this browser runtime.") if sys.version_info < (3, 10) else None'
    .venv/bin/python -m pip install --upgrade -r requirements.txt
    .venv/bin/python tools/check_runtime.py
fi
exec .venv/bin/python main.py "$@"
