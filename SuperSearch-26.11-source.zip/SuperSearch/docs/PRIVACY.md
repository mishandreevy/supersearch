# SuperSearch Privacy Policy

Effective date: 3 November 2026. Application version: **26.11**.

## Local data and portable backups

The default browser uses Electron/Chromium. Preferences, bookmarks, optional
history, shortcuts, blocking statistics, icon caches, download records, local
scripts and the encrypted password vault stay in `data/electron/`. Website storage
is in memory by default; you may select a persistent profile instead.

On first migration, compatible libraries can be copied from an older local layout.
Original files are left intact; the active browser profile is `data/electron/`.
There is one browser implementation. Website sessions are not migrated across engines.

Portable data exports are encrypted locally with a password you choose. They include
saved settings, bookmarks, the encrypted vault, history, tabs, statistics, shortcuts,
wallpaper, filters, cached icons and UserScripts/styles. They exclude website sessions,
cache, extension packages, downloaded files and records authorizing file deletion.
The export password and vault master password are independent and are not recoverable.
Export and restore send no data to a server.

Restoring requires explicit confirmation to replace current browser data and restart.
A wrong password or invalid archive leaves current libraries unchanged. Existing
website sessions are cleared after validation and process exit. Restoring scripts
requires separate opt-in. Keep exports securely: anyone with the backup password can
read their ordinary libraries, and the vault still requires its master password.
Exports outside the profile and legacy copies are not removed by browser reset.

## Network requests

SuperSearch does not send browsing history or product telemetry to its developer.
Visited websites and selected search engines receive the requests needed to provide
their services. Enabling suggestions sends typed queries to DuckDuckGo in the
address/start-page search fields. Suggestions are disabled in private windows.

Start-page shortcut icons are bundled or cached locally. Visiting a site can fetch
its supplied favicon through the browsing session. Filter lists are downloaded
from EasyList only when you request an update. An explicit proxy test contacts
api64.ipify.org through the selected draft proxy or Tor route.

The start page shows a public IP by default. After setup, when the IP/counter
feature is enabled and a start-page pane is selected in an open, non-minimized
window, a native HTTPS request contacts api64.ipify.org. The service receives the
public address of that connection. No browsing URL, website cookies or history is
included in the request. The visible session's active proxy/Tor route is used,
including a private session when the visible page is private. Results and failures
are cached only in memory for ten minutes. Refresh explicitly checks again.

Disable **Show public IP on the start page** in Appearance or the home editor to
avoid these requests. No check starts before setup is complete. Disabling clears
pending results; a request already sent may still finish. The shown address is a
snapshot of one connection, not a guarantee of anonymity or what every site sees.

The first launch can download the official pinned Electron runtime from GitHub.
Its archive checksum is verified against the source manifest before installation.
Runtime downloads use saved proxy/Tor preferences. Normal launches with a matching
runtime do not contact an update service. Clicking the source link opens GitHub
inside the browser as an ordinary website visit.

Proxy/Tor and secure DNS startup changes require restart. Tor needs a separately
running service at 127.0.0.1:9050. A configured proxy failure does not silently fall
back to a direct connection. Secure DNS and proxy behavior have protocol/platform
limits described in the security model.

## Passwords and import

Passwords use authenticated Fernet encryption. PBKDF2-HMAC-SHA256 derives the key
from the master password with a random salt and 1,200,000 iterations. The master
password is not saved. Migration preserves the encrypted vault format. Plaintext
values can exist temporarily in the browser, private stdio pipe and local service
memory while unlocking, editing, importing, filling or explicitly saving.

After a supported HTTPS form submission, a captured login may remain in memory
for up to 30 seconds while the browser waits for navigation or form disappearance.
A small browser-owned card lets you save or decline. Save requires an unlocked
vault and your explicit choice. The card expires after 90 seconds and clears its
pending references on dismissal or tab change. Private and website-JavaScript-off
views do not capture logins. Explicit filling checks the complete website origin.
The service locks an idle vault after five minutes.

Import starts only after you select a detected browser, manual folder or password
CSV. Source files are read-only. Compatible bookmarks, history, settings, downloads
and readable cookies can transfer. Password CSV records require an unlocked vault.
OS-protected passwords/cookies, sync accounts, payment details and protected keys
are not silently decrypted. The import report explains supported and skipped data.

## Extensions and deletion

Installed UserScripts/styles and compatible local extensions can read data on
pages where they run and may send it to third parties. Choose only code you trust.
Extensions require a persistent profile and are not loaded into private sessions.
UserScripts in private windows require a separate option. SuperSearch does not
provide a direct Chrome Web Store installer or claim universal API compatibility.

Storage offers selective cleanup and an explicitly confirmed reset. Reset requires
typing `Delete`, restarts the browser and removes the selected Electron profile's
data. Legacy copies and exported files outside the active profile are not removed.
Download-file cleanup removes only recorded unchanged files; unrelated or replaced
files are kept. Deletion cannot guarantee physical erasure from media or backups.

Privacy controls reduce tracking but do not guarantee anonymity. Direct connections
reveal an IP address to the services used. SuperSearch is not Tor Browser. A
compromised operating system or trusted extension can access data within its
capabilities. See `SECURITY.md` for the threat model and practical limits.
