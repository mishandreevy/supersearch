# Publishing a source release

The public project is https://github.com/mishandreevy/supersearch.
These instructions prepare source files and artifacts; they do not publish or
push anything automatically.

## Release identity

`engine/package.json` is the source of release identity:

- `displayVersion`: `26.11`, shown by the UI, CLI and backup metadata.
- `version`: `26.11.0`, the three-part version used by Electron package metadata.

`core/version.py` and the Electron controller read that same manifest. For a future
release, update both manifest fields, the changelog, version references in the
public docs and the explicit version assertion in `tests/test_sessions_release.py`.
Do not change backup format version `1` just to change the application version.

## Validate and package

Run from an activated project virtual environment:

```sh
python tools/check_runtime.py
python -m pip check
python -m compileall -q main.py core settings engine tests tools
python -m unittest discover -s tests -p 'test_*.py' -v
python tests/gui_electron.py
python main.py --engine-version
python tools/export_source.py
```

GUI tests use temporary profiles. On a headless Linux host, run them with
`xvfb-run -a`. JavaScript policy checks are described in `CONTRIBUTING.md`.
Windows and macOS need native verification before claiming support for a binary
release; a source archive does not bundle a desktop runtime.

The exporter creates:

- `SuperSearch-26.11-source.zip`: the versioned publication artifact.
- `SuperSearch-26.11-source.sha256`: SHA-256 checksum of that archive.
- `SuperSearch-source.zip`: the same archive under the unversioned convenience name.
- `SOURCE_FULL.md`: complete files, each under its own path and code fence.
- `SOURCE_MANIFEST.json`: SHA-256 digest of every included source file.

On Linux, verify the archive checksum with:

```sh
sha256sum -c SuperSearch-26.11-source.sha256
```

The exporter preserves shell-script permissions, sorts archive entries and fixes
archive timestamps. Equal source bytes produce the same archive in the same
Python/zlib environment. CI runs the tests and retains the source artifacts.

## Publish only the prepared source

Extract the versioned source archive to a clean directory and use its `SuperSearch/`
contents for the public repository. It includes the license, notices, documentation,
CI configuration, assets, code and tests. Do not upload the entire working folder.

The allowlist excludes user profiles, virtual environments, downloaded runtimes,
backups, credentials, private tooling directories, caches and symlinks. `.gitignore`
provides additional protection for local development. Source-export tests exercise
these exclusions using synthetic private files.

Review the changelog and preserve `LICENSE`, `THIRD_PARTY.md` and
`assets/site-icons/LICENSE.md`. When publishing a GitHub release, use the title
`SuperSearch 26.11` and tag `v26.11`, and attach the versioned ZIP and checksum.
Do not attach the `data/` directory or private `.supersearch` backups.
