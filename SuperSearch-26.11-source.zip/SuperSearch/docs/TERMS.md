# SuperSearch User Agreement

Effective date: 2 November 2026. Application version: **26.11**.

SuperSearch is an open-source desktop browser. This agreement explains how you can
use the application and make informed choices about your local data. The source
code license is provided in `LICENSE`.

## Your choices

You control the websites you visit, your network route, the data you import, your
installed scripts and extensions, and the appearance of your workspace. Search
suggestions are optional. You can change your preferences in Settings.

## Local data and security

Settings, bookmarks, shortcuts, statistics and encrypted passwords are stored on
your device in the browser's `data/` directory. Downloaded files are saved to your
system Downloads folder. Choosing to retain tabs stores their URLs locally.
Private-window tabs are never included in tab restoration.

A master password protects the local password vault. SuperSearch does not store
that master password, and a forgotten master password cannot be recovered. Keep
your operating system and browser dependencies up to date.

## Imports and third-party services

Import reads only the browser profile or file you select. The source profile is
not modified. Some browser data is protected by the operating system or source
browser and cannot be transferred directly. A password CSV contains unencrypted
passwords; you remain in control of the original file after import.

Websites, search providers, proxy services and installed extensions have their own
terms and privacy practices. Third-party components and asset notices are listed
in `THIRD_PARTY.md`.

## Deletion and reset

Storage settings let you delete selected categories of data or reset the browser.
Full reset requires a separate warning and typing **Delete**. The browser then
restarts with first-run setup. Optional downloaded-file removal affects only
files tracked by SuperSearch that have not subsequently changed; it does not erase
your entire Downloads folder, original import profiles or unrelated files.

## License and availability

The software is provided under the license in `LICENSE`, without warranties to the
extent permitted by applicable law. Nothing in these terms limits rights that
cannot lawfully be excluded. Read the Privacy Policy below for details of data
processing and privacy controls.
