"""Start the verified Electron/Chromium browser and its local Python service."""
import os
import sys


def wait_for_restart():
    """Wait for the previous process to release Chromium's profile lock."""
    if '--wait-for-pid' not in sys.argv:
        return
    index = sys.argv.index('--wait-for-pid')
    try:
        pid = int(sys.argv[index + 1])
        if pid <= 0 or pid == os.getpid():
            raise ValueError('Invalid restart PID')
    except (IndexError, ValueError) as exc:
        raise RuntimeError('Invalid restart arguments') from exc
    del sys.argv[index:index + 2]
    if sys.platform == 'win32':
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        kernel.WaitForSingleObject.restype = wintypes.DWORD
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        handle = kernel.OpenProcess(0x00100000, False, pid)
        if handle:
            try:
                if kernel.WaitForSingleObject(handle, 30000) != 0:
                    raise RuntimeError('Previous SuperSearch process is still running')
            finally:
                kernel.CloseHandle(handle)
    else:
        import time
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                return
            time.sleep(.1)
        raise RuntimeError('Previous SuperSearch process is still running')


def main():
    wait_for_restart()
    if "--qt" in sys.argv:
        raise SystemExit("The Qt version has been removed. Start SuperSearch without --qt.")
    from core.electron_launcher import launch
    launch(sys.argv[1:])


if __name__=="__main__":main()
