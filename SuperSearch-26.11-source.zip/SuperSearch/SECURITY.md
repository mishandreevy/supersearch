# Security and privacy model

SuperSearch 26.11 uses Electron 45.2.1 / Chromium 156.0.8078.75 by default.
This project has
not undergone an independent security audit and does not implement Tor Browser's
anonymity model.

## Process and trust boundaries

Untrusted websites run in Chromium WebContentsView renderers with `sandbox: true`,
`contextIsolation: true`, `nodeIntegration: false`, `webSecurity: true`, no Node in
workers/subframes, no webview embedding and no insecure-content override. The app
explicitly enables Chromium's sandbox. Linux uses its user-namespace sandbox;
`--no-sandbox` is not used. Linux integration tests check the renderer's actual
NoNewPrivs and seccomp flags as well as its web preferences.

The browser UI has a separate in-memory session and a restrictive CSP. Site
renderers cannot load its resource handler or access its exposed API. The UI
preload exposes a bounded command interface, not raw ipcRenderer, filesystem or
code execution. Native handlers check the exact UI webContents, top-level frame
and `ss-app://browser/index.html` URL. Remote renderers have no public browser API.

The Python service accepts newline-delimited JSON over the parent process's stdio
pipes. It does not open an HTTP server, WebSocket or TCP listener. Plaintext vault
operations and a master password can exist in process/pipe memory during explicit
operations, but are never logged, included in state broadcasts or sent to websites
through the UI bridge. A compromised OS can read memory or modify executable code.
Python and JavaScript do not guarantee secure physical memory erasure.

## Engine installation and maintenance

`engine/runtime.json` pins both compiled engine versions and official archive
SHA-256 digests. Installation checks the archive digest before safe extraction,
including containment checks for paths and symlinks. Loading checks the actual
runtime versions. Installed runtimes are not silently updated on browser launch.
Source archives exclude `.runtime/` and all user data.

Current release information comes from the official Electron release service.
Maintainers must review future Chromium security releases and update the pin and
digests; a pinned dependency is not a promise of indefinite security.

## Network route and permissions

Browsing sessions are configured before website views are created. Tor uses a
separately running SOCKS5 service at 127.0.0.1:9050 and takes priority over the
configured proxy. Fixed proxy routes have no DIRECT fallback and disable the
implicit loopback bypass. Integration tests verify that a failed proxy cannot
reach a loopback origin directly. Session fetches for suggestions, icons, filters
and IP checks use the selected route. Proxy tests use their own memory session.
Runtime downloads also respect saved proxy/Tor preferences.

Secure DNS uses the configured Chromium resolver and requires restart. SOCKS4 and
HTTP proxy behavior is protocol-dependent; selecting a proxy does not establish
Tor Browser-like anonymity. There is no promise that every system DNS or OS-level
network request is hidden. Site JavaScript and startup networking changes require
a new browser process. The trusted UI remains operational with site JS disabled.

Camera, microphone, geolocation, notifications, display capture and device access
are denied by default. User-gesture website fullscreen is supported without
granting these permissions. Invalid certificates are rejected and the local error
screen offers no certificate bypass. Tests trust only their generated loopback
certificate inside an explicitly marked temporary test process.

## Tracking controls and limits

The filter engine supports domain anchors, exceptions and literal substring
rules. Unsupported ABP syntax, cosmetic rules and modifiers are skipped and
reported. It does not claim full EasyList/EasyPrivacy semantics. HTTPS-only mode
upgrades requests without falling back to HTTP. Link cleanup removes common
advertising parameters; referrer stripping and privacy preference signals are
configurable.

Third-party cookie handling uses the top-level browsing host to remove cross-site
Cookie and Set-Cookie headers. This is a heuristic, not a complete public-suffix
cookie policy or a guarantee of total third-party storage isolation. Strict
settings can break embedded sign-in features.

Privacy preloads run before main-frame website scripts. They can block WebRTC and
location APIs, restrict canvas reads and alter some navigator/screen/UTC/canvas/
WebGL/audio observations. This does not cover every worker, subframe or device API.
Spoofing is observable and can increase fingerprint uniqueness. Canvas/WebGL
restrictions and disabled JavaScript can break websites. A direct connection
still exposes its public IP address; these controls do not guarantee anonymity.

Suggestions require opt-in, reject obvious URL/credential-shaped input and are
unavailable in private windows. Stale results are discarded after edits, tab
changes or loss of focus. Settings search is local and never goes to a provider.

Public IP checks contact ipify only when the feature/counters are enabled and a
start-page pane is selected in an open, non-minimized window. The visible session's
proxy/Tor route is used, including a private session when appropriate. Results and
failures stay in memory for ten minutes; disabling clears pending results. This
snapshot is not an anonymity or leak test.

## Passwords, persistence and portable backups

The original Fernet vault format is preserved. PBKDF2-HMAC-SHA256 uses a random
salt and 1,200,000 iterations. The master password is not stored and needs at least
12 characters. Idle locking happens in the service rather than depending on a
visible password screen. State snapshots list only vault status, not credentials.

Login capture is limited to submitted same-origin HTTPS forms in an owned
main-frame site view. Private windows and JS-disabled views do not capture.
Pending input expires after 30 seconds. A post-navigation/form-disappearance
heuristic can offer a save card; this is not proof that the server authenticated
the user. Only an explicit Save writes to the encrypted vault. Dismissal, tab
changes, locking and expiry clear pending references. Explicit filling checks the
complete scheme/host/port origin before retrieving and placing a secret.

The active browser profile lives in `data/electron/`. The one-time legacy migration
copies compatible libraries without deleting original data. There is one browser
implementation and no Qt dependency or alternate launcher. Chromium profile
internals are not reused across engines. Import reads an explicitly selected source;
OS-protected credentials, cookies, payment details and sync are not bypassed.

Encrypted `.supersearch` backups use Fernet with PBKDF2-HMAC-SHA256 (1,200,000
iterations and a fresh 16-byte salt). The backup password is never stored. The
existing vault stays encrypted with its own master password. Exports omit website
sessions, cache, extension packages, downloads and download deletion proofs. Normal
window data only is exported; backup operations are denied in private windows.

Restore requires native file selection, an expiring owner-bound choice token, the
backup password and explicit replacement consent. Before setup is complete, the
current User Agreement must also be accepted. Authenticated payloads still undergo
size/version/hash/path/type checks; duplicate entries, symlinks and unsupported paths
are rejected. Settings validation prevents injected toolbar identifiers and unreadable
colors. Statistics are rebuilt into a clean database. UserScripts require a separate
opt-in, and local extensions are not restored.

Staging files stay under a private directory inside the profile. The old browser and
service exit before the launcher replaces local libraries and clears website sessions.
Rename failures roll back installation; malformed or unauthenticated backups never
reach this step. Filesystem replacement is not a power-loss-proof database transaction.
Backups and files exported outside the profile are not removed by browser reset.

Normal website storage is in memory by default. Private windows always use their
own memory sessions and do not write tab pins, history, tracker records or captured
credentials. Downloads are explicit files outside the browser profile; private
file downloads are not automatically erased when the window closes.

## Extensions and deletion

UserScripts/styles and local Manifest V3 extensions are trusted code chosen by the
user. They may read website data and communicate over the network. Extension
installation shows declared permissions, restricts archive paths and symlinks,
disallows local file access and requires a persistent non-private session. Electron
supports a subset of extension APIs; Chrome Web Store is not a direct installer.
Scripts cannot access Node through site views. Private script execution is opt-in.

Storage cleanup names its categories and requires confirmation. Reset requires the
literal text `Delete`. The old browser/service processes release their files
before startup cleanup runs. Reset targets the active `data/electron/` profile. Original legacy migration files
elsewhere and user-selected exports outside that profile are not deleted.

Download cleanup deletes only paths whose stored file identity still matches the
owned download record. Unrelated/replaced files are preserved. File deletion is
not secure physical erasure and cannot remove copies in backups or other apps.

## Reporting

Report a reproducible issue with the actual runtime versions and minimal steps.
Never include a real vault, master password, cookies, private history or a complete
`data/` folder in a public report. See the source repository link in About.
