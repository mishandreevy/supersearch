"""Explicit persistent pinned tabs. Private-window pins remain in memory only."""
from copy import deepcopy
from pathlib import Path
from core.session import normalize_tab, tab_record
from settings.config import DATA, read_json, write_json


class PinStore:
    def __init__(self, directory=None):
        self.directory=Path(directory) if directory else DATA
        self.path=self.directory/'pinned-tabs.json'
        self.records=[]
        raw=read_json(self.path, {})
        values=raw.get('tabs',[]) if isinstance(raw,dict) else []
        if isinstance(values,list):
            for value in values[:100]:
                record=normalize_tab(value)
                if record and not any(e['id']==record['id'] for e in self.records):
                    record['pinned']=True
                    self.records.append(record)

    def commit(self, records):
        self.directory.mkdir(parents=True,exist_ok=True)
        write_json(self.path,dict(tabs=records))
        self.records=records

    def upsert(self, tab):
        record=tab_record(tab)
        record['pinned']=True
        for index,entry in enumerate(self.records):
            if entry['id']==record['id']:
                if entry!=record:
                    values=self.records[:]
                    values[index]=record
                    self.commit(values)
                return
        self.commit(self.records+[record])

    def remove(self, identifier):
        values=[e for e in self.records if e['id']!=identifier]
        if values!=self.records:
            self.commit(values)

    def startup(self, session=None):
        pins=deepcopy(self.records)
        pinned_ids={e['id'] for e in pins}
        ordinary=[]
        active_id=None
        if session:
            tabs=session.get('tabs',[])
            if tabs:
                active_id=tabs[min(session.get('active_tab',0),len(tabs)-1)]['id']
            for entry in tabs:
                if entry['id'] not in pinned_ids:
                    record=deepcopy(entry)
                    record['pinned']=False
                    ordinary.append(record)
        combined=pins+ordinary
        if not combined:
            return None
        active=next((i for i,e in enumerate(combined) if e['id']==active_id),0)
        return dict(tabs=combined,active_tab=active)
