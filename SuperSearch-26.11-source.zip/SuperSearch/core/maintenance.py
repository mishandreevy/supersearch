"""Delete selected local data only after the old Chromium process has exited."""
import json
import os
import secrets
import shutil
from pathlib import Path
from settings.config import DATA, write_json

CATEGORIES = {'cookies','cache','accounts','history','bookmarks','downloads','download_files','pinned_tabs','reset'}


def identity(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        return None
    s = path.stat()
    return dict(path=str(path.absolute()), dev=s.st_dev, ino=s.st_ino, size=s.st_size, mtime=s.st_mtime_ns)


def record_download(path, directory=None):
    directory = Path(directory) if directory else DATA
    proof = identity(path)
    if proof is None:
        return
    manifest = directory / 'download_files.json'
    try:
        entries = json.loads(manifest.read_text())
    except (OSError, ValueError):
        entries = []
    entries = [e for e in entries if e.get('path') != proof['path']]
    entries.append(proof)
    write_json(manifest, entries)


def remove_owned_downloads(directory):
    try:
        entries = json.loads((directory / 'download_files.json').read_text())
    except (OSError, ValueError):
        entries = []
    removed, skipped = 0, 0
    for proof in entries:
        try:
            path = Path(proof['path'])
            if identity(path) == proof:
                path.unlink()
                removed += 1
            else:
                skipped += 1
        except (OSError, KeyError, TypeError):
            skipped += 1
    return removed, skipped


def remove_path(path):
    if path.is_symlink() or path.is_file():
        path.unlink(missing_ok=True)
    elif path.is_dir():
        shutil.rmtree(path)


def execute(directory, categories):
    directory = Path(directory)
    categories = set(categories)
    if not categories or not categories <= CATEGORIES or directory.is_symlink():
        raise ValueError('Invalid cleanup operation.')
    report = dict(removed_downloads=0, skipped_downloads=0)
    if 'download_files' in categories:
        report['removed_downloads'], report['skipped_downloads'] = remove_owned_downloads(directory)
        remove_path(directory / 'download_files.json')
    if 'reset' in categories:
        for child in directory.iterdir():
            remove_path(child)
        return report
    if 'pinned_tabs' in categories and 'history' not in categories:
        from core.session import load
        session_path=directory/'session.json'
        if session_path.is_symlink():
            remove_path(session_path)
        else:
            session=load(directory)
            if session:
                active=session['tabs'][session['active_tab']]['id']
                remaining=[tab for tab in session['tabs'] if not tab['pinned']]
                if remaining:
                    index=next((i for i,tab in enumerate(remaining) if tab['id']==active),0)
                    write_json(session_path,dict(tabs=remaining,active_tab=index))
                else:
                    remove_path(session_path)
    paths = {
        'cookies':['profile/Cookies','profile/Cookies-journal','profile/Network/Cookies','profile/Network/Cookies-journal',
                   'profile/Local Storage','profile/IndexedDB','profile/Session Storage','profile/Service Worker',
                   'profile/WebStorage','profile/Storage','profile/File System','profile/blob_storage',
                   'profile/QuotaManager','profile/QuotaManager-journal','profile/SharedStorage'],
        'cache':['cache','profile/Cache','profile/Code Cache','profile/GPUCache','profile/ShaderCache','profile/DawnCache'],
        'accounts':['passwords.vault','passwords.tmp'],
        'history':['history.json','session.json','statistics.sqlite','statistics.sqlite-wal','statistics.sqlite-shm'],
        'bookmarks':['bookmarks.json'], 'pinned_tabs':['pinned-tabs.json'], 'downloads':['downloads.json'],
    }
    for category in categories:
        for name in paths.get(category, []):
            current = directory
            for part in Path(name).parts[:-1]:
                current = current / part
                if current.is_symlink():
                    raise ValueError('Cleanup does not follow symbolic links outside the browser data directory.')
            remove_path(directory / name)
    return report


def schedule(categories, directory=None):
    directory = Path(directory) if directory else DATA
    token = secrets.token_hex(24)
    write_json(directory / '.maintenance.json', dict(token=token, categories=list(categories)))
    return token


def run_pending(token, directory=None):
    directory = Path(directory) if directory else DATA
    path = directory / '.maintenance.json'
    plan = json.loads(path.read_text())
    if not secrets.compare_digest(plan.get('token',''), token):
        raise ValueError('The cleanup request is not authenticated.')
    report = execute(directory, plan['categories'])
    path.unlink(missing_ok=True)
    return report
