"""Local JSON libraries and SQLite tracker counters."""
import sqlite3
import threading
import logging
from datetime import date, timedelta
from settings.config import DATA, ROOT, read_json, write_json, config
import requests


class Store:
    def __init__(self):
        self.lock = threading.Lock()
        self.db = sqlite3.connect(str(DATA / 'statistics.sqlite'), check_same_thread=False)
        self.db.execute('CREATE TABLE IF NOT EXISTS blocks(day TEXT, domain TEXT, n INTEGER, PRIMARY KEY(day,domain))')
        self.db.commit()
        self.history = read_json(DATA / 'history.json', [])
        self.bookmarks = read_json(DATA / 'bookmarks.json', [])
        legacy=read_json(ROOT/'settings/translations/legacy_folders.json',{})
        for entry in self.bookmarks:
            if isinstance(entry,dict) and entry.get('folder') in legacy:
                entry['folder']=legacy[entry['folder']]

    def block(self, host):
        with self.lock:
            self.db.execute('INSERT INTO blocks VALUES(?,?,1) ON CONFLICT(day,domain) DO UPDATE SET n=n+1',
                            (date.today().isoformat(), host))
            self.db.commit()

    def stats(self):
        with self.lock:
            total = self.db.execute('SELECT coalesce(sum(n),0) FROM blocks').fetchone()[0]
            top = self.db.execute('SELECT domain,sum(n) FROM blocks GROUP BY domain ORDER BY sum(n) DESC LIMIT 10').fetchall()
            rows = dict(self.db.execute('SELECT day,sum(n) FROM blocks GROUP BY day').fetchall())
        daily = [((date.today()-timedelta(days=i)).isoformat(), rows.get((date.today()-timedelta(days=i)).isoformat(), 0)) for i in reversed(range(14))]
        return total, top, daily

    def visit(self, url, title):
        self.history = [x for x in self.history if x['url'] != url]
        self.history.insert(0, dict(url=url, title=title))
        self.history = self.history[:3000]
        write_json(DATA / 'history.json', self.history)

    def bookmark(self, url, title):
        exists = any(x['url'] == url for x in self.bookmarks)
        self.bookmarks = [x for x in self.bookmarks if x['url'] != url]
        if not exists:
            self.bookmarks.append(dict(url=url, title=title))
        write_json(DATA / 'bookmarks.json', self.bookmarks)


    def save_bookmark(self, url, title, folder='Bookmarks toolbar', original_url=None):
        self.bookmarks = [e for e in self.bookmarks if e['url'] not in (url, original_url)]
        self.bookmarks.append(dict(url=url, title=title, folder=folder))
        write_json(DATA / 'bookmarks.json', self.bookmarks)

    def remove_bookmark(self, url):
        self.bookmarks = [e for e in self.bookmarks if e['url'] != url]
        write_json(DATA / 'bookmarks.json', self.bookmarks)


RUNTIME_NETWORK = dict(config)


def proxy_url(options=None):
    options = RUNTIME_NETWORK if options is None else options
    return 'socks5h://127.0.0.1:9050' if options['tor'] else options['proxy'].strip().replace('socks5://', 'socks5h://', 1)


def get(url, options=None, **kwargs):
    # No ambient system proxies, cookies, or application browsing history.
    with requests.Session() as session:
        session.trust_env = False
        proxy = proxy_url(options)
        if proxy:
            session.proxies.update(http=proxy, https=proxy)
        response = session.get(url, timeout=(5, 15), **kwargs)
        response.raise_for_status()
        return response
