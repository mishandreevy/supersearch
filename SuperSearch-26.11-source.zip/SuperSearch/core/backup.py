"""Password-protected portable data snapshots and transactional offline restore."""
import base64
import hashlib
import io
import json
import os
import re
import secrets
import shutil
import sqlite3
import stat
import tempfile
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from zipfile import ZipFile, ZIP_DEFLATED
from core.version import APP_VERSION
from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

MAGIC=b'SUPERSEARCH-BACKUP\x00\x01'
ITERATIONS=1_200_000
MAX_TOTAL=128*1024*1024
MAX_FILE=32*1024*1024
MAX_ARCHIVE=180*1024*1024
MAX_ENTRIES=4096
FILES={'settings.json','bookmarks.json','history.json','shortcuts.json','passwords.vault',
       'pinned-tabs.json','session.json','statistics.sqlite'}
DIRECTORIES={'userscripts','filters','wallpapers','favicons'}
# Never import Chromium internals, extension binaries, external paths or deletion proofs.
REPLACED=FILES|DIRECTORIES|{'statistics.sqlite-wal','statistics.sqlite-shm','downloads.json',
                           'download_files.json','extensions.json','extensions','chromium','crashes','.restore-tabs-once'}


def allowed(name):
    path=PurePosixPath(name)
    if not name or '\\' in name or path.is_absolute() or '..' in path.parts or path.as_posix()!=name:return False
    if name in FILES:return True
    if len(path.parts)!=2:return False
    parent,leaf=path.parts
    if parent=='wallpapers':return leaf=='home.png'
    if parent=='favicons':return bool(re.fullmatch(r'[a-f0-9]{64}\.png',leaf))
    if parent=='userscripts':return bool(re.fullmatch(r'[a-zA-Z0-9_. -]{1,160}\.(js|css)',leaf)) and not leaf.startswith('.')
    if parent=='filters':return bool(re.fullmatch(r'[a-zA-Z0-9_-]{1,100}\.(txt|json)',leaf))
    return False


def cipher(password,salt):
    if not isinstance(password,str) or not 12<=len(password)<=1024:
        raise ValueError('Use a backup password with 12 to 1024 characters.')
    key=PBKDF2HMAC(algorithm=hashes.SHA256(),length=32,salt=salt,iterations=ITERATIONS).derive(password.encode('utf-8'))
    return Fernet(base64.urlsafe_b64encode(key))


def atomic_private(path,content):
    path=Path(path)
    if path.is_symlink():raise ValueError('Choose a regular file, not a symbolic link.')
    path.parent.mkdir(parents=True,exist_ok=True)
    descriptor,temporary=tempfile.mkstemp(prefix='.supersearch-',dir=path.parent)
    try:
        with os.fdopen(descriptor,'wb') as stream:stream.write(content);stream.flush();os.fsync(stream.fileno())
        os.replace(temporary,path)
    finally:
        if os.path.exists(temporary):os.unlink(temporary)


def export_data(directory,destination,password,database=None):
    directory,destination=Path(directory),Path(destination)
    # A backup must survive reset and never be included recursively in the profile.
    if destination.resolve().is_relative_to(directory.resolve()):raise ValueError('Save the backup outside the browser data folder.')
    salt=os.urandom(16);encryption=cipher(password,salt)
    content={};total=0
    def collect(name,path):
        nonlocal total
        if path.is_symlink():raise ValueError('Data export does not follow symbolic links.')
        size=path.stat().st_size
        if size>MAX_FILE or total+size>MAX_TOTAL:raise ValueError('Browser data is too large for a portable backup (128 MB maximum).')
        value=path.read_bytes();total+=len(value);content[name]=value
    for name in sorted(FILES-{'statistics.sqlite'}):
        path=directory/name
        if path.exists():collect(name,path)
    for parent in sorted(DIRECTORIES):
        folder=directory/parent
        if folder.is_symlink():raise ValueError('Data export does not follow symbolic links.')
        if folder.is_dir():
            for path in sorted(folder.iterdir()):
                name=parent+'/'+path.name
                if path.is_file() and allowed(name):collect(name,path)
    if database is not None:
        with tempfile.TemporaryDirectory(prefix='.backup-snapshot-',dir=directory) as temporary:
            snapshot=Path(temporary)/'statistics.sqlite'
            with closing(sqlite3.connect(snapshot)) as copied:database.backup(copied)
            collect('statistics.sqlite',snapshot)
    elif (directory/'statistics.sqlite').exists():
        with tempfile.TemporaryDirectory(prefix='.backup-snapshot-',dir=directory) as temporary:
            snapshot=Path(temporary)/'statistics.sqlite'
            with closing(sqlite3.connect((directory/'statistics.sqlite').resolve().as_uri()+'?mode=ro',uri=True)) as original,closing(sqlite3.connect(snapshot)) as copied:original.backup(copied)
            collect('statistics.sqlite',snapshot)
    if len(content)>MAX_ENTRIES:raise ValueError('Too many files for a portable backup.')
    metadata=dict(format='SuperSearch',version=1,app_version=APP_VERSION,created=datetime.now(timezone.utc).isoformat(),
                  files={name:hashlib.sha256(value).hexdigest() for name,value in content.items()})
    buffer=io.BytesIO()
    with ZipFile(buffer,'w',ZIP_DEFLATED) as archive:
        archive.writestr('manifest.json',json.dumps(metadata))
        for name,value in content.items():archive.writestr(name,value)
    encrypted=MAGIC+salt+encryption.encrypt(buffer.getvalue())
    if len(encrypted)>MAX_ARCHIVE:raise ValueError('Backup is too large.')
    atomic_private(destination,encrypted)
    return dict(name=destination.name,files=len(content),bytes=len(encrypted))


def unpack(source,password):
    source=Path(source)
    if source.is_symlink() or not source.is_file() or source.stat().st_size>MAX_ARCHIVE:raise ValueError('Choose a regular SuperSearch backup smaller than 180 MB.')
    envelope=source.read_bytes()
    if not envelope.startswith(MAGIC) or len(envelope)<len(MAGIC)+16+100:raise ValueError('This is not a supported SuperSearch backup.')
    offset=len(MAGIC)
    try:payload=cipher(password,envelope[offset:offset+16]).decrypt(envelope[offset+16:])
    except InvalidToken:raise ValueError('The backup password is incorrect or the file is damaged.') from None
    if len(payload)>MAX_TOTAL+2*1024*1024:raise ValueError('Backup is too large.')
    try:
        with ZipFile(io.BytesIO(payload)) as archive:
            members=archive.infolist();names=[entry.filename for entry in members]
            if len(names)>MAX_ENTRIES+1 or len(set(names))!=len(names) or 'manifest.json' not in names:raise ValueError('Invalid backup manifest.')
            if sum(entry.file_size for entry in members)>MAX_TOTAL+1024*1024:raise ValueError('Backup contents are too large.')
            for entry in members:
                mode=entry.external_attr>>16
                if entry.is_dir() or stat.S_ISLNK(mode) or entry.file_size>MAX_FILE or (entry.filename!='manifest.json' and not allowed(entry.filename)):
                    raise ValueError('Backup contains an unsupported or unsafe path.')
            if archive.getinfo('manifest.json').file_size>1024*1024:raise ValueError('Invalid backup manifest.')
            metadata=json.loads(archive.read('manifest.json'))
            if metadata.get('format')!='SuperSearch' or type(metadata.get('version')) is not int or metadata['version']!=1:raise ValueError('Unsupported backup version.')
            manifest=metadata.get('files')
            if not isinstance(manifest,dict) or set(manifest)!=set(names)-{'manifest.json'}:raise ValueError('Invalid backup file list.')
            values={name:archive.read(name) for name in manifest}
            if any(hashlib.sha256(value).hexdigest()!=manifest[name] for name,value in values.items()):raise ValueError('Backup integrity check failed.')
            return values
    except (KeyError,TypeError,json.JSONDecodeError,UnicodeError) as error:raise ValueError('The backup structure is invalid.') from error


def validate(values,settings_validator):
    from core.session import normalize_tab
    from core.vault import origin_of
    for name in ('bookmarks.json','history.json','shortcuts.json'):
        if name not in values:continue
        rows=json.loads(values[name])
        if not isinstance(rows,list) or len(rows)>10000:raise ValueError('Invalid backup library: '+name)
        for row in rows:
            if not isinstance(row,dict) or not origin_of(row.get('url','')) or not isinstance(row.get('title'),str):raise ValueError('Invalid backup library: '+name)
            if name=='shortcuts.json' and (not isinstance(row.get('id'),str) or len(row['id'])>100):raise ValueError('Invalid backup shortcut.')
            if name=='bookmarks.json' and not isinstance(row.get('folder',''),str):raise ValueError('Invalid backup bookmark folder.')
    for name in ('session.json','pinned-tabs.json'):
        if name not in values:continue
        document=json.loads(values[name]);rows=document.get('tabs') if isinstance(document,dict) else None
        if not isinstance(rows,list) or len(rows)>100 or any(normalize_tab(row) is None for row in rows):raise ValueError('Invalid backup tabs.')
        document['tabs']=[normalize_tab(row) for row in rows]
        values[name]=json.dumps(document).encode()
    if 'passwords.vault' in values:
        vault=json.loads(values['passwords.vault'])
        if not isinstance(vault,dict) or not isinstance(vault.get('salt'),str) or not isinstance(vault.get('token'),str):raise ValueError('Invalid encrypted password vault.')
        if len(base64.b64decode(vault['salt'],validate=True))!=16 or len(vault['token'])>MAX_FILE:raise ValueError('Invalid encrypted password vault.')
    saved=json.loads(values.get('settings.json',b'{}'))
    if not isinstance(saved,dict):raise ValueError('Invalid backup settings.')
    checked=settings_validator(saved)
    checked.update(onboarding_complete=True,tour_pending=False,tour_completed=True,terms_version='2026-11-02',extension_enabled=[])
    values['settings.json']=json.dumps(checked).encode()


def normalize_statistics(stage):
    path=stage/'statistics.sqlite'
    if not path.exists():return
    fresh=stage/'statistics.clean'
    with closing(sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True)) as source:
        source.execute('PRAGMA trusted_schema=OFF')
        if source.execute('PRAGMA quick_check').fetchone()!=('ok',):raise ValueError('Backup statistics are damaged.')
        if source.execute("SELECT type FROM sqlite_master WHERE name='blocks'").fetchone()!=('table',):raise ValueError('Invalid backup statistics.')
        rows=source.execute('SELECT day,domain,n FROM blocks LIMIT 100001').fetchall()
        if len(rows)>100000 or any(not isinstance(day,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',day) or not isinstance(domain,str) or len(domain)>255 or type(n) is not int or not 0<n<2**53 for day,domain,n in rows):raise ValueError('Invalid backup statistics.')
    with closing(sqlite3.connect(fresh)) as target:
        target.execute('CREATE TABLE blocks(day TEXT,domain TEXT,n INTEGER,PRIMARY KEY(day,domain))')
        target.executemany('INSERT INTO blocks VALUES(?,?,?)',rows);target.commit()
    os.replace(fresh,path)
    for suffix in ('-wal','-shm'):(stage/('statistics.sqlite'+suffix)).unlink(missing_ok=True)


def prepare_restore(source,password,directory,settings_validator,include_scripts=False):
    directory=Path(directory)
    values=unpack(source,password);validate(values,settings_validator)
    if not include_scripts:values={name:value for name,value in values.items() if not name.startswith('userscripts/')}
    if 'session.json' in values and json.loads(values['session.json']).get('tabs'):values['.restore-tabs-once']=b'1'
    token=secrets.token_hex(24);stage=directory/('.restore-staging-'+token)
    stage.mkdir(mode=0o700)
    try:
        for name,value in values.items():atomic_private(stage/name,value)
        normalize_statistics(stage)
        manifest={path.relative_to(stage).as_posix():hashlib.sha256(path.read_bytes()).hexdigest() for path in stage.rglob('*') if path.is_file()}
        atomic_private(directory/'.restore-plan.json',json.dumps(dict(token=token,files=manifest)).encode())
        return token
    except BaseException:
        shutil.rmtree(stage);raise


def apply_pending(token,directory):
    directory=Path(directory)
    if directory.is_symlink() or not re.fullmatch(r'[a-f0-9]{48}',token):raise ValueError('Invalid restore request.')
    plan_path=directory/'.restore-plan.json'
    if plan_path.is_symlink():raise ValueError('Invalid restore plan.')
    plan=json.loads(plan_path.read_text())
    if not secrets.compare_digest(plan.get('token',''),token):raise ValueError('Restore request is not authenticated.')
    stage=directory/('.restore-staging-'+token)
    if stage.is_symlink() or not stage.is_dir():raise ValueError('Missing restore staging data.')
    expected=plan.get('files',{})
    actual={}
    for path in stage.rglob('*'):
        if path.is_symlink():raise ValueError('Restore does not follow symbolic links.')
        if path.is_file():
            name=path.relative_to(stage).as_posix()
            if name!='.restore-tabs-once' and not allowed(name):raise ValueError('Invalid staged restore path.')
            actual[name]=hashlib.sha256(path.read_bytes()).hexdigest()
    if not expected or actual!=expected:raise ValueError('Staged restore integrity check failed.')
    rollback=directory/('.restore-previous-'+token);rollback.mkdir(mode=0o700)
    moved=[];installed=[]
    try:
        for name in sorted(REPLACED):
            path=directory/name
            if path.exists() or path.is_symlink():path.rename(rollback/name);moved.append(name)
        for path in sorted(stage.iterdir()):
            path.rename(directory/path.name);installed.append(path.name)
    except BaseException:
        for name in reversed(installed):(directory/name).rename(stage/name)
        for name in reversed(moved):(rollback/name).rename(directory/name)
        rollback.rmdir();raise
    plan_path.unlink(missing_ok=True);stage.rmdir();shutil.rmtree(rollback)
