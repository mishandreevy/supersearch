"""Local start-page shortcuts and favicon cache; rendering never fetches a URL."""
import base64
import hashlib
import html
from copy import deepcopy
from pathlib import Path
from urllib.parse import urlsplit
from uuid import uuid4
from settings.config import DATA, ROOT, read_json, write_json
from core.vault import origin_of

DEFAULT_SHORTCUTS = [
    dict(id='duckduckgo', title='DuckDuckGo', url='https://duckduckgo.com'),
    dict(id='wikipedia', title='Wikipedia', url='https://wikipedia.org'),
    dict(id='github', title='GitHub', url='https://github.com'),
    dict(id='reddit', title='Reddit', url='https://reddit.com'),
    dict(id='youtube', title='YouTube', url='https://youtube.com'),
    dict(id='archlinux', title='Arch Wiki', url='https://wiki.archlinux.org'),
]
BUILTINS = {origin_of(e['url']): e['id'] for e in DEFAULT_SHORTCUTS}


def valid_shortcut_url(value):
    return bool(origin_of(value)) and len(value) < 8192


class Shortcuts:
    def __init__(self, directory=None):
        self.directory = Path(directory) if directory else DATA
        self.path = self.directory / 'shortcuts.json'
        saved = read_json(self.path, None)
        self.entries = [e for e in saved if isinstance(e, dict) and all(isinstance(e.get(k), str) for k in ('id', 'title', 'url'))
                        and valid_shortcut_url(e['url'])] if isinstance(saved, list) else deepcopy(DEFAULT_SHORTCUTS)

    def commit(self, entries):
        if any(not valid_shortcut_url(e['url']) for e in entries):
            raise ValueError('Only HTTP and HTTPS addresses without embedded credentials are allowed.')
        self.directory.mkdir(parents=True, exist_ok=True)
        write_json(self.path, entries)
        self.entries = deepcopy(entries)

    def new(self, title, url):
        return dict(id=uuid4().hex, title=title.strip() or urlsplit(url).hostname, url=url.strip())

    def icon_path(self, url):
        digest = hashlib.sha256(origin_of(url).encode('utf-8')).hexdigest()
        return self.directory / 'favicons' / (digest + '.png')

    def icon_data(self, entry, foreground='#25304a'):
        cached = self.icon_path(entry['url'])
        if cached.is_file() and cached.stat().st_size < 1_000_000:
            return 'data:image/png;base64,' + base64.b64encode(cached.read_bytes()).decode('ascii')
        builtin = BUILTINS.get(origin_of(entry['url']))
        if builtin:
            svg = (ROOT / 'assets/site-icons' / (builtin + '.svg')).read_text(encoding='utf-8')
            svg = svg.replace('<svg ', '<svg fill="' + foreground + '" ', 1)
        else:
            label = html.escape((entry['title'] or '?')[:1].upper())
            svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><rect x="2" y="2" width="60" height="60" rx="16" fill="{foreground}" opacity=".12"/><text x="32" y="44" text-anchor="middle" font-family="sans-serif" font-size="36" fill="{foreground}">{label}</text></svg>'
        return 'data:image/svg+xml;base64,' + base64.b64encode(svg.encode()).decode('ascii')
