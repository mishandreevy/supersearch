"""Portable download names and collision-safe destinations."""
import re
import unicodedata
from pathlib import Path

def safe_filename(name):
    name = ''.join(c for c in (name or 'download') if not unicodedata.category(c).startswith('C'))
    name = name.replace('\\', '/').rsplit('/', 1)[-1]
    name = re.sub(r'[\x00-\x1f\x7f<>:"/\\|?*]', '_', name).strip(' .')
    if not name:
        name = 'download'
    if name.split('.')[0].upper() in {'CON', 'PRN', 'AUX', 'NUL'} | {f'{k}{n}' for k in ('COM', 'LPT') for n in range(1, 10)}:
        name = '_' + name
    return name[:180]

def download_target(directory, name, reserved=()):
    directory = Path(directory)
    name = safe_filename(name)
    stem, suffix = Path(name).stem, Path(name).suffix
    candidate = directory / name
    number = 1
    while candidate.exists() or candidate.is_symlink() or str(candidate) in reserved:
        candidate = directory / f'{stem} ({number}){suffix}'
        number += 1
    return candidate
