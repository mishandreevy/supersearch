"""Explicit local tab restoration; private windows are never persisted."""
import re
from pathlib import Path
from urllib.parse import urlsplit
from uuid import uuid4
from settings.config import DATA,read_json,write_json


def safe_url(value):
    if not isinstance(value,str):
        return 'supersearch:start'
    if value in ('supersearch:start','about:blank'):
        return value
    try:
        parts=urlsplit(value)
        if parts.scheme in ('http','https') and parts.hostname and not parts.username and not parts.password:
            return value
    except (ValueError,TypeError):
        pass
    return 'supersearch:start'


def normalize_tab(value):
    if not isinstance(value,dict) or not isinstance(value.get('panes'),list):
        return None
    identifier=value.get('id','')
    if not isinstance(identifier,str) or not re.fullmatch(r'[a-zA-Z0-9_-]{1,64}',identifier):
        identifier=uuid4().hex
    return dict(id=identifier,panes=[safe_url(url) for url in value['panes'][:2]] or ['supersearch:start'],
                active_pane=1 if value.get('active_pane')==1 and len(value['panes'])>1 else 0,
                pinned=bool(value.get('pinned',False)))


def tab_record(tab):
    pending=getattr(tab,'pending_session',None)
    if pending:
        record=normalize_tab(pending)
    else:
        panes=[]
        for view in tab.views[:2]:
            url=view.url().toString()
            if url in ('','about:blank'):
                requested=view.page().requestedUrl().toString()
                if requested:
                    url=requested
            panes.append(safe_url(url))
        record=dict(panes=panes,active_pane=tab.views.index(tab.active) if tab.active in tab.views else 0)
    record['id']=getattr(tab,'id',record.get('id',uuid4().hex))
    record['pinned']=getattr(tab,'pinned',record.get('pinned',False))
    return normalize_tab(record)


def snapshot(window):
    return dict(tabs=[tab_record(tab) for tab in window.tabs[:100]],active_tab=max(0,window.list.currentRow()))


def save(window,directory=None):
    if window.private:
        return
    directory=Path(directory) if directory else DATA
    write_json(directory/'session.json',snapshot(window))


def load(directory=None):
    directory=Path(directory) if directory else DATA
    record=read_json(directory/'session.json',{})
    tabs=[]
    if isinstance(record,dict):
        records=record.get('tabs',[])
        if not isinstance(records,list):return None
        for entry in records[:100]:
            tab=normalize_tab(entry)
            if tab:tabs.append(tab)
    active=record.get('active_tab',0) if isinstance(record,dict) else 0
    active=active if isinstance(active,int) else 0
    return dict(tabs=tabs,active_tab=min(max(0,active),max(0,len(tabs)-1))) if tabs else None
