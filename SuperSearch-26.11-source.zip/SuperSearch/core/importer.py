"""Explicit, read-only import of a user-selected Chromium profile and password CSV.
OS-protected cookies and credentials are reported, never silently decrypted or bypassed.
"""
import csv
import json
import sqlite3
import sys
import time
from pathlib import Path
from urllib.parse import quote
from core.vault import origin_of


def discover_profiles(home=None):
    overridden=home is not None
    home = Path(home) if overridden else Path.home()
    if sys.platform == 'win32':
        import os
        local = home/'AppData/Local' if overridden else Path(os.environ.get('LOCALAPPDATA', home / 'AppData/Local'))
        roots = {'Chrome':local/'Google/Chrome/User Data', 'Edge':local/'Microsoft/Edge/User Data',
                 'Brave':local/'BraveSoftware/Brave-Browser/User Data', 'Chromium':local/'Chromium/User Data',
                 'Vivaldi':local/'Vivaldi/User Data', 'Opera':home/'AppData/Roaming/Opera Software/Opera Stable'}
    elif sys.platform == 'darwin':
        base = home/'Library/Application Support'
        roots = {'Chrome':base/'Google/Chrome','Edge':base/'Microsoft Edge','Brave':base/'BraveSoftware/Brave-Browser','Chromium':base/'Chromium','Vivaldi':base/'Vivaldi','Opera':base/'com.operasoftware.Opera'}
    else:
        base = home/'.config'
        roots = {'Chrome':base/'google-chrome','Chromium':base/'chromium','Brave':base/'BraveSoftware/Brave-Browser','Edge':base/'microsoft-edge','Vivaldi':base/'vivaldi','Opera':base/'opera',
                 'Chromium (Snap)':home/'snap/chromium/common/chromium',
                 'Chrome (Flatpak)':home/'.var/app/com.google.Chrome/config/google-chrome',
                 'Chromium (Flatpak)':home/'.var/app/org.chromium.Chromium/config/chromium',
                 'Brave (Flatpak)':home/'.var/app/com.brave.Browser/config/BraveSoftware/Brave-Browser'}
    result = []
    for browser, root in roots.items():
        try:
            if not root.is_dir():
                continue
            info={}
            state=root/'Local State'
            if state.is_file():
                try:
                    info=json.loads(state.read_text(encoding='utf-8')).get('profile',{}).get('info_cache',{})
                except (ValueError,OSError):
                    pass
            if (root/'Bookmarks').is_file() or (root/'History').is_file():
                result.append((browser,str(root)))
            for profile in sorted(root.iterdir()):
                if profile.is_dir() and (profile.name=='Default' or profile.name.startswith('Profile ')):
                    name=info.get(profile.name,{}).get('name',profile.name)
                    result.append((f'{browser} · {name}',str(profile)))
        except OSError:
            continue
    return result


def database_rows(path, query):
    if not path.is_file():
        return []
    uri = 'file:' + quote(str(path.absolute()), safe='/:') + '?mode=ro'
    connection = sqlite3.connect(uri, uri=True, timeout=2)
    try:
        connection.execute('PRAGMA query_only=ON')
        return connection.execute(query).fetchall()
    finally:
        connection.close()


def read_profile(profile, selected, password_csv=''):
    profile = Path(profile) if profile else None
    if profile and not (profile/'Bookmarks').is_file() and (profile/'Default').is_dir():
        profile=profile/'Default'
    result = dict(bookmarks=[], history=[], cookies=[], downloads=[], passwords=[], preferences={}, skipped_cookies=0, notices=[])
    def rows(path,query,label):
        try:
            return database_rows(path,query)
        except (sqlite3.DatabaseError,OSError) as exc:
            result['notices'].append(label+' could not be read: '+str(exc))
            return []
    if profile and 'bookmarks' in selected and (profile/'Bookmarks').is_file():
        document = json.loads((profile/'Bookmarks').read_text(encoding='utf-8'))
        def walk(node, folder):
            if node.get('type') == 'url' and origin_of(node.get('url','')):
                result['bookmarks'].append(dict(url=node['url'], title=node.get('name') or node['url'], folder='Imported / ' + folder))
            for child in node.get('children', []):
                walk(child, folder + (' / ' + child.get('name','') if child.get('type') == 'folder' else ''))
        for key, node in document.get('roots',{}).items():
            if isinstance(node,dict):
                walk(node, node.get('name') or key)
    if profile and 'history' in selected:
        records = rows(profile/'History', 'SELECT url,title FROM urls ORDER BY last_visit_time DESC LIMIT 10000','History')
        result['history'] = [dict(url=url,title=title or url) for url,title in records if origin_of(url)]
    if profile and 'downloads' in selected:
        try:
            records = rows(profile/'History', 'SELECT target_path,received_bytes,total_bytes FROM downloads ORDER BY start_time DESC LIMIT 2000','Downloads')
            result['downloads'] = [dict(path=path,received=received,total=total,imported=True) for path,received,total in records if path]
        except sqlite3.DatabaseError:
            result['notices'].append('The source download history format is not supported.')
    if profile and 'cookies' in selected:
        path = profile/'Network/Cookies'
        if not path.is_file():
            path = profile/'Cookies'
        records = rows(path, 'SELECT host_key,name,value,encrypted_value,path,expires_utc,is_secure,is_httponly FROM cookies','Cookies')
        for domain,name,value,encrypted,path,expires,secure,http_only in records:
            if encrypted:
                result['skipped_cookies'] += 1
                continue
            expiry = int(expires / 1_000_000 - 11644473600) if expires else 0
            if value and (not expiry or expiry > time.time()):
                result['cookies'].append(dict(domain=domain,name=name,value=value,path=path,expires=expiry,secure=bool(secure),http_only=bool(http_only)))
    if profile and 'preferences' in selected and (profile/'Preferences').is_file():
        prefs = json.loads((profile/'Preferences').read_text(encoding='utf-8'))
        homepage = prefs.get('homepage','')
        if origin_of(homepage):
            result['preferences']['homepage'] = homepage
        language = prefs.get('intl',{}).get('app_locale','').split('-')[0]
        if language in ('ru','en','de','fr','es'):
            result['preferences']['language'] = language
        result['preferences']['bookmark_bar'] = bool(prefs.get('bookmark_bar',{}).get('show_on_all_tabs',True))
    if password_csv:
        with open(password_csv, newline='', encoding='utf-8-sig') as stream:
            for row in csv.DictReader(stream):
                url = row.get('url') or row.get('origin') or ''
                password = row.get('password') or ''
                if origin_of(url) and password:
                    result['passwords'].append(dict(origin=origin_of(url), username=row.get('username') or '', password=password))
    if result['skipped_cookies']:
        result['notices'].append(f"Protected cookies: {result['skipped_cookies']} — sign in to these websites again.")
    result['notices'].append('Chrome account sync, payment details, protected keys and active sessions are not automatically transferred. Passwords are imported from an explicitly selected CSV into the encrypted vault.')
    return result

