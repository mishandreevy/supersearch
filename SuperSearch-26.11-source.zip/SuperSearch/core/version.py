"""Release identity from the shared application manifest."""
import json
from pathlib import Path

_RELEASE=json.loads((Path(__file__).resolve().parent.parent/'engine/package.json').read_text(encoding='utf-8'))
APP_VERSION=_RELEASE['displayVersion']
PACKAGE_VERSION=_RELEASE['version']
SOURCE_URL=_RELEASE['repository']['url']
