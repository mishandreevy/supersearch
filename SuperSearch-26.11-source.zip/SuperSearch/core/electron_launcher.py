"""Verified Electron launcher and one-time migration of legacy local libraries."""
import json
from contextlib import closing
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
from pathlib import Path
from settings.config import ROOT,DATA
from tools.install_electron import ensure,MANIFEST
from core.version import APP_VERSION

LIBRARIES=('settings.json','bookmarks.json','history.json','shortcuts.json','passwords.vault',
           'pinned-tabs.json','session.json','downloads.json','download_files.json','import-report.json')


def migrate(source,destination):
    source,destination=Path(source),Path(destination)
    if destination.exists():return
    destination.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.electron-migration-',dir=destination.parent) as temporary:
        staging=Path(temporary)/'data';staging.mkdir()
        for name in LIBRARIES:
            file=source/name
            if file.is_file() and not file.is_symlink():shutil.copy2(file,staging/name)
        for name in ('userscripts','filters','wallpapers','favicons'):
            directory=source/name
            if directory.is_dir() and not directory.is_symlink():
                (staging/name).mkdir()
                for file in directory.iterdir():
                    if file.is_file() and not file.is_symlink():shutil.copy2(file,staging/name/file.name)
        database=source/'statistics.sqlite'
        if database.is_file() and not database.is_symlink():
            with closing(sqlite3.connect(database.resolve().as_uri()+'?mode=ro',uri=True)) as original,closing(sqlite3.connect(staging/'statistics.sqlite')) as copied:original.backup(copied)
        (staging/'engine-migration.json').write_text(json.dumps(dict(source='QtWebEngine',version=1,cookies_copied=False,original_data_preserved=True)))
        staging.rename(destination)


def versions(executable):
    env=dict(os.environ,ELECTRON_RUN_AS_NODE='1')
    code="console.log(JSON.stringify({Electron:process.versions.electron,Chromium:process.versions.chrome,Node:process.versions.node}))"
    result=subprocess.run([str(executable),'-e',code],env=env,capture_output=True,text=True,check=True,timeout=20)
    value=json.loads(result.stdout)
    if value['Electron']!=MANIFEST['electron'] or value['Chromium']!=MANIFEST['chromium']:
        raise RuntimeError('The installed Electron/Chromium versions do not match the verified runtime manifest.')
    return dict(SuperSearch=APP_VERSION,**value)


def launch(arguments):
    if '--self-test' in arguments and os.environ.get('SUPERSEARCH_SKIP_MIGRATION')!='1':raise RuntimeError('Run tests/gui_electron.py to use an isolated test profile.')
    executable=ensure();actual=versions(executable)
    if '--engine-version' in arguments:
        print(json.dumps(actual,indent=2));return
    destination=Path(os.environ.get('SUPERSEARCH_ENGINE_DATA',DATA/'electron')).absolute()
    if os.environ.get('SUPERSEARCH_SKIP_MIGRATION')=='1':destination.mkdir(parents=True,exist_ok=True)
    else:migrate(DATA,destination)
    if '--maintenance-token' in arguments:
        index=arguments.index('--maintenance-token')
        from core.maintenance import run_pending
        run_pending(arguments[index+1],destination)
        del arguments[index:index+2]
    if '--restore-token' in arguments:
        index=arguments.index('--restore-token')
        from core.backup import apply_pending
        apply_pending(arguments[index+1],destination)
        del arguments[index:index+2]
    env=dict(os.environ,SUPERSEARCH_DATA=str(destination),SUPERSEARCH_PYTHON=sys.executable)
    env.pop('ELECTRON_RUN_AS_NODE',None)
    env.pop('QTWEBENGINE_CHROMIUM_FLAGS',None)
    command=[str(executable),str(ROOT/'engine/main.js')]+[arg for arg in arguments if arg!='--electron']
    os.execve(str(executable),command,env)
