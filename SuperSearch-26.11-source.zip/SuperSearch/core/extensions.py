"""Validate local Manifest V3 folders and bounded ZIP packages."""
import json
from pathlib import Path, PurePosixPath
from zipfile import ZipFile

def extension_manifest(path):
    path = Path(path)
    if path.is_dir():
        raw = (path / 'manifest.json').read_bytes()
    else:
        with ZipFile(path) as archive:
            entries = archive.infolist()
            if len(entries) > 10000 or sum(e.file_size for e in entries) > 128 * 1024 * 1024:
                raise ValueError('The extension archive is too large.')
            for entry in entries:
                if ((entry.external_attr >> 16) & 0o170000) == 0o120000:
                    raise ValueError('Symbolic links are not allowed in extensions.')
                p = PurePosixPath(entry.filename.replace('\\', '/'))
                if p.is_absolute() or '..' in p.parts or (p.parts and ':' in p.parts[0]):
                    raise ValueError('Invalid paths in the extension archive.')
            info = archive.getinfo('manifest.json')
            if info.file_size > 1_000_000:
                raise ValueError('The manifest.json file is too large.')
            raw = archive.read(info)
    if len(raw) > 1_000_000:
        raise ValueError('The manifest.json file is too large.')
    manifest = json.loads(raw)
    if manifest.get('manifest_version') != 3:
        raise ValueError('Only Manifest V3 extensions are supported.')
    if not isinstance(manifest.get('name'), str):
        raise ValueError('The extension name is missing.')
    return manifest
