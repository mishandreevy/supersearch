"""Authenticated local vault. The master password is never stored."""
import base64
import json
import os
from pathlib import Path
from urllib.parse import urlsplit

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from settings.config import DATA


def origin_of(url):
    try:
        p = urlsplit(url)
        if p.scheme not in ('http', 'https') or not p.hostname or p.username or p.password:
            return ''
        port = p.port
        host = p.hostname.encode('idna').decode('ascii').lower()
        if ':' in host:
            host = '[' + host + ']'
        default = 443 if p.scheme == 'https' else 80
        return p.scheme + '://' + host + (':' + str(port) if port and port != default else '')
    except (ValueError, UnicodeError):
        return ''


class Vault:
    ITERATIONS = 1_200_000

    def __init__(self, path=None):
        self.path = Path(path) if path else DATA / 'passwords.vault'
        self.lock()

    @property
    def exists(self):
        return self.path.exists()

    @property
    def unlocked(self):
        return self._cipher is not None

    def lock(self):
        self._cipher = None
        self._salt = None
        self._entries = None

    def _derive(self, password, salt):
        key = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32,
                        salt=salt, iterations=self.ITERATIONS).derive(password.encode('utf-8'))
        return Fernet(base64.urlsafe_b64encode(key))

    def create(self, password):
        if self.exists:
            raise ValueError('The vault already exists.')
        if len(password) < 12:
            raise ValueError('The master password must contain at least 12 characters.')
        salt = os.urandom(16)
        cipher = self._derive(password, salt)
        self._write(cipher, salt, [])
        self._cipher, self._salt, self._entries = cipher, salt, []

    def unlock(self, password):
        self.lock()
        try:
            document = json.loads(self.path.read_text(encoding='utf-8'))
            if document['version'] != 1 or document['iterations'] != self.ITERATIONS:
                raise ValueError('Unsupported vault format.')
            salt = base64.b64decode(document['salt'], validate=True)
            if len(salt) != 16:
                raise ValueError('Invalid salt format.')
            cipher = self._derive(password, salt)
            entries = json.loads(cipher.decrypt(document['token'].encode('ascii')))
            if not isinstance(entries, list) or any(
                not isinstance(e, dict) or set(e) != {'origin', 'username', 'password'}
                or not all(isinstance(v, str) for v in e.values())
                or origin_of(e['origin']) != e['origin'] for e in entries
            ):
                raise ValueError('Invalid entry format.')
        except InvalidToken as exc:
            raise ValueError('Incorrect master password or damaged vault.') from exc
        except (KeyError, TypeError, UnicodeError, json.JSONDecodeError) as exc:
            raise ValueError('The vault is damaged.') from exc
        self._cipher, self._salt, self._entries = cipher, salt, entries

    def _require(self):
        if not self.unlocked:
            raise ValueError('The vault is locked.')

    def entries(self, origin=None):
        self._require()
        return [dict(e) for e in self._entries if origin is None or e['origin'] == origin]

    def save(self, origin, username, password, previous=None):
        self._require()
        canonical = origin_of(origin)
        if not canonical or not password:
            raise ValueError('A website address and password are required.')
        entries = [dict(e) for e in self._entries
                   if (e['origin'], e['username']) not in ((canonical, username), previous)]
        entries.append(dict(origin=canonical, username=username, password=password))
        self._write(self._cipher, self._salt, entries)
        self._entries = entries

    def import_entries(self, records):
        self._require()
        entries = {(e['origin'],e['username']):dict(e) for e in self._entries}
        for entry in records:
            origin = origin_of(entry['origin'])
            if origin and entry['password']:
                entries[(origin,entry['username'])] = dict(origin=origin,username=entry['username'],password=entry['password'])
        result = list(entries.values())
        self._write(self._cipher,self._salt,result)
        self._entries = result

    def remove(self, origin, username):
        self._require()
        entries = [dict(e) for e in self._entries
                   if (e['origin'], e['username']) != (origin, username)]
        self._write(self._cipher, self._salt, entries)
        self._entries = entries

    def change_password(self, password):
        self._require()
        if len(password) < 12:
            raise ValueError('The master password must contain at least 12 characters.')
        salt = os.urandom(16)
        cipher = self._derive(password, salt)
        self._write(cipher, salt, self._entries)
        self._cipher, self._salt = cipher, salt

    def _write(self, cipher, salt, entries):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        token = cipher.encrypt(json.dumps(entries, ensure_ascii=False).encode('utf-8'))
        data = dict(version=1, iterations=self.ITERATIONS,
                    salt=base64.b64encode(salt).decode('ascii'), token=token.decode('ascii'))
        temporary = self.path.with_suffix('.tmp')
        fd = os.open(str(temporary), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as stream:
                json.dump(data, stream)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(str(temporary), str(self.path))
        finally:
            temporary.unlink(missing_ok=True)
