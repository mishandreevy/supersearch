"""Read local battery status. No network calls, telemetry or persistent state.

Windows: GetSystemPowerStatus / SYSTEM_POWER_STATUS (Microsoft Win32 API).
Linux: kernel power_supply sysfs attributes. macOS: the system pmset command.
"""
import ctypes
from dataclasses import dataclass
from pathlib import Path
import re
import subprocess
import sys


@dataclass(frozen=True)
class BatteryState:
    percent:int
    charging:bool=False


def _text(path):
    try:return path.read_text(encoding='utf-8').strip()
    except (OSError,UnicodeError):return ''


def linux_battery(directory='/sys/class/power_supply'):
    batteries=[]
    try:devices=list(Path(directory).iterdir())
    except OSError:return None
    for device in devices:
        if (_text(device/'type')!='Battery' or _text(device/'scope')=='Device'
                or _text(device/'present')=='0'):
            continue
        energy=None
        try:
            now=int(_text(device/'energy_now'))
            full=int(_text(device/'energy_full'))
            if now>=0 and full>0:energy=(min(now,full),full)
        except ValueError:pass
        try:percent=int(_text(device/'capacity'))
        except ValueError:
            if energy is None:continue
            percent=round(100*energy[0]/energy[1])
        if not 0<=percent<=100:continue
        batteries.append((percent,_text(device/'status').lower()=='charging',energy))
    if not batteries:return None
    if all(entry[2] is not None for entry in batteries):
        percent=round(100*sum(entry[2][0] for entry in batteries)/sum(entry[2][1] for entry in batteries))
    else:
        percent=round(sum(entry[0] for entry in batteries)/len(batteries))
    return BatteryState(percent,any(entry[1] for entry in batteries))


class SystemPowerStatus(ctypes.Structure):
    _fields_=[('ACLineStatus',ctypes.c_ubyte),('BatteryFlag',ctypes.c_ubyte),
              ('BatteryLifePercent',ctypes.c_ubyte),('SystemStatusFlag',ctypes.c_ubyte),
              ('BatteryLifeTime',ctypes.c_uint32),('BatteryFullLifeTime',ctypes.c_uint32)]


def windows_battery(api=None):
    if api is None:api=ctypes.WinDLL('kernel32',use_last_error=True)
    call=api.GetSystemPowerStatus
    call.argtypes=[ctypes.POINTER(SystemPowerStatus)]
    call.restype=ctypes.c_int
    state=SystemPowerStatus()
    if (not call(ctypes.byref(state)) or state.BatteryFlag==255
            or state.BatteryFlag&128 or state.BatteryLifePercent>100):
        return None
    return BatteryState(state.BatteryLifePercent,bool(state.BatteryFlag&8))


def macos_battery():
    result=subprocess.run(['/usr/bin/pmset','-g','batt'],capture_output=True,text=True,
                          timeout=2,check=False)
    if result.returncode:return None
    for line in result.stdout.splitlines():
        if 'InternalBattery' not in line:continue
        match=re.search(r'\b(\d{1,3})%',line)
        if match and 0<=int(match.group(1))<=100:
            parts=line.split(';')
            charging=len(parts)>1 and parts[1].strip().lower()=='charging'
            return BatteryState(int(match.group(1)),charging)
    return None


def read_battery():
    try:
        if sys.platform.startswith('linux'):return linux_battery()
        if sys.platform=='win32':return windows_battery()
        if sys.platform=='darwin':return macos_battery()
    except (OSError,ValueError,AttributeError,subprocess.TimeoutExpired):pass
    return None
