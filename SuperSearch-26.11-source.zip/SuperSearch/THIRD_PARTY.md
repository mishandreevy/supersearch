# Third-party components

The source archive contains SuperSearch source and assets. It does not bundle Python,
Electron, Node.js, Chromium or installed Python dependencies. The separately
downloaded official Electron archive retains its bundled LICENSE and
LICENSES.chromium.html notices; preserve these when distributing a runtime.

| Component | Project | License |
|---|---|---|
| Electron | https://github.com/electron/electron | MIT; bundled dependency notices apply |
| Node.js | https://github.com/nodejs/node | MIT and bundled dependency notices |
| Chromium / Electron dependencies | https://www.electronjs.org/docs/latest/tutorial/electron-timelines | Upstream component licenses; see the runtime LICENSES.chromium.html |
| requests | https://requests.readthedocs.io/ | Apache-2.0 |
| PySocks | https://github.com/Anorov/PySocks | BSD-3-Clause |
| Pillow | https://python-pillow.github.io/ | MIT-CMU (HPND) |
| cryptography | https://cryptography.io/ | Apache-2.0 OR BSD-3-Clause |
| Simple Icons SVG brand icons | https://github.com/simple-icons/simple-icons | CC0-1.0 |

The six SVGs in `assets/site-icons/` were obtained from the Simple Icons repository:
DuckDuckGo, Wikipedia, GitHub, Reddit, YouTube and Arch Linux. The complete upstream
license is included in `assets/site-icons/LICENSE.md`. Brand names and trademarks
remain with their respective owners; CC0 does not grant trademark rights.

`assets/logo.svg` is the original logo supplied with this project and is used on
the start page, first-run setup and About screen. The small interface icons
in `core/icons.py` are repo-native SVG paths and do not require an external icon service.

EasyList and EasyPrivacy are not bundled in the source archive. The user explicitly
requests their download. Their upstream licenses and notices apply to those lists:
https://easylist.to/ . Distributing Electron/Chromium binaries or downloaded filter lists
requires preserving the applicable upstream notices.
