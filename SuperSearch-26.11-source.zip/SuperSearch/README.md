<div align="center">

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/logo-light.svg">
  <img src="assets/logo.svg" alt="SuperSearch" width="440">
</picture>

### Your web. Your choices.

A customizable desktop browser with local data, thoughtful privacy controls,\
and a Chromium engine. Built with **Electron + Python**, released under **MIT**.

[![Version](https://img.shields.io/badge/version-26.11-6366f1?style=flat-square)](CHANGELOG.md)
[![Chromium](https://img.shields.io/badge/Chromium-156-4285f4?style=flat-square)](engine/runtime.json)
[![Python](https://img.shields.io/badge/Python-3.10%2B-3776ab?style=flat-square)](requirements.txt)
[![License: MIT](https://img.shields.io/badge/license-MIT-16a34a?style=flat-square)](LICENSE)

[Features](#features) · [Quickstart](#quickstart) · [Privacy](#privacy-by-choice) · [Backups](#take-your-browser-with-you) · [Contributing](#build-with-us)

</div>

---

SuperSearch gives your everyday browsing a workspace you can shape: move your tabs,
keep two pages side by side, choose your colors and make the start page your own.
Your bookmarks, preferences and password vault stay on your device, with clear
controls over what the browser remembers and how it connects.

## Features

| Your workspace | Your privacy | Your everyday browsing |
| :--- | :--- | :--- |
| Panels on any edge | Ad and tracker filtering | Bookmarks with folders |
| Compact horizontal tabs | Separate private sessions | Master-password vault |
| Pinned tabs that stay pinned | Optional search suggestions | Password-save prompts |
| Two-page split view | HTTPS upgrades and link cleanup | Automatic file downloads |
| Light, dark and OLED themes | Configurable proxy, Tor and secure DNS | Encrypted data backups |
| Wallpaper and editable shortcuts | Camera, microphone and location denied by default | Five interface languages |

**An interface that adapts to you.** Adjust fonts, scale, colors, corners and toolbar
buttons. Collapsed panels show site icons; horizontal tabs fit into one compact row.
Settings, downloads and password management open inside the browser window.

**A start page that feels like home.** Search, pin your favorite websites, choose a
wallpaper and see real tracker-blocking statistics. Site icons are bundled or cached
locally. The optional public-IP display follows your active connection route.

**A welcoming first launch.** Choose a language, preview your preferences, import
supported data from another browser or restore a SuperSearch backup. New users can
follow a short tour, skip it or replay it later from **Settings → About**.

## Quickstart

You need **Python 3.10+ with pip**, a graphical desktop and the platform libraries
required by Chromium. Node.js, npm and Qt/PySide6 are not required.

Get the source by cloning this repository or extracting a source-release archive:

```bash
git clone https://github.com/mishandreevy/supersearch.git
cd supersearch
```

**Linux / macOS**

```bash
chmod +x run.sh
./run.sh
```

**Windows**

```bat
run.bat
```

The launcher creates `.venv`, installs the Python dependencies and downloads the
pinned official Electron runtime on first launch. Its archive is verified against a
SHA-256 digest before extraction. The first launch needs internet access; a matching
runtime is reused on later launches. Saved proxy/Tor settings apply to the download.

<details>
<summary><strong>Arch Linux dependencies</strong></summary>

Install the desktop libraries and Python tooling before running `./run.sh`:

```bash
sudo pacman -Syu --needed python python-pip gtk3 nss alsa-lib libcups libxcomposite libxdamage libxrandr libxkbcommon mesa xdg-utils
```

Run the browser as your normal user with Chromium's sandbox enabled. Linux needs
unprivileged user namespaces. The source launcher runs from a writable project
folder; a native Arch `.pkg.tar.zst` package is not included.

</details>

<details>
<summary><strong>Manual setup</strong></summary>

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python main.py
```

On Windows, use `.venv\Scripts\python.exe` instead of `.venv/bin/python`.

Check the actual loaded application and engine versions:

```bash
.venv/bin/python main.py --engine-version
```

</details>

Version **26.11** uses **Electron 45.2.1 / Chromium 156.0.8078.75**, pinned in
[`engine/runtime.json`](engine/runtime.json). Browser checks currently run on Linux;
Windows and macOS launch scripts are included, with native verification still needed
before publishing binaries for those platforms.

## Privacy by choice

Privacy controls should be understandable. SuperSearch keeps everyday data local
and lets you choose the settings that suit your browsing.

- **Local libraries.** Bookmarks, preferences, shortcuts, blocking statistics and
  the encrypted password vault live in `data/electron/`.
- **Less persistence by default.** Website storage stays in memory unless you
  enable a persistent profile. Recording browsing history is optional.
- **Separate private sessions.** Private windows do not persist their history,
  tab pins, tracker records or captured passwords. Downloaded files remain on disk.
- **Optional suggestions.** Enabling suggestions sends typed queries to DuckDuckGo.
  Suggestions are disabled in private windows.
- **Explicit connection choices.** Proxy and Tor routes have no direct fallback.
  Tor requires a separately running service at `127.0.0.1:9050`.
- **No product telemetry or browsing-history uploads to the developer.** Visited
  websites, chosen search services and enabled network features still receive the
  requests needed to work.

The optional start-page IP display contacts **ipify** through the browsing session's
route. You can turn it off in Appearance or the start-page editor. Filter-list
updates and proxy tests are user-triggered actions.

SuperSearch does not promise complete anonymity or implement Tor Browser's anonymity
model. Fingerprinting controls and third-party cookie handling have practical limits.
Read the [security model](SECURITY.md) and [Privacy Policy](docs/PRIVACY.md) for details.

## Take your browser with you

**Settings → Storage → Export browser data** creates a password-protected
`.supersearch` file that you can restore on another installation.

| Included | Kept out of the transfer |
| :--- | :--- |
| Saved settings, bookmarks and history | Website cookies and signed-in sessions |
| Encrypted password vault | Browser cache and Chromium profile internals |
| Tabs, pins and tracker statistics | Downloaded files and deletion records |
| Shortcuts, wallpaper and cached icons | Extension packages |
| Filters and UserScripts/styles | Private-window data |

The backup uses a separate password of at least **12 characters**. The password
vault keeps its original master password; the backup password does not unlock it.
Neither password can be recovered if forgotten.

Restore from **Settings → Storage → Restore browser data**, or choose **Yes, I am
returning** during first launch. SuperSearch validates the backup before changing
your libraries, asks for replacement confirmation and restarts to install the data.
A wrong password or invalid archive leaves your current libraries intact.

Restoring clears existing website sessions. Exported tabs reopen once without
changing your normal keep-tabs preference. UserScripts/styles require separate
opt-in, and extensions need to be installed again. Portable backups support up to
128 MB of source data and a 180 MB encrypted file.

## Make it your own

Use JavaScript UserScripts, CSS styles or compatible local **Manifest V3** extensions
to customize websites. CSS files are injected as styles; scripts are loaded from
local storage.

Local extensions require a persistent profile. Chrome Web Store does not install
directly into SuperSearch, and Electron supports a subset of Chrome extension APIs.
Install only scripts and extensions you trust: they can access website data.

### A few useful shortcuts

| Shortcut | Action |
| :--- | :--- |
| `Ctrl+T` / `Ctrl+W` | Open / close a tab |
| `Ctrl+L` | Focus the address bar |
| `Ctrl+D` | Bookmark the current page |
| `Ctrl+J` | Open downloads |
| `Ctrl+,` | Open settings |
| `Ctrl+Shift+N` | Open a private window |
| `Ctrl+\` | Toggle split view |
| `Ctrl+Shift+K` | Pin / unpin selected tabs |
| `Ctrl` / `Shift` + click | Select multiple tabs |
| `Delete` | Close selected tabs while the tab list is focused |
| `F11` | Toggle fullscreen |

## Build with us

Bug reports, thoughtful feature ideas, translations and contributions are welcome.
Read [CONTRIBUTING.md](CONTRIBUTING.md) for the workflow, and include clear steps
and runtime versions when reporting a problem. Keep personal data out of reports.

```text
supersearch/
├── main.py          Application launcher
├── engine/          Electron controller, isolated preloads and browser UI
├── core/            Local libraries, password vault, backups and import
├── settings/        Preferences, translations and UI metadata
├── assets/          Original logo and local site icons
├── docs/            Privacy, agreement and release documentation
├── tests/           Unit tests and isolated browser scenarios
└── tools/           Runtime installation and source packaging
```

Run the checks from the project virtual environment:

```bash
python -m unittest discover -s tests -p 'test_*.py' -v
python tests/gui_electron.py
```

Browser tests use temporary profiles and local web fixtures. They cover navigation,
private sessions, downloads, passwords, extensions, onboarding, tours, panel layout
and backup restoration through a real process restart.

## Source releases

See the [changelog](CHANGELOG.md) for release contents and the
[release guide](docs/RELEASING.md) for publication instructions.

```bash
python tools/export_source.py
```

This produces `SuperSearch-26.11-source.zip`, its `.sha256` checksum, a per-file
manifest and `SOURCE_FULL.md` with every file included in full. User data, virtual
environments and downloaded runtimes are excluded from the source archive.

## License

SuperSearch source code is available under the **[MIT License](LICENSE)**.
Dependencies and bundled assets retain their respective licenses. See
[THIRD_PARTY.md](THIRD_PARTY.md) for attribution and distribution notices.

---

<div align="center">

**SuperSearch · Your web. Your choices.**

[Privacy Policy](docs/PRIVACY.md) · [Security](SECURITY.md) · [User Agreement](docs/TERMS.md) · [Report an issue](https://github.com/mishandreevy/supersearch/issues)

</div>
