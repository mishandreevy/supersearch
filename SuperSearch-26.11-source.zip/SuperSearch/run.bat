@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
    py -3 -m venv .venv
    if errorlevel 1 exit /b 1
)
.venv\Scripts\python.exe tools\check_runtime.py
if errorlevel 1 (
    .venv\Scripts\python.exe -c "import sys; sys.exit('Python 3.10 or newer is required for this browser runtime.') if sys.version_info < (3, 10) else None"
    if errorlevel 1 exit /b 1
    .venv\Scripts\python.exe -m pip install --upgrade -r requirements.txt
    if errorlevel 1 exit /b 1
    .venv\Scripts\python.exe tools\check_runtime.py
    if errorlevel 1 exit /b 1
)
.venv\Scripts\python.exe main.py %*
