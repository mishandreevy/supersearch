"""Install a pinned official Electron runtime with a source-controlled SHA-256 digest."""
import hashlib
import json
import os
import platform
import shutil
import stat
import sys
import tempfile
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import requests

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
MANIFEST=json.loads((ROOT/'engine/runtime.json').read_text())


def target():
    system={'linux':'linux','darwin':'darwin','win32':'win32'}.get(sys.platform)
    arch={'x86_64':'x64','amd64':'x64','aarch64':'arm64','arm64':'arm64'}.get(platform.machine().lower())
    value=f'{system}-{arch}'
    if value not in MANIFEST['sha256']:raise RuntimeError('Unsupported Electron platform: '+value)
    return value


def executable(directory):
    return directory/('Electron.app/Contents/MacOS/Electron' if sys.platform=='darwin' else 'electron.exe' if sys.platform=='win32' else 'electron')


def unpack(archive,directory):
    with ZipFile(archive) as package:
        for member in package.infolist():
            name=PurePosixPath(member.filename)
            if name.is_absolute() or '..' in name.parts or '\\' in member.filename:
                raise ValueError('Unsafe runtime archive path')
            output=directory.joinpath(*name.parts)
            mode=member.external_attr>>16
            if stat.S_ISLNK(mode):
                link=package.read(member).decode()
                resolved=(output.parent/link).resolve()
                if not resolved.is_relative_to(directory.resolve()):raise ValueError('Unsafe runtime symlink')
                output.parent.mkdir(parents=True,exist_ok=True);output.symlink_to(link)
            else:
                package.extract(member,directory)
                if mode and output.exists():output.chmod(mode&0o777)


def ensure():
    name=target();version=MANIFEST['electron']
    destination=ROOT/'.runtime'/f'electron-{version}-{name}'
    marker=destination/'.verified'
    if executable(destination).is_file() and marker.is_file() and marker.read_text()==MANIFEST['sha256'][name]:
        return executable(destination)
    destination.parent.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='electron-',dir=destination.parent) as folder:
        temporary=Path(folder);archive=temporary/'runtime.zip'
        url=f'https://github.com/electron/electron/releases/download/v{version}/electron-v{version}-{name}.zip'
        print(f'Downloading verified Electron {version} / Chromium {MANIFEST["chromium"]}…',file=sys.stderr,flush=True)
        digest=hashlib.sha256()
        from settings.config import config,DATA
        options=dict(config)
        selected=Path(os.environ.get('SUPERSEARCH_ENGINE_DATA',DATA/'electron'))/'settings.json'
        if selected.is_file():
            saved=json.loads(selected.read_text())
            if isinstance(saved,dict):options.update(saved)
        proxy='socks5h://127.0.0.1:9050' if options['tor'] else options['proxy'].strip().replace('socks5://','socks5h://',1)
        with requests.Session() as client:
            client.trust_env=False
            if proxy:client.proxies.update(http=proxy,https=proxy)
            with client.get(url,stream=True,timeout=(15,60)) as response:
                response.raise_for_status()
                with archive.open('wb') as stream:
                    for chunk in response.iter_content(1024*1024):
                        stream.write(chunk);digest.update(chunk)
        if digest.hexdigest()!=MANIFEST['sha256'][name]:raise ValueError('Electron archive checksum mismatch')
        extracted=temporary/'unpacked';extracted.mkdir()
        unpack(archive,extracted)
        (extracted/'.verified').write_text(digest.hexdigest())
        if not executable(extracted).is_file():raise ValueError('Incomplete Electron runtime')
        if destination.exists():shutil.rmtree(destination)
        extracted.rename(destination)
    return executable(destination)


if __name__=='__main__':print(ensure())
