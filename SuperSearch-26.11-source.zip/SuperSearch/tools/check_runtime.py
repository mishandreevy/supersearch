"""Check the local data-service dependencies without Qt or any network access."""
import importlib
import sys


def ready():
    if sys.version_info<(3,10):return False
    try:
        for name in ('requests','socks','cryptography.fernet','PIL.Image'):
            importlib.import_module(name)
    except (ImportError,OSError):return False
    return True


if __name__=='__main__':raise SystemExit(0 if ready() else 1)
