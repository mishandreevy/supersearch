"""Export complete, reproducible source archives without local user data."""
import hashlib
import json
import re
import shutil
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parent.parent
ROOT_FILES = ('main.py','requirements.txt','run.sh','run.bat','.gitignore','.gitattributes',
              '.editorconfig','README.md','CHANGELOG.md','LICENSE','THIRD_PARTY.md',
              'SECURITY.md','CONTRIBUTING.md')
TREES = ('core','settings','assets','tests','tools','docs','.github','engine')
SUFFIXES = {'.py','.svg','.js','.css','.html','.md','.txt','.yml','.yaml','.json'}
PRIVATE_PARTS = {'data','.venv','venv','.runtime','.aws','.codex','.agents','.git',
                 '__pycache__','node_modules','.cache','.pytest_cache','build','dist','coverage'}
ROOT_DOTFILES = {'.gitignore','.gitattributes','.editorconfig'}


def public_source(root,path):
    relative=path.relative_to(root)
    if any(part in PRIVATE_PARTS for part in relative.parts):return False
    if any(part.startswith('.') and part!='.github' for part in relative.parts):
        if relative.as_posix() not in ROOT_DOTFILES:return False
    current=root
    for part in relative.parts:
        current=current/part
        if current.is_symlink():return False
    return path.is_file()


def sources(root=ROOT):
    root=Path(root)
    result=[]
    for name in ROOT_FILES:
        path=root/name
        if not public_source(root,path):raise ValueError('Missing or unsafe required source: '+name)
        result.append(path)
    for tree in TREES:
        result += [path for path in (root/tree).rglob('*')
                   if path.suffix in SUFFIXES and public_source(root,path)]
    return sorted(set(result),key=lambda path:path.relative_to(root).as_posix())


def release_version(root):
    package=json.loads((root/'engine/package.json').read_text(encoding='utf-8'))
    version=package['displayVersion']
    if not isinstance(version,str) or not re.fullmatch(r'\d+\.\d+(?:\.\d+)?',version):
        raise ValueError('Invalid display version in engine/package.json')
    expected=version+'.0' if version.count('.')==1 else version
    if package['version']!=expected:raise ValueError('Package version and display version do not match')
    return version


def zip_entry(name,content,executable=False):
    info=ZipInfo('SuperSearch/'+name,(2026,1,1,0,0,0))
    info.compress_type=ZIP_DEFLATED
    info.create_system=3
    info.external_attr=(0o100755 if executable else 0o100644)<<16
    return info,content


def export(root=ROOT):
    root=Path(root)
    files=sources(root)
    version=release_version(root)
    blocks=[f'# SuperSearch {version} — complete project files\n\nEvery file is included in full. Runtime user data is excluded.\n\n']
    languages={'.py':'python','.js':'javascript','.css':'css','.html':'html','.json':'json',
               '.svg':'svg','.sh':'bash','.bat':'bat','.md':'markdown','.yml':'yaml','.yaml':'yaml'}
    manifest={};contents={}
    for path in files:
        name=path.relative_to(root).as_posix()
        raw=path.read_bytes();contents[name]=raw
        content=raw.decode('utf-8')
        fence='`'*max(3,1+max([len(match) for match in re.findall(r'`{3,}',content)] or [2]))
        blocks.append(f'### {name}\n{fence}{languages.get(path.suffix,"text")}\n{content.rstrip()}\n{fence}\n\n')
        manifest[name]=hashlib.sha256(raw).hexdigest()
    full=''.join(blocks).encode('utf-8')
    manifest_bytes=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode('utf-8')
    (root/'SOURCE_FULL.md').write_bytes(full)
    (root/'SOURCE_MANIFEST.json').write_bytes(manifest_bytes)
    contents.update({'SOURCE_FULL.md':full,'SOURCE_MANIFEST.json':manifest_bytes})
    archive_path=root/'SuperSearch-source.zip'
    with ZipFile(archive_path,'w',ZIP_DEFLATED) as archive:
        for name,content in sorted(contents.items()):
            info,content=zip_entry(name,content,Path(name).suffix=='.sh')
            archive.writestr(info,content)
    with ZipFile(archive_path) as archive:
        if archive.testzip() is not None:raise ValueError('Archive verification failed')
        for name,digest in manifest.items():
            if hashlib.sha256(archive.read('SuperSearch/'+name)).hexdigest()!=digest:
                raise ValueError('Source digest mismatch: '+name)
    versioned=root/f'SuperSearch-{version}-source.zip'
    shutil.copyfile(archive_path,versioned)
    digest=hashlib.sha256(versioned.read_bytes()).hexdigest()
    (root/f'SuperSearch-{version}-source.sha256').write_text(digest+'  '+versioned.name+'\n',encoding='ascii')
    print(f'Exported {len(files)} complete files for {version}. Archive and SHA-256 manifest verified.')
    return archive_path


if __name__=='__main__':export()
