# SuperSearch 26.11 — complete project files

Every file is included in full. Runtime user data is excluded.

### .editorconfig
```text
root = true

[*]
charset = utf-8
end_of_line = lf
insert_final_newline = true
trim_trailing_whitespace = true
indent_style = space
indent_size = 4

[*.{js,json,css,html,yml,yaml}]
indent_size = 2

[*.bat]
end_of_line = crlf
```

### .gitattributes
```text
* text=auto
*.py text eol=lf
*.js text eol=lf
*.css text eol=lf
*.html text eol=lf
*.json text eol=lf
*.md text eol=lf
*.yml text eol=lf
*.yaml text eol=lf
*.svg text eol=lf
*.sh text eol=lf
*.bat text eol=crlf
*.zip binary
*.supersearch binary
```

### .github/ISSUE_TEMPLATE/bug_report.md
```markdown
---
name: Bug report
about: Describe a reproducible problem in SuperSearch
---

**SuperSearch version and operating system**

Copy the versions from Settings → About or `python main.py --engine-version`.

**Steps to reproduce**

1.
2.
3.

**Expected behavior**

**Actual behavior**

**Relevant logs or screenshots**

Remove personal information first. Do not attach browser profiles, backups,
vaults, passwords, cookies, private URLs or browsing history. For a security issue,
read SECURITY.md before posting technical details publicly.
```

### .github/PULL_REQUEST_TEMPLATE.md
```markdown
## Change

Describe the problem and resulting behavior.

## Validation

List the checks run and any platform limitations.

## Privacy impact

Describe any changes to network requests, persisted data, permissions or deletion.
Do not include real user profiles or credentials in test fixtures.
```

### .github/workflows/tests.yml
```yaml
name: Tests
on: [push, pull_request]
permissions:
  contents: read
jobs:
  python:
    runs-on: ubuntu-22.04
    strategy:
      matrix:
        python-version: ['3.11', '3.12']
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}
      - run: sudo apt-get update && sudo apt-get install -y libegl1 libgl1 libnss3 libxkbcommon0 libxkbcommon-x11-0 libxcb-cursor0 libasound2 libgtk-3-0 libgbm1 xvfb xauth
      - run: python -m pip install -r requirements.txt
      - uses: actions/cache@v4
        with:
          path: .runtime
          key: electron-${{ runner.os }}-${{ hashFiles('engine/runtime.json') }}
      - run: python tools/install_electron.py
      - run: python tools/check_runtime.py && python -m pip check
      - run: python main.py --engine-version
      - run: ELECTRON_RUN_AS_NODE=1 .runtime/electron-45.2.1-linux-x64/electron tests/electron_policy.test.js
      - run: xvfb-run -a python tests/gui_electron.py
      - run: python -m compileall -q main.py core settings engine tests tools
      - run: python -m unittest discover -s tests -p 'test_*.py' -v
      - run: python tools/export_source.py
      - uses: actions/upload-artifact@v4
        with:
          name: SuperSearch-source-python-${{ matrix.python-version }}
          path: |
            SuperSearch-*-source.zip
            SuperSearch-*-source.sha256
            SOURCE_FULL.md
            SOURCE_MANIFEST.json
          if-no-files-found: error
```

### .gitignore
```text
.venv/
.runtime/
venv/
__pycache__/
*.py[cod]
data/
.env
.env.*
.aws/
.codex/
.agents/
.idea/
.vscode/
.DS_Store
Thumbs.db
*.log
*.core
core.*
SOURCE_FULL.md
SuperSearch-source.zip
SOURCE_MANIFEST.json
dist/

# Local exports, secrets, caches and release outputs
*.supersearch
*.vault
*.sqlite
*.sqlite-*
*.db
*.pem
*.key
*.p12
*.pfx
*.bak
*.tmp
node_modules/
build/
coverage/
.pytest_cache/
SuperSearch-*-source.zip
SuperSearch-*-source.sha256
```

### CHANGELOG.md
```markdown
# Changelog

## 26.11 — 2026-11-03

Source release of SuperSearch with a single Electron/Chromium implementation.
The application displays `26.11`; Electron package metadata uses `26.11.0`.

- Chromium 156.0.8078.75 through the verified Electron 45.2.1 runtime.
- Configurable panels, compact horizontal tabs, persistent pins, split view,
  rounded controls and the original supplied start-page logo.
- English, Russian, German, French and Spanish dictionaries; first-run setup,
  optional guided tour and a returning-user backup restore flow.
- Tracker filtering, private sessions, optional search suggestions, permission
  controls and configurable proxy/Tor/secure DNS preferences.
- Local bookmarks/history/statistics, master-password vault, password-save cards,
  automatic downloads and reviewed local extensions/UserScripts.
- Password-protected `.supersearch` export and validated restore after restart.
- Complete source archives, per-file SHA-256 manifest and archive checksum.

The backup format version remains `1`, so existing supported SuperSearch exports
remain readable. Existing local profiles and the user's logo are not replaced by
this application-version update. Python 3.10+ is required; Qt/PySide6 is not used.

For scope and limitations of privacy controls, see [SECURITY.md](SECURITY.md).
```

### CONTRIBUTING.md
````markdown
# Contributing

Use Python 3.10 or newer. The browser is in `engine/`: the Electron controller,
isolated website preload, trusted HTML/CSS UI and private Python stdio service.
Shared storage and encrypted backups are in `core/`, and dictionaries/metadata in
`settings/`. Qt/PySide6 and an extra Node.js/npm installation are not required.

Runtime user data belongs only in `data/`. Never commit it or include it in source
archives. The downloaded engine cache in `.runtime/` also stays outside releases.
The application display version is **26.11**. Read it from `engine/package.json`;
Python, Electron, the About screen and backup metadata share that release identity.
See `docs/RELEASING.md` for source-publication steps.

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python tools/install_electron.py
.venv/bin/python tools/check_runtime.py
.venv/bin/python -m compileall -q main.py core settings engine tests tools
.venv/bin/python -m unittest discover -s tests -p 'test_*.py' -v
.venv/bin/python tests/gui_electron.py
.venv/bin/python main.py --engine-version
.venv/bin/python -m pip check
.venv/bin/python tools/export_source.py
```

Run JavaScript policy checks with the installed runtime (substitute the platform
path from `tools/install_electron.py`):

```sh
ELECTRON_RUN_AS_NODE=1 .runtime/electron-45.2.1-linux-x64/electron tests/electron_policy.test.js
```

`tests/gui_electron.py` runs isolated modes for ephemeral browsing, persistent storage/local extensions,
onboarding/tours, disabled website JavaScript, panel layout, backup and returning-user
restore. Pass mode names to run a subset. Tests use temporary profiles, local
HTTP/HTTPS fixtures and generated certificates. Certificate trust is scoped to the
fixture fingerprint inside a marked test profile. Layout checks cover both
horizontal edges, collapsed buttons, long translations and 75–175% interface scale.
On a headless Linux machine, use `xvfb-run -a` with a functioning sandbox.

All GUI tests use the Electron runtime and temporary profiles. `backup` and
`returning` modes export or select an encrypted file, check a wrong password,
stage a restore and launch a second process through the real restore-token path.
Never run restore/reset tests against actual user data. Keep the sandbox enabled;
Linux tests inspect real seccomp and NoNewPrivs flags.

For engine updates, review the official stable release, update the compiled
Electron/Chromium versions and official platform SHA-256 digests together in
`engine/runtime.json`, preserve upstream notices and run the integration tests.
A user-agent change is not an engine update. Do not silently reuse incompatible
Chromium-internal profile files.

For privacy changes, describe which network requests occur, whether they require
consent, how proxy/Tor routing is preserved and whether anything reaches disk.
For storage cleanup changes, use a temporary directory and an unrelated sentinel
file. Never test deletion against a real profile. Never log IPC request bodies,
master passwords, vault plaintext or captured form credentials.

Do not claim full anonymity, universal extension compatibility, complete OS-key
migration or secure physical erasure. Preserve dependency and asset attribution.
````

### LICENSE
```text
MIT License

Copyright (c) 2026 SuperSearch contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### README.md
````markdown
<div align="center">

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/logo-light.svg">
  <img src="assets/logo.svg" alt="SuperSearch" width="440">
</picture>

### Your web. Your choices.

A customizable desktop browser with local data, thoughtful privacy controls,\
and a Chromium engine. Built with **Electron + Python**, released under **MIT**.

[![Version](https://img.shields.io/badge/version-26.11-6366f1?style=flat-square)](CHANGELOG.md)
[![Chromium](https://img.shields.io/badge/Chromium-156-4285f4?style=flat-square)](engine/runtime.json)
[![Python](https://img.shields.io/badge/Python-3.10%2B-3776ab?style=flat-square)](requirements.txt)
[![License: MIT](https://img.shields.io/badge/license-MIT-16a34a?style=flat-square)](LICENSE)

[Features](#features) · [Quickstart](#quickstart) · [Privacy](#privacy-by-choice) · [Backups](#take-your-browser-with-you) · [Contributing](#build-with-us)

</div>

---

SuperSearch gives your everyday browsing a workspace you can shape: move your tabs,
keep two pages side by side, choose your colors and make the start page your own.
Your bookmarks, preferences and password vault stay on your device, with clear
controls over what the browser remembers and how it connects.

## Features

| Your workspace | Your privacy | Your everyday browsing |
| :--- | :--- | :--- |
| Panels on any edge | Ad and tracker filtering | Bookmarks with folders |
| Compact horizontal tabs | Separate private sessions | Master-password vault |
| Pinned tabs that stay pinned | Optional search suggestions | Password-save prompts |
| Two-page split view | HTTPS upgrades and link cleanup | Automatic file downloads |
| Light, dark and OLED themes | Configurable proxy, Tor and secure DNS | Encrypted data backups |
| Wallpaper and editable shortcuts | Camera, microphone and location denied by default | Five interface languages |

**An interface that adapts to you.** Adjust fonts, scale, colors, corners and toolbar
buttons. Collapsed panels show site icons; horizontal tabs fit into one compact row.
Settings, downloads and password management open inside the browser window.

**A start page that feels like home.** Search, pin your favorite websites, choose a
wallpaper and see real tracker-blocking statistics. Site icons are bundled or cached
locally. The optional public-IP display follows your active connection route.

**A welcoming first launch.** Choose a language, preview your preferences, import
supported data from another browser or restore a SuperSearch backup. New users can
follow a short tour, skip it or replay it later from **Settings → About**.

## Quickstart

You need **Python 3.10+ with pip**, a graphical desktop and the platform libraries
required by Chromium. Node.js, npm and Qt/PySide6 are not required.

Get the source by cloning this repository or extracting a source-release archive:

```bash
git clone https://github.com/mishandreevy/supersearch.git
cd supersearch
```

**Linux / macOS**

```bash
chmod +x run.sh
./run.sh
```

**Windows**

```bat
run.bat
```

The launcher creates `.venv`, installs the Python dependencies and downloads the
pinned official Electron runtime on first launch. Its archive is verified against a
SHA-256 digest before extraction. The first launch needs internet access; a matching
runtime is reused on later launches. Saved proxy/Tor settings apply to the download.

<details>
<summary><strong>Arch Linux dependencies</strong></summary>

Install the desktop libraries and Python tooling before running `./run.sh`:

```bash
sudo pacman -Syu --needed python python-pip gtk3 nss alsa-lib libcups libxcomposite libxdamage libxrandr libxkbcommon mesa xdg-utils
```

Run the browser as your normal user with Chromium's sandbox enabled. Linux needs
unprivileged user namespaces. The source launcher runs from a writable project
folder; a native Arch `.pkg.tar.zst` package is not included.

</details>

<details>
<summary><strong>Manual setup</strong></summary>

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python main.py
```

On Windows, use `.venv\Scripts\python.exe` instead of `.venv/bin/python`.

Check the actual loaded application and engine versions:

```bash
.venv/bin/python main.py --engine-version
```

</details>

Version **26.11** uses **Electron 45.2.1 / Chromium 156.0.8078.75**, pinned in
[`engine/runtime.json`](engine/runtime.json). Browser checks currently run on Linux;
Windows and macOS launch scripts are included, with native verification still needed
before publishing binaries for those platforms.

## Privacy by choice

Privacy controls should be understandable. SuperSearch keeps everyday data local
and lets you choose the settings that suit your browsing.

- **Local libraries.** Bookmarks, preferences, shortcuts, blocking statistics and
  the encrypted password vault live in `data/electron/`.
- **Less persistence by default.** Website storage stays in memory unless you
  enable a persistent profile. Recording browsing history is optional.
- **Separate private sessions.** Private windows do not persist their history,
  tab pins, tracker records or captured passwords. Downloaded files remain on disk.
- **Optional suggestions.** Enabling suggestions sends typed queries to DuckDuckGo.
  Suggestions are disabled in private windows.
- **Explicit connection choices.** Proxy and Tor routes have no direct fallback.
  Tor requires a separately running service at `127.0.0.1:9050`.
- **No product telemetry or browsing-history uploads to the developer.** Visited
  websites, chosen search services and enabled network features still receive the
  requests needed to work.

The optional start-page IP display contacts **ipify** through the browsing session's
route. You can turn it off in Appearance or the start-page editor. Filter-list
updates and proxy tests are user-triggered actions.

SuperSearch does not promise complete anonymity or implement Tor Browser's anonymity
model. Fingerprinting controls and third-party cookie handling have practical limits.
Read the [security model](SECURITY.md) and [Privacy Policy](docs/PRIVACY.md) for details.

## Take your browser with you

**Settings → Storage → Export browser data** creates a password-protected
`.supersearch` file that you can restore on another installation.

| Included | Kept out of the transfer |
| :--- | :--- |
| Saved settings, bookmarks and history | Website cookies and signed-in sessions |
| Encrypted password vault | Browser cache and Chromium profile internals |
| Tabs, pins and tracker statistics | Downloaded files and deletion records |
| Shortcuts, wallpaper and cached icons | Extension packages |
| Filters and UserScripts/styles | Private-window data |

The backup uses a separate password of at least **12 characters**. The password
vault keeps its original master password; the backup password does not unlock it.
Neither password can be recovered if forgotten.

Restore from **Settings → Storage → Restore browser data**, or choose **Yes, I am
returning** during first launch. SuperSearch validates the backup before changing
your libraries, asks for replacement confirmation and restarts to install the data.
A wrong password or invalid archive leaves your current libraries intact.

Restoring clears existing website sessions. Exported tabs reopen once without
changing your normal keep-tabs preference. UserScripts/styles require separate
opt-in, and extensions need to be installed again. Portable backups support up to
128 MB of source data and a 180 MB encrypted file.

## Make it your own

Use JavaScript UserScripts, CSS styles or compatible local **Manifest V3** extensions
to customize websites. CSS files are injected as styles; scripts are loaded from
local storage.

Local extensions require a persistent profile. Chrome Web Store does not install
directly into SuperSearch, and Electron supports a subset of Chrome extension APIs.
Install only scripts and extensions you trust: they can access website data.

### A few useful shortcuts

| Shortcut | Action |
| :--- | :--- |
| `Ctrl+T` / `Ctrl+W` | Open / close a tab |
| `Ctrl+L` | Focus the address bar |
| `Ctrl+D` | Bookmark the current page |
| `Ctrl+J` | Open downloads |
| `Ctrl+,` | Open settings |
| `Ctrl+Shift+N` | Open a private window |
| `Ctrl+\` | Toggle split view |
| `Ctrl+Shift+K` | Pin / unpin selected tabs |
| `Ctrl` / `Shift` + click | Select multiple tabs |
| `Delete` | Close selected tabs while the tab list is focused |
| `F11` | Toggle fullscreen |

## Build with us

Bug reports, thoughtful feature ideas, translations and contributions are welcome.
Read [CONTRIBUTING.md](CONTRIBUTING.md) for the workflow, and include clear steps
and runtime versions when reporting a problem. Keep personal data out of reports.

```text
supersearch/
├── main.py          Application launcher
├── engine/          Electron controller, isolated preloads and browser UI
├── core/            Local libraries, password vault, backups and import
├── settings/        Preferences, translations and UI metadata
├── assets/          Original logo and local site icons
├── docs/            Privacy, agreement and release documentation
├── tests/           Unit tests and isolated browser scenarios
└── tools/           Runtime installation and source packaging
```

Run the checks from the project virtual environment:

```bash
python -m unittest discover -s tests -p 'test_*.py' -v
python tests/gui_electron.py
```

Browser tests use temporary profiles and local web fixtures. They cover navigation,
private sessions, downloads, passwords, extensions, onboarding, tours, panel layout
and backup restoration through a real process restart.

## Source releases

See the [changelog](CHANGELOG.md) for release contents and the
[release guide](docs/RELEASING.md) for publication instructions.

```bash
python tools/export_source.py
```

This produces `SuperSearch-26.11-source.zip`, its `.sha256` checksum, a per-file
manifest and `SOURCE_FULL.md` with every file included in full. User data, virtual
environments and downloaded runtimes are excluded from the source archive.

## License

SuperSearch source code is available under the **[MIT License](LICENSE)**.
Dependencies and bundled assets retain their respective licenses. See
[THIRD_PARTY.md](THIRD_PARTY.md) for attribution and distribution notices.

---

<div align="center">

**SuperSearch · Your web. Your choices.**

[Privacy Policy](docs/PRIVACY.md) · [Security](SECURITY.md) · [User Agreement](docs/TERMS.md) · [Report an issue](https://github.com/mishandreevy/supersearch/issues)

</div>
````

### SECURITY.md
```markdown
# Security and privacy model

SuperSearch 26.11 uses Electron 45.2.1 / Chromium 156.0.8078.75 by default.
This project has
not undergone an independent security audit and does not implement Tor Browser's
anonymity model.

## Process and trust boundaries

Untrusted websites run in Chromium WebContentsView renderers with `sandbox: true`,
`contextIsolation: true`, `nodeIntegration: false`, `webSecurity: true`, no Node in
workers/subframes, no webview embedding and no insecure-content override. The app
explicitly enables Chromium's sandbox. Linux uses its user-namespace sandbox;
`--no-sandbox` is not used. Linux integration tests check the renderer's actual
NoNewPrivs and seccomp flags as well as its web preferences.

The browser UI has a separate in-memory session and a restrictive CSP. Site
renderers cannot load its resource handler or access its exposed API. The UI
preload exposes a bounded command interface, not raw ipcRenderer, filesystem or
code execution. Native handlers check the exact UI webContents, top-level frame
and `ss-app://browser/index.html` URL. Remote renderers have no public browser API.

The Python service accepts newline-delimited JSON over the parent process's stdio
pipes. It does not open an HTTP server, WebSocket or TCP listener. Plaintext vault
operations and a master password can exist in process/pipe memory during explicit
operations, but are never logged, included in state broadcasts or sent to websites
through the UI bridge. A compromised OS can read memory or modify executable code.
Python and JavaScript do not guarantee secure physical memory erasure.

## Engine installation and maintenance

`engine/runtime.json` pins both compiled engine versions and official archive
SHA-256 digests. Installation checks the archive digest before safe extraction,
including containment checks for paths and symlinks. Loading checks the actual
runtime versions. Installed runtimes are not silently updated on browser launch.
Source archives exclude `.runtime/` and all user data.

Current release information comes from the official Electron release service.
Maintainers must review future Chromium security releases and update the pin and
digests; a pinned dependency is not a promise of indefinite security.

## Network route and permissions

Browsing sessions are configured before website views are created. Tor uses a
separately running SOCKS5 service at 127.0.0.1:9050 and takes priority over the
configured proxy. Fixed proxy routes have no DIRECT fallback and disable the
implicit loopback bypass. Integration tests verify that a failed proxy cannot
reach a loopback origin directly. Session fetches for suggestions, icons, filters
and IP checks use the selected route. Proxy tests use their own memory session.
Runtime downloads also respect saved proxy/Tor preferences.

Secure DNS uses the configured Chromium resolver and requires restart. SOCKS4 and
HTTP proxy behavior is protocol-dependent; selecting a proxy does not establish
Tor Browser-like anonymity. There is no promise that every system DNS or OS-level
network request is hidden. Site JavaScript and startup networking changes require
a new browser process. The trusted UI remains operational with site JS disabled.

Camera, microphone, geolocation, notifications, display capture and device access
are denied by default. User-gesture website fullscreen is supported without
granting these permissions. Invalid certificates are rejected and the local error
screen offers no certificate bypass. Tests trust only their generated loopback
certificate inside an explicitly marked temporary test process.

## Tracking controls and limits

The filter engine supports domain anchors, exceptions and literal substring
rules. Unsupported ABP syntax, cosmetic rules and modifiers are skipped and
reported. It does not claim full EasyList/EasyPrivacy semantics. HTTPS-only mode
upgrades requests without falling back to HTTP. Link cleanup removes common
advertising parameters; referrer stripping and privacy preference signals are
configurable.

Third-party cookie handling uses the top-level browsing host to remove cross-site
Cookie and Set-Cookie headers. This is a heuristic, not a complete public-suffix
cookie policy or a guarantee of total third-party storage isolation. Strict
settings can break embedded sign-in features.

Privacy preloads run before main-frame website scripts. They can block WebRTC and
location APIs, restrict canvas reads and alter some navigator/screen/UTC/canvas/
WebGL/audio observations. This does not cover every worker, subframe or device API.
Spoofing is observable and can increase fingerprint uniqueness. Canvas/WebGL
restrictions and disabled JavaScript can break websites. A direct connection
still exposes its public IP address; these controls do not guarantee anonymity.

Suggestions require opt-in, reject obvious URL/credential-shaped input and are
unavailable in private windows. Stale results are discarded after edits, tab
changes or loss of focus. Settings search is local and never goes to a provider.

Public IP checks contact ipify only when the feature/counters are enabled and a
start-page pane is selected in an open, non-minimized window. The visible session's
proxy/Tor route is used, including a private session when appropriate. Results and
failures stay in memory for ten minutes; disabling clears pending results. This
snapshot is not an anonymity or leak test.

## Passwords, persistence and portable backups

The original Fernet vault format is preserved. PBKDF2-HMAC-SHA256 uses a random
salt and 1,200,000 iterations. The master password is not stored and needs at least
12 characters. Idle locking happens in the service rather than depending on a
visible password screen. State snapshots list only vault status, not credentials.

Login capture is limited to submitted same-origin HTTPS forms in an owned
main-frame site view. Private windows and JS-disabled views do not capture.
Pending input expires after 30 seconds. A post-navigation/form-disappearance
heuristic can offer a save card; this is not proof that the server authenticated
the user. Only an explicit Save writes to the encrypted vault. Dismissal, tab
changes, locking and expiry clear pending references. Explicit filling checks the
complete scheme/host/port origin before retrieving and placing a secret.

The active browser profile lives in `data/electron/`. The one-time legacy migration
copies compatible libraries without deleting original data. There is one browser
implementation and no Qt dependency or alternate launcher. Chromium profile
internals are not reused across engines. Import reads an explicitly selected source;
OS-protected credentials, cookies, payment details and sync are not bypassed.

Encrypted `.supersearch` backups use Fernet with PBKDF2-HMAC-SHA256 (1,200,000
iterations and a fresh 16-byte salt). The backup password is never stored. The
existing vault stays encrypted with its own master password. Exports omit website
sessions, cache, extension packages, downloads and download deletion proofs. Normal
window data only is exported; backup operations are denied in private windows.

Restore requires native file selection, an expiring owner-bound choice token, the
backup password and explicit replacement consent. Before setup is complete, the
current User Agreement must also be accepted. Authenticated payloads still undergo
size/version/hash/path/type checks; duplicate entries, symlinks and unsupported paths
are rejected. Settings validation prevents injected toolbar identifiers and unreadable
colors. Statistics are rebuilt into a clean database. UserScripts require a separate
opt-in, and local extensions are not restored.

Staging files stay under a private directory inside the profile. The old browser and
service exit before the launcher replaces local libraries and clears website sessions.
Rename failures roll back installation; malformed or unauthenticated backups never
reach this step. Filesystem replacement is not a power-loss-proof database transaction.
Backups and files exported outside the profile are not removed by browser reset.

Normal website storage is in memory by default. Private windows always use their
own memory sessions and do not write tab pins, history, tracker records or captured
credentials. Downloads are explicit files outside the browser profile; private
file downloads are not automatically erased when the window closes.

## Extensions and deletion

UserScripts/styles and local Manifest V3 extensions are trusted code chosen by the
user. They may read website data and communicate over the network. Extension
installation shows declared permissions, restricts archive paths and symlinks,
disallows local file access and requires a persistent non-private session. Electron
supports a subset of extension APIs; Chrome Web Store is not a direct installer.
Scripts cannot access Node through site views. Private script execution is opt-in.

Storage cleanup names its categories and requires confirmation. Reset requires the
literal text `Delete`. The old browser/service processes release their files
before startup cleanup runs. Reset targets the active `data/electron/` profile. Original legacy migration files
elsewhere and user-selected exports outside that profile are not deleted.

Download cleanup deletes only paths whose stored file identity still matches the
owned download record. Unrelated/replaced files are preserved. File deletion is
not secure physical erasure and cannot remove copies in backups or other apps.

## Reporting

Report a reproducible issue with the actual runtime versions and minimal steps.
Never include a real vault, master password, cookies, private history or a complete
`data/` folder in a public report. See the source repository link in About.
```

### THIRD_PARTY.md
```markdown
# Third-party components

The source archive contains SuperSearch source and assets. It does not bundle Python,
Electron, Node.js, Chromium or installed Python dependencies. The separately
downloaded official Electron archive retains its bundled LICENSE and
LICENSES.chromium.html notices; preserve these when distributing a runtime.

| Component | Project | License |
|---|---|---|
| Electron | https://github.com/electron/electron | MIT; bundled dependency notices apply |
| Node.js | https://github.com/nodejs/node | MIT and bundled dependency notices |
| Chromium / Electron dependencies | https://www.electronjs.org/docs/latest/tutorial/electron-timelines | Upstream component licenses; see the runtime LICENSES.chromium.html |
| requests | https://requests.readthedocs.io/ | Apache-2.0 |
| PySocks | https://github.com/Anorov/PySocks | BSD-3-Clause |
| Pillow | https://python-pillow.github.io/ | MIT-CMU (HPND) |
| cryptography | https://cryptography.io/ | Apache-2.0 OR BSD-3-Clause |
| Simple Icons SVG brand icons | https://github.com/simple-icons/simple-icons | CC0-1.0 |

The six SVGs in `assets/site-icons/` were obtained from the Simple Icons repository:
DuckDuckGo, Wikipedia, GitHub, Reddit, YouTube and Arch Linux. The complete upstream
license is included in `assets/site-icons/LICENSE.md`. Brand names and trademarks
remain with their respective owners; CC0 does not grant trademark rights.

`assets/logo.svg` is the original logo supplied with this project and is used on
the start page, first-run setup and About screen. The small interface icons
in `core/icons.py` are repo-native SVG paths and do not require an external icon service.

EasyList and EasyPrivacy are not bundled in the source archive. The user explicitly
requests their download. Their upstream licenses and notices apply to those lists:
https://easylist.to/ . Distributing Electron/Chromium binaries or downloaded filter lists
requires preserving the applicable upstream notices.
```

### assets/logo-light.svg
```svg
<?xml version="1.0" standalone="no"?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 20010904//EN"
 "http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd">
<svg version="1.0" xmlns="http://www.w3.org/2000/svg"
 width="1271.000000pt" height="158.000000pt" viewBox="0 0 1271.000000 158.000000"
 preserveAspectRatio="xMidYMid meet">

<g transform="translate(0.000000,158.000000) scale(0.100000,-0.100000)"
fill="#f0f3f9" stroke="none">
<path d="M11575 1548 c-3 -7 -4 -287 -3 -623 l3 -610 131 -3 132 -3 4 263 c4
246 6 266 26 313 45 98 103 137 215 143 123 7 192 -29 234 -123 15 -35 18 -78
21 -318 l4 -278 131 3 132 3 3 250 c4 372 -15 469 -112 573 -82 88 -233 134
-359 112 -121 -22 -161 -51 -242 -178 -22 -34 -43 -62 -47 -62 -5 0 -8 124 -8
275 l0 275 -130 0 c-95 0 -132 -3 -135 -12z"/>
<path d="M620 1254 c-305 -32 -453 -159 -410 -351 10 -47 21 -65 65 -109 74
-75 152 -98 417 -123 112 -11 215 -24 230 -30 82 -31 64 -118 -31 -150 -51
-17 -237 -14 -300 5 -54 16 -125 71 -136 105 -6 17 -17 19 -141 19 l-134 0 0
-28 c0 -15 12 -51 26 -79 70 -142 264 -223 529 -223 204 0 346 41 429 123 98
99 101 275 6 361 -76 68 -154 89 -434 115 -231 21 -258 30 -264 88 -6 64 79
98 233 91 120 -5 186 -32 224 -91 l24 -37 134 0 c92 0 133 3 133 11 0 77 -85
179 -194 233 -104 51 -285 83 -406 70z"/>
<path d="M3204 1245 c-113 -24 -180 -71 -261 -181 -26 -35 -50 -64 -55 -64 -4
0 -8 52 -8 115 l0 115 -135 0 -135 0 0 -590 0 -590 135 0 135 0 0 245 c0 135
3 245 8 245 4 0 18 -17 32 -38 40 -60 109 -129 154 -156 127 -74 325 -74 452
0 150 88 237 275 220 475 -20 235 -163 397 -381 429 -85 12 -85 12 -161 -5z
m80 -210 c77 -20 128 -62 163 -133 36 -73 38 -181 6 -252 -80 -176 -303 -202
-463 -54 -58 54 -110 138 -110 178 0 31 56 122 104 170 47 47 112 82 177 95
62 12 59 13 123 -4z"/>
<path d="M4311 1250 c-184 -26 -332 -123 -406 -270 -45 -87 -58 -226 -31 -326
46 -173 198 -308 393 -349 184 -39 422 -2 579 90 l45 26 -20 27 c-11 15 -35
42 -55 61 l-35 34 -59 -26 c-53 -24 -72 -27 -171 -27 -197 0 -311 42 -371 136
-16 26 -27 51 -24 55 3 5 176 9 384 9 l380 0 -6 63 c-14 155 -65 275 -151 361
-113 112 -273 160 -452 136z m206 -215 c21 -9 51 -28 66 -43 28 -27 67 -91 67
-112 0 -7 -84 -10 -250 -10 -237 0 -250 1 -250 18 0 25 51 94 87 119 28 19 69
37 108 47 34 8 133 -3 172 -19z"/>
<path d="M5610 1247 c-30 -7 -66 -19 -80 -26 -78 -42 -143 -121 -171 -206
l-13 -40 -21 125 -20 125 -138 3 -138 3 6 -23 c50 -226 55 -283 55 -593 l0
-305 134 0 135 0 3 257 c3 288 8 312 79 382 68 67 155 87 314 71 l50 -5 3 107
c2 94 1 108 -15 116 -32 17 -126 22 -183 9z"/>
<path d="M6258 1250 c-150 -17 -242 -55 -311 -129 -53 -57 -72 -112 -64 -189
8 -71 45 -132 104 -169 91 -57 140 -68 393 -93 230 -22 263 -33 268 -89 7 -74
-65 -105 -240 -100 -111 4 -129 7 -181 32 -42 21 -63 39 -80 68 l-22 39 -137
0 -137 0 6 -32 c18 -95 94 -183 200 -234 174 -82 523 -86 688 -8 162 77 223
260 132 395 -62 92 -165 124 -487 149 -164 14 -203 23 -229 56 -27 35 -12 76
37 101 30 15 61 18 162 18 117 0 128 -2 178 -28 33 -17 61 -41 74 -62 l20 -35
134 0 c154 0 153 -1 108 88 -80 161 -336 253 -616 222z"/>
<path d="M7475 1249 c-141 -21 -246 -72 -328 -160 -96 -103 -137 -237 -117
-384 35 -249 260 -415 564 -415 110 0 214 18 307 53 65 25 149 71 149 83 0 4
-23 32 -50 64 l-51 58 -47 -26 c-45 -26 -52 -27 -202 -26 -136 0 -162 3 -212
22 -31 13 -68 32 -83 44 -33 26 -85 96 -85 115 0 11 68 13 380 13 l380 0 0 48
c-1 179 -101 365 -241 449 -92 55 -243 81 -364 62z m229 -227 c37 -21 60 -44
84 -82 17 -30 32 -58 32 -62 0 -4 -115 -8 -256 -8 l-255 0 7 22 c45 144 245
210 388 130z"/>
<path d="M8595 1253 c-111 -15 -199 -58 -272 -136 -84 -89 -123 -200 -123
-347 0 -288 180 -480 450 -480 153 0 260 55 353 182 l52 71 6 -39 c4 -21 10
-74 14 -116 l7 -78 140 0 141 0 -6 52 c-3 29 -15 134 -27 233 l-20 180 25 213
c14 117 25 220 25 228 0 11 -25 14 -139 14 l-139 0 -12 -115 c-7 -63 -14 -115
-15 -115 -1 0 -15 19 -30 42 -81 122 -175 186 -305 207 -66 11 -71 11 -125 4z
m235 -225 c80 -25 172 -110 217 -203 l27 -54 -25 -53 c-30 -66 -119 -157 -184
-189 -41 -20 -65 -24 -136 -24 -78 0 -90 3 -135 30 -160 99 -165 358 -9 467
65 46 151 55 245 26z"/>
<path d="M10080 1247 c-123 -29 -201 -103 -255 -242 -10 -25 -10 -25 -33 117
l-18 103 -138 3 -138 3 7 -28 c4 -15 18 -84 31 -153 22 -115 24 -149 24 -433
l0 -308 133 3 132 3 5 255 c5 230 8 259 27 300 25 55 96 123 149 141 42 15
164 18 232 6 l42 -7 0 114 c0 110 -1 114 -22 119 -56 14 -127 15 -178 4z"/>
<path d="M10777 1249 c-245 -33 -416 -189 -447 -407 -29 -206 64 -390 246
-485 88 -45 187 -67 308 -67 254 0 457 123 523 319 12 36 20 68 18 71 -4 7
-263 -25 -271 -33 -3 -2 -15 -24 -27 -48 -27 -55 -77 -84 -169 -99 -153 -26
-273 23 -331 135 -29 57 -35 176 -12 245 46 138 209 204 374 153 67 -21 145
-92 156 -141 l7 -32 138 0 138 0 -9 41 c-52 231 -342 389 -642 348z"/>
<path d="M1380 958 c0 -150 5 -302 11 -338 25 -160 121 -274 264 -316 78 -22
212 -16 277 13 58 27 137 98 180 165 17 28 33 47 35 42 2 -6 11 -55 21 -109
l17 -100 133 -3 c107 -2 132 0 132 11 0 8 -11 74 -25 148 -23 124 -25 156 -25
447 l0 312 -134 0 -135 0 -4 -262 c-2 -191 -7 -274 -18 -303 -20 -59 -94 -129
-151 -143 -132 -33 -235 6 -282 108 -19 42 -21 66 -24 323 l-3 277 -135 0
-134 0 0 -272z"/>
</g>
</svg>
```

### assets/logo.svg
```svg
<?xml version="1.0" standalone="no"?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 20010904//EN"
 "http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd">
<svg version="1.0" xmlns="http://www.w3.org/2000/svg"
 width="1271.000000pt" height="158.000000pt" viewBox="0 0 1271.000000 158.000000"
 preserveAspectRatio="xMidYMid meet">

<g transform="translate(0.000000,158.000000) scale(0.100000,-0.100000)"
fill="#000000" stroke="none">
<path d="M11575 1548 c-3 -7 -4 -287 -3 -623 l3 -610 131 -3 132 -3 4 263 c4
246 6 266 26 313 45 98 103 137 215 143 123 7 192 -29 234 -123 15 -35 18 -78
21 -318 l4 -278 131 3 132 3 3 250 c4 372 -15 469 -112 573 -82 88 -233 134
-359 112 -121 -22 -161 -51 -242 -178 -22 -34 -43 -62 -47 -62 -5 0 -8 124 -8
275 l0 275 -130 0 c-95 0 -132 -3 -135 -12z"/>
<path d="M620 1254 c-305 -32 -453 -159 -410 -351 10 -47 21 -65 65 -109 74
-75 152 -98 417 -123 112 -11 215 -24 230 -30 82 -31 64 -118 -31 -150 -51
-17 -237 -14 -300 5 -54 16 -125 71 -136 105 -6 17 -17 19 -141 19 l-134 0 0
-28 c0 -15 12 -51 26 -79 70 -142 264 -223 529 -223 204 0 346 41 429 123 98
99 101 275 6 361 -76 68 -154 89 -434 115 -231 21 -258 30 -264 88 -6 64 79
98 233 91 120 -5 186 -32 224 -91 l24 -37 134 0 c92 0 133 3 133 11 0 77 -85
179 -194 233 -104 51 -285 83 -406 70z"/>
<path d="M3204 1245 c-113 -24 -180 -71 -261 -181 -26 -35 -50 -64 -55 -64 -4
0 -8 52 -8 115 l0 115 -135 0 -135 0 0 -590 0 -590 135 0 135 0 0 245 c0 135
3 245 8 245 4 0 18 -17 32 -38 40 -60 109 -129 154 -156 127 -74 325 -74 452
0 150 88 237 275 220 475 -20 235 -163 397 -381 429 -85 12 -85 12 -161 -5z
m80 -210 c77 -20 128 -62 163 -133 36 -73 38 -181 6 -252 -80 -176 -303 -202
-463 -54 -58 54 -110 138 -110 178 0 31 56 122 104 170 47 47 112 82 177 95
62 12 59 13 123 -4z"/>
<path d="M4311 1250 c-184 -26 -332 -123 -406 -270 -45 -87 -58 -226 -31 -326
46 -173 198 -308 393 -349 184 -39 422 -2 579 90 l45 26 -20 27 c-11 15 -35
42 -55 61 l-35 34 -59 -26 c-53 -24 -72 -27 -171 -27 -197 0 -311 42 -371 136
-16 26 -27 51 -24 55 3 5 176 9 384 9 l380 0 -6 63 c-14 155 -65 275 -151 361
-113 112 -273 160 -452 136z m206 -215 c21 -9 51 -28 66 -43 28 -27 67 -91 67
-112 0 -7 -84 -10 -250 -10 -237 0 -250 1 -250 18 0 25 51 94 87 119 28 19 69
37 108 47 34 8 133 -3 172 -19z"/>
<path d="M5610 1247 c-30 -7 -66 -19 -80 -26 -78 -42 -143 -121 -171 -206
l-13 -40 -21 125 -20 125 -138 3 -138 3 6 -23 c50 -226 55 -283 55 -593 l0
-305 134 0 135 0 3 257 c3 288 8 312 79 382 68 67 155 87 314 71 l50 -5 3 107
c2 94 1 108 -15 116 -32 17 -126 22 -183 9z"/>
<path d="M6258 1250 c-150 -17 -242 -55 -311 -129 -53 -57 -72 -112 -64 -189
8 -71 45 -132 104 -169 91 -57 140 -68 393 -93 230 -22 263 -33 268 -89 7 -74
-65 -105 -240 -100 -111 4 -129 7 -181 32 -42 21 -63 39 -80 68 l-22 39 -137
0 -137 0 6 -32 c18 -95 94 -183 200 -234 174 -82 523 -86 688 -8 162 77 223
260 132 395 -62 92 -165 124 -487 149 -164 14 -203 23 -229 56 -27 35 -12 76
37 101 30 15 61 18 162 18 117 0 128 -2 178 -28 33 -17 61 -41 74 -62 l20 -35
134 0 c154 0 153 -1 108 88 -80 161 -336 253 -616 222z"/>
<path d="M7475 1249 c-141 -21 -246 -72 -328 -160 -96 -103 -137 -237 -117
-384 35 -249 260 -415 564 -415 110 0 214 18 307 53 65 25 149 71 149 83 0 4
-23 32 -50 64 l-51 58 -47 -26 c-45 -26 -52 -27 -202 -26 -136 0 -162 3 -212
22 -31 13 -68 32 -83 44 -33 26 -85 96 -85 115 0 11 68 13 380 13 l380 0 0 48
c-1 179 -101 365 -241 449 -92 55 -243 81 -364 62z m229 -227 c37 -21 60 -44
84 -82 17 -30 32 -58 32 -62 0 -4 -115 -8 -256 -8 l-255 0 7 22 c45 144 245
210 388 130z"/>
<path d="M8595 1253 c-111 -15 -199 -58 -272 -136 -84 -89 -123 -200 -123
-347 0 -288 180 -480 450 -480 153 0 260 55 353 182 l52 71 6 -39 c4 -21 10
-74 14 -116 l7 -78 140 0 141 0 -6 52 c-3 29 -15 134 -27 233 l-20 180 25 213
c14 117 25 220 25 228 0 11 -25 14 -139 14 l-139 0 -12 -115 c-7 -63 -14 -115
-15 -115 -1 0 -15 19 -30 42 -81 122 -175 186 -305 207 -66 11 -71 11 -125 4z
m235 -225 c80 -25 172 -110 217 -203 l27 -54 -25 -53 c-30 -66 -119 -157 -184
-189 -41 -20 -65 -24 -136 -24 -78 0 -90 3 -135 30 -160 99 -165 358 -9 467
65 46 151 55 245 26z"/>
<path d="M10080 1247 c-123 -29 -201 -103 -255 -242 -10 -25 -10 -25 -33 117
l-18 103 -138 3 -138 3 7 -28 c4 -15 18 -84 31 -153 22 -115 24 -149 24 -433
l0 -308 133 3 132 3 5 255 c5 230 8 259 27 300 25 55 96 123 149 141 42 15
164 18 232 6 l42 -7 0 114 c0 110 -1 114 -22 119 -56 14 -127 15 -178 4z"/>
<path d="M10777 1249 c-245 -33 -416 -189 -447 -407 -29 -206 64 -390 246
-485 88 -45 187 -67 308 -67 254 0 457 123 523 319 12 36 20 68 18 71 -4 7
-263 -25 -271 -33 -3 -2 -15 -24 -27 -48 -27 -55 -77 -84 -169 -99 -153 -26
-273 23 -331 135 -29 57 -35 176 -12 245 46 138 209 204 374 153 67 -21 145
-92 156 -141 l7 -32 138 0 138 0 -9 41 c-52 231 -342 389 -642 348z"/>
<path d="M1380 958 c0 -150 5 -302 11 -338 25 -160 121 -274 264 -316 78 -22
212 -16 277 13 58 27 137 98 180 165 17 28 33 47 35 42 2 -6 11 -55 21 -109
l17 -100 133 -3 c107 -2 132 0 132 11 0 8 -11 74 -25 148 -23 124 -25 156 -25
447 l0 312 -134 0 -135 0 -4 -262 c-2 -191 -7 -274 -18 -303 -20 -59 -94 -129
-151 -143 -132 -33 -235 6 -282 108 -19 42 -21 66 -24 323 l-3 277 -135 0
-134 0 0 -272z"/>
</g>
</svg>
```

### assets/site-icons/LICENSE.md
```markdown
# CC0 1.0 Universal

## Statement of Purpose

The laws of most jurisdictions throughout the world automatically confer exclusive Copyright and Related Rights (defined below) upon the creator and subsequent owner(s) (each and all, an “owner”) of an original work of authorship and/or a database (each, a “Work”).

Certain owners wish to permanently relinquish those rights to a Work for the purpose of contributing to a commons of creative, cultural and scientific works (“Commons”) that the public can reliably and without fear of later claims of infringement build upon, modify, incorporate in other works, reuse and redistribute as freely as possible in any form whatsoever and for any purposes, including without limitation commercial purposes. These owners may contribute to the Commons to promote the ideal of a free culture and the further production of creative, cultural and scientific works, or to gain reputation or greater distribution for their Work in part through the use and efforts of others.

For these and/or other purposes and motivations, and without any expectation of additional consideration or compensation, the person associating CC0 with a Work (the “Affirmer”), to the extent that he or she is an owner of Copyright and Related Rights in the Work, voluntarily elects to apply CC0 to the Work and publicly distribute the Work under its terms, with knowledge of his or her Copyright and Related Rights in the Work and the meaning and intended legal effect of CC0 on those rights.

1. Copyright and Related Rights. A Work made available under CC0 may be protected by copyright and related or neighboring rights (“Copyright and Related Rights”). Copyright and Related Rights include, but are not limited to, the following:
    1. the right to reproduce, adapt, distribute, perform, display, communicate, and translate a Work;
    2. moral rights retained by the original author(s) and/or performer(s);
    3. publicity and privacy rights pertaining to a person’s image or likeness depicted in a Work;
    4. rights protecting against unfair competition in regards to a Work, subject to the limitations in paragraph 4(i), below;
    5. rights protecting the extraction, dissemination, use and reuse of data in a Work;
    6. database rights (such as those arising under Directive 96/9/EC of the European Parliament and of the Council of 11 March 1996 on the legal protection of databases, and under any national implementation thereof, including any amended or successor version of such directive); and
    7. other similar, equivalent or corresponding rights throughout the world based on applicable law or treaty, and any national implementations thereof.

2. Waiver. To the greatest extent permitted by, but not in contravention of, applicable law, Affirmer hereby overtly, fully, permanently, irrevocably and unconditionally waives, abandons, and surrenders all of Affirmer’s Copyright and Related Rights and associated claims and causes of action, whether now known or unknown (including existing as well as future claims and causes of action), in the Work (i) in all territories worldwide, (ii) for the maximum duration provided by applicable law or treaty (including future time extensions), (iii) in any current or future medium and for any number of copies, and (iv) for any purpose whatsoever, including without limitation commercial, advertising or promotional purposes (the “Waiver”). Affirmer makes the Waiver for the benefit of each member of the public at large and to the detriment of Affirmer’s heirs and successors, fully intending that such Waiver shall not be subject to revocation, rescission, cancellation, termination, or any other legal or equitable action to disrupt the quiet enjoyment of the Work by the public as contemplated by Affirmer’s express Statement of Purpose.

3. Public License Fallback. Should any part of the Waiver for any reason be judged legally invalid or ineffective under applicable law, then the Waiver shall be preserved to the maximum extent permitted taking into account Affirmer’s express Statement of Purpose. In addition, to the extent the Waiver is so judged Affirmer hereby grants to each affected person a royalty-free, non transferable, non sublicensable, non exclusive, irrevocable and unconditional license to exercise Affirmer’s Copyright and Related Rights in the Work (i) in all territories worldwide, (ii) for the maximum duration provided by applicable law or treaty (including future time extensions), (iii) in any current or future medium and for any number of copies, and (iv) for any purpose whatsoever, including without limitation commercial, advertising or promotional purposes (the “License”). The License shall be deemed effective as of the date CC0 was applied by Affirmer to the Work. Should any part of the License for any reason be judged legally invalid or ineffective under applicable law, such partial invalidity or ineffectiveness shall not invalidate the remainder of the License, and in such case Affirmer hereby affirms that he or she will not (i) exercise any of his or her remaining Copyright and Related Rights in the Work or (ii) assert any associated claims and causes of action with respect to the Work, in either case contrary to Affirmer’s express Statement of Purpose.

4. Limitations and Disclaimers.
    1. No trademark or patent rights held by Affirmer are waived, abandoned, surrendered, licensed or otherwise affected by this document.
    2. Affirmer offers the Work as-is and makes no representations or warranties of any kind concerning the Work, express, implied, statutory or otherwise, including without limitation warranties of title, merchantability, fitness for a particular purpose, non infringement, or the absence of latent or other defects, accuracy, or the present or absence of errors, whether or not discoverable, all to the greatest extent permissible under applicable law.
    3. Affirmer disclaims responsibility for clearing rights of other persons that may apply to the Work or any use thereof, including without limitation any person’s Copyright and Related Rights in the Work. Further, Affirmer disclaims responsibility for obtaining any necessary consents, permissions or other rights required for any use of the Work.
    4. Affirmer understands and acknowledges that Creative Commons is not a party to this document and has no duty or obligation with respect to this CC0 or use of the Work.

For more information, please see <https://creativecommons.org/publicdomain/zero/1.0>.
```

### assets/site-icons/archlinux.svg
```svg
<svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><title>Arch Linux</title><path d="M11.39.605C10.376 3.092 9.764 4.72 8.635 7.132c.693.734 1.543 1.589 2.923 2.554-1.484-.61-2.496-1.224-3.252-1.86C6.86 10.842 4.596 15.138 0 23.395c3.612-2.085 6.412-3.37 9.021-3.862a6.61 6.61 0 01-.171-1.547l.003-.115c.058-2.315 1.261-4.095 2.687-3.973 1.426.12 2.534 2.096 2.478 4.409a6.52 6.52 0 01-.146 1.243c2.58.505 5.352 1.787 8.914 3.844-.702-1.293-1.33-2.459-1.929-3.57-.943-.73-1.926-1.682-3.933-2.713 1.38.359 2.367.772 3.137 1.234-6.09-11.334-6.582-12.84-8.67-17.74zM22.898 21.36v-.623h-.234v-.084h.562v.084h-.234v.623h.331v-.707h.142l.167.5.034.107a2.26 2.26 0 01.038-.114l.17-.493H24v.707h-.091v-.593l-.206.593h-.084l-.205-.602v.602h-.091"/></svg>
```

### assets/site-icons/duckduckgo.svg
```svg
<svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><title>DuckDuckGo</title><path d="M12 0C5.37 0 0 5.37 0 12s5.37 12 12 12 12-5.37 12-12S18.63 0 12 0zm0 .984C18.083.984 23.016 5.916 23.016 12S18.084 23.016 12 23.016.984 18.084.984 12C.984 5.917 5.916.984 12 .984zm0 .938C6.434 1.922 1.922 6.434 1.922 12c0 4.437 2.867 8.205 6.85 9.55-.237-.82-.776-2.753-1.6-6.052-1.184-4.741-2.064-8.606 2.379-9.813.047-.011.064-.064.03-.093-.514-.467-1.382-.548-2.233-.38a.06.06 0 0 1-.07-.058c0-.011 0-.023.011-.035.205-.286.572-.507.822-.64a1.843 1.843 0 0 0-.607-.335c-.059-.022-.059-.12-.006-.144.006-.006.012-.012.024-.012 1.749-.233 3.586.292 4.49 1.448.011.011.023.017.035.023 2.968.635 3.509 4.837 3.328 5.998a9.607 9.607 0 0 0 2.346-.576c.746-.286 1.008-.222 1.101-.053.1.193-.018.513-.28.81-.496.567-1.393 1.01-2.974 1.137-.546.044-1.029.024-1.445.006-.789-.035-1.339-.059-1.633.39-.192.298-.041.998 1.487 1.22 1.09.157 2.078.047 2.798-.034.643-.07 1.073-.118 1.172.069.21.402-.996 1.207-3.066 1.224-.158 0-.315-.006-.467-.011-1.283-.065-2.227-.414-2.816-.735a.094.094 0 0 1-.035-.017c-.105-.059-.31.045-.188.267.07.134.444.478 1.004.776-.058.466.087 1.184.338 2l.088-.016c.041-.009.087-.019.134-.025.507-.082.775.012.926.175.717-.536 1.913-1.294 2.03-1.154.583.694.66 2.332.53 2.99-.004.012-.017.024-.04.035-.274.117-1.783-.296-1.783-.511-.059-1.075-.26-1.173-.493-1.225h-.156c.006.006.012.018.018.03l.052.12c.093.257.24 1.063.13 1.26-.112.199-.835.297-1.284.303-.443.006-.543-.158-.637-.408-.07-.204-.103-.675-.103-.95a.857.857 0 0 1 .012-.216c-.134.058-.333.193-.397.281-.017.262-.017.682.123 1.149.07.221-1.518 1.164-1.74.99-.227-.181-.634-1.952-.459-2.67-.187.017-.338.075-.42.191-.367.508.093 2.933.582 3.248.257.169 1.54-.553 2.176-1.095.105.145.305.158.553.158.326-.012.782-.06 1.103-.158.192.45.423.972.613 1.388 4.47-1.032 7.803-5.037 7.803-9.82 0-5.566-4.512-10.078-10.078-10.078zm1.791 5.646c-.42 0-.678.146-.795.332-.023.047.047.094.094.07.14-.075.357-.161.701-.156.328.006.516.09.67.159l.023.01c.041.017.088-.03.059-.065-.134-.18-.332-.35-.752-.35zm-5.078.198a1.24 1.24 0 0 0-.522.082c-.454.169-.67.526-.67.76 0 .051.112.057.141.011.081-.123.21-.31.617-.478.408-.17.73-.146.951-.094.047.012.083-.041.041-.07a.989.989 0 0 0-.558-.211zm5.434 1.423a.651.651 0 0 0-.655.647.652.652 0 0 0 1.307 0 .646.646 0 0 0-.652-.647zm.283.262h.008a.17.17 0 0 1 .17.17c0 .093-.077.17-.17.17a.17.17 0 0 1-.17-.17c0-.09.072-.165.162-.17zm-5.358.076a.752.752 0 0 0-.758.758c0 .42.338.758.758.758s.758-.337.758-.758a.756.756 0 0 0-.758-.758zm.328.303h.01c.112 0 .2.089.2.2 0 .11-.088.197-.2.197a.195.195 0 0 1-.197-.198c0-.107.082-.194.187-.199z"/></svg>
```

### assets/site-icons/github.svg
```svg
<svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><title>GitHub</title><path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/></svg>
```

### assets/site-icons/reddit.svg
```svg
<svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><title>Reddit</title><path d="M12 0C5.373 0 0 5.373 0 12c0 3.314 1.343 6.314 3.515 8.485l-2.286 2.286C.775 23.225 1.097 24 1.738 24H12c6.627 0 12-5.373 12-12S18.627 0 12 0Zm4.388 3.199c1.104 0 1.999.895 1.999 1.999 0 1.105-.895 2-1.999 2-.946 0-1.739-.657-1.947-1.539v.002c-1.147.162-2.032 1.15-2.032 2.341v.007c1.776.067 3.4.567 4.686 1.363.473-.363 1.064-.58 1.707-.58 1.547 0 2.802 1.254 2.802 2.802 0 1.117-.655 2.081-1.601 2.531-.088 3.256-3.637 5.876-7.997 5.876-4.361 0-7.905-2.617-7.998-5.87-.954-.447-1.614-1.415-1.614-2.538 0-1.548 1.255-2.802 2.803-2.802.645 0 1.239.218 1.712.585 1.275-.79 2.881-1.291 4.64-1.365v-.01c0-1.663 1.263-3.034 2.88-3.207.188-.911.993-1.595 1.959-1.595Zm-8.085 8.376c-.784 0-1.459.78-1.506 1.797-.047 1.016.64 1.429 1.426 1.429.786 0 1.371-.369 1.418-1.385.047-1.017-.553-1.841-1.338-1.841Zm7.406 0c-.786 0-1.385.824-1.338 1.841.047 1.017.634 1.385 1.418 1.385.785 0 1.473-.413 1.426-1.429-.046-1.017-.721-1.797-1.506-1.797Zm-3.703 4.013c-.974 0-1.907.048-2.77.135-.147.015-.241.168-.183.305.483 1.154 1.622 1.964 2.953 1.964 1.33 0 2.47-.81 2.953-1.964.057-.137-.037-.29-.184-.305-.863-.087-1.795-.135-2.769-.135Z"/></svg>
```

### assets/site-icons/wikipedia.svg
```svg
<svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><title>Wikipedia</title><path d="M12.09 13.119c-.936 1.932-2.217 4.548-2.853 5.728-.616 1.074-1.127.931-1.532.029-1.406-3.321-4.293-9.144-5.651-12.409-.251-.601-.441-.987-.619-1.139-.181-.15-.554-.24-1.122-.271C.103 5.033 0 4.982 0 4.898v-.455l.052-.045c.924-.005 5.401 0 5.401 0l.051.045v.434c0 .119-.075.176-.225.176l-.564.031c-.485.029-.727.164-.727.436 0 .135.053.33.166.601 1.082 2.646 4.818 10.521 4.818 10.521l.136.046 2.411-4.81-.482-1.067-1.658-3.264s-.318-.654-.428-.872c-.728-1.443-.712-1.518-1.447-1.617-.207-.023-.313-.05-.313-.149v-.468l.06-.045h4.292l.113.037v.451c0 .105-.076.15-.227.15l-.308.047c-.792.061-.661.381-.136 1.422l1.582 3.252 1.758-3.504c.293-.64.233-.801.111-.947-.07-.084-.305-.22-.812-.24l-.201-.021c-.052 0-.098-.015-.145-.051-.045-.031-.067-.076-.067-.129v-.427l.061-.045c1.247-.008 4.043 0 4.043 0l.059.045v.436c0 .121-.059.178-.193.178-.646.03-.782.095-1.023.439-.12.186-.375.589-.646 1.039l-2.301 4.273-.065.135 2.792 5.712.17.048 4.396-10.438c.154-.422.129-.722-.064-.895-.197-.172-.346-.273-.857-.295l-.42-.016c-.061 0-.105-.014-.152-.045-.043-.029-.072-.075-.072-.119v-.436l.059-.045h4.961l.041.045v.437c0 .119-.074.18-.209.18-.648.03-1.127.18-1.443.421-.314.255-.557.616-.736 1.067 0 0-4.043 9.258-5.426 12.339-.525 1.007-1.053.917-1.503-.031-.571-1.171-1.773-3.786-2.646-5.71l.053-.036z"/></svg>
```

### assets/site-icons/youtube.svg
```svg
<svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><title>YouTube</title><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
```

### core/backup.py
```python
"""Password-protected portable data snapshots and transactional offline restore."""
import base64
import hashlib
import io
import json
import os
import re
import secrets
import shutil
import sqlite3
import stat
import tempfile
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from zipfile import ZipFile, ZIP_DEFLATED
from core.version import APP_VERSION
from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

MAGIC=b'SUPERSEARCH-BACKUP\x00\x01'
ITERATIONS=1_200_000
MAX_TOTAL=128*1024*1024
MAX_FILE=32*1024*1024
MAX_ARCHIVE=180*1024*1024
MAX_ENTRIES=4096
FILES={'settings.json','bookmarks.json','history.json','shortcuts.json','passwords.vault',
       'pinned-tabs.json','session.json','statistics.sqlite'}
DIRECTORIES={'userscripts','filters','wallpapers','favicons'}
# Never import Chromium internals, extension binaries, external paths or deletion proofs.
REPLACED=FILES|DIRECTORIES|{'statistics.sqlite-wal','statistics.sqlite-shm','downloads.json',
                           'download_files.json','extensions.json','extensions','chromium','crashes','.restore-tabs-once'}


def allowed(name):
    path=PurePosixPath(name)
    if not name or '\\' in name or path.is_absolute() or '..' in path.parts or path.as_posix()!=name:return False
    if name in FILES:return True
    if len(path.parts)!=2:return False
    parent,leaf=path.parts
    if parent=='wallpapers':return leaf=='home.png'
    if parent=='favicons':return bool(re.fullmatch(r'[a-f0-9]{64}\.png',leaf))
    if parent=='userscripts':return bool(re.fullmatch(r'[a-zA-Z0-9_. -]{1,160}\.(js|css)',leaf)) and not leaf.startswith('.')
    if parent=='filters':return bool(re.fullmatch(r'[a-zA-Z0-9_-]{1,100}\.(txt|json)',leaf))
    return False


def cipher(password,salt):
    if not isinstance(password,str) or not 12<=len(password)<=1024:
        raise ValueError('Use a backup password with 12 to 1024 characters.')
    key=PBKDF2HMAC(algorithm=hashes.SHA256(),length=32,salt=salt,iterations=ITERATIONS).derive(password.encode('utf-8'))
    return Fernet(base64.urlsafe_b64encode(key))


def atomic_private(path,content):
    path=Path(path)
    if path.is_symlink():raise ValueError('Choose a regular file, not a symbolic link.')
    path.parent.mkdir(parents=True,exist_ok=True)
    descriptor,temporary=tempfile.mkstemp(prefix='.supersearch-',dir=path.parent)
    try:
        with os.fdopen(descriptor,'wb') as stream:stream.write(content);stream.flush();os.fsync(stream.fileno())
        os.replace(temporary,path)
    finally:
        if os.path.exists(temporary):os.unlink(temporary)


def export_data(directory,destination,password,database=None):
    directory,destination=Path(directory),Path(destination)
    # A backup must survive reset and never be included recursively in the profile.
    if destination.resolve().is_relative_to(directory.resolve()):raise ValueError('Save the backup outside the browser data folder.')
    salt=os.urandom(16);encryption=cipher(password,salt)
    content={};total=0
    def collect(name,path):
        nonlocal total
        if path.is_symlink():raise ValueError('Data export does not follow symbolic links.')
        size=path.stat().st_size
        if size>MAX_FILE or total+size>MAX_TOTAL:raise ValueError('Browser data is too large for a portable backup (128 MB maximum).')
        value=path.read_bytes();total+=len(value);content[name]=value
    for name in sorted(FILES-{'statistics.sqlite'}):
        path=directory/name
        if path.exists():collect(name,path)
    for parent in sorted(DIRECTORIES):
        folder=directory/parent
        if folder.is_symlink():raise ValueError('Data export does not follow symbolic links.')
        if folder.is_dir():
            for path in sorted(folder.iterdir()):
                name=parent+'/'+path.name
                if path.is_file() and allowed(name):collect(name,path)
    if database is not None:
        with tempfile.TemporaryDirectory(prefix='.backup-snapshot-',dir=directory) as temporary:
            snapshot=Path(temporary)/'statistics.sqlite'
            with closing(sqlite3.connect(snapshot)) as copied:database.backup(copied)
            collect('statistics.sqlite',snapshot)
    elif (directory/'statistics.sqlite').exists():
        with tempfile.TemporaryDirectory(prefix='.backup-snapshot-',dir=directory) as temporary:
            snapshot=Path(temporary)/'statistics.sqlite'
            with closing(sqlite3.connect((directory/'statistics.sqlite').resolve().as_uri()+'?mode=ro',uri=True)) as original,closing(sqlite3.connect(snapshot)) as copied:original.backup(copied)
            collect('statistics.sqlite',snapshot)
    if len(content)>MAX_ENTRIES:raise ValueError('Too many files for a portable backup.')
    metadata=dict(format='SuperSearch',version=1,app_version=APP_VERSION,created=datetime.now(timezone.utc).isoformat(),
                  files={name:hashlib.sha256(value).hexdigest() for name,value in content.items()})
    buffer=io.BytesIO()
    with ZipFile(buffer,'w',ZIP_DEFLATED) as archive:
        archive.writestr('manifest.json',json.dumps(metadata))
        for name,value in content.items():archive.writestr(name,value)
    encrypted=MAGIC+salt+encryption.encrypt(buffer.getvalue())
    if len(encrypted)>MAX_ARCHIVE:raise ValueError('Backup is too large.')
    atomic_private(destination,encrypted)
    return dict(name=destination.name,files=len(content),bytes=len(encrypted))


def unpack(source,password):
    source=Path(source)
    if source.is_symlink() or not source.is_file() or source.stat().st_size>MAX_ARCHIVE:raise ValueError('Choose a regular SuperSearch backup smaller than 180 MB.')
    envelope=source.read_bytes()
    if not envelope.startswith(MAGIC) or len(envelope)<len(MAGIC)+16+100:raise ValueError('This is not a supported SuperSearch backup.')
    offset=len(MAGIC)
    try:payload=cipher(password,envelope[offset:offset+16]).decrypt(envelope[offset+16:])
    except InvalidToken:raise ValueError('The backup password is incorrect or the file is damaged.') from None
    if len(payload)>MAX_TOTAL+2*1024*1024:raise ValueError('Backup is too large.')
    try:
        with ZipFile(io.BytesIO(payload)) as archive:
            members=archive.infolist();names=[entry.filename for entry in members]
            if len(names)>MAX_ENTRIES+1 or len(set(names))!=len(names) or 'manifest.json' not in names:raise ValueError('Invalid backup manifest.')
            if sum(entry.file_size for entry in members)>MAX_TOTAL+1024*1024:raise ValueError('Backup contents are too large.')
            for entry in members:
                mode=entry.external_attr>>16
                if entry.is_dir() or stat.S_ISLNK(mode) or entry.file_size>MAX_FILE or (entry.filename!='manifest.json' and not allowed(entry.filename)):
                    raise ValueError('Backup contains an unsupported or unsafe path.')
            if archive.getinfo('manifest.json').file_size>1024*1024:raise ValueError('Invalid backup manifest.')
            metadata=json.loads(archive.read('manifest.json'))
            if metadata.get('format')!='SuperSearch' or type(metadata.get('version')) is not int or metadata['version']!=1:raise ValueError('Unsupported backup version.')
            manifest=metadata.get('files')
            if not isinstance(manifest,dict) or set(manifest)!=set(names)-{'manifest.json'}:raise ValueError('Invalid backup file list.')
            values={name:archive.read(name) for name in manifest}
            if any(hashlib.sha256(value).hexdigest()!=manifest[name] for name,value in values.items()):raise ValueError('Backup integrity check failed.')
            return values
    except (KeyError,TypeError,json.JSONDecodeError,UnicodeError) as error:raise ValueError('The backup structure is invalid.') from error


def validate(values,settings_validator):
    from core.session import normalize_tab
    from core.vault import origin_of
    for name in ('bookmarks.json','history.json','shortcuts.json'):
        if name not in values:continue
        rows=json.loads(values[name])
        if not isinstance(rows,list) or len(rows)>10000:raise ValueError('Invalid backup library: '+name)
        for row in rows:
            if not isinstance(row,dict) or not origin_of(row.get('url','')) or not isinstance(row.get('title'),str):raise ValueError('Invalid backup library: '+name)
            if name=='shortcuts.json' and (not isinstance(row.get('id'),str) or len(row['id'])>100):raise ValueError('Invalid backup shortcut.')
            if name=='bookmarks.json' and not isinstance(row.get('folder',''),str):raise ValueError('Invalid backup bookmark folder.')
    for name in ('session.json','pinned-tabs.json'):
        if name not in values:continue
        document=json.loads(values[name]);rows=document.get('tabs') if isinstance(document,dict) else None
        if not isinstance(rows,list) or len(rows)>100 or any(normalize_tab(row) is None for row in rows):raise ValueError('Invalid backup tabs.')
        document['tabs']=[normalize_tab(row) for row in rows]
        values[name]=json.dumps(document).encode()
    if 'passwords.vault' in values:
        vault=json.loads(values['passwords.vault'])
        if not isinstance(vault,dict) or not isinstance(vault.get('salt'),str) or not isinstance(vault.get('token'),str):raise ValueError('Invalid encrypted password vault.')
        if len(base64.b64decode(vault['salt'],validate=True))!=16 or len(vault['token'])>MAX_FILE:raise ValueError('Invalid encrypted password vault.')
    saved=json.loads(values.get('settings.json',b'{}'))
    if not isinstance(saved,dict):raise ValueError('Invalid backup settings.')
    checked=settings_validator(saved)
    checked.update(onboarding_complete=True,tour_pending=False,tour_completed=True,terms_version='2026-11-02',extension_enabled=[])
    values['settings.json']=json.dumps(checked).encode()


def normalize_statistics(stage):
    path=stage/'statistics.sqlite'
    if not path.exists():return
    fresh=stage/'statistics.clean'
    with closing(sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True)) as source:
        source.execute('PRAGMA trusted_schema=OFF')
        if source.execute('PRAGMA quick_check').fetchone()!=('ok',):raise ValueError('Backup statistics are damaged.')
        if source.execute("SELECT type FROM sqlite_master WHERE name='blocks'").fetchone()!=('table',):raise ValueError('Invalid backup statistics.')
        rows=source.execute('SELECT day,domain,n FROM blocks LIMIT 100001').fetchall()
        if len(rows)>100000 or any(not isinstance(day,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',day) or not isinstance(domain,str) or len(domain)>255 or type(n) is not int or not 0<n<2**53 for day,domain,n in rows):raise ValueError('Invalid backup statistics.')
    with closing(sqlite3.connect(fresh)) as target:
        target.execute('CREATE TABLE blocks(day TEXT,domain TEXT,n INTEGER,PRIMARY KEY(day,domain))')
        target.executemany('INSERT INTO blocks VALUES(?,?,?)',rows);target.commit()
    os.replace(fresh,path)
    for suffix in ('-wal','-shm'):(stage/('statistics.sqlite'+suffix)).unlink(missing_ok=True)


def prepare_restore(source,password,directory,settings_validator,include_scripts=False):
    directory=Path(directory)
    values=unpack(source,password);validate(values,settings_validator)
    if not include_scripts:values={name:value for name,value in values.items() if not name.startswith('userscripts/')}
    if 'session.json' in values and json.loads(values['session.json']).get('tabs'):values['.restore-tabs-once']=b'1'
    token=secrets.token_hex(24);stage=directory/('.restore-staging-'+token)
    stage.mkdir(mode=0o700)
    try:
        for name,value in values.items():atomic_private(stage/name,value)
        normalize_statistics(stage)
        manifest={path.relative_to(stage).as_posix():hashlib.sha256(path.read_bytes()).hexdigest() for path in stage.rglob('*') if path.is_file()}
        atomic_private(directory/'.restore-plan.json',json.dumps(dict(token=token,files=manifest)).encode())
        return token
    except BaseException:
        shutil.rmtree(stage);raise


def apply_pending(token,directory):
    directory=Path(directory)
    if directory.is_symlink() or not re.fullmatch(r'[a-f0-9]{48}',token):raise ValueError('Invalid restore request.')
    plan_path=directory/'.restore-plan.json'
    if plan_path.is_symlink():raise ValueError('Invalid restore plan.')
    plan=json.loads(plan_path.read_text())
    if not secrets.compare_digest(plan.get('token',''),token):raise ValueError('Restore request is not authenticated.')
    stage=directory/('.restore-staging-'+token)
    if stage.is_symlink() or not stage.is_dir():raise ValueError('Missing restore staging data.')
    expected=plan.get('files',{})
    actual={}
    for path in stage.rglob('*'):
        if path.is_symlink():raise ValueError('Restore does not follow symbolic links.')
        if path.is_file():
            name=path.relative_to(stage).as_posix()
            if name!='.restore-tabs-once' and not allowed(name):raise ValueError('Invalid staged restore path.')
            actual[name]=hashlib.sha256(path.read_bytes()).hexdigest()
    if not expected or actual!=expected:raise ValueError('Staged restore integrity check failed.')
    rollback=directory/('.restore-previous-'+token);rollback.mkdir(mode=0o700)
    moved=[];installed=[]
    try:
        for name in sorted(REPLACED):
            path=directory/name
            if path.exists() or path.is_symlink():path.rename(rollback/name);moved.append(name)
        for path in sorted(stage.iterdir()):
            path.rename(directory/path.name);installed.append(path.name)
    except BaseException:
        for name in reversed(installed):(directory/name).rename(stage/name)
        for name in reversed(moved):(rollback/name).rename(directory/name)
        rollback.rmdir();raise
    plan_path.unlink(missing_ok=True);stage.rmdir();shutil.rmtree(rollback)
```

### core/downloads.py
```python
"""Portable download names and collision-safe destinations."""
import re
import unicodedata
from pathlib import Path

def safe_filename(name):
    name = ''.join(c for c in (name or 'download') if not unicodedata.category(c).startswith('C'))
    name = name.replace('\\', '/').rsplit('/', 1)[-1]
    name = re.sub(r'[\x00-\x1f\x7f<>:"/\\|?*]', '_', name).strip(' .')
    if not name:
        name = 'download'
    if name.split('.')[0].upper() in {'CON', 'PRN', 'AUX', 'NUL'} | {f'{k}{n}' for k in ('COM', 'LPT') for n in range(1, 10)}:
        name = '_' + name
    return name[:180]

def download_target(directory, name, reserved=()):
    directory = Path(directory)
    name = safe_filename(name)
    stem, suffix = Path(name).stem, Path(name).suffix
    candidate = directory / name
    number = 1
    while candidate.exists() or candidate.is_symlink() or str(candidate) in reserved:
        candidate = directory / f'{stem} ({number}){suffix}'
        number += 1
    return candidate
```

### core/electron_launcher.py
```python
"""Verified Electron launcher and one-time migration of legacy local libraries."""
import json
from contextlib import closing
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
from pathlib import Path
from settings.config import ROOT,DATA
from tools.install_electron import ensure,MANIFEST
from core.version import APP_VERSION

LIBRARIES=('settings.json','bookmarks.json','history.json','shortcuts.json','passwords.vault',
           'pinned-tabs.json','session.json','downloads.json','download_files.json','import-report.json')


def migrate(source,destination):
    source,destination=Path(source),Path(destination)
    if destination.exists():return
    destination.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.electron-migration-',dir=destination.parent) as temporary:
        staging=Path(temporary)/'data';staging.mkdir()
        for name in LIBRARIES:
            file=source/name
            if file.is_file() and not file.is_symlink():shutil.copy2(file,staging/name)
        for name in ('userscripts','filters','wallpapers','favicons'):
            directory=source/name
            if directory.is_dir() and not directory.is_symlink():
                (staging/name).mkdir()
                for file in directory.iterdir():
                    if file.is_file() and not file.is_symlink():shutil.copy2(file,staging/name/file.name)
        database=source/'statistics.sqlite'
        if database.is_file() and not database.is_symlink():
            with closing(sqlite3.connect(database.resolve().as_uri()+'?mode=ro',uri=True)) as original,closing(sqlite3.connect(staging/'statistics.sqlite')) as copied:original.backup(copied)
        (staging/'engine-migration.json').write_text(json.dumps(dict(source='QtWebEngine',version=1,cookies_copied=False,original_data_preserved=True)))
        staging.rename(destination)


def versions(executable):
    env=dict(os.environ,ELECTRON_RUN_AS_NODE='1')
    code="console.log(JSON.stringify({Electron:process.versions.electron,Chromium:process.versions.chrome,Node:process.versions.node}))"
    result=subprocess.run([str(executable),'-e',code],env=env,capture_output=True,text=True,check=True,timeout=20)
    value=json.loads(result.stdout)
    if value['Electron']!=MANIFEST['electron'] or value['Chromium']!=MANIFEST['chromium']:
        raise RuntimeError('The installed Electron/Chromium versions do not match the verified runtime manifest.')
    return dict(SuperSearch=APP_VERSION,**value)


def launch(arguments):
    if '--self-test' in arguments and os.environ.get('SUPERSEARCH_SKIP_MIGRATION')!='1':raise RuntimeError('Run tests/gui_electron.py to use an isolated test profile.')
    executable=ensure();actual=versions(executable)
    if '--engine-version' in arguments:
        print(json.dumps(actual,indent=2));return
    destination=Path(os.environ.get('SUPERSEARCH_ENGINE_DATA',DATA/'electron')).absolute()
    if os.environ.get('SUPERSEARCH_SKIP_MIGRATION')=='1':destination.mkdir(parents=True,exist_ok=True)
    else:migrate(DATA,destination)
    if '--maintenance-token' in arguments:
        index=arguments.index('--maintenance-token')
        from core.maintenance import run_pending
        run_pending(arguments[index+1],destination)
        del arguments[index:index+2]
    if '--restore-token' in arguments:
        index=arguments.index('--restore-token')
        from core.backup import apply_pending
        apply_pending(arguments[index+1],destination)
        del arguments[index:index+2]
    env=dict(os.environ,SUPERSEARCH_DATA=str(destination),SUPERSEARCH_PYTHON=sys.executable)
    env.pop('ELECTRON_RUN_AS_NODE',None)
    env.pop('QTWEBENGINE_CHROMIUM_FLAGS',None)
    command=[str(executable),str(ROOT/'engine/main.js')]+[arg for arg in arguments if arg!='--electron']
    os.execve(str(executable),command,env)
```

### core/extensions.py
```python
"""Validate local Manifest V3 folders and bounded ZIP packages."""
import json
from pathlib import Path, PurePosixPath
from zipfile import ZipFile

def extension_manifest(path):
    path = Path(path)
    if path.is_dir():
        raw = (path / 'manifest.json').read_bytes()
    else:
        with ZipFile(path) as archive:
            entries = archive.infolist()
            if len(entries) > 10000 or sum(e.file_size for e in entries) > 128 * 1024 * 1024:
                raise ValueError('The extension archive is too large.')
            for entry in entries:
                if ((entry.external_attr >> 16) & 0o170000) == 0o120000:
                    raise ValueError('Symbolic links are not allowed in extensions.')
                p = PurePosixPath(entry.filename.replace('\\', '/'))
                if p.is_absolute() or '..' in p.parts or (p.parts and ':' in p.parts[0]):
                    raise ValueError('Invalid paths in the extension archive.')
            info = archive.getinfo('manifest.json')
            if info.file_size > 1_000_000:
                raise ValueError('The manifest.json file is too large.')
            raw = archive.read(info)
    if len(raw) > 1_000_000:
        raise ValueError('The manifest.json file is too large.')
    manifest = json.loads(raw)
    if manifest.get('manifest_version') != 3:
        raise ValueError('Only Manifest V3 extensions are supported.')
    if not isinstance(manifest.get('name'), str):
        raise ValueError('The extension name is missing.')
    return manifest
```

### core/icons.py
```python
"""Repo-native SVG paths shared by the trusted browser interface."""
PATHS = {
 'chart':'<path d="M4 3v17h17M8 16v-4m5 4V8m5 8V5"/>',
 'puzzle':'<path d="M9 3H4v6a3 3 0 1 0 0 6v6h6a3 3 0 1 1 6 0h5v-6a3 3 0 1 1 0-6V4h-6a3 3 0 1 0-6 0Z"/>',
 'maximize':'<rect x="4" y="4" width="16" height="16" rx="2"/>',
 'restore':'<path d="M8 8V4h12v12h-4"/><rect x="4" y="8" width="12" height="12" rx="2"/>',
 'fullscreen':'<path d="M9 3H3v6m12-6h6v6M3 15v6h6m12-6v6h-6"/>',
 'battery':'<rect x="2" y="7" width="17" height="10" rx="2"/><path d="M22 10v4"/>',
 'battery-charging':'<rect x="2" y="7" width="17" height="10" rx="2"/><path d="M22 10v4M12 8l-4 4h5l-4 4"/>',
 'eye':'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
 'home':'<path d="m3 10 9-7 9 7v10H3Z"/><path d="M9 20v-7h6v7"/>',
 'wifi-off':'<path d="m3 3 18 18M3 8a16 16 0 0 1 3-2M10 4a16 16 0 0 1 11 4M6 12a10 10 0 0 1 3-2M13 10a10 10 0 0 1 5 2M9 16a5 5 0 0 1 5 0"/><circle cx="12" cy="20" r="1"/>',
 'pin':'<path d="m15 3 6 6-3 1-4 4v4l-3-3-7 7 7-7-3-3h4l4-4 1-3Z"/>',
 'chevron-down':'<path d="m6 9 6 6 6-6"/>',
 'chevron-up':'<path d="m6 15 6-6 6 6"/>',
 'menu':'<path d="M4 6h16M4 12h16M4 18h16"/>',
 'more':'<circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/>',
 'plus':'<path d="M12 5v14M5 12h14"/>',
 'back':'<path d="m14 5-7 7 7 7M7 12h14"/>',
 'forward':'<path d="m10 5 7 7-7 7M3 12h14"/>',
 'reload':'<path d="M20 7v5h-5M20 12a8 8 0 1 1-2-6"/>',
 'shield':'<path d="M12 3 3 6v6c0 5 9 9 9 9s9-4 9-9V6l-9-3Z"/><path d="m8 12 3 3 5-6"/>',
 'split':'<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M12 4v16"/>',
 'key':'<circle cx="8" cy="9" r="5"/><path d="m12 13 8 8M16 17l3-3M18 19l3-3"/>',
 'star':'<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9L12 3Z"/>',
 'star-filled':'<path fill="currentColor" d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9L12 3Z"/>',
 'download':'<path d="M12 3v12m-5-5 5 5 5-5M4 17v4h16v-4"/>',
 'settings':'<path d="m9 3-1 3-3 1v3l-2 2 2 2v3l3 1 1 3h6l1-3 3-1v-3l2-2-2-2V7l-3-1-1-3H9Z"/><circle cx="12" cy="12" r="3"/>',
 'close':'<path d="m6 6 12 12M6 18 18 6"/>',
 'minimize':'<path d="M5 12h14"/>',
 'globe':'<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/>',
 'folder':'<path d="M3 7V4h7l2 3h9v13H3V7Z"/>',
 'trash':'<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7"/>',
 'file':'<path d="M5 3h9l5 5v13H5V3Z"/><path d="M14 3v6h5M8 14h8M8 17h6"/>',
 'image':'<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8" cy="8" r="2"/><path d="m3 17 6-6 5 5 3-3 4 4"/>',
 'edit':'<path d="m4 16 12-12 4 4L8 20l-5 1 1-5ZM13 7l4 4"/>',
 'check':'<path d="m4 12 5 5L20 6"/>',
 'lock':'<rect x="5" y="10" width="14" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
 'search':'<circle cx="10" cy="10" r="7"/><path d="m15 15 6 6"/>',
 'history':'<path d="M3 3v6h6M3 9a9 9 0 1 1 1 9M12 7v6l4 2"/>',
 'storage':'<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 4 18 4 18 0V5M3 12c0 4 18 4 18 0"/>',
 'import':'<path d="M14 3h7v18h-7M3 12h13m-5-5 5 5-5 5"/>',
 'info':'<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
 'pause':'<path d="M8 5v14M16 5v14"/>',
 'play':'<path d="m7 3 14 9-14 9V3Z"/>',
}
```

### core/importer.py
```python
"""Explicit, read-only import of a user-selected Chromium profile and password CSV.
OS-protected cookies and credentials are reported, never silently decrypted or bypassed.
"""
import csv
import json
import sqlite3
import sys
import time
from pathlib import Path
from urllib.parse import quote
from core.vault import origin_of


def discover_profiles(home=None):
    overridden=home is not None
    home = Path(home) if overridden else Path.home()
    if sys.platform == 'win32':
        import os
        local = home/'AppData/Local' if overridden else Path(os.environ.get('LOCALAPPDATA', home / 'AppData/Local'))
        roots = {'Chrome':local/'Google/Chrome/User Data', 'Edge':local/'Microsoft/Edge/User Data',
                 'Brave':local/'BraveSoftware/Brave-Browser/User Data', 'Chromium':local/'Chromium/User Data',
                 'Vivaldi':local/'Vivaldi/User Data', 'Opera':home/'AppData/Roaming/Opera Software/Opera Stable'}
    elif sys.platform == 'darwin':
        base = home/'Library/Application Support'
        roots = {'Chrome':base/'Google/Chrome','Edge':base/'Microsoft Edge','Brave':base/'BraveSoftware/Brave-Browser','Chromium':base/'Chromium','Vivaldi':base/'Vivaldi','Opera':base/'com.operasoftware.Opera'}
    else:
        base = home/'.config'
        roots = {'Chrome':base/'google-chrome','Chromium':base/'chromium','Brave':base/'BraveSoftware/Brave-Browser','Edge':base/'microsoft-edge','Vivaldi':base/'vivaldi','Opera':base/'opera',
                 'Chromium (Snap)':home/'snap/chromium/common/chromium',
                 'Chrome (Flatpak)':home/'.var/app/com.google.Chrome/config/google-chrome',
                 'Chromium (Flatpak)':home/'.var/app/org.chromium.Chromium/config/chromium',
                 'Brave (Flatpak)':home/'.var/app/com.brave.Browser/config/BraveSoftware/Brave-Browser'}
    result = []
    for browser, root in roots.items():
        try:
            if not root.is_dir():
                continue
            info={}
            state=root/'Local State'
            if state.is_file():
                try:
                    info=json.loads(state.read_text(encoding='utf-8')).get('profile',{}).get('info_cache',{})
                except (ValueError,OSError):
                    pass
            if (root/'Bookmarks').is_file() or (root/'History').is_file():
                result.append((browser,str(root)))
            for profile in sorted(root.iterdir()):
                if profile.is_dir() and (profile.name=='Default' or profile.name.startswith('Profile ')):
                    name=info.get(profile.name,{}).get('name',profile.name)
                    result.append((f'{browser} · {name}',str(profile)))
        except OSError:
            continue
    return result


def database_rows(path, query):
    if not path.is_file():
        return []
    uri = 'file:' + quote(str(path.absolute()), safe='/:') + '?mode=ro'
    connection = sqlite3.connect(uri, uri=True, timeout=2)
    try:
        connection.execute('PRAGMA query_only=ON')
        return connection.execute(query).fetchall()
    finally:
        connection.close()


def read_profile(profile, selected, password_csv=''):
    profile = Path(profile) if profile else None
    if profile and not (profile/'Bookmarks').is_file() and (profile/'Default').is_dir():
        profile=profile/'Default'
    result = dict(bookmarks=[], history=[], cookies=[], downloads=[], passwords=[], preferences={}, skipped_cookies=0, notices=[])
    def rows(path,query,label):
        try:
            return database_rows(path,query)
        except (sqlite3.DatabaseError,OSError) as exc:
            result['notices'].append(label+' could not be read: '+str(exc))
            return []
    if profile and 'bookmarks' in selected and (profile/'Bookmarks').is_file():
        document = json.loads((profile/'Bookmarks').read_text(encoding='utf-8'))
        def walk(node, folder):
            if node.get('type') == 'url' and origin_of(node.get('url','')):
                result['bookmarks'].append(dict(url=node['url'], title=node.get('name') or node['url'], folder='Imported / ' + folder))
            for child in node.get('children', []):
                walk(child, folder + (' / ' + child.get('name','') if child.get('type') == 'folder' else ''))
        for key, node in document.get('roots',{}).items():
            if isinstance(node,dict):
                walk(node, node.get('name') or key)
    if profile and 'history' in selected:
        records = rows(profile/'History', 'SELECT url,title FROM urls ORDER BY last_visit_time DESC LIMIT 10000','History')
        result['history'] = [dict(url=url,title=title or url) for url,title in records if origin_of(url)]
    if profile and 'downloads' in selected:
        try:
            records = rows(profile/'History', 'SELECT target_path,received_bytes,total_bytes FROM downloads ORDER BY start_time DESC LIMIT 2000','Downloads')
            result['downloads'] = [dict(path=path,received=received,total=total,imported=True) for path,received,total in records if path]
        except sqlite3.DatabaseError:
            result['notices'].append('The source download history format is not supported.')
    if profile and 'cookies' in selected:
        path = profile/'Network/Cookies'
        if not path.is_file():
            path = profile/'Cookies'
        records = rows(path, 'SELECT host_key,name,value,encrypted_value,path,expires_utc,is_secure,is_httponly FROM cookies','Cookies')
        for domain,name,value,encrypted,path,expires,secure,http_only in records:
            if encrypted:
                result['skipped_cookies'] += 1
                continue
            expiry = int(expires / 1_000_000 - 11644473600) if expires else 0
            if value and (not expiry or expiry > time.time()):
                result['cookies'].append(dict(domain=domain,name=name,value=value,path=path,expires=expiry,secure=bool(secure),http_only=bool(http_only)))
    if profile and 'preferences' in selected and (profile/'Preferences').is_file():
        prefs = json.loads((profile/'Preferences').read_text(encoding='utf-8'))
        homepage = prefs.get('homepage','')
        if origin_of(homepage):
            result['preferences']['homepage'] = homepage
        language = prefs.get('intl',{}).get('app_locale','').split('-')[0]
        if language in ('ru','en','de','fr','es'):
            result['preferences']['language'] = language
        result['preferences']['bookmark_bar'] = bool(prefs.get('bookmark_bar',{}).get('show_on_all_tabs',True))
    if password_csv:
        with open(password_csv, newline='', encoding='utf-8-sig') as stream:
            for row in csv.DictReader(stream):
                url = row.get('url') or row.get('origin') or ''
                password = row.get('password') or ''
                if origin_of(url) and password:
                    result['passwords'].append(dict(origin=origin_of(url), username=row.get('username') or '', password=password))
    if result['skipped_cookies']:
        result['notices'].append(f"Protected cookies: {result['skipped_cookies']} — sign in to these websites again.")
    result['notices'].append('Chrome account sync, payment details, protected keys and active sessions are not automatically transferred. Passwords are imported from an explicitly selected CSV into the encrypted vault.')
    return result
```

### core/maintenance.py
```python
"""Delete selected local data only after the old Chromium process has exited."""
import json
import os
import secrets
import shutil
from pathlib import Path
from settings.config import DATA, write_json

CATEGORIES = {'cookies','cache','accounts','history','bookmarks','downloads','download_files','pinned_tabs','reset'}


def identity(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        return None
    s = path.stat()
    return dict(path=str(path.absolute()), dev=s.st_dev, ino=s.st_ino, size=s.st_size, mtime=s.st_mtime_ns)


def record_download(path, directory=None):
    directory = Path(directory) if directory else DATA
    proof = identity(path)
    if proof is None:
        return
    manifest = directory / 'download_files.json'
    try:
        entries = json.loads(manifest.read_text())
    except (OSError, ValueError):
        entries = []
    entries = [e for e in entries if e.get('path') != proof['path']]
    entries.append(proof)
    write_json(manifest, entries)


def remove_owned_downloads(directory):
    try:
        entries = json.loads((directory / 'download_files.json').read_text())
    except (OSError, ValueError):
        entries = []
    removed, skipped = 0, 0
    for proof in entries:
        try:
            path = Path(proof['path'])
            if identity(path) == proof:
                path.unlink()
                removed += 1
            else:
                skipped += 1
        except (OSError, KeyError, TypeError):
            skipped += 1
    return removed, skipped


def remove_path(path):
    if path.is_symlink() or path.is_file():
        path.unlink(missing_ok=True)
    elif path.is_dir():
        shutil.rmtree(path)


def execute(directory, categories):
    directory = Path(directory)
    categories = set(categories)
    if not categories or not categories <= CATEGORIES or directory.is_symlink():
        raise ValueError('Invalid cleanup operation.')
    report = dict(removed_downloads=0, skipped_downloads=0)
    if 'download_files' in categories:
        report['removed_downloads'], report['skipped_downloads'] = remove_owned_downloads(directory)
        remove_path(directory / 'download_files.json')
    if 'reset' in categories:
        for child in directory.iterdir():
            remove_path(child)
        return report
    if 'pinned_tabs' in categories and 'history' not in categories:
        from core.session import load
        session_path=directory/'session.json'
        if session_path.is_symlink():
            remove_path(session_path)
        else:
            session=load(directory)
            if session:
                active=session['tabs'][session['active_tab']]['id']
                remaining=[tab for tab in session['tabs'] if not tab['pinned']]
                if remaining:
                    index=next((i for i,tab in enumerate(remaining) if tab['id']==active),0)
                    write_json(session_path,dict(tabs=remaining,active_tab=index))
                else:
                    remove_path(session_path)
    paths = {
        'cookies':['profile/Cookies','profile/Cookies-journal','profile/Network/Cookies','profile/Network/Cookies-journal',
                   'profile/Local Storage','profile/IndexedDB','profile/Session Storage','profile/Service Worker',
                   'profile/WebStorage','profile/Storage','profile/File System','profile/blob_storage',
                   'profile/QuotaManager','profile/QuotaManager-journal','profile/SharedStorage'],
        'cache':['cache','profile/Cache','profile/Code Cache','profile/GPUCache','profile/ShaderCache','profile/DawnCache'],
        'accounts':['passwords.vault','passwords.tmp'],
        'history':['history.json','session.json','statistics.sqlite','statistics.sqlite-wal','statistics.sqlite-shm'],
        'bookmarks':['bookmarks.json'], 'pinned_tabs':['pinned-tabs.json'], 'downloads':['downloads.json'],
    }
    for category in categories:
        for name in paths.get(category, []):
            current = directory
            for part in Path(name).parts[:-1]:
                current = current / part
                if current.is_symlink():
                    raise ValueError('Cleanup does not follow symbolic links outside the browser data directory.')
            remove_path(directory / name)
    return report


def schedule(categories, directory=None):
    directory = Path(directory) if directory else DATA
    token = secrets.token_hex(24)
    write_json(directory / '.maintenance.json', dict(token=token, categories=list(categories)))
    return token


def run_pending(token, directory=None):
    directory = Path(directory) if directory else DATA
    path = directory / '.maintenance.json'
    plan = json.loads(path.read_text())
    if not secrets.compare_digest(plan.get('token',''), token):
        raise ValueError('The cleanup request is not authenticated.')
    report = execute(directory, plan['categories'])
    path.unlink(missing_ok=True)
    return report
```

### core/pins.py
```python
"""Explicit persistent pinned tabs. Private-window pins remain in memory only."""
from copy import deepcopy
from pathlib import Path
from core.session import normalize_tab, tab_record
from settings.config import DATA, read_json, write_json


class PinStore:
    def __init__(self, directory=None):
        self.directory=Path(directory) if directory else DATA
        self.path=self.directory/'pinned-tabs.json'
        self.records=[]
        raw=read_json(self.path, {})
        values=raw.get('tabs',[]) if isinstance(raw,dict) else []
        if isinstance(values,list):
            for value in values[:100]:
                record=normalize_tab(value)
                if record and not any(e['id']==record['id'] for e in self.records):
                    record['pinned']=True
                    self.records.append(record)

    def commit(self, records):
        self.directory.mkdir(parents=True,exist_ok=True)
        write_json(self.path,dict(tabs=records))
        self.records=records

    def upsert(self, tab):
        record=tab_record(tab)
        record['pinned']=True
        for index,entry in enumerate(self.records):
            if entry['id']==record['id']:
                if entry!=record:
                    values=self.records[:]
                    values[index]=record
                    self.commit(values)
                return
        self.commit(self.records+[record])

    def remove(self, identifier):
        values=[e for e in self.records if e['id']!=identifier]
        if values!=self.records:
            self.commit(values)

    def startup(self, session=None):
        pins=deepcopy(self.records)
        pinned_ids={e['id'] for e in pins}
        ordinary=[]
        active_id=None
        if session:
            tabs=session.get('tabs',[])
            if tabs:
                active_id=tabs[min(session.get('active_tab',0),len(tabs)-1)]['id']
            for entry in tabs:
                if entry['id'] not in pinned_ids:
                    record=deepcopy(entry)
                    record['pinned']=False
                    ordinary.append(record)
        combined=pins+ordinary
        if not combined:
            return None
        active=next((i for i,e in enumerate(combined) if e['id']==active_id),0)
        return dict(tabs=combined,active_tab=active)
```

### core/session.py
```python
"""Explicit local tab restoration; private windows are never persisted."""
import re
from pathlib import Path
from urllib.parse import urlsplit
from uuid import uuid4
from settings.config import DATA,read_json,write_json


def safe_url(value):
    if not isinstance(value,str):
        return 'supersearch:start'
    if value in ('supersearch:start','about:blank'):
        return value
    try:
        parts=urlsplit(value)
        if parts.scheme in ('http','https') and parts.hostname and not parts.username and not parts.password:
            return value
    except (ValueError,TypeError):
        pass
    return 'supersearch:start'


def normalize_tab(value):
    if not isinstance(value,dict) or not isinstance(value.get('panes'),list):
        return None
    identifier=value.get('id','')
    if not isinstance(identifier,str) or not re.fullmatch(r'[a-zA-Z0-9_-]{1,64}',identifier):
        identifier=uuid4().hex
    return dict(id=identifier,panes=[safe_url(url) for url in value['panes'][:2]] or ['supersearch:start'],
                active_pane=1 if value.get('active_pane')==1 and len(value['panes'])>1 else 0,
                pinned=bool(value.get('pinned',False)))


def tab_record(tab):
    pending=getattr(tab,'pending_session',None)
    if pending:
        record=normalize_tab(pending)
    else:
        panes=[]
        for view in tab.views[:2]:
            url=view.url().toString()
            if url in ('','about:blank'):
                requested=view.page().requestedUrl().toString()
                if requested:
                    url=requested
            panes.append(safe_url(url))
        record=dict(panes=panes,active_pane=tab.views.index(tab.active) if tab.active in tab.views else 0)
    record['id']=getattr(tab,'id',record.get('id',uuid4().hex))
    record['pinned']=getattr(tab,'pinned',record.get('pinned',False))
    return normalize_tab(record)


def snapshot(window):
    return dict(tabs=[tab_record(tab) for tab in window.tabs[:100]],active_tab=max(0,window.list.currentRow()))


def save(window,directory=None):
    if window.private:
        return
    directory=Path(directory) if directory else DATA
    write_json(directory/'session.json',snapshot(window))


def load(directory=None):
    directory=Path(directory) if directory else DATA
    record=read_json(directory/'session.json',{})
    tabs=[]
    if isinstance(record,dict):
        records=record.get('tabs',[])
        if not isinstance(records,list):return None
        for entry in records[:100]:
            tab=normalize_tab(entry)
            if tab:tabs.append(tab)
    active=record.get('active_tab',0) if isinstance(record,dict) else 0
    active=active if isinstance(active,int) else 0
    return dict(tabs=tabs,active_tab=min(max(0,active),max(0,len(tabs)-1))) if tabs else None
```

### core/shortcuts.py
```python
"""Local start-page shortcuts and favicon cache; rendering never fetches a URL."""
import base64
import hashlib
import html
from copy import deepcopy
from pathlib import Path
from urllib.parse import urlsplit
from uuid import uuid4
from settings.config import DATA, ROOT, read_json, write_json
from core.vault import origin_of

DEFAULT_SHORTCUTS = [
    dict(id='duckduckgo', title='DuckDuckGo', url='https://duckduckgo.com'),
    dict(id='wikipedia', title='Wikipedia', url='https://wikipedia.org'),
    dict(id='github', title='GitHub', url='https://github.com'),
    dict(id='reddit', title='Reddit', url='https://reddit.com'),
    dict(id='youtube', title='YouTube', url='https://youtube.com'),
    dict(id='archlinux', title='Arch Wiki', url='https://wiki.archlinux.org'),
]
BUILTINS = {origin_of(e['url']): e['id'] for e in DEFAULT_SHORTCUTS}


def valid_shortcut_url(value):
    return bool(origin_of(value)) and len(value) < 8192


class Shortcuts:
    def __init__(self, directory=None):
        self.directory = Path(directory) if directory else DATA
        self.path = self.directory / 'shortcuts.json'
        saved = read_json(self.path, None)
        self.entries = [e for e in saved if isinstance(e, dict) and all(isinstance(e.get(k), str) for k in ('id', 'title', 'url'))
                        and valid_shortcut_url(e['url'])] if isinstance(saved, list) else deepcopy(DEFAULT_SHORTCUTS)

    def commit(self, entries):
        if any(not valid_shortcut_url(e['url']) for e in entries):
            raise ValueError('Only HTTP and HTTPS addresses without embedded credentials are allowed.')
        self.directory.mkdir(parents=True, exist_ok=True)
        write_json(self.path, entries)
        self.entries = deepcopy(entries)

    def new(self, title, url):
        return dict(id=uuid4().hex, title=title.strip() or urlsplit(url).hostname, url=url.strip())

    def icon_path(self, url):
        digest = hashlib.sha256(origin_of(url).encode('utf-8')).hexdigest()
        return self.directory / 'favicons' / (digest + '.png')

    def icon_data(self, entry, foreground='#25304a'):
        cached = self.icon_path(entry['url'])
        if cached.is_file() and cached.stat().st_size < 1_000_000:
            return 'data:image/png;base64,' + base64.b64encode(cached.read_bytes()).decode('ascii')
        builtin = BUILTINS.get(origin_of(entry['url']))
        if builtin:
            svg = (ROOT / 'assets/site-icons' / (builtin + '.svg')).read_text(encoding='utf-8')
            svg = svg.replace('<svg ', '<svg fill="' + foreground + '" ', 1)
        else:
            label = html.escape((entry['title'] or '?')[:1].upper())
            svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><rect x="2" y="2" width="60" height="60" rx="16" fill="{foreground}" opacity=".12"/><text x="32" y="44" text-anchor="middle" font-family="sans-serif" font-size="36" fill="{foreground}">{label}</text></svg>'
        return 'data:image/svg+xml;base64,' + base64.b64encode(svg.encode()).decode('ascii')
```

### core/storage.py
```python
"""Local JSON libraries and SQLite tracker counters."""
import sqlite3
import threading
import logging
from datetime import date, timedelta
from settings.config import DATA, ROOT, read_json, write_json, config
import requests


class Store:
    def __init__(self):
        self.lock = threading.Lock()
        self.db = sqlite3.connect(str(DATA / 'statistics.sqlite'), check_same_thread=False)
        self.db.execute('CREATE TABLE IF NOT EXISTS blocks(day TEXT, domain TEXT, n INTEGER, PRIMARY KEY(day,domain))')
        self.db.commit()
        self.history = read_json(DATA / 'history.json', [])
        self.bookmarks = read_json(DATA / 'bookmarks.json', [])
        legacy=read_json(ROOT/'settings/translations/legacy_folders.json',{})
        for entry in self.bookmarks:
            if isinstance(entry,dict) and entry.get('folder') in legacy:
                entry['folder']=legacy[entry['folder']]

    def block(self, host):
        with self.lock:
            self.db.execute('INSERT INTO blocks VALUES(?,?,1) ON CONFLICT(day,domain) DO UPDATE SET n=n+1',
                            (date.today().isoformat(), host))
            self.db.commit()

    def stats(self):
        with self.lock:
            total = self.db.execute('SELECT coalesce(sum(n),0) FROM blocks').fetchone()[0]
            top = self.db.execute('SELECT domain,sum(n) FROM blocks GROUP BY domain ORDER BY sum(n) DESC LIMIT 10').fetchall()
            rows = dict(self.db.execute('SELECT day,sum(n) FROM blocks GROUP BY day').fetchall())
        daily = [((date.today()-timedelta(days=i)).isoformat(), rows.get((date.today()-timedelta(days=i)).isoformat(), 0)) for i in reversed(range(14))]
        return total, top, daily

    def visit(self, url, title):
        self.history = [x for x in self.history if x['url'] != url]
        self.history.insert(0, dict(url=url, title=title))
        self.history = self.history[:3000]
        write_json(DATA / 'history.json', self.history)

    def bookmark(self, url, title):
        exists = any(x['url'] == url for x in self.bookmarks)
        self.bookmarks = [x for x in self.bookmarks if x['url'] != url]
        if not exists:
            self.bookmarks.append(dict(url=url, title=title))
        write_json(DATA / 'bookmarks.json', self.bookmarks)


    def save_bookmark(self, url, title, folder='Bookmarks toolbar', original_url=None):
        self.bookmarks = [e for e in self.bookmarks if e['url'] not in (url, original_url)]
        self.bookmarks.append(dict(url=url, title=title, folder=folder))
        write_json(DATA / 'bookmarks.json', self.bookmarks)

    def remove_bookmark(self, url):
        self.bookmarks = [e for e in self.bookmarks if e['url'] != url]
        write_json(DATA / 'bookmarks.json', self.bookmarks)


RUNTIME_NETWORK = dict(config)


def proxy_url(options=None):
    options = RUNTIME_NETWORK if options is None else options
    return 'socks5h://127.0.0.1:9050' if options['tor'] else options['proxy'].strip().replace('socks5://', 'socks5h://', 1)


def get(url, options=None, **kwargs):
    # No ambient system proxies, cookies, or application browsing history.
    with requests.Session() as session:
        session.trust_env = False
        proxy = proxy_url(options)
        if proxy:
            session.proxies.update(http=proxy, https=proxy)
        response = session.get(url, timeout=(5, 15), **kwargs)
        response.raise_for_status()
        return response
```

### core/system_status.py
```python
"""Read local battery status. No network calls, telemetry or persistent state.

Windows: GetSystemPowerStatus / SYSTEM_POWER_STATUS (Microsoft Win32 API).
Linux: kernel power_supply sysfs attributes. macOS: the system pmset command.
"""
import ctypes
from dataclasses import dataclass
from pathlib import Path
import re
import subprocess
import sys


@dataclass(frozen=True)
class BatteryState:
    percent:int
    charging:bool=False


def _text(path):
    try:return path.read_text(encoding='utf-8').strip()
    except (OSError,UnicodeError):return ''


def linux_battery(directory='/sys/class/power_supply'):
    batteries=[]
    try:devices=list(Path(directory).iterdir())
    except OSError:return None
    for device in devices:
        if (_text(device/'type')!='Battery' or _text(device/'scope')=='Device'
                or _text(device/'present')=='0'):
            continue
        energy=None
        try:
            now=int(_text(device/'energy_now'))
            full=int(_text(device/'energy_full'))
            if now>=0 and full>0:energy=(min(now,full),full)
        except ValueError:pass
        try:percent=int(_text(device/'capacity'))
        except ValueError:
            if energy is None:continue
            percent=round(100*energy[0]/energy[1])
        if not 0<=percent<=100:continue
        batteries.append((percent,_text(device/'status').lower()=='charging',energy))
    if not batteries:return None
    if all(entry[2] is not None for entry in batteries):
        percent=round(100*sum(entry[2][0] for entry in batteries)/sum(entry[2][1] for entry in batteries))
    else:
        percent=round(sum(entry[0] for entry in batteries)/len(batteries))
    return BatteryState(percent,any(entry[1] for entry in batteries))


class SystemPowerStatus(ctypes.Structure):
    _fields_=[('ACLineStatus',ctypes.c_ubyte),('BatteryFlag',ctypes.c_ubyte),
              ('BatteryLifePercent',ctypes.c_ubyte),('SystemStatusFlag',ctypes.c_ubyte),
              ('BatteryLifeTime',ctypes.c_uint32),('BatteryFullLifeTime',ctypes.c_uint32)]


def windows_battery(api=None):
    if api is None:api=ctypes.WinDLL('kernel32',use_last_error=True)
    call=api.GetSystemPowerStatus
    call.argtypes=[ctypes.POINTER(SystemPowerStatus)]
    call.restype=ctypes.c_int
    state=SystemPowerStatus()
    if (not call(ctypes.byref(state)) or state.BatteryFlag==255
            or state.BatteryFlag&128 or state.BatteryLifePercent>100):
        return None
    return BatteryState(state.BatteryLifePercent,bool(state.BatteryFlag&8))


def macos_battery():
    result=subprocess.run(['/usr/bin/pmset','-g','batt'],capture_output=True,text=True,
                          timeout=2,check=False)
    if result.returncode:return None
    for line in result.stdout.splitlines():
        if 'InternalBattery' not in line:continue
        match=re.search(r'\b(\d{1,3})%',line)
        if match and 0<=int(match.group(1))<=100:
            parts=line.split(';')
            charging=len(parts)>1 and parts[1].strip().lower()=='charging'
            return BatteryState(int(match.group(1)),charging)
    return None


def read_battery():
    try:
        if sys.platform.startswith('linux'):return linux_battery()
        if sys.platform=='win32':return windows_battery()
        if sys.platform=='darwin':return macos_battery()
    except (OSError,ValueError,AttributeError,subprocess.TimeoutExpired):pass
    return None
```

### core/vault.py
```python
"""Authenticated local vault. The master password is never stored."""
import base64
import json
import os
from pathlib import Path
from urllib.parse import urlsplit

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from settings.config import DATA


def origin_of(url):
    try:
        p = urlsplit(url)
        if p.scheme not in ('http', 'https') or not p.hostname or p.username or p.password:
            return ''
        port = p.port
        host = p.hostname.encode('idna').decode('ascii').lower()
        if ':' in host:
            host = '[' + host + ']'
        default = 443 if p.scheme == 'https' else 80
        return p.scheme + '://' + host + (':' + str(port) if port and port != default else '')
    except (ValueError, UnicodeError):
        return ''


class Vault:
    ITERATIONS = 1_200_000

    def __init__(self, path=None):
        self.path = Path(path) if path else DATA / 'passwords.vault'
        self.lock()

    @property
    def exists(self):
        return self.path.exists()

    @property
    def unlocked(self):
        return self._cipher is not None

    def lock(self):
        self._cipher = None
        self._salt = None
        self._entries = None

    def _derive(self, password, salt):
        key = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32,
                        salt=salt, iterations=self.ITERATIONS).derive(password.encode('utf-8'))
        return Fernet(base64.urlsafe_b64encode(key))

    def create(self, password):
        if self.exists:
            raise ValueError('The vault already exists.')
        if len(password) < 12:
            raise ValueError('The master password must contain at least 12 characters.')
        salt = os.urandom(16)
        cipher = self._derive(password, salt)
        self._write(cipher, salt, [])
        self._cipher, self._salt, self._entries = cipher, salt, []

    def unlock(self, password):
        self.lock()
        try:
            document = json.loads(self.path.read_text(encoding='utf-8'))
            if document['version'] != 1 or document['iterations'] != self.ITERATIONS:
                raise ValueError('Unsupported vault format.')
            salt = base64.b64decode(document['salt'], validate=True)
            if len(salt) != 16:
                raise ValueError('Invalid salt format.')
            cipher = self._derive(password, salt)
            entries = json.loads(cipher.decrypt(document['token'].encode('ascii')))
            if not isinstance(entries, list) or any(
                not isinstance(e, dict) or set(e) != {'origin', 'username', 'password'}
                or not all(isinstance(v, str) for v in e.values())
                or origin_of(e['origin']) != e['origin'] for e in entries
            ):
                raise ValueError('Invalid entry format.')
        except InvalidToken as exc:
            raise ValueError('Incorrect master password or damaged vault.') from exc
        except (KeyError, TypeError, UnicodeError, json.JSONDecodeError) as exc:
            raise ValueError('The vault is damaged.') from exc
        self._cipher, self._salt, self._entries = cipher, salt, entries

    def _require(self):
        if not self.unlocked:
            raise ValueError('The vault is locked.')

    def entries(self, origin=None):
        self._require()
        return [dict(e) for e in self._entries if origin is None or e['origin'] == origin]

    def save(self, origin, username, password, previous=None):
        self._require()
        canonical = origin_of(origin)
        if not canonical or not password:
            raise ValueError('A website address and password are required.')
        entries = [dict(e) for e in self._entries
                   if (e['origin'], e['username']) not in ((canonical, username), previous)]
        entries.append(dict(origin=canonical, username=username, password=password))
        self._write(self._cipher, self._salt, entries)
        self._entries = entries

    def import_entries(self, records):
        self._require()
        entries = {(e['origin'],e['username']):dict(e) for e in self._entries}
        for entry in records:
            origin = origin_of(entry['origin'])
            if origin and entry['password']:
                entries[(origin,entry['username'])] = dict(origin=origin,username=entry['username'],password=entry['password'])
        result = list(entries.values())
        self._write(self._cipher,self._salt,result)
        self._entries = result

    def remove(self, origin, username):
        self._require()
        entries = [dict(e) for e in self._entries
                   if (e['origin'], e['username']) != (origin, username)]
        self._write(self._cipher, self._salt, entries)
        self._entries = entries

    def change_password(self, password):
        self._require()
        if len(password) < 12:
            raise ValueError('The master password must contain at least 12 characters.')
        salt = os.urandom(16)
        cipher = self._derive(password, salt)
        self._write(cipher, salt, self._entries)
        self._cipher, self._salt = cipher, salt

    def _write(self, cipher, salt, entries):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        token = cipher.encrypt(json.dumps(entries, ensure_ascii=False).encode('utf-8'))
        data = dict(version=1, iterations=self.ITERATIONS,
                    salt=base64.b64encode(salt).decode('ascii'), token=token.decode('ascii'))
        temporary = self.path.with_suffix('.tmp')
        fd = os.open(str(temporary), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as stream:
                json.dump(data, stream)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(str(temporary), str(self.path))
        finally:
            temporary.unlink(missing_ok=True)
```

### core/version.py
```python
"""Release identity from the shared application manifest."""
import json
from pathlib import Path

_RELEASE=json.loads((Path(__file__).resolve().parent.parent/'engine/package.json').read_text(encoding='utf-8'))
APP_VERSION=_RELEASE['displayVersion']
PACKAGE_VERSION=_RELEASE['version']
SOURCE_URL=_RELEASE['repository']['url']
```

### docs/PRIVACY.md
```markdown
# SuperSearch Privacy Policy

Effective date: 3 November 2026. Application version: **26.11**.

## Local data and portable backups

The default browser uses Electron/Chromium. Preferences, bookmarks, optional
history, shortcuts, blocking statistics, icon caches, download records, local
scripts and the encrypted password vault stay in `data/electron/`. Website storage
is in memory by default; you may select a persistent profile instead.

On first migration, compatible libraries can be copied from an older local layout.
Original files are left intact; the active browser profile is `data/electron/`.
There is one browser implementation. Website sessions are not migrated across engines.

Portable data exports are encrypted locally with a password you choose. They include
saved settings, bookmarks, the encrypted vault, history, tabs, statistics, shortcuts,
wallpaper, filters, cached icons and UserScripts/styles. They exclude website sessions,
cache, extension packages, downloaded files and records authorizing file deletion.
The export password and vault master password are independent and are not recoverable.
Export and restore send no data to a server.

Restoring requires explicit confirmation to replace current browser data and restart.
A wrong password or invalid archive leaves current libraries unchanged. Existing
website sessions are cleared after validation and process exit. Restoring scripts
requires separate opt-in. Keep exports securely: anyone with the backup password can
read their ordinary libraries, and the vault still requires its master password.
Exports outside the profile and legacy copies are not removed by browser reset.

## Network requests

SuperSearch does not send browsing history or product telemetry to its developer.
Visited websites and selected search engines receive the requests needed to provide
their services. Enabling suggestions sends typed queries to DuckDuckGo in the
address/start-page search fields. Suggestions are disabled in private windows.

Start-page shortcut icons are bundled or cached locally. Visiting a site can fetch
its supplied favicon through the browsing session. Filter lists are downloaded
from EasyList only when you request an update. An explicit proxy test contacts
api64.ipify.org through the selected draft proxy or Tor route.

The start page shows a public IP by default. After setup, when the IP/counter
feature is enabled and a start-page pane is selected in an open, non-minimized
window, a native HTTPS request contacts api64.ipify.org. The service receives the
public address of that connection. No browsing URL, website cookies or history is
included in the request. The visible session's active proxy/Tor route is used,
including a private session when the visible page is private. Results and failures
are cached only in memory for ten minutes. Refresh explicitly checks again.

Disable **Show public IP on the start page** in Appearance or the home editor to
avoid these requests. No check starts before setup is complete. Disabling clears
pending results; a request already sent may still finish. The shown address is a
snapshot of one connection, not a guarantee of anonymity or what every site sees.

The first launch can download the official pinned Electron runtime from GitHub.
Its archive checksum is verified against the source manifest before installation.
Runtime downloads use saved proxy/Tor preferences. Normal launches with a matching
runtime do not contact an update service. Clicking the source link opens GitHub
inside the browser as an ordinary website visit.

Proxy/Tor and secure DNS startup changes require restart. Tor needs a separately
running service at 127.0.0.1:9050. A configured proxy failure does not silently fall
back to a direct connection. Secure DNS and proxy behavior have protocol/platform
limits described in the security model.

## Passwords and import

Passwords use authenticated Fernet encryption. PBKDF2-HMAC-SHA256 derives the key
from the master password with a random salt and 1,200,000 iterations. The master
password is not saved. Migration preserves the encrypted vault format. Plaintext
values can exist temporarily in the browser, private stdio pipe and local service
memory while unlocking, editing, importing, filling or explicitly saving.

After a supported HTTPS form submission, a captured login may remain in memory
for up to 30 seconds while the browser waits for navigation or form disappearance.
A small browser-owned card lets you save or decline. Save requires an unlocked
vault and your explicit choice. The card expires after 90 seconds and clears its
pending references on dismissal or tab change. Private and website-JavaScript-off
views do not capture logins. Explicit filling checks the complete website origin.
The service locks an idle vault after five minutes.

Import starts only after you select a detected browser, manual folder or password
CSV. Source files are read-only. Compatible bookmarks, history, settings, downloads
and readable cookies can transfer. Password CSV records require an unlocked vault.
OS-protected passwords/cookies, sync accounts, payment details and protected keys
are not silently decrypted. The import report explains supported and skipped data.

## Extensions and deletion

Installed UserScripts/styles and compatible local extensions can read data on
pages where they run and may send it to third parties. Choose only code you trust.
Extensions require a persistent profile and are not loaded into private sessions.
UserScripts in private windows require a separate option. SuperSearch does not
provide a direct Chrome Web Store installer or claim universal API compatibility.

Storage offers selective cleanup and an explicitly confirmed reset. Reset requires
typing `Delete`, restarts the browser and removes the selected Electron profile's
data. Legacy copies and exported files outside the active profile are not removed.
Download-file cleanup removes only recorded unchanged files; unrelated or replaced
files are kept. Deletion cannot guarantee physical erasure from media or backups.

Privacy controls reduce tracking but do not guarantee anonymity. Direct connections
reveal an IP address to the services used. SuperSearch is not Tor Browser. A
compromised operating system or trusted extension can access data within its
capabilities. See `SECURITY.md` for the threat model and practical limits.
```

### docs/RELEASING.md
````markdown
# Publishing a source release

The public project is https://github.com/mishandreevy/supersearch.
These instructions prepare source files and artifacts; they do not publish or
push anything automatically.

## Release identity

`engine/package.json` is the source of release identity:

- `displayVersion`: `26.11`, shown by the UI, CLI and backup metadata.
- `version`: `26.11.0`, the three-part version used by Electron package metadata.

`core/version.py` and the Electron controller read that same manifest. For a future
release, update both manifest fields, the changelog, version references in the
public docs and the explicit version assertion in `tests/test_sessions_release.py`.
Do not change backup format version `1` just to change the application version.

## Validate and package

Run from an activated project virtual environment:

```sh
python tools/check_runtime.py
python -m pip check
python -m compileall -q main.py core settings engine tests tools
python -m unittest discover -s tests -p 'test_*.py' -v
python tests/gui_electron.py
python main.py --engine-version
python tools/export_source.py
```

GUI tests use temporary profiles. On a headless Linux host, run them with
`xvfb-run -a`. JavaScript policy checks are described in `CONTRIBUTING.md`.
Windows and macOS need native verification before claiming support for a binary
release; a source archive does not bundle a desktop runtime.

The exporter creates:

- `SuperSearch-26.11-source.zip`: the versioned publication artifact.
- `SuperSearch-26.11-source.sha256`: SHA-256 checksum of that archive.
- `SuperSearch-source.zip`: the same archive under the unversioned convenience name.
- `SOURCE_FULL.md`: complete files, each under its own path and code fence.
- `SOURCE_MANIFEST.json`: SHA-256 digest of every included source file.

On Linux, verify the archive checksum with:

```sh
sha256sum -c SuperSearch-26.11-source.sha256
```

The exporter preserves shell-script permissions, sorts archive entries and fixes
archive timestamps. Equal source bytes produce the same archive in the same
Python/zlib environment. CI runs the tests and retains the source artifacts.

## Publish only the prepared source

Extract the versioned source archive to a clean directory and use its `SuperSearch/`
contents for the public repository. It includes the license, notices, documentation,
CI configuration, assets, code and tests. Do not upload the entire working folder.

The allowlist excludes user profiles, virtual environments, downloaded runtimes,
backups, credentials, private tooling directories, caches and symlinks. `.gitignore`
provides additional protection for local development. Source-export tests exercise
these exclusions using synthetic private files.

Review the changelog and preserve `LICENSE`, `THIRD_PARTY.md` and
`assets/site-icons/LICENSE.md`. When publishing a GitHub release, use the title
`SuperSearch 26.11` and tag `v26.11`, and attach the versioned ZIP and checksum.
Do not attach the `data/` directory or private `.supersearch` backups.
````

### docs/TERMS.md
```markdown
# SuperSearch User Agreement

Effective date: 2 November 2026. Application version: **26.11**.

SuperSearch is an open-source desktop browser. This agreement explains how you can
use the application and make informed choices about your local data. The source
code license is provided in `LICENSE`.

## Your choices

You control the websites you visit, your network route, the data you import, your
installed scripts and extensions, and the appearance of your workspace. Search
suggestions are optional. You can change your preferences in Settings.

## Local data and security

Settings, bookmarks, shortcuts, statistics and encrypted passwords are stored on
your device in the browser's `data/` directory. Downloaded files are saved to your
system Downloads folder. Choosing to retain tabs stores their URLs locally.
Private-window tabs are never included in tab restoration.

A master password protects the local password vault. SuperSearch does not store
that master password, and a forgotten master password cannot be recovered. Keep
your operating system and browser dependencies up to date.

## Imports and third-party services

Import reads only the browser profile or file you select. The source profile is
not modified. Some browser data is protected by the operating system or source
browser and cannot be transferred directly. A password CSV contains unencrypted
passwords; you remain in control of the original file after import.

Websites, search providers, proxy services and installed extensions have their own
terms and privacy practices. Third-party components and asset notices are listed
in `THIRD_PARTY.md`.

## Deletion and reset

Storage settings let you delete selected categories of data or reset the browser.
Full reset requires a separate warning and typing **Delete**. The browser then
restarts with first-run setup. Optional downloaded-file removal affects only
files tracked by SuperSearch that have not subsequently changed; it does not erase
your entire Downloads folder, original import profiles or unrelated files.

## License and availability

The software is provided under the license in `LICENSE`, without warranties to the
extent permitted by applicable law. Nothing in these terms limits rights that
cannot lawfully be excluded. Read the Privacy Policy below for details of data
processing and privacy controls.
```

### engine/backend.js
```javascript
'use strict';
const {spawn}=require('node:child_process');
const path=require('node:path');
const readline=require('node:readline');

class Backend {
  constructor(root,data) {
    this.sequence=0;this.pending=new Map();
    this.process=spawn(process.env.SUPERSEARCH_PYTHON||'python3',[path.join(root,'engine/service.py')],{
      cwd:root,env:{...process.env,SUPERSEARCH_DATA:data,PYTHONUNBUFFERED:'1'},stdio:['pipe','pipe','pipe']
    });
    readline.createInterface({input:this.process.stdout}).on('line',line=>{
      let message;try{message=JSON.parse(line);}catch{return;}
      const task=this.pending.get(message.id);if(!task)return;
      this.pending.delete(message.id);clearTimeout(task.timer);
      if(message.error)task.reject(new Error(message.error));else task.resolve(message.result);
    });
    // Service errors never contain request bodies or passwords.
    this.process.stderr.on('data',()=>{});
    this.process.on('error',()=>this.fail());this.process.on('exit',()=>this.fail());
  }
  fail(){for(const task of this.pending.values()){clearTimeout(task.timer);task.reject(new Error('The local data service stopped.'));}this.pending.clear();}
  call(operation,data={}) {
    return new Promise((resolve,reject)=>{
      const id=++this.sequence;
      const timer=setTimeout(()=>{this.pending.delete(id);reject(new Error('The local operation timed out.'));},30000);
      this.pending.set(id,{resolve,reject,timer});
      this.process.stdin.write(JSON.stringify({id,operation,data})+'\n',error=>{if(error){clearTimeout(timer);this.pending.delete(id);reject(new Error('The local data service is unavailable.'));}});
    });
  }
  close(){
    if(this.closing)return this.closing;
    this.closing=new Promise(resolve=>{
      if(this.process.exitCode!==null){resolve();return;}
      const timer=setTimeout(()=>this.process.kill(),5000);timer.unref();
      this.process.once('exit',()=>{clearTimeout(timer);this.fail();resolve();});this.process.stdin.end();
    });
    return this.closing;
  }
}
module.exports={Backend};
```

### engine/content-preload.js
```javascript
'use strict';
const {contextBridge,ipcRenderer}=require('electron');
const argument=process.argv.find(value=>value.startsWith('--ss-options='));
const options=argument?JSON.parse(atob(argument.slice(13))):{};

function protect(settings) {
  'use strict';
  const override=(object,key,value)=>{try{Object.defineProperty(object,key,{get:()=>value,configurable:true});}catch{}};
  if(settings.webrtc)for(const name of ['RTCPeerConnection','webkitRTCPeerConnection','RTCDataChannel'])override(window,name,undefined);
  if(settings.geolocation){const deny=(_success,error)=>{if(error)queueMicrotask(()=>error({code:1,message:'Location blocked'}));return 0;};override(navigator,'geolocation',{getCurrentPosition:deny,watchPosition:deny,clearWatch:()=>{}});}
  if(settings.third_party&&window.top!==window){let third=true;try{third=window.top.location.origin!==location.origin;}catch{}
    if(third)for(const key of ['localStorage','sessionStorage','indexedDB','caches'])try{Object.defineProperty(window,key,{get(){throw new DOMException('Third-party storage blocked','SecurityError');},configurable:true});}catch{}
  }
  if(settings.canvas===false){const deny=()=>{throw new DOMException('Canvas reading is blocked','SecurityError');};
    if(window.CanvasRenderingContext2D)CanvasRenderingContext2D.prototype.getImageData=deny;
    if(window.HTMLCanvasElement){HTMLCanvasElement.prototype.toDataURL=deny;HTMLCanvasElement.prototype.toBlob=deny;}
  }
  if(!settings.fingerprint)return;
  for(const [key,value] of Object.entries({hardwareConcurrency:4,deviceMemory:8,language:'en-US',languages:Object.freeze(['en-US','en']),platform:'Linux x86_64'}))override(Navigator.prototype,key,value);
  for(const [key,value] of Object.entries({width:1920,height:1080,availWidth:1920,availHeight:1080,colorDepth:24,pixelDepth:24}))override(Screen.prototype,key,value);
  Date.prototype.getTimezoneOffset=()=>0;
  const NativeFormat=Intl.DateTimeFormat;
  function Format(locales,options){return new NativeFormat(locales,{...options,timeZone:'UTC'});}
  Format.prototype=NativeFormat.prototype;Format.supportedLocalesOf=NativeFormat.supportedLocalesOf.bind(NativeFormat);Intl.DateTimeFormat=Format;
  for(const key of ['FullYear','Month','Date','Day','Hours','Minutes','Seconds','Milliseconds'])Date.prototype['get'+key]=Date.prototype['getUTC'+key];
  const seed=crypto.getRandomValues(new Uint8Array(1))[0];
  if(window.CanvasRenderingContext2D){const original=CanvasRenderingContext2D.prototype.getImageData;CanvasRenderingContext2D.prototype.getImageData=function(...args){const result=original.apply(this,args);for(let i=0;i<result.data.length;i+=64)result.data[i]^=seed&1;return result;};}
  if(window.HTMLCanvasElement)for(const key of ['toDataURL','toBlob']){const original=HTMLCanvasElement.prototype[key];HTMLCanvasElement.prototype[key]=function(...args){const copy=document.createElement('canvas');copy.width=this.width;copy.height=this.height;try{const ctx=copy.getContext('2d');ctx.drawImage(this,0,0);ctx.putImageData(ctx.getImageData(0,0,copy.width,copy.height),0,0);return original.apply(copy,args);}catch{return original.apply(this,args);}};}
  for(const cls of [window.WebGLRenderingContext,window.WebGL2RenderingContext])if(cls){const original=cls.prototype.getParameter;cls.prototype.getParameter=function(value){if(value===37445)return 'Intel Inc.';if(value===37446)return 'Intel Iris OpenGL Engine';return original.call(this,value);};}
  if(window.AudioBuffer){const original=AudioBuffer.prototype.getChannelData,seen=new WeakSet();AudioBuffer.prototype.getChannelData=function(...args){const data=original.apply(this,args);if(!seen.has(data)){for(let i=0;i<data.length;i+=100)data[i]+=(seed-128)*1e-9;seen.add(data);}return data;};}
}
// Runs before website scripts; no Node or IPC capabilities are copied into the page.
if(!options.javascript_disabled)contextBridge.executeInMainWorld({func:protect,args:[options]});

if(process.isMainFrame){
  document.addEventListener('mousedown',event=>ipcRenderer.send('ss:click',{x:event.clientX,y:event.clientY}),true);
  if(!options.private&&!options.javascript_disabled&&location.protocol==='https:')document.addEventListener('submit',event=>{
    const form=event.target;if(!(form instanceof HTMLFormElement))return;
    try{if(new URL(form.action||location.href,location.href).origin!==location.origin)return;}catch{return;}
    const fields=[...form.querySelectorAll('input')];
    if(fields.some(field=>field.autocomplete==='new-password'))return;
    const password=fields.find(field=>field.type==='password'&&field.value);
    const username=fields.find(field=>field.autocomplete==='username')||fields.find(field=>['email','text'].includes(field.type)&&field.value);
    if(password)ipcRenderer.send('ss:credential',{origin:location.origin,username:username?.value||'',password:password.value});
  },true);
}
```

### engine/index.html
```html
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SuperSearch</title><link rel="stylesheet" href="ui.css"><script src="ui.js" defer></script></head>
<body>
<header id="titlebar"><div id="window-title">SuperSearch</div><div id="system-status" hidden></div><div class="window-buttons"><button id="expand" title="Expand" hidden></button><button id="minimize" title="Minimize"></button><button id="close" title="Close"></button></div></header>
<div id="workspace">
 <aside id="sidebar"><div class="sidebar-top"><button id="collapse" title="Collapse tab panel"></button><button id="new-tab" title="New tab · Ctrl+T"></button></div><div id="tabs" role="tablist" tabindex="0" aria-label="Tabs"></div><div class="sidebar-bottom"><button id="bookmarks-button"></button><div class="sidebar-bottom-row"><button id="downloads-button"></button><button id="settings-button"></button></div></div><div id="sidebar-resizer" title="Resize tab panel"></div></aside>
 <main id="browser">
  <nav id="navigation"><button id="back" title="Back · Alt+Left"></button><button id="forward" title="Forward · Alt+Right"></button><button id="reload" title="Reload · F5"></button><form id="address-form"><input id="address" spellcheck="false" autocomplete="off" aria-label="Address and search" placeholder="Search the web or enter an address"></form><button id="shield" title="Privacy"></button><button id="split" title="Split view · Ctrl+\"></button><button id="passwords" title="Saved passwords"></button><button id="bookmark" title="Bookmark · Ctrl+D"></button><button id="menu" title="Browser menu"></button></nav>
  <div id="bookmark-bar"></div><div id="password-offer" hidden></div><div id="find-bar" hidden><input id="find-text" placeholder="Find on page"><button id="find-close" aria-label="Close find bar"></button></div>
  <section id="viewport"><div id="panes"></div><div id="screen" hidden></div></section>
 </main>
</div>
<div id="modal-layer" hidden></div><div id="toasts" role="status" aria-live="polite"></div><div id="download-flight" hidden></div>
</body></html>
```

### engine/main.js
```javascript
'use strict';
const {app,BrowserWindow,WebContentsView,ipcMain,session,protocol,net,dialog,shell,Menu,clipboard,nativeImage}=require('electron');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {spawn}=require('node:child_process');
const {Backend}=require('./backend');
const {origin,target,cleaned,sameParty,Filters,validSender}=require('./policy');
const ROOT=path.dirname(__dirname),DATA=path.resolve(process.env.SUPERSEARCH_DATA||path.join(ROOT,'data/electron'));
const RUNTIME=require('./runtime.json'),RELEASE=require('./package.json');
const TEST=process.argv.includes('--self-test');
if(TEST&&(!fs.existsSync(path.join(DATA,'.supersearch-test-profile'))||process.env.SUPERSEARCH_SKIP_MIGRATION!=='1'))throw Error('Run tests/gui_electron.py to use an isolated test profile.');
if(TEST){app.commandLine.appendSwitch('ozone-platform','headless');app.disableHardwareAcceleration();}
if(process.versions.electron!==RUNTIME.electron||process.versions.chrome!==RUNTIME.chromium)throw Error('Unexpected browser runtime');
fs.mkdirSync(DATA,{recursive:true});
if(TEST){fs.mkdirSync(path.join(DATA,'test-downloads'),{recursive:true});app.setPath('downloads',path.join(DATA,'test-downloads'));}
app.setName('SuperSearch');app.setPath('userData',path.join(DATA,'chromium'));app.setPath('sessionData',path.join(DATA,'chromium'));app.setPath('crashDumps',path.join(DATA,'crashes'));
app.enableSandbox();
let initial={webrtc:true,tor:false};try{initial={...initial,...JSON.parse(fs.readFileSync(path.join(DATA,'settings.json'),'utf8'))};}catch{}
if(initial.webrtc){for(const flag of ['disable-webrtc','disable-webrtc-hw-encoding','disable-webrtc-hw-decoding'])app.commandLine.appendSwitch(flag);app.commandLine.appendSwitch('force-webrtc-ip-handling-policy','disable_non_proxied_udp');}
if(initial.tor)app.commandLine.appendSwitch('host-resolver-rules','MAP * ~NOTFOUND, EXCLUDE 127.0.0.1, EXCLUDE localhost');
if(process.platform==='linux')app.commandLine.appendSwitch('disable-setuid-sandbox');
for(const flag of ['disable-quic','disable-background-networking','disable-sync','disable-component-update','no-pings','dns-prefetch-disable'])app.commandLine.appendSwitch(flag);
protocol.registerSchemesAsPrivileged([{scheme:'ss-app',privileges:{standard:true,secure:true,supportFetchAPI:true}}]);
let backend,bootstrap,config,startup,normalSession,filters,quitting=false;
let backendStopped=false,backupBusy=false;
const windows=new Map(),remote=new Map(),downloads=[],reserved=new Set(),blocks={};
let ip={address:'',state:'idle',expires:0,generation:0},ipController=null,statsTimer=null;
let ipLastAttempt=0;
const UI_URL='ss-app://browser/index.html';
const extensionChoices=new Map();
const RESTART=['webrtc','javascript','tor','doh','proxy','ephemeral_profile'];

function writeJSON(name,value){const file=path.join(DATA,name),temporary=file+'.tmp';fs.writeFileSync(temporary,JSON.stringify(value));fs.renameSync(temporary,file);}
function laterError(error){console.error(error?.name||'Browser operation failed');}
function safeURL(url){if(url==='about:blank'||url==='supersearch:start'||origin(url))return true;try{const parsed=new URL(url);return parsed.protocol==='chrome-extension:'&&!!normalSession?.extensions.getExtension(parsed.hostname);}catch{return false;}}
function background(){return config.theme==='light'?'#ffffff':'#000000';}
function activeTab(owner){return owner.tabs.find(tab=>tab.id===owner.active)||owner.tabs[0];}
function activePane(owner){const tab=activeTab(owner);return tab?.panes[tab.active]||null;}
function browserVisible(owner){return !owner.page&&!owner.modal&&!owner.uiModal&&!owner.closing&&config.onboarding_complete;}
function paneRecord(pane){return {url:pane.url,title:pane.title,icon:pane.icon,loading:pane.loading,error:pane.error,canBack:pane.view?.webContents.navigationHistory.canGoBack()||false,canForward:pane.view?.webContents.navigationHistory.canGoForward()||false};}
function tabRecord(tab){return {id:tab.id,pinned:tab.pinned,active_pane:tab.active,panes:tab.panes.map(pane=>pane.url)};}
function state(owner){return {config,private:owner.private,tabs:owner.tabs.map(tab=>({id:tab.id,pinned:tab.pinned,active:tab.active,panes:tab.panes.map(paneRecord)})),active:owner.active,
  bookmarks:bootstrap.bookmarks,history:owner.private?[]:bootstrap.history,shortcuts:bootstrap.shortcuts,stats:owner.private?owner.stats:bootstrap.stats,
  downloads:downloads.filter(record=>record.private?record.owner===owner.id:!owner.private).map(({item,...record})=>record),ip,
  page:owner.page,modal:owner.modal,passwordOffer:owner.offer?{origin:owner.offer.origin,username:owner.offer.username}:null,
  fullscreen:owner.window.isFullScreen(),maximized:owner.window.isMaximized(),battery:owner.battery,
  restart:RESTART.some(key=>config[key]!==startup[key]),vault:bootstrap.vault,
  versions:{SuperSearch:RELEASE.displayVersion,Electron:process.versions.electron,Chromium:process.versions.chrome,Node:process.versions.node},
  source:'https://github.com/mishandreevy/supersearch',route:{tor:startup.tor,proxy:startup.proxy,ephemeral:startup.ephemeral_profile},lastClick:owner.lastClick};}
function publish(owner){if(!owner.window.isDestroyed()&&!owner.ui.isDestroyed())owner.ui.send('ss:state',state(owner));}
function publishAll(){for(const owner of windows.values())publish(owner);}
function event(owner,type,data={}){if(!owner.ui.isDestroyed())owner.ui.send('ss:event',{type,...data});}
function persistPins(owner){return owner.private?Promise.resolve(true):backend.call('pins',owner.tabs.filter(tab=>tab.pinned).map(tabRecord)).catch(error=>{event(owner,'error',{message:error.message});return false;});}
function disposePane(pane){if(!pane.view)return;remote.delete(pane.view.webContents.id);if(!pane.view.webContents.isDestroyed())pane.view.webContents.close();pane.view=null;}
function cancelOffer(owner){if(owner.offer){owner.offer.password='';owner.offer=null;}if(owner.candidate)owner.candidate.password='';clearTimeout(owner.offerTimer);clearTimeout(owner.candidateTimer);clearTimeout(owner.candidateExpiry);owner.candidate=null;}

async function configureProxy(ses,settings){
  const proxy=settings.tor?'socks5://127.0.0.1:9050':settings.proxy.trim();
  await ses.setProxy(proxy?{mode:'fixed_servers',proxyRules:proxy,proxyBypassRules:'<-loopback>'}:{mode:'direct'});
}
function installPolicy(ses,isPrivate){
  ses.setPermissionRequestHandler((contents,permission,callback)=>callback(permission==='fullscreen'&&!!contents&&remote.has(contents.id)));
  ses.setPermissionCheckHandler((contents,permission)=>permission==='fullscreen'&&!!contents&&remote.has(contents.id));ses.setDevicePermissionHandler(()=>false);
  ses.setDisplayMediaRequestHandler((_request,callback)=>callback(null));
  ses.webRequest.onBeforeRequest({urls:['http://*/*','https://*/*']},(details,callback)=>{
    if(config.block_ads&&filters.blocked(details.url)){
      const host=new URL(details.url).hostname,entry=remote.get(details.webContentsId);
      if(entry?.owner.private){entry.owner.stats.total++;entry.owner.stats.today++;entry.owner.blockedDomains.add(host);entry.owner.stats.domains=entry.owner.blockedDomains.size;publish(entry.owner);}
      else if(!isPrivate)blocks[host]=(blocks[host]||0)+1;
      callback({cancel:true});return;
    }
    const next=cleaned(details.url,config);callback(next===details.url?{}:{redirectURL:next});
  });
  ses.webRequest.onBeforeSendHeaders((details,callback)=>{
    const headers={...details.requestHeaders};
    for(const key of Object.keys(headers)){
      if(config.block_referrers&&key.toLowerCase()==='referer')delete headers[key];
      if(config.third_party&&key.toLowerCase()==='cookie'&&details.resourceType!=='mainFrame'&&!sameParty(details.url,remote.get(details.webContentsId)?.pane.url||details.initiator||''))delete headers[key];
    }
    if(config.gpc){headers['Sec-GPC']='1';headers.DNT='1';}
    callback({requestHeaders:headers});
  });
  ses.webRequest.onHeadersReceived((details,callback)=>{
    const headers={...details.responseHeaders};
    if(config.third_party&&details.resourceType!=='mainFrame'&&!sameParty(details.url,remote.get(details.webContentsId)?.pane.url||details.initiator||''))for(const key of Object.keys(headers))if(key.toLowerCase()==='set-cookie')delete headers[key];
    callback({responseHeaders:headers});
  });
  ses.on('will-download',(downloadEvent,item,contents)=>{
    const entry=remote.get(contents?.id);if(!entry){downloadEvent.preventDefault();return;}
    try{receiveDownload(entry.owner,item);}catch{downloadEvent.preventDefault();event(entry.owner,'error',{message:'Could not save the file to the Downloads folder.'});}
  });
}
async function makeSession(isPrivate=false){
  const partition=!isPrivate&&!startup.ephemeral_profile?'persist:supersearch':'session-'+crypto.randomUUID();
  const ses=session.fromPartition(partition,{cache:false});await configureProxy(ses,startup);installPolicy(ses,isPrivate);return ses;
}
function privacyOptions(owner){return Object.fromEntries(['fingerprint','webrtc','geolocation','third_party','canvas'].map(key=>[key,config[key]]).concat([['private',owner.private],['javascript_disabled',startup.javascript]]));}

function layout(owner){
  if(owner.window.isDestroyed())return;
  const tab=activeTab(owner),area=owner.area;
  for(const entry of owner.tabs)for(const pane of entry.panes)if(pane.view){
    const visible=browserVisible(owner)&&entry===tab&&pane.url!=='supersearch:start'&&!pane.error&&area;
    pane.view.setVisible(!!visible);
    if(visible){
      const index=entry.panes.indexOf(pane),count=entry.panes.length;
      const left=count===2?Math.round(area.width*config.split_ratio/100):area.width,gap=Math.round(4*owner.ui.getZoomFactor());
      const popup=Math.min(owner.popupHeight||0,Math.max(0,area.height-80));
      pane.view.setBounds({x:area.x+(index?left+gap:0),y:area.y+popup,width:Math.max(1,count===1?area.width:index?area.width-left-gap:left-gap),height:Math.max(1,area.height-popup)});
      pane.view.setBackgroundColor(background());
    }
  }
}
function select(owner,id){
  const tab=owner.tabs.find(tab=>tab.id===id);if(!tab)return;
  cancelOffer(owner);owner.active=id;owner.page=null;owner.suggestionGeneration++;
  for(const pane of tab.panes)if(!pane.view&&pane.url!=='supersearch:start')attachPane(owner,tab,pane);
  layout(owner);publish(owner);maybeIP();
  if(browserVisible(owner)){const pane=tab.panes[tab.active];if(pane.view&&!pane.error)pane.view.webContents.focus();else owner.ui.focus();}
}
function newPane(url){return {url,title:url==='supersearch:start'?'SuperSearch':url,icon:'',loading:false,error:null,view:null};}
function newTab(owner,url=config.homepage,record=null){
  const tab={id:record?.id||crypto.randomUUID(),pinned:!!record?.pinned,active:record?.active_pane||0,panes:(record?.panes||[url]).map(value=>newPane(safeURL(value)?value:'supersearch:start'))};
  owner.tabs.push(tab);owner.tabs.sort((a,b)=>Number(b.pinned)-Number(a.pinned));select(owner,tab.id);persistPins(owner);return tab;
}
function removeTabs(owner,ids){
  const selected=new Set(ids);cancelOffer(owner);
  for(const tab of owner.tabs)if(selected.has(tab.id))for(const pane of tab.panes)disposePane(pane);
  const index=owner.tabs.findIndex(tab=>tab.id===owner.active);owner.tabs=owner.tabs.filter(tab=>!selected.has(tab.id));
  if(!owner.tabs.length)newTab(owner);else select(owner,owner.tabs[Math.min(index,owner.tabs.length-1)].id);
  persistPins(owner);
}
function navigate(owner,text,pane=activePane(owner)){
  const url=target(text,config.search);if(!url||!pane){if(text?.trim())event(owner,'error',{message:'Use an HTTP or HTTPS address without embedded credentials.'});return;}
  cancelOffer(owner);owner.suggestionGeneration++;pane.url=url;pane.error=null;pane.title=url==='supersearch:start'?'SuperSearch':url;
  if(url==='supersearch:start'){disposePane(pane);pane.loading=false;layout(owner);publish(owner);maybeIP();}
  else if(pane.view)pane.view.webContents.loadURL(cleaned(url,config)).catch(()=>{});
  else attachPane(owner,activeTab(owner),pane);
  layout(owner);if(pane.view&&!pane.error)pane.view.webContents.focus();
  persistPins(owner);
}
function attachPane(owner,tab,pane){
  const encoded=Buffer.from(JSON.stringify(privacyOptions(owner))).toString('base64');
  const view=new WebContentsView({webPreferences:{session:owner.session,preload:path.join(__dirname,'content-preload.js'),additionalArguments:['--ss-options='+encoded],
    nodeIntegration:false,nodeIntegrationInSubFrames:false,nodeIntegrationInWorker:false,contextIsolation:true,sandbox:true,webSecurity:true,
    allowRunningInsecureContent:false,webviewTag:false,devTools:TEST,javascript:!startup.javascript,webgl:config.webgl,plugins:false,spellcheck:false,
    backgroundThrottling:true,navigateOnDragDrop:false,safeDialogs:true,autoplayPolicy:'user-gesture-required'}});
  pane.view=view;view.setBackgroundColor(background());owner.window.contentView.addChildView(view);view.setVisible(false);
  const contents=view.webContents;remote.set(contents.id,{owner,tab,pane});contents.setZoomFactor(config.page_zoom/100);
  contents.on('preload-error',(_event,_file,error)=>{pane.securityError=error.message;pane.error={code:0,description:'The privacy preload could not start. Restart SuperSearch.',url:pane.url};contents.stop();layout(owner);publish(owner);if(TEST)console.error('PRELOAD ERROR: '+error.message);});
  contents.setWindowOpenHandler(({url})=>{if(origin(url)&&config.allow_popups)newTab(owner,url);return {action:'deny'};});
  contents.on('will-navigate',(event,url)=>{if(!safeURL(url)||url==='supersearch:start')event.preventDefault();});
  contents.on('will-redirect',(event,url)=>{if(!safeURL(url)||url==='supersearch:start')event.preventDefault();});
  contents.on('did-start-navigation',(_event,url,_same,inMain)=>{if(inMain){pane.loading=true;pane.error=null;pane.securityError=null;pane.url=url;owner.suggestionGeneration++;publish(owner);}});
  contents.on('did-navigate',(_event,url)=>{pane.url=url;if(!pane.securityError)pane.error=null;persistPins(owner);settleCredential(owner);publish(owner);});
  contents.on('did-navigate-in-page',(_event,url,isMain)=>{if(isMain){pane.url=url;persistPins(owner);publish(owner);}});
  contents.on('did-start-loading',()=>{pane.loading=true;publish(owner);});
  contents.on('did-stop-loading',()=>{pane.loading=false;publish(owner);});
  contents.on('page-title-updated',(_event,title)=>{pane.title=title;publish(owner);});
  contents.on('page-favicon-updated',(_event,urls)=>{updateFavicon(owner,pane,urls[0]).catch(()=>{});});
  contents.on('did-fail-load',(_event,code,description,url,isMain)=>{if(!isMain||code===-3||contents.isDestroyed()||url!==pane.url)return;pane.loading=false;pane.error={code,description,url};layout(owner);publish(owner);});
  contents.on('render-process-gone',()=>{pane.loading=false;pane.error={code:0,description:'The page process stopped. Reload to continue.',url:pane.url};layout(owner);publish(owner);});
  contents.on('did-finish-load',()=>{
    pane.loading=false;layout(owner);publish(owner);settleCredential(owner);
    if(!owner.private&&config.remember_history&&origin(pane.url))backend.call('visit',{url:pane.url,title:pane.title}).then(()=>{bootstrap.history=[{url:pane.url,title:pane.title},...bootstrap.history.filter(e=>e.url!==pane.url)].slice(0,3000);}).catch(laterError);
    installUserscripts(owner,pane).catch(()=>{});
  });
  contents.on('focus',()=>{if(activeTab(owner)===tab){tab.active=tab.panes.indexOf(pane);owner.suggestionGeneration++;publish(owner);}});
  contents.on('before-input-event',(event,input)=>shortcut(owner,event,input));
  contents.on('enter-html-full-screen',()=>owner.window.setFullScreen(true));
  contents.on('leave-html-full-screen',()=>owner.window.setFullScreen(false));
  contents.on('context-menu',(_event,params)=>{
    const template=[{label:'Back',enabled:contents.navigationHistory.canGoBack(),click:()=>contents.navigationHistory.goBack()},
      {label:'Reload',click:()=>contents.reload()},{type:'separator'},
      {label:'Copy',enabled:!!params.selectionText,click:()=>contents.copy()}];
    if(origin(params.linkURL)){template.push({label:'Open link in new tab',click:()=>newTab(owner,params.linkURL)},{label:'Copy link address',click:()=>clipboard.writeText(params.linkURL)});}
    Menu.buildFromTemplate(template).popup({window:owner.window});
  });
  contents.loadURL(cleaned(pane.url,config)).catch(()=>{});layout(owner);
}
async function installUserscripts(owner,pane){
  if(owner.private&&!config.userscripts_private||!pane.view||!origin(pane.url))return;
  const directory=path.join(DATA,'userscripts');if(!fs.existsSync(directory))return;
  const sourceURL=pane.url;
  for(const name of fs.readdirSync(directory).sort()){
    const file=path.join(directory,name);if(!fs.statSync(file).isFile()||!['.js','.css'].includes(path.extname(name).toLowerCase()))continue;
    const text=fs.readFileSync(file,'utf8');
    if(!pane.view||pane.url!==sourceURL)return;
    if(name.toLowerCase().endsWith('.css'))await pane.view.webContents.insertCSS(text);
    else await pane.view.webContents.executeJavaScript(text);
  }
}
async function bytes(response,maximum=1000000){
  if(!response.ok)throw Error('The server returned an error.');
  const reader=response.body.getReader(),parts=[];let size=0;
  while(true){const {value,done}=await reader.read();if(done)break;size+=value.byteLength;if(size>maximum){await reader.cancel();throw Error('Response too large');}parts.push(Buffer.from(value));}
  return Buffer.concat(parts);
}
async function updateFavicon(owner,pane,url){
  if(!origin(url)||!pane.view)return;
  const current=pane.url,controller=new AbortController(),timer=setTimeout(()=>controller.abort(),8000);
  try{
    const response=await owner.session.fetch(url,{credentials:'omit',signal:controller.signal});
    const image=nativeImage.createFromBuffer(await bytes(response));if(image.isEmpty()||pane.url!==current)return;
    const png=image.resize({width:64,height:64}).toPNG();pane.icon='data:image/png;base64,'+png.toString('base64');
    if(!owner.private){const directory=path.join(DATA,'favicons');fs.mkdirSync(directory,{recursive:true});fs.writeFileSync(path.join(directory,crypto.createHash('sha256').update(origin(current)).digest('hex')+'.png'),png);}
    if(!owner.private){const local=await backend.call('state');bootstrap.shortcuts=local.shortcuts;}
    publish(owner);
  }finally{clearTimeout(timer);}
}

async function createWindow(isPrivate=false){
  const ses=isPrivate?await makeSession(true):normalSession;
  const uiSession=session.fromPartition('ui-'+crypto.randomUUID(),{cache:false});
  uiSession.setPermissionRequestHandler((_contents,_permission,callback)=>callback(false));uiSession.setPermissionCheckHandler(()=>false);
  uiSession.protocol.handle('ss-app',async request=>{
    const url=new URL(request.url),name=decodeURIComponent(url.pathname);
    let file;
    if(url.hostname==='browser'&&['/index.html','/ui.js','/ui.css'].includes(name))file=path.join(__dirname,name);
    else if(url.hostname==='assets'&&/^\/(logo\.svg|site-icons\/[a-z]+\.svg)$/.test(name))file=path.join(ROOT,'assets',name);
    else return new Response('Not found',{status:404});
    let content=fs.readFileSync(file);
    if(name==='/index.html'){const palette={...bootstrap.palettes[config.theme],...config.colors};const declarations=Object.entries(palette).filter(([_key,value])=>/^#[0-9a-fA-F]{6}$/.test(value)).map(([key,value])=>'--'+key+':'+value).join(';');content=Buffer.from(content.toString().replace('<html lang="en">',`<html lang="${config.language}" style="${declarations};color-scheme:${config.theme==='light'?'light':'dark'}">`));}
    if(name==='/logo.svg'){const text=content.toString();content=Buffer.from(text.slice(text.indexOf('<svg')));}
    return new Response(content,{headers:{'content-type':name.endsWith('.html')?'text/html; charset=utf-8':name.endsWith('.js')?'text/javascript':name.endsWith('.css')?'text/css':'image/svg+xml','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' ss-app: data:; connect-src 'none'; object-src 'none'; frame-src 'none'; base-uri 'none'; form-action 'none'",'X-Content-Type-Options':'nosniff'}});
  });
  const win=new BrowserWindow({width:1250,height:850,minWidth:720,minHeight:540,frame:false,show:false,backgroundColor:background(),
    webPreferences:{session:uiSession,preload:path.join(__dirname,'preload.js'),contextIsolation:true,sandbox:true,nodeIntegration:false,webSecurity:true,webviewTag:false,devTools:TEST,spellcheck:false}});
  const owner={id:win.id,window:win,ui:win.webContents,session:ses,private:isPrivate,tabs:[],active:null,page:null,modal:null,offer:null,candidate:null,suggestionGeneration:0,
    stats:{total:0,today:0,domains:0,top:[],daily:[]},blockedDomains:new Set(),battery:null,closing:false,lastClick:{x:500,y:200},area:null};
  windows.set(win.id,owner);win.setMenu(null);
  if(TEST)owner.ui.on('console-message',(_event,...args)=>{const message=typeof _event.message==='string'?_event.message:args[1];if(typeof message==='string'&&/Uncaught/.test(message))console.error('UI SCRIPT ERROR: '+message);});
  owner.ui.setWindowOpenHandler(()=>({action:'deny'}));owner.ui.on('will-navigate',event=>event.preventDefault());owner.ui.on('before-input-event',(event,input)=>shortcut(owner,event,input));
  owner.ui.once('did-finish-load',()=>{
    owner.ui.setZoomFactor(config.ui_scale/100);
    owner.ui.send('ss:event',{type:'bootstrap',data:bootstrap});
    if(config.onboarding_complete&&!isPrivate&&bootstrap.session?.tabs?.length){
      for(const record of bootstrap.session.tabs){const tab={id:record.id,pinned:record.pinned,active:record.active_pane,panes:record.panes.map(newPane)};owner.tabs.push(tab);}
      select(owner,owner.tabs[Math.min(bootstrap.session.active_tab,owner.tabs.length-1)].id);
    }else newTab(owner,config.onboarding_complete?config.homepage:'supersearch:start');
    publish(owner);if(owner.uiReady)win.show();
  });
  win.on('resize',()=>{layout(owner);publish(owner);});
  win.on('enter-full-screen',()=>{systemStatus(owner);publish(owner);});
  win.on('leave-full-screen',()=>{clearInterval(owner.systemTimer);owner.systemTimer=null;owner.battery=null;publish(owner);});
  win.on('maximize',()=>publish(owner));win.on('unmaximize',()=>publish(owner));win.on('restore',()=>maybeIP());
  win.on('close',event=>{
    if(owner.closing||quitting)return;
    event.preventDefault();
    if(config.confirm_close){owner.modal={type:'close',save:config.restore_tabs};layout(owner);publish(owner);}
    else closeWindow(owner,config.restore_tabs).catch(laterError);
  });
  win.on('closed',()=>{cancelOffer(owner);clearInterval(owner.systemTimer);for(const tab of owner.tabs)for(const pane of tab.panes)disposePane(pane);windows.delete(win.id);if(!windows.size)app.quit();});
  await owner.ui.loadURL(UI_URL);return owner;
}
async function closeWindow(owner,save){
  if(!owner.private){config=await backend.call('settings',{restore_tabs:!!save});await backend.call('pins',owner.tabs.filter(tab=>tab.pinned).map(tabRecord));await backend.call('session',save?{tabs:owner.tabs.map(tabRecord),active_tab:owner.tabs.findIndex(tab=>tab.id===owner.active)}:{tabs:[]});}
  owner.closing=true;owner.window.close();
}
async function systemStatus(owner){
  clearInterval(owner.systemTimer);owner.systemTimer=null;
  if(!owner.window.isFullScreen()||!config.titlebar_system_status){owner.battery=null;return;}
  const read=async()=>{const battery=await backend.call('system_status');if(!owner.window.isDestroyed()&&owner.window.isFullScreen()){owner.battery=battery;publish(owner);}};
  await read();owner.systemTimer=setInterval(()=>read().catch(()=>{}),30000);
}
function expand(owner){if(config.window_expand_mode==='fullscreen')owner.window.setFullScreen(!owner.window.isFullScreen());else if(owner.window.isFullScreen())owner.window.setFullScreen(false);else owner.window.isMaximized()?owner.window.unmaximize():owner.window.maximize();}
function shortcut(owner,keyEvent,input){
  if(input.type!=='keyDown')return;
  const ctrl=input.control||input.meta,key=input.key.toLowerCase();let command=null;
  if(!config.onboarding_complete){if(key==='f11'){keyEvent.preventDefault();owner.window.setFullScreen(!owner.window.isFullScreen());}if(ctrl&&input.shift&&key==='w')owner.window.close();return;}
  if(ctrl&&!input.shift){command={t:'new_tab',w:'close_active',l:'focus_address',d:'bookmark',h:'history',',':'settings',j:'downloads','\\':'split',tab:'next',pagedown:'next',pageup:'previous',f4:'close_active','+':'zoom_in','=':'zoom_in','-':'zoom_out','0':'zoom_reset',f:'find'}[key];}
  if(ctrl&&input.shift){command={n:'private',tab:'previous',k:'pin_active',p:'passwords',b:'bookmark_bar',w:'close_window',u:'customize'}[key];}
  if(ctrl&&/^[1-9]$/.test(key)){const index=key==='9'?owner.tabs.length-1:Math.min(Number(key)-1,owner.tabs.length-1);select(owner,owner.tabs[index]?.id);keyEvent.preventDefault();return;}
  if(key==='f11')command='fullscreen';if(key==='f5')command='reload';if(key==='f1')command='keyboard_help';if(input.alt&&key==='arrowleft')command='back';if(input.alt&&key==='arrowright')command='forward';
  if(command){keyEvent.preventDefault();if(['focus_address','bookmark','find','pin_active','customize','keyboard_help'].includes(command)){owner.ui.focus();eventToUI(owner,command==='pin_active'?'pin_selection':command==='find'&&owner.page==='settings'?'settings_find':command);}else action(owner,command,{}).catch(error=>event(owner,'error',{message:error.message}));}
}
function eventToUI(owner,type){event(owner,type);}

async function maybeIP(force=false){
  const visible=[...windows.values()].find(owner=>browserVisible(owner)&&activeTab(owner)?.panes.some(pane=>pane.url==='supersearch:start')&&owner.window.isVisible()&&!owner.window.isMinimized());
  if(!config.home_ip||!config.home_stats||!config.onboarding_complete||!visible||ip.state==='loading'||Date.now()-ipLastAttempt<5000||(!force&&Date.now()<ip.expires))return;
  ipLastAttempt=Date.now();
  const generation=++ip.generation;ipController=new AbortController();const timer=setTimeout(()=>ipController?.abort(),15000);
  ip={address:'',state:'loading',expires:Date.now()+600000,generation};publishAll();
  try{
    const response=await visible.session.fetch('https://api64.ipify.org?format=json',{credentials:'omit',redirect:'error',signal:ipController.signal});
    const data=JSON.parse((await bytes(response,1024)).toString());
    if(!require('node:net').isIP(data.ip)||data.ip.includes('%'))throw Error('Invalid IP response');
    if(ip.generation===generation){ip.address=data.ip;ip.state='ready';}
  }catch{if(ip.generation===generation){ip.address='';ip.state='error';}}
  finally{clearTimeout(timer);if(ip.generation===generation)ipController=null;publishAll();}
}
async function suggest(owner,data){
  const query=String(data.query||''),generation=++owner.suggestionGeneration;
  if(owner.private||!config.suggestions||!query.trim()||query.length>160||query.includes('://')||query.includes('@'))return [];
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),5000);
  try{const response=await owner.session.fetch('https://duckduckgo.com/ac/?q='+encodeURIComponent(query)+'&type=list',{credentials:'omit',signal:controller.signal});
    const raw=JSON.parse((await bytes(response,64000)).toString());
    if(generation!==owner.suggestionGeneration||owner.private||!config.suggestions)return [];
    const values=Array.isArray(raw?.[1])?raw[1]:Array.isArray(raw)?raw.map(item=>item.phrase):[];
    return values.filter(value=>typeof value==='string').slice(0,10);
  }finally{clearTimeout(timer);}
}

function safeFilename(name){let value=path.basename(String(name).replaceAll('\\','/')).replace(/[<>:"/\\|?*\x00-\x1f\u202a-\u202e\u2066-\u2069]/g,'_').replace(/[. ]+$/,'').slice(0,180)||'download';if(/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(value))value='_'+value;return value;}
function receiveDownload(owner,item){
  const directory=app.getPath('downloads');fs.mkdirSync(directory,{recursive:true});
  const filename=safeFilename(item.getFilename()),extension=path.extname(filename),stem=path.basename(filename,extension);let destination=path.join(directory,filename),index=0;
  while(fs.existsSync(destination)||reserved.has(destination))destination=path.join(directory,`${stem} (${++index})${extension}`);
  reserved.add(destination);item.setSavePath(destination);
  const record={id:crypto.randomUUID(),owner:owner.id,private:owner.private,name:path.basename(destination),path:destination,url:item.getURL(),received:0,total:item.getTotalBytes(),state:'progressing',paused:false,item};downloads.unshift(record);
  event(owner,'download-start',{click:owner.lastClick});
  const update=()=>{record.received=item.getReceivedBytes();record.total=item.getTotalBytes();record.paused=item.isPaused();publishAll();};
  item.on('updated',(_event,state)=>{record.state=state;update();});
  item.once('done',async(_event,state)=>{record.state=state;update();reserved.delete(destination);if(!owner.private&&!quitting)try{await backend.call('downloads',downloads.filter(e=>!e.private).map(({item,url,...entry})=>entry));if(state==='completed')await backend.call('download_owned',{path:destination});}catch(error){laterError(error);}});
  publishAll();
}
function credential(event,data){
  const entry=remote.get(event.sender.id);if(!entry||entry.owner.private||event.senderFrame!==event.sender.mainFrame||typeof data?.origin!=='string'||!data.origin.startsWith('https://')||origin(event.senderFrame.url)!==data.origin||typeof data.password!=='string'||!data.password||data.password.length>4096||typeof data.username!=='string'||data.username.length>1000)return;
  const owner=entry.owner;if(activePane(owner)!==entry.pane)return;
  cancelOffer(owner);owner.candidate={...data,pane:entry.pane,expires:Date.now()+30000};
  owner.candidateExpiry=setTimeout(()=>{if(owner.candidate)cancelOffer(owner);},30000);
  owner.candidateTimer=setTimeout(()=>settleCredential(owner),850);
}
async function settleCredential(owner){
  const candidate=owner.candidate;if(!candidate||candidate.expires<Date.now()||activePane(owner)!==candidate.pane){if(candidate)cancelOffer(owner);return;}
  const contents=candidate.pane.view?.webContents;if(!contents||contents.isDestroyed())return;
  if(candidate.pane.loading){clearTimeout(owner.candidateTimer);owner.candidateTimer=setTimeout(()=>settleCredential(owner),500);return;}
  let formRemains=false;
  if(origin(contents.getURL())===candidate.origin)try{formRemains=await contents.executeJavaScriptInIsolatedWorld(1001,[{code:"!!document.querySelector('form input[type=password]')"}]);}catch{return;}
  if(owner.candidate!==candidate)return;
  if(formRemains){clearTimeout(owner.candidateTimer);owner.candidateTimer=setTimeout(()=>settleCredential(owner),500);return;}
  owner.candidate=null;clearTimeout(owner.candidateExpiry);owner.offer=candidate;delete owner.offer.pane;
  if(bootstrap.vault.unlocked)try{const entry=await backend.call('vault_get',candidate);if(entry?.password===candidate.password){cancelOffer(owner);return;}}catch{}
  owner.offerTimer=setTimeout(()=>{cancelOffer(owner);layout(owner);publish(owner);},90000);layout(owner);publish(owner);
}

async function chooseFile(owner,kind){
  const options={properties:[kind==='profile'?'openDirectory':'openFile']};
  if(kind==='wallpaper')options.filters=[{name:'Images',extensions:['png','jpg','jpeg','webp']}];
  if(kind==='script')options.filters=[{name:'UserScripts',extensions:['js','css']}];
  if(kind==='csv')options.filters=[{name:'Passwords CSV',extensions:['csv']}];
  const result=await dialog.showOpenDialog(owner.window,options);return result.canceled?null:result.filePaths[0];
}
async function restart(token=null,restoreToken=null){
  const args=[path.join(ROOT,'main.py'),'--wait-for-pid',String(process.pid)];if(token)args.push('--maintenance-token',token);if(restoreToken)args.push('--restore-token',restoreToken);
  const env={...process.env,SUPERSEARCH_ENGINE_DATA:DATA};delete env.SUPERSEARCH_DATA;
  const child=spawn(process.env.SUPERSEARCH_PYTHON||'python3',args,{cwd:ROOT,env,stdio:'ignore',detached:true});
  child.on('error',()=>publishAll());child.unref();quitting=true;for(const owner of windows.values())owner.closing=true;app.quit();
}
async function action(owner,operation,data){
  const pane=activePane(owner),tab=activeTab(owner),contents=pane?.view?.webContents;
  switch(operation){
    case 'bootstrap':return {bootstrap,state:state(owner)};
    case 'ui_ready':owner.uiReady=true;if(owner.tabs.length)owner.window.show();return true;
    case 'bounds':{
      if(!data||!['x','y','width','height'].every(key=>Number.isFinite(data[key])))return false;
      const bounds=owner.window.getContentBounds(),scale=owner.ui.getZoomFactor(),x=Math.max(0,Math.min(bounds.width-1,Math.round(data.x*scale))),y=Math.max(0,Math.min(bounds.height-1,Math.round(data.y*scale)));
      owner.area={x,y,width:Math.max(1,Math.min(bounds.width-x,Math.round(data.width*scale))),height:Math.max(1,Math.min(bounds.height-y,Math.round(data.height*scale)))};layout(owner);return true;}
    case 'overlay':owner.popupHeight=Math.max(0,Math.min(400,Number(data.height)||0))*owner.ui.getZoomFactor();layout(owner);return true;
    case 'ui_modal':owner.uiModal=!!data.open;layout(owner);return true;
    case 'navigate':owner.page=null;navigate(owner,data.text);break;
    case 'new_tab':newTab(owner,data.url||config.homepage);owner.ui.focus();eventToUI(owner,'focus_address');break;
    case 'select':select(owner,data.id);break;
    case 'close_tabs':removeTabs(owner,Array.isArray(data.ids)?data.ids:[]);break;
    case 'close_active':removeTabs(owner,[owner.active]);break;
    case 'next':case 'previous':{const index=owner.tabs.findIndex(tab=>tab.id===owner.active),delta=operation==='next'?1:-1;select(owner,owner.tabs[(index+delta+owner.tabs.length)%owner.tabs.length].id);break;}
    case 'pin_active':case 'pin':{const ids=new Set(data.ids||[owner.active]);const selected=owner.tabs.filter(tab=>ids.has(tab.id)),pinned=!selected.every(tab=>tab.pinned);for(const entry of selected)entry.pinned=pinned;owner.tabs.sort((a,b)=>Number(b.pinned)-Number(a.pinned));await persistPins(owner);break;}
    case 'split':cancelOffer(owner);if(tab.panes.length===1){const second=newPane(config.homepage);tab.panes.push(second);tab.active=1;if(second.url!=='supersearch:start')attachPane(owner,tab,second);}else{disposePane(tab.panes.pop());tab.active=0;}persistPins(owner);break;
    case 'pane':if(data.index>=0&&data.index<tab.panes.length){tab.active=data.index;owner.suggestionGeneration++;}break;
    case 'home':navigate(owner,'supersearch:start');break;
    case 'back':if(contents?.navigationHistory.canGoBack())contents.navigationHistory.goBack();break;
    case 'forward':if(contents?.navigationHistory.canGoForward())contents.navigationHistory.goForward();break;
    case 'reload':case 'retry':if(pane?.url==='supersearch:start')maybeIP(true);else if(contents){pane.error=null;contents.reload();}break;
    case 'zoom_in':case 'zoom_out':case 'zoom_reset':if(contents)contents.setZoomFactor(operation==='zoom_reset'?1:Math.max(.25,Math.min(2.5,contents.getZoomFactor()+(operation==='zoom_in'?.1:-.1))));break;
    case 'find':if(contents)contents.findInPage(String(data.text||''));break;
    case 'stop_find':contents?.stopFindInPage('clearSelection');break;
    case 'private':await createWindow(true);break;
    case 'settings':case 'downloads':case 'history':case 'bookmarks':case 'passwords':cancelOffer(owner);owner.page=operation;owner.suggestionGeneration++;break;
    case 'web':owner.page=null;break;
    case 'minimize':owner.window.minimize();break;
    case 'expand':expand(owner);break;
    case 'fullscreen':owner.window.setFullScreen(!owner.window.isFullScreen());break;
    case 'close_window':owner.window.close();break;
    case 'close_cancel':owner.modal=null;break;
    case 'close_confirm':await closeWindow(owner,!!data.save);return true;
    case 'bookmark_bar':config=await backend.call('settings',{bookmark_bar:!config.bookmark_bar});break;
    case 'settings_apply':{
      const old=config;config=await backend.call('settings',data);bootstrap.config=config;
      if(!config.home_ip||!config.home_stats){ipController?.abort();ip={address:'',state:'idle',expires:0,generation:ip.generation+1};}
      for(const current of windows.values()){
        current.ui.setZoomFactor(config.ui_scale/100);
        current.suggestionGeneration++;current.window.setBackgroundColor(background());
        for(const entry of current.tabs)for(const view of entry.panes)if(view.view){view.view.webContents.setZoomFactor(config.page_zoom/100);view.view.setBackgroundColor(background());if(old.webgl!==config.webgl||old.fingerprint!==config.fingerprint||old.webrtc!==config.webrtc||old.geolocation!==config.geolocation||old.third_party!==config.third_party)replacePane(current,entry,view);}
        systemStatus(current).catch(()=>{});layout(current);
      }
      publishAll();maybeIP();return {config,restart:RESTART.some(key=>config[key]!==startup[key])};}
    case 'suggest':return suggest(owner,data);
    case 'ip_refresh':await maybeIP(true);return ip;
    case 'source':newTab(owner,'https://github.com/mishandreevy/supersearch');owner.page=null;break;
    case 'bookmarks_save':bootstrap.bookmarks=await backend.call('bookmarks_save',data);publishAll();return bootstrap.bookmarks;
    case 'bookmarks_remove':bootstrap.bookmarks=await backend.call('bookmarks_remove',data);publishAll();return bootstrap.bookmarks;
    case 'shortcuts':bootstrap.shortcuts=await backend.call('shortcuts',data);publishAll();return bootstrap.shortcuts;
    case 'backup_export':{
      if(owner.private)throw Error('Backups are unavailable in private windows.');
      if(backupBusy)throw Error('Another backup operation is in progress.');backupBusy=true;
      try{
        const destination=await dialog.showSaveDialog(owner.window,{title:'Export SuperSearch data',defaultPath:path.join(app.getPath('documents'),'SuperSearch-'+new Date().toISOString().slice(0,10)+'.supersearch'),filters:[{name:'SuperSearch encrypted backup',extensions:['supersearch']}]});
        if(destination.canceled||!destination.filePath)return null;
        await persistPins(owner);await backend.call('session',{tabs:owner.tabs.map(tabRecord),active_tab:owner.tabs.findIndex(tab=>tab.id===owner.active)});
        const pending={...blocks};if(Object.keys(pending).length){for(const key of Object.keys(pending))delete blocks[key];bootstrap.stats=await backend.call('blocks',pending);}
        return await backend.call('backup_export',{path:destination.filePath,password:data.password});
      }finally{backupBusy=false;}}
    case 'backup_choose':{
      if(owner.private)throw Error('Backups are unavailable in private windows.');
      const selected=await dialog.showOpenDialog(owner.window,{title:'Restore SuperSearch data',properties:['openFile'],filters:[{name:'SuperSearch encrypted backup',extensions:['supersearch']}]});
      if(selected.canceled)return null;
      owner.backupChoice={path:selected.filePaths[0],token:crypto.randomUUID(),expires:Date.now()+300000};
      return {token:owner.backupChoice.token,name:path.basename(owner.backupChoice.path)};}
    case 'backup_restore':{
      if(owner.private)throw Error('Backups are unavailable in private windows.');
      if(data.confirmation!=='Replace')throw Error('Confirm replacement of current browser data.');
      if(!config.onboarding_complete&&data.accepted_terms!=='2026-11-02')throw Error('Accept the User Agreement before restoring data.');
      const selected=owner.backupChoice;
      if(!selected||selected.token!==data.token||selected.expires<Date.now())throw Error('Choose the backup file again.');
      if(backupBusy)throw Error('Another backup operation is in progress.');backupBusy=true;
      try{
        const token=await backend.call('backup_restore',{path:selected.path,password:data.password,include_scripts:data.include_scripts===true});
        owner.backupChoice=null;for(const current of windows.values())cancelOffer(current);
        if(TEST){owner.testRestoreToken=token;return {prepared:true};}
        await restart(null,token);return {prepared:true};
      }finally{if(!quitting)backupBusy=false;}}
    case 'profiles':return backend.call('profiles');
    case 'choose_profile':return chooseFile(owner,'profile');
    case 'choose_csv':return chooseFile(owner,'csv');
    case 'import':{
      if(owner.private&&data.csv)throw Error('Private windows do not access the password vault.');
      const result=await backend.call('import',data);
      for(const cookie of result.cookies){const value={url:(cookie.secure?'https://':'http://')+cookie.domain.replace(/^\./,'')+cookie.path,name:cookie.name,value:cookie.value,domain:cookie.domain,path:cookie.path,secure:cookie.secure,httpOnly:cookie.http_only};if(cookie.expires)value.expirationDate=cookie.expires;await owner.session.cookies.set(value);}
      const state=await backend.call('state');Object.assign(bootstrap,state);config=state.config;publishAll();return {counts:result.counts,notices:result.notices};}
    case 'legal':return backend.call('legal',data);
    case 'wallpaper':{
      const file=await chooseFile(owner,'wallpaper');if(!file)return null;if(fs.statSync(file).size>30*1024*1024)throw Error('Choose an image smaller than 30 MB.');
      await backend.call('wallpaper_validate',{path:file});
      const image=nativeImage.createFromPath(file);if(image.isEmpty())throw Error('Could not read the image.');
      const size=image.getSize(),resized=Math.max(size.width,size.height)>2560?image.resize(size.width>=size.height?{width:2560}:{height:2560}):image;
      fs.mkdirSync(path.join(DATA,'wallpapers'),{recursive:true});fs.writeFileSync(path.join(DATA,'wallpapers/home.png'),resized.toPNG());config=await backend.call('settings',{wallpaper:'home.png'});publishAll();return 'data:image/png;base64,'+resized.toPNG().toString('base64');}
    case 'wallpaper_data':{const file=path.join(DATA,'wallpapers/home.png');return config.wallpaper&&fs.existsSync(file)?'data:image/png;base64,'+fs.readFileSync(file).toString('base64'):'';}
    case 'wallpaper_reset':config=await backend.call('settings',{wallpaper:''});publishAll();return true;
    case 'scripts':{const directory=path.join(DATA,'userscripts');fs.mkdirSync(directory,{recursive:true});return fs.readdirSync(directory).filter(name=>/\.(js|css)$/i.test(name));}
    case 'script_install':{
      const file=await chooseFile(owner,'script');if(!file)return null;if(!/\.(js|css)$/i.test(file)||fs.statSync(file).size>2000000)throw Error('Choose a .js or .css file smaller than 2 MB.');
      const directory=path.join(DATA,'userscripts');fs.mkdirSync(directory,{recursive:true});const destination=path.join(directory,path.basename(file));
      if(fs.existsSync(destination)&&!data.replace)throw Error('A script with this name already exists. Remove it first.');fs.copyFileSync(file,destination);return path.basename(file);}
    case 'script_remove':{if(path.basename(data.name)!==data.name||! /\.(js|css)$/i.test(data.name))throw Error('Invalid script name');fs.unlinkSync(path.join(DATA,'userscripts',data.name));return true;}
    case 'extensions_list':return startup.ephemeral_profile||owner.private?[]:normalSession.extensions.getAllExtensions().map(extension=>({id:extension.id,name:extension.name,popup:extension.manifest.action?.default_popup||extension.manifest.browser_action?.default_popup||''}));
    case 'extension_choose':{
      if(owner.private||startup.ephemeral_profile)throw Error('Extensions require a persistent profile and a restart.');
      const result=await dialog.showOpenDialog(owner.window,{properties:[data.kind==='folder'?'openDirectory':'openFile'],filters:data.kind==='folder'?undefined:[{name:'Extensions',extensions:['zip']}]});
      if(result.canceled)return null;const file=result.filePaths[0],manifest=await backend.call('extension_info',{path:file}),token=crypto.randomUUID();extensionChoices.set(token,{owner:owner.id,path:file,expires:Date.now()+120000});
      return {token,name:manifest.name,permissions:[...(manifest.permissions||[]),...(manifest.host_permissions||[])]};}
    case 'extension_install':{
      const choice=extensionChoices.get(data.token);extensionChoices.delete(data.token);if(!choice||choice.owner!==owner.id||choice.expires<Date.now()||owner.private||startup.ephemeral_profile)throw Error('Choose the extension again.');
      const directory=await backend.call('extension_prepare',{path:choice.path});
      const extension=await normalSession.extensions.loadExtension(directory,{allowFileAccess:false});let saved=[];try{saved=JSON.parse(fs.readFileSync(path.join(DATA,'extensions.json')));}catch{}
      saved.push({id:extension.id,directory});writeJSON('extensions.json',saved);return {id:extension.id,name:extension.name};}
    case 'extension_remove':{
      if(owner.private||startup.ephemeral_profile)throw Error('Extensions are unavailable in this window.');normalSession.extensions.removeExtension(data.id);let saved=[];try{saved=JSON.parse(fs.readFileSync(path.join(DATA,'extensions.json')));}catch{}
      const removed=saved.find(entry=>entry.id===data.id);writeJSON('extensions.json',saved.filter(entry=>entry.id!==data.id));if(removed&&path.dirname(removed.directory)===path.join(DATA,'extensions'))fs.rmSync(removed.directory,{recursive:true,force:true});return true;}
    case 'extension_open':{
      if(owner.private)throw Error('Extensions are unavailable in private windows.');const extension=normalSession.extensions.getExtension(data.id),popup=extension?.manifest.action?.default_popup||extension?.manifest.browser_action?.default_popup;
      if(!popup)throw Error('This extension has no popup.');newTab(owner,'chrome-extension://'+extension.id+'/'+popup);owner.page=null;break;}
    case 'filters_update':{
      for(const [name,url] of [['easylist','https://easylist.to/easylist/easylist.txt'],['easyprivacy','https://easylist.to/easylist/easyprivacy.txt']]){
        const response=await owner.session.fetch(url,{credentials:'omit',signal:AbortSignal.timeout(30000)}),text=(await bytes(response,20000000)).toString();if(!text.startsWith('[Adblock')||text.length<1000)throw Error('Invalid filter list');
        fs.mkdirSync(path.join(DATA,'filters'),{recursive:true});fs.writeFileSync(path.join(DATA,'filters',name+'.txt.tmp'),text);fs.renameSync(path.join(DATA,'filters',name+'.txt.tmp'),path.join(DATA,'filters',name+'.txt'));
      }
      filters.reload();return {rules:filters.blocks.length,skipped:filters.skipped};}
    case 'proxy_test':{
      const draft={...config,...data};if(draft.proxy){const u=new URL(draft.proxy);if(!['http:','socks4:','socks5:'].includes(u.protocol)||!u.hostname||!u.port||u.username||u.password)throw Error('Invalid proxy address');}
      if(!draft.tor&&!draft.proxy.trim())throw Error('Configure a proxy or enable Tor first.');
      const ses=session.fromPartition('proxy-test-'+crypto.randomUUID(),{cache:false});await configureProxy(ses,draft);
      try{const response=await ses.fetch('https://api64.ipify.org?format=json',{credentials:'omit',redirect:'error',signal:AbortSignal.timeout(15000)}),value=JSON.parse((await bytes(response,1024)).toString());if(!require('node:net').isIP(value.ip))throw Error('Invalid response');return value.ip;}finally{await ses.closeAllConnections();}}
    case 'vault_status':bootstrap.vault=await backend.call('vault_status');return bootstrap.vault;
    case 'vault_create':case 'vault_unlock':case 'vault_change':case 'vault_lock':case 'vault_list':case 'vault_remove':{
      if(owner.private)throw Error('The password manager is unavailable in private windows.');
      const result=await backend.call(operation,data);bootstrap.vault=await backend.call('vault_status');publishAll();return result;}
    case 'vault_save':{
      if(owner.private)throw Error('Private windows do not save passwords.');await backend.call('vault_save',data);return true;}
    case 'vault_get':if(owner.private)throw Error('Private windows do not access saved passwords.');return backend.call('vault_get',data);
    case 'password_decline':cancelOffer(owner);break;
    case 'password_save':{
      if(owner.private||!owner.offer)throw Error('There is no password offer.');await backend.call('vault_save',owner.offer);cancelOffer(owner);break;}
    case 'password_fill':{
      if(owner.private||!contents||origin(contents.getURL())!==data.origin)throw Error('Select the matching website first.');
      const entry=await backend.call('vault_get',data);if(!entry)throw Error('No matching saved login.');
      const code=`(()=>{const value=${JSON.stringify(entry)};if(location.origin!==value.origin)return false;const fields=[...document.querySelectorAll('input')],password=fields.find(e=>e.type==='password'),username=fields.find(e=>e.autocomplete==='username')||fields.find(e=>['email','text'].includes(e.type));const set=(field,text)=>{if(field){Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(field,text);field.dispatchEvent(new Event('input',{bubbles:true}));field.dispatchEvent(new Event('change',{bubbles:true}));}};if(!password)return false;set(username,value.username);set(password,value.password);return true;})()`;
      const filled=await contents.executeJavaScriptInIsolatedWorld(1001,[{code}]);if(!filled)throw Error('No password field was found.');owner.page=null;break;}
    case 'download_action':{
      const record=downloads.find(entry=>entry.id===data.id&&(!entry.private||entry.owner===owner.id));if(!record)throw Error('Unknown download');
      if(data.action==='folder')shell.showItemInFolder(record.path);else if(record.item){if(data.action==='pause')record.item.pause();if(data.action==='resume')record.item.resume();if(data.action==='cancel')record.item.cancel();}break;}
    case 'maintenance':{
      if(!Array.isArray(data.categories)||!data.categories.length)throw Error('Choose data to remove.');
      if(data.categories.includes('reset')&&data.confirmation!=='Delete')throw Error('Type Delete to reset the browser.');
      const sessions=[...new Set([...windows.values()].map(value=>value.session))];
      if(data.categories.some(value=>['cookies','reset'].includes(value)))await Promise.all(sessions.map(ses=>ses.clearStorageData()));
      if(data.categories.some(value=>['cache','reset'].includes(value)))await Promise.all(sessions.map(ses=>ses.clearCache()));
      const token=await backend.call('maintenance',data);await restart(token);return true;}
    case 'tour':event(owner,'tour');return true;
    case 'restart':await restart();return true;
    default:throw Error('Unknown browser action');
  }
  layout(owner);publishAll();return true;
}
function replacePane(owner,tab,pane){disposePane(pane);if(pane.url!=='supersearch:start')attachPane(owner,tab,pane);}

ipcMain.handle('ss:ui',async(event,operation,data)=>{
  const owner=[...windows.values()].find(value=>validSender(event,value.ui));
  if(!owner)throw Error('Untrusted UI request');
  if(typeof operation!=='string'||JSON.stringify(data||{}).length>4000000)throw Error('Invalid request');
  if(!config.onboarding_complete&&!['bootstrap','ui_ready','bounds','overlay','ui_modal','settings_apply','profiles','choose_profile','choose_csv','import','legal','wallpaper','wallpaper_data','wallpaper_reset','backup_choose','backup_restore','vault_status','vault_create','vault_unlock','vault_lock','proxy_test','filters_update','minimize','close_window','close_cancel','close_confirm'].includes(operation))throw Error('Finish setup before browsing.');
  return action(owner,operation,data||{});
});
ipcMain.on('ss:credential',credential);
ipcMain.on('ss:click',(event,data)=>{const entry=remote.get(event.sender.id);if(entry&&event.senderFrame===event.sender.mainFrame&&Number.isFinite(data.x)&&Number.isFinite(data.y)){const bounds=entry.pane.view.getBounds();entry.owner.lastClick={x:Math.max(0,bounds.x+data.x*event.sender.getZoomFactor()),y:Math.max(0,bounds.y+data.y*event.sender.getZoomFactor())};}});
app.on('certificate-error',(event,_contents,_url,_error,_certificate,callback)=>{event.preventDefault();callback(false);});
app.on('before-quit',event=>{if(backend&&!backendStopped){event.preventDefault();quitting=true;clearInterval(statsTimer);ipController?.abort();for(const owner of windows.values())owner.closing=true;(async()=>{try{if(Object.keys(blocks).length)await backend.call('blocks',{...blocks});await backend.call('downloads',downloads.filter(entry=>!entry.private).map(({item,url,...entry})=>entry));}finally{await backend.close();backendStopped=true;app.quit();}})().catch(()=>{backendStopped=true;app.quit();});}});
app.on('will-quit',()=>{clearInterval(statsTimer);ipController?.abort();backend?.close();});
app.on('window-all-closed',()=>app.quit());

async function start(){
  backend=new Backend(ROOT,DATA);bootstrap=await backend.call('bootstrap');config=bootstrap.config;startup={...config};
  await app.whenReady();
  if(!app.requestSingleInstanceLock()){backend.close();app.quit();return;}
  app.on('second-instance',()=>{const owner=[...windows.values()][0];if(owner){owner.window.restore();owner.window.focus();}});
  const providers={Cloudflare:'https://cloudflare-dns.com/dns-query',Quad9:'https://dns.quad9.net/dns-query',Google:'https://dns.google/dns-query'};
  if(!startup.tor&&providers[startup.doh])app.configureHostResolver({enableBuiltInResolver:true,secureDnsMode:'secure',secureDnsServers:[providers[startup.doh]]});
  filters=new Filters(path.join(DATA,'filters'));normalSession=await makeSession();
  if(!startup.ephemeral_profile){let saved=[];try{saved=JSON.parse(fs.readFileSync(path.join(DATA,'extensions.json')));}catch{}
    for(const entry of saved)if(path.dirname(entry.directory)===path.join(DATA,'extensions'))try{await normalSession.extensions.loadExtension(entry.directory,{allowFileAccess:false});}catch{}
  }
  for(const record of bootstrap.downloads||[])downloads.push({...record,id:record.id||crypto.randomUUID(),private:false,state:record.state==='completed'?'completed':'interrupted'});
  let statusTick=0;
  statsTimer=setInterval(async()=>{try{
    const entries={...blocks};for(const key of Object.keys(entries))delete blocks[key];
    if(Object.keys(entries).length){bootstrap.stats=await backend.call('blocks',entries);publishAll();}
    if(++statusTick%30===0){const status=await backend.call('vault_status');if(bootstrap.vault.unlocked&&!status.unlocked)for(const owner of windows.values())cancelOffer(owner);bootstrap.vault=status;publishAll();}
    maybeIP().catch(()=>{});
  }catch{}},1000);
  const owner=await createWindow();
  if(TEST){const module=['backup','returning','restored'].includes(process.env.SUPERSEARCH_TEST_MODE)?'./smoke_backup':process.env.SUPERSEARCH_TEST_MODE==='layout'?'./smoke_layout':['onboarding','javascript-off'].includes(process.env.SUPERSEARCH_TEST_MODE)?'./smoke_modes':'./smoke';require(module).run({app,owner,windows,remote,backend,action,createWindow,normalSession,configureProxy,config:()=>config,filters}).then(async()=>{quitting=true;clearInterval(statsTimer);for(const value of windows.values())value.closing=true;await backend.close();app.exit(0);}).catch(async error=>{console.error(error.stack);quitting=true;clearInterval(statsTimer);for(const value of windows.values())value.closing=true;await backend.close();app.exit(1);});}
}
start().catch(error=>{console.error(error.stack||error.message);process.exitCode=1;app.quit();});
```

### engine/package.json
```json
{
  "name": "supersearch",
  "productName": "SuperSearch",
  "version": "26.11.0",
  "description": "Local-first desktop browser with a modern Chromium engine",
  "main": "main.js",
  "private": true,
  "license": "MIT",
  "repository": {
    "type": "git",
    "url": "https://github.com/mishandreevy/supersearch"
  },
  "displayVersion": "26.11",
  "homepage": "https://github.com/mishandreevy/supersearch",
  "bugs": {
    "url": "https://github.com/mishandreevy/supersearch/issues"
  }
}
```

### engine/policy.js
```javascript
'use strict';
const fs=require('node:fs');
const path=require('node:path');
const BUILTIN='||doubleclick.net^\n||google-analytics.com^\n||googlesyndication.com^\n||facebook.net^\n||scorecardresearch.com^\n||hotjar.com^';
const TRACKING=new Set(['fbclid','gclid','dclid','msclkid','mc_cid','mc_eid','igshid','yclid','_ga','_gl']);
const SEARCH={DuckDuckGo:'https://duckduckgo.com/?q=',Google:'https://www.google.com/search?q=',Brave:'https://search.brave.com/search?q=',Wikipedia:'https://en.wikipedia.org/w/index.php?search='};

function origin(value){try{const u=new URL(value);return ['http:','https:'].includes(u.protocol)&&!u.username&&!u.password?u.origin:'';}catch{return '';}}
function target(text,search='DuckDuckGo') {
  text=String(text||'').trim();if(!text)return null;
  if(['supersearch:start','about:blank'].includes(text))return text;
  if(/^(javascript|data|file|chrome|chrome-extension|ss-app|about):/i.test(text))return null;
  if(text.includes('://')){try{const explicit=new URL(text);return origin(explicit.href)&&! /\s/.test(text)?explicit.href:null;}catch{return null;}}
  try{
    const candidate=new URL(text.includes('://')?text:'https://'+text);
    if(!/\s/.test(text)&&(candidate.hostname.includes('.')||candidate.hostname==='localhost'||candidate.hostname.includes(':'))&&origin(candidate.href))return candidate.href;
  }catch{}
  return (SEARCH[search]||SEARCH.DuckDuckGo)+encodeURIComponent(text);
}
function cleaned(value,config){try{const u=new URL(value);if(!['http:','https:'].includes(u.protocol))return value;
  if(config.https_only&&u.protocol==='http:')u.protocol='https:';
  if(config.strip_params)for(const key of [...u.searchParams.keys()])if(key.toLowerCase().startsWith('utm_')||TRACKING.has(key.toLowerCase()))u.searchParams.delete(key);
  return u.href;
}catch{return value;}}
function sameParty(first,second){try{const a=new URL(first).hostname,b=new URL(second).hostname;return a===b||a.endsWith('.'+b)||b.endsWith('.'+a);}catch{return false;}}
class Filters {
  constructor(directory){this.directory=directory;this.reload();}
  reload(){let source=BUILTIN;try{for(const name of fs.readdirSync(this.directory))if(name.endsWith('.txt'))source+='\n'+fs.readFileSync(path.join(this.directory,name),'utf8');}catch{}
    this.blocks=[];this.exceptions=[];this.skipped=0;this.indexSize=null;
    for(let line of source.split(/\r?\n/)){line=line.trim();if(!line||line.startsWith('!')||line.startsWith('['))continue;
      const exception=line.startsWith('@@');if(exception)line=line.slice(2);
      const match=/^\|\|([a-zA-Z0-9._-]+)\^$/.exec(line);
      if(!match&&(/[$#*|^]/.test(line)||line.startsWith('/'))){this.skipped++;continue;}
      (exception?this.exceptions:this.blocks).push(match?{domain:match[1].toLowerCase()}:{text:line});
    }
  }
  blocked(url){let host;try{host=new URL(url).hostname.toLowerCase();}catch{return false;}
    const size=this.blocks.length+':'+this.exceptions.length;
    if(this.indexSize!==size){this.indexSize=size;this.blockDomains=new Set(this.blocks.filter(rule=>rule.domain).map(rule=>rule.domain));this.allowDomains=new Set(this.exceptions.filter(rule=>rule.domain).map(rule=>rule.domain));this.blockTexts=this.blocks.filter(rule=>!rule.domain).map(rule=>rule.text);this.allowTexts=this.exceptions.filter(rule=>!rule.domain).map(rule=>rule.text);}
    const labels=host.split('.'),suffixes=labels.map((_value,index)=>labels.slice(index).join('.'));
    return !suffixes.some(value=>this.allowDomains.has(value))&&!this.allowTexts.some(text=>url.includes(text))&&(suffixes.some(value=>this.blockDomains.has(value))||this.blockTexts.some(text=>url.includes(text)));
  }
}
function validSender(event,contents){return event.sender===contents&&event.senderFrame===contents.mainFrame&&event.senderFrame.url==='ss-app://browser/index.html';}
module.exports={origin,target,cleaned,sameParty,Filters,validSender};
```

### engine/preload.js
```javascript
'use strict';
const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('supersearch',Object.freeze({
  call:(operation,data={})=>ipcRenderer.invoke('ss:ui',operation,data),
  subscribe:callback=>{const listener=(_event,state)=>callback(state);ipcRenderer.on('ss:state',listener);return ()=>ipcRenderer.removeListener('ss:state',listener);},
  event:callback=>{const listener=(_event,message)=>callback(message);ipcRenderer.on('ss:event',listener);return ()=>ipcRenderer.removeListener('ss:event',listener);}
}));
```

### engine/runtime.json
```json
{
  "electron": "45.2.1",
  "chromium": "156.0.8078.75",
  "channel": "stable",
  "sha256": {
    "linux-x64": "616efc1ae4784af1a4f3f0e8774e73e7030e7bd1708da9d09bcf543dfa499beb",
    "linux-arm64": "e04e635e7312f4b361664e18319aefddbcaaebfdee9c8d9a521e520aa8d385bb",
    "win32-x64": "7c342aee45d5b4ccafe5dfe9037028796b082735a576e21e2b4e2d8422ebb727",
    "win32-arm64": "2b20d7d9f9deed87d0f78a57be046a4578a5e91e884cb4e52013ca14e793a0f7",
    "darwin-x64": "308578d938129666a165f2a3b5c9e0fc866d553e6d53a38ca114bc5209b765f0",
    "darwin-arm64": "a9a1a0a5b64df714957f83467c84823cb34792205922c6f136550b2403605922"
  }
}
```

### engine/service.py
```python
"""Private stdio service for the Electron engine. No HTTP server or listening socket."""
import json
import os
import sys
import threading
from pathlib import Path
from urllib.parse import urlsplit
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from settings.config import DATA,ROOT,config,DEFAULTS,PRESETS,PALETTES,WORDS,read_json,write_json
from core.storage import Store
from core.vault import Vault,origin_of
from core.shortcuts import Shortcuts
from core.pins import PinStore
from core.session import load,normalize_tab
from core.importer import discover_profiles,read_profile
from core.maintenance import record_download,schedule
from settings.i18n import LANGUAGES,catalog
from core.icons import PATHS

EXTRA={'sidebar_position':'left','navigation_position':'top','split_ratio':50}


class Service:
    def __init__(self):
        DATA.mkdir(parents=True,exist_ok=True)
        for key,value in EXTRA.items():config.setdefault(key,value)
        self.store=Store();self.vault=Vault();self.shortcuts=Shortcuts(DATA);self.lock=threading.RLock()
        self.vault_timer=None
        self.restore_once=(DATA/'.restore-tabs-once').is_file()

    def arm_vault(self):
        if self.vault_timer:self.vault_timer.cancel()
        def expire():
            with self.lock:self.vault.lock()
        self.vault_timer=threading.Timer(300,expire);self.vault_timer.daemon=True;self.vault_timer.start()

    def state(self):
        total,top,daily=self.store.stats()
        domains=self.store.db.execute('SELECT count(DISTINCT domain) FROM blocks').fetchone()[0]
        return dict(config=dict(config),bookmarks=self.store.bookmarks,history=self.store.history,
                    shortcuts=[dict(entry,icon=self.shortcuts.icon_data(entry,config.palette()['fg'])) for entry in self.shortcuts.entries],
                    stats=dict(total=total,top=top,daily=daily,domains=domains),
                    downloads=read_json(DATA/'downloads.json',[]),
                    vault=dict(exists=self.vault.exists,unlocked=self.vault.unlocked),
                    session=PinStore(DATA).startup(load(DATA) if config['restore_tabs'] or self.restore_once else None))

    def validate_settings(self,changes,base=None):
        if not isinstance(changes,dict):raise ValueError('Invalid settings')
        allowed=dict(DEFAULTS,**EXTRA)
        candidate=dict(config) if base is None else dict(base)
        for key,value in changes.items():
            if key not in allowed:raise ValueError('Unknown setting')
            default=allowed[key]
            if key=='suggestions':valid=isinstance(value,bool) or value is None
            else:valid=type(value) is type(default)
            if not valid:raise ValueError('Invalid value for '+key)
            candidate[key]=value
        if candidate['language'] not in LANGUAGES or candidate['theme'] not in PALETTES:raise ValueError('Invalid language or theme')
        if candidate['search'] not in ('DuckDuckGo','Google','Brave','Wikipedia'):raise ValueError('Invalid search engine')
        if candidate['doh'] not in ('Off','Cloudflare','Quad9','Google'):raise ValueError('Invalid DNS provider')
        proxy=candidate['proxy'].strip();parts=urlsplit(proxy)
        if proxy and (parts.scheme not in ('http','socks4','socks5') or not parts.hostname or not parts.port or parts.username or parts.password or parts.path not in ('','/') or parts.query or parts.fragment or any(c.isspace() for c in proxy)):
            raise ValueError('Enter a proxy address such as socks5://127.0.0.1:1080, without a username or password.')
        candidate['proxy']=proxy
        if candidate['homepage']!='supersearch:start' and not origin_of(candidate['homepage']):raise ValueError('Enter a complete HTTP or HTTPS homepage address.')
        bounds={'ui_scale':(75,175),'page_zoom':(25,250),'radius':(0,40),'spacing':(0,24),'sidebar_width':(160,640),'sidebar_height':(120,600),'tab_height':(32,88),'icon_size':(16,48),'toolbar_size':(24,64),'titlebar_height':(28,64),'home_columns':(2,8),'home_tile_size':(72,200),'home_width':(600,1600),'split_ratio':(20,80)}
        for key,(low,high) in bounds.items():
            if not low<=candidate[key]<=high:raise ValueError('Out-of-range setting: '+key)
        if candidate['shape'] not in ('rounded','pill','square') or candidate['home_align'] not in ('center','top'):raise ValueError('Invalid layout')
        if candidate['sidebar_position'] not in ('left','right','top','bottom') or candidate['navigation_position'] not in ('top','bottom'):raise ValueError('Invalid panel position')
        if candidate['window_expand_mode'] not in ('fullscreen','maximized'):raise ValueError('Invalid window mode')
        import re
        if any(k not in ('bg','panel','fg','accent') or not isinstance(v,str) or not re.fullmatch(r'#[0-9a-fA-F]{6}',v) for k,v in candidate['colors'].items()):raise ValueError('Use hexadecimal theme colors')
        colors=dict(PALETTES[candidate['theme']],**candidate['colors'])
        def luminance(color):
            channels=[int(color[index:index+2],16)/255 for index in (1,3,5)]
            return sum(weight*(channel/12.92 if channel<=.04045 else ((channel+.055)/1.055)**2.4) for channel,weight in zip(channels,(.2126,.7152,.0722)))
        fg=luminance(colors['fg'])
        if any((max(fg,luminance(colors[key]))+.05)/(min(fg,luminance(colors[key]))+.05)<4.5 for key in ('bg','panel')):raise ValueError('Choose colors with enough contrast to keep text readable.')
        nav={'back','forward','reload','address','shield','split','passwords','bookmark','menu'}
        if any(not isinstance(key,str) or key not in nav for key in candidate['nav_order']+candidate['nav_hidden']):raise ValueError('Invalid address-bar buttons.')
        candidate['dark_sites']=False
        return candidate

    def settings(self,changes):
        candidate=self.validate_settings(changes)
        old=dict(config)
        try:
            config.clear();config.update(candidate);config.save()
        except OSError:
            config.clear();config.update(old);raise
        return dict(config)

    def handle(self,operation,data):
        if operation=='bootstrap':
            from settings.metadata import PRIVACY_OPTIONS,PRESET_HELP,PRESET_LABELS
            dictionaries={lang:dict(catalog(lang),**{WORDS['en'][key]:value for key,value in words.items()}) for lang,words in WORDS.items()}
            for language in dictionaries:
                dictionaries[language].update(read_json(ROOT/'engine/translations'/(language+'.json'),{}))
            result=dict(self.state(),defaults=dict(DEFAULTS,**EXTRA),presets=PRESETS,palettes=PALETTES,languages=LANGUAGES,translations=dictionaries,icons=PATHS,privacy_options=PRIVACY_OPTIONS,preset_help=PRESET_HELP,preset_labels=PRESET_LABELS)
            if self.restore_once:(DATA/'.restore-tabs-once').unlink(missing_ok=True);self.restore_once=False
            return result
        if operation=='state':return self.state()
        if operation=='backup_export':
            from core.backup import export_data
            return export_data(DATA,data['path'],data['password'],self.store.db)
        if operation=='backup_restore':
            from core.backup import prepare_restore
            return prepare_restore(data['path'],data['password'],DATA,lambda saved:self.validate_settings(saved,dict(DEFAULTS,**EXTRA)),data.get('include_scripts') is True)
        if operation=='settings':return self.settings(data)
        if operation=='bookmarks_save':
            if not origin_of(data['url']):raise ValueError('Only HTTP and HTTPS bookmarks are supported')
            self.store.save_bookmark(data['url'],data.get('title') or data['url'],data.get('folder','Bookmarks toolbar'),data.get('original_url'));return self.store.bookmarks
        if operation=='bookmarks_remove':self.store.remove_bookmark(data['url']);return self.store.bookmarks
        if operation=='visit':
            if config['remember_history'] and origin_of(data['url']):self.store.visit(data['url'],data.get('title') or data['url'])
            return True
        if operation=='blocks':
            from datetime import date
            with self.store.lock:
                self.store.db.executemany('INSERT INTO blocks VALUES(?,?,?) ON CONFLICT(day,domain) DO UPDATE SET n=n+excluded.n',[(date.today().isoformat(),host,int(count)) for host,count in data.items() if isinstance(host,str) and isinstance(count,int) and count>0])
                self.store.db.commit()
            return self.state()['stats']
        if operation=='shortcuts':self.shortcuts.commit(data);return self.state()['shortcuts']
        if operation=='extension_info':
            from core.extensions import extension_manifest
            return extension_manifest(data['path'])
        if operation=='wallpaper_validate':
            from PIL import Image
            file=Path(data['path'])
            if file.stat().st_size>30*1024*1024:raise ValueError('Choose an image smaller than 30 MB.')
            with Image.open(file) as image:
                if image.width*image.height>80_000_000:raise ValueError('Choose a readable image smaller than 80 megapixels.')
                image.verify()
            return True
        if operation=='extension_prepare':
            import shutil
            from uuid import uuid4
            from zipfile import ZipFile
            from core.extensions import extension_manifest
            source=Path(data['path']);extension_manifest(source)
            destination=DATA/'extensions'/uuid4().hex;destination.parent.mkdir(exist_ok=True)
            if source.is_dir():
                if any(file.is_symlink() for file in source.rglob('*')):raise ValueError('Extension folders must not contain symbolic links')
                shutil.copytree(source,destination)
            else:
                destination.mkdir()
                with ZipFile(source) as archive:archive.extractall(destination)
            return str(destination)
        if operation=='pins':
            records=[normalize_tab(value) for value in data[:100]]
            if any(record is None for record in records):raise ValueError('Invalid pinned tab')
            PinStore(DATA).commit(records);return True
        if operation=='session':
            records=[normalize_tab(value) for value in data.get('tabs',[])[:100]]
            if records and all(records):write_json(DATA/'session.json',dict(tabs=records,active_tab=max(0,min(data.get('active_tab',0),len(records)-1))))
            else:(DATA/'session.json').unlink(missing_ok=True)
            return True
        if operation=='vault_status':return dict(exists=self.vault.exists,unlocked=self.vault.unlocked)
        if operation in ('vault_create','vault_unlock'):
            getattr(self.vault,'create' if operation=='vault_create' else 'unlock')(data['password']);self.arm_vault();return True
        if operation=='vault_lock':self.vault.lock();return True
        if operation=='vault_list':
            self.arm_vault();return [dict(origin=e['origin'],username=e['username']) for e in self.vault.entries()]
        if operation=='vault_get':
            self.arm_vault();return next((e for e in self.vault.entries(data['origin']) if e['username']==data['username']),None)
        if operation=='vault_save':
            self.vault.save(data['origin'],data['username'],data['password'],tuple(data['previous']) if data.get('previous') else None);self.arm_vault();return True
        if operation=='vault_remove':self.vault.remove(data['origin'],data['username']);return True
        if operation=='vault_change':self.vault.change_password(data['password']);self.arm_vault();return True
        if operation=='profiles':return discover_profiles(os.environ.get('SUPERSEARCH_TEST_PROFILE_HOME'))
        if operation=='import':
            result=read_profile(data.get('profile'),data.get('selected',['bookmarks','history','downloads','cookies','preferences']),data.get('csv'))
            if result['passwords'] and not self.vault.unlocked:raise ValueError('Unlock or create the password vault before importing passwords')
            for key in ('bookmarks','history'):
                entries={e['url']:e for e in getattr(self.store,key)};entries.update((e['url'],e) for e in result[key]);setattr(self.store,key,list(entries.values()));write_json(DATA/(key+'.json'),list(entries.values()))
            if result['passwords']:self.vault.import_entries(result['passwords']);self.arm_vault()
            if result['preferences']:self.settings(result['preferences'])
            if result['downloads']:write_json(DATA/'downloads.json',result['downloads'])
            return dict(counts={key:len(result[key]) for key in ('bookmarks','history','passwords','cookies','downloads')},cookies=result['cookies'],notices=result['notices'])
        if operation=='downloads':write_json(DATA/'downloads.json',data);return True
        if operation=='download_owned':record_download(data['path'],DATA);return True
        if operation=='maintenance':return schedule(data['categories'],DATA)
        if operation=='legal':
            if data['name'] not in ('TERMS.md','PRIVACY.md'):raise ValueError('Unknown document')
            return (ROOT/'docs'/data['name']).read_text()
        if operation=='system_status':
            from core.system_status import read_battery
            battery=read_battery()
            return dict(percent=battery.percent,charging=battery.charging) if battery else None
        raise ValueError('Unknown operation')


def main():
    service=Service()
    try:
        for line in sys.stdin:
            request=None
            try:
                if len(line)>4_000_000:raise ValueError('Request too large')
                request=json.loads(line)
                with service.lock:result=service.handle(request['operation'],request.get('data',{}))
                response=dict(id=request['id'],result=result)
            except Exception as error:
                response=dict(id=request.get('id') if isinstance(request,dict) else None,error=str(error))
            print(json.dumps(response,ensure_ascii=True),flush=True)
    finally:
        if service.vault_timer:service.vault_timer.cancel()
        service.vault.lock();service.store.db.close()


if __name__=='__main__':main()
```

### engine/smoke.js
```javascript
'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const http=require('node:http');
const {once}=require('node:events');
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function until(predicate,label){for(let index=0;index<150;index++){if(await predicate())return;await delay(40);}throw Error('Timed out: '+label);}

async function run(context){
  const {app,owner,windows,backend,action,createWindow,config,filters}=context;
  const errors=[];owner.ui.on('console-message',(_event,...args)=>{const message=typeof _event.message==='string'?_event.message:args[1];if(typeof message==='string'&&/Uncaught|Error invoking remote method/.test(message))errors.push(message);});
  await until(()=>owner.tabs.length&&owner.area,'initial browser UI');
  assert.equal(process.versions.chrome,'156.0.8078.75');
  assert.equal(await owner.ui.executeJavaScript("document.querySelector('.home')!==null"),true);
  const shot=await owner.ui.capturePage();fs.writeFileSync('/tmp/supersearch-electron-home.png',shot.toPNG());
  const server=http.createServer((request,response)=>{
    if(request.url.startsWith('/file')){response.writeHead(200,{'content-type':'application/octet-stream','content-disposition':'attachment; filename="report.txt"'});response.end('local download fixture');return;}
    response.writeHead(200,{'content-type':'text/html'});response.end('<!doctype html><title>Local fixture</title><h1 id="fixture">Chromium 156</h1><input id="text"><a href="/file">Download</a>');
  });
  server.listen(0,'127.0.0.1');await once(server,'listening');const url='http://127.0.0.1:'+server.address().port;
  try{
    await action(owner,'navigate',{text:url});
    await until(()=>owner.tabs[0].panes[0].view&&!owner.tabs[0].panes[0].loading,'fixture page');
    const contents=owner.tabs[0].panes[0].view.webContents;
    await until(async()=>await contents.executeJavaScript("!!document.getElementById('fixture')"),'fixture DOM');
    assert.equal(await contents.executeJavaScript("typeof require+'|'+typeof process+'|'+typeof window.supersearch"),'undefined|undefined|undefined');
    assert.equal(contents.getLastWebPreferences().sandbox,true);assert.equal(contents.getLastWebPreferences().contextIsolation,true);
    assert.ok(!owner.tabs[0].panes[0].securityError);
    assert.equal(await contents.executeJavaScript("typeof RTCPeerConnection"),'undefined');
    await action(owner,'settings',{});assert.equal(owner.page,'settings');assert.equal(owner.tabs[0].panes[0].view.getVisible(),false);
    await action(owner,'web',{});await action(owner,'split',{});assert.equal(owner.tabs[0].panes.length,2);
    await action(owner,'split',{});assert.equal(owner.tabs[0].panes.length,1);
    await action(owner,'pin_active',{});const pins=JSON.parse(fs.readFileSync(path.join(process.env.SUPERSEARCH_DATA,'pinned-tabs.json')));assert.equal(pins.tabs.length,1);
    const privateOwner=await createWindow(true);await until(()=>privateOwner.tabs.length,'private window');assert.notEqual(privateOwner.session,owner.session);assert.equal(privateOwner.session.getStoragePath(),null);
    await action(privateOwner,'new_tab',{url:'about:blank'});await action(privateOwner,'pin_active',{});assert.equal(JSON.parse(fs.readFileSync(path.join(process.env.SUPERSEARCH_DATA,'pinned-tabs.json'))).tabs.length,1);
    await action(privateOwner,'close_confirm',{save:false});
    await action(owner,'settings_apply',{theme:'dark'});assert.equal(config().theme,'dark');
    await action(owner,'settings',{});await until(async()=>await owner.ui.executeJavaScript("!!document.getElementById('settings-content')"),'settings content');
    await owner.ui.executeJavaScript("settingsCategory='About';renderSettingsContent();true");
    assert.equal(await owner.ui.executeJavaScript("document.querySelector('[data-source]').href"),'https://github.com/mishandreevy/supersearch');
    const about=await owner.ui.capturePage();fs.writeFileSync('/tmp/supersearch-electron-about.png',about.toPNG());
    await require('./smoke_extended').run(context);
    assert.deepEqual(errors,[]);
    console.log('ELECTRON CHECKS OK: Chromium '+process.versions.chrome+', sandboxed isolated sites, privacy preload, embedded settings, split view, persistent pins, private session isolation, dark theme and source link');
  }finally{server.close();}
}
module.exports={run,until,delay};
```

### engine/smoke_backup.js
```javascript
'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {dialog}=require('electron');
const {until,delay}=require('./smoke');

async function run({owner,action,backend,config,createWindow}){
  const ui=code=>owner.ui.executeJavaScript(code),mode=process.env.SUPERSEARCH_TEST_MODE;
  const profile=process.env.SUPERSEARCH_DATA,file=process.env.SUPERSEARCH_TEST_BACKUP_PATH;
  await until(()=>owner.tabs.length&&owner.area,'initial backup UI');
  if(mode==='restored'){
    if(fs.existsSync(path.join(profile,'session.json')))assert.ok(owner.tabs.some(tab=>tab.panes[0].url==='about:blank'));
    assert.equal(config().onboarding_complete,true);assert.equal(config().theme,'oled');assert.equal(config().tour_pending,false);
    const state=await backend.call('state');assert.equal(state.bookmarks[0].title,'Portable bookmark');
    await action(owner,'settings',{});await until(()=>ui("!!document.getElementById('settings-content')"),'restored settings');
    await ui("settingsCategory='About';renderSettingsContent();true");assert.equal(await ui("!!document.querySelector('[data-rollback]')"),false);
    assert.equal(await ui(`document.querySelector('.engine-version').textContent.includes(${JSON.stringify(require('./package.json').displayVersion)})`),true);
    console.log('RESTORE RESTART CHECKS OK: validated file installed by the launcher after old process exit, libraries and theme loaded, onboarding complete, no Qt action');return;
  }
  const originalOpen=dialog.showOpenDialog,originalSave=dialog.showSaveDialog;
  dialog.showOpenDialog=async()=>({canceled:false,filePaths:[file]});dialog.showSaveDialog=async()=>({canceled:false,filePath:file});
  try{
    if(mode==='returning'){
      await until(()=>ui("!!document.querySelector('[data-returning=yes]')"),'returning-user choice');
      await ui("document.querySelector('[data-returning=yes]').click();document.getElementById('wizard-continue').click();true");
      await until(()=>ui("!!document.getElementById('agreement')"),'returning agreement');
      assert.equal(await ui("document.getElementById('wizard-continue').disabled"),true);
      await ui("document.getElementById('agreement').click();document.getElementById('wizard-continue').click();true");
      await until(()=>ui("!!document.querySelector('[data-wizard-restore]')"),'restore branch');
      assert.equal(await ui("!!document.getElementById('wizard-tour')"),false);
      await ui("document.querySelector('[data-wizard-restore]').click();true");
    }else{
      await action(owner,'bookmarks_save',{url:'https://example.org',title:'Portable bookmark',folder:'Work'});
      await action(owner,'new_tab',{url:'about:blank'});
      await action(owner,'settings_apply',{theme:'oled'});await action(owner,'settings',{});
      await until(()=>ui("!!document.getElementById('settings-content')"),'storage settings');
      await ui("settingsCategory='Storage';renderSettingsContent();true");
      await delay(200);fs.writeFileSync('/tmp/supersearch-storage-backup.png',(await owner.ui.capturePage()).toPNG());
      await ui("document.querySelector('[data-backup-export]').click();true");
      await until(()=>ui("!!document.querySelector('input[name=repeat]')"),'export password dialog');
      await ui("(()=>{const form=document.querySelector('#modal-layer form');form.elements.password.value='fixture backup password';form.elements.repeat.value='fixture backup password';form.requestSubmit();return true})()");
      await until(()=>fs.existsSync(file)&&fs.statSync(file).size>100,'encrypted export');
      await until(()=>ui("document.getElementById('modal-layer').hidden"),'export finished');
      assert.ok(!fs.readFileSync(file).includes(Buffer.from('Portable bookmark')));
      await action(owner,'bookmarks_remove',{url:'https://example.org'});
      await ui("document.querySelector('[data-backup-restore]').click();true");
      const privateOwner=await createWindow(true);await until(()=>privateOwner.tabs.length,'private backup guard');
      await assert.rejects(action(privateOwner,'backup_choose',{}));await action(privateOwner,'close_confirm',{save:false});
    }
    await until(()=>ui("!!document.querySelector('input[name=confirm]')"),'restore confirmation');
    const before=fs.existsSync(path.join(profile,'bookmarks.json'))?fs.readFileSync(path.join(profile,'bookmarks.json')):null;
    await ui("(()=>{const form=document.querySelector('#modal-layer form');form.elements.password.value='wrong backup password';form.elements.confirm.checked=true;form.requestSubmit();return true})()");
    await until(()=>ui("!document.querySelector('[data-dialog-error]').hidden"),'wrong password shown');assert.equal(owner.testRestoreToken,undefined);
    if(before)assert.deepEqual(fs.readFileSync(path.join(profile,'bookmarks.json')),before);
    await ui("(()=>{const form=document.querySelector('#modal-layer form');form.elements.password.value='fixture backup password';form.requestSubmit();return true})()");
    await until(()=>!!owner.testRestoreToken,'restore prepared for next process');
    if(before)assert.deepEqual(fs.readFileSync(path.join(profile,'bookmarks.json')),before);
    assert.ok(fs.existsSync(path.join(profile,'.restore-plan.json')));
    console.log('BACKUP UI CHECKS OK: '+mode+', native file selection, encrypted export, wrong-password protection, explicit replacement and deferred restore');
  }finally{dialog.showOpenDialog=originalOpen;dialog.showSaveDialog=originalSave;}
}
module.exports={run};
```

### engine/smoke_extended.js
```javascript
'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const http=require('node:http');
const https=require('node:https');
const {session,dialog}=require('electron');
const {once}=require('node:events');
const {delay,until}=require('./smoke');

async function run(context){
  const {app,owner,backend,action,createWindow,normalSession,configureProxy,config,filters}=context;
  const DATA=process.env.SUPERSEARCH_DATA,checks=[];
  const mark=name=>{checks.push(name);console.log('PASS: '+name);};
  const ui=code=>owner.ui.executeJavaScript(code);
  const pane=()=>owner.tabs.find(tab=>tab.id===owner.active).panes[owner.tabs.find(tab=>tab.id===owner.active).active];
  const loaded=async()=>{await until(()=>pane().view&&!pane().loading,'page load');return pane().view.webContents;};
  let trackerHits=0,proxyHits=0;
  function fixture(request,response){
    if(request.url.startsWith('/fixture-tracker')){trackerHits++;response.end('tracker');return;}
    if(request.url.startsWith('/proxy-probe'))proxyHits++;
    if(request.url.startsWith('/file')){response.writeHead(200,{'content-type':'application/octet-stream','content-disposition':'attachment; filename="report.txt"'});response.end('local download fixture');return;}
    response.writeHead(200,{'content-type':'text/html'});
    if(request.url.startsWith('/login')&&request.method!=='POST'){response.end('<!doctype html><title>Login fixture</title><form method="post" action="/login"><input name="user" autocomplete="username"><input name="pass" type="password"><button>Sign in</button></form>');return;}
    if(request.url.startsWith('/login')){request.resume();response.end('<!doctype html><title>Signed in</title><h1 id="signed-in">Welcome</h1>');return;}
    response.end('<!doctype html><title>Local fixture</title><h1 id="fixture">Chromium 156</h1><input id="text"><script>window.scriptRan=true</script><img src="/fixture-tracker"><a href="/file">Download</a>');
  }
  const server=http.createServer(fixture),certificate=fs.readFileSync(path.join(DATA,'fixture-cert.pem'));
  const tls=https.createServer({cert:certificate,key:fs.readFileSync(path.join(DATA,'fixture-key.pem'))},fixture);
  server.listen(0,'127.0.0.1');tls.listen(0,'127.0.0.1');await Promise.all([once(server,'listening'),once(tls,'listening')]);
  const url='http://127.0.0.1:'+server.address().port,secure='https://127.0.0.1:'+tls.address().port;
  const fingerprint=new crypto.X509Certificate(certificate).fingerprint256;
  function trustFixture(ses){ses.setCertificateVerifyProc((request,callback)=>{let trusted=false;try{trusted=request.hostname==='127.0.0.1'&&new crypto.X509Certificate(request.certificate.data).fingerprint256===fingerprint;}catch{}callback(trusted?0:-3);});}
  trustFixture(normalSession);filters.blocks.push({text:'/fixture-tracker'});
  try{
    await action(owner,'navigate',{text:url+'/?utm_source=fixture&safe=1'});let contents=await loaded();
    await until(()=>contents.executeJavaScript("!!document.getElementById('fixture')"),'fixture DOM');
    assert.equal(new URL(pane().url).search,'?safe=1');assert.equal(trackerHits,0);
    assert.equal(await contents.executeJavaScript("typeof require+'|'+typeof process+'|'+typeof window.supersearch"),'undefined|undefined|undefined');
    assert.equal(contents.getLastWebPreferences().sandbox,true);assert.equal(contents.getLastWebPreferences().contextIsolation,true);assert.ok(!pane().securityError);
    if(process.platform==='linux'){const status=fs.readFileSync('/proc/'+contents.getOSProcessId()+'/status','utf8');assert.match(status,/NoNewPrivs:\s+1/);assert.match(status,/Seccomp:\s+2/);}
    assert.equal(await contents.executeJavaScript("typeof RTCPeerConnection"),'undefined');
    assert.equal(await contents.executeJavaScript("window.scriptRan"),true);
    assert.equal(await contents.executeJavaScript("window.open('https://example.org')===null"),true);
    assert.equal(await contents.executeJavaScript("fetch('ss-app://browser/index.html').then(()=>false,()=>true)"),true);
    assert.equal((await backend.call('state')).history.length,0);
    mark('OS sandbox, no Node/IPC in sites, tracker blocking, clean URLs and no default history');

    const probe=session.fromPartition('proxy-probe-'+crypto.randomUUID());
    await configureProxy(probe,{tor:true,proxy:'http://unused.example:123'});assert.match(await probe.resolveProxy(url),/SOCKS5 127\.0\.0\.1:9050/);
    await configureProxy(probe,{tor:false,proxy:'http://127.0.0.1:9'});
    await assert.rejects(probe.fetch(url+'/proxy-probe',{signal:AbortSignal.timeout(5000)}));assert.equal(proxyHits,0);await probe.closeAllConnections();
    mark('Tor takes priority; an unavailable proxy has no direct or loopback fallback');

    await action(owner,'settings',{});assert.equal(pane().view.getVisible(),false);
    await until(()=>ui("!!document.getElementById('settings-content')"),'embedded settings');
    await ui("document.querySelector('[data-category=General]').click();const field=document.querySelector('[data-setting=remember_history]');field.click();true");
    assert.equal(config().remember_history,false);assert.equal(await ui("dirtySettings().includes('remember_history')"),true);
    await ui("document.querySelector('[data-settings=apply]').click();true");await until(()=>config().remember_history===true,'Apply saves settings');
    await action(owner,'settings_apply',{remember_history:false});await action(owner,'web',{});
    mark('settings stage changes until Apply and use the native data service');

    const downloadDirectory=app.getPath('downloads');fs.writeFileSync(path.join(downloadDirectory,'report.txt'),'original');contents.downloadURL(url+'/file');
    await until(()=>fs.existsSync(path.join(downloadDirectory,'report (1).txt'))&&fs.readFileSync(path.join(downloadDirectory,'report (1).txt'),'utf8')==='local download fixture','automatic download');
    assert.equal(fs.readFileSync(path.join(downloadDirectory,'report.txt'),'utf8'),'original');await until(()=>fs.existsSync(path.join(DATA,'download_files.json')),'download ownership index');
    mark('automatic downloads preserve existing files and track owned completed downloads');

    await action(owner,'navigate',{text:secure+'/login'});contents=await loaded();await until(()=>contents.executeJavaScript("!!document.querySelector('input[type=password]')"),'HTTPS login form');
    assert.equal(await contents.executeJavaScript("Notification.requestPermission()"),'denied');
    await contents.executeJavaScriptInIsolatedWorld(1001,[{code:"document.querySelector('[name=user]').value='alice';document.querySelector('[name=pass]').value='fixture-secret';document.querySelector('form').requestSubmit();true"}]);
    await until(()=>!!owner.offer,'native password offer after login');assert.equal(owner.offer.origin,secure);
    await action(owner,'vault_create',{password:'fixture master password'});await action(owner,'password_save',{});assert.equal(owner.offer,null);
    assert.ok(!fs.readFileSync(path.join(DATA,'passwords.vault'),'utf8').includes('fixture-secret'));
    await action(owner,'navigate',{text:secure+'/login'});contents=await loaded();await until(()=>contents.executeJavaScript("!!document.querySelector('input[type=password]')"),'login form for filling');
    await action(owner,'vault_lock',{});await assert.rejects(action(owner,'password_fill',{origin:secure,username:'alice'}));
    await action(owner,'vault_unlock',{password:'fixture master password'});await action(owner,'password_fill',{origin:secure,username:'alice'});
    assert.equal(await contents.executeJavaScript("document.querySelector('input[type=password]').value==='fixture-secret'"),true);
    await action(owner,'navigate',{text:url});contents=await loaded();await assert.rejects(action(owner,'password_fill',{origin:secure,username:'alice'}));
    mark('HTTPS login offers, encrypted saves, locked-vault checks and origin-bound filling');

    const privateOwner=await createWindow(true);await until(()=>privateOwner.tabs.length,'private window');trustFixture(privateOwner.session);
    assert.notEqual(privateOwner.session,owner.session);assert.equal(privateOwner.session.getStoragePath(),null);
    await action(privateOwner,'pin_active',{});assert.equal(JSON.parse(fs.readFileSync(path.join(DATA,'pinned-tabs.json'))).tabs.length,1);
    await assert.rejects(action(privateOwner,'vault_list',{}));await action(privateOwner,'navigate',{text:secure+'/login'});
    const privatePane=privateOwner.tabs[0].panes[0];await until(()=>privatePane.view&&!privatePane.loading,'private login');
    await privatePane.view.webContents.executeJavaScript("document.querySelector('[name=user]').value='private';document.querySelector('[name=pass]').value='private-fixture';document.querySelector('form').requestSubmit();true");
    await delay(1200);assert.equal(privateOwner.offer,null);assert.ok(!fs.readFileSync(path.join(DATA,'passwords.vault'),'utf8').includes('private-fixture'));
    await action(privateOwner,'close_confirm',{save:false});mark('private sessions save neither pins nor credentials and cannot access the vault');

    for(const position of ['right','top','bottom','left']){await action(owner,'settings_apply',{sidebar_position:position});await delay(60);assert.ok(owner.area.width>100&&owner.area.height>100);}
    await action(owner,'settings_apply',{theme:'dark',titlebar_system_status:true});await action(owner,'settings',{});await until(()=>ui("!!document.getElementById('settings-content')"),'settings after layout');
    await ui("settingsCategory='About';renderSettingsContent();true");assert.equal(await ui("document.querySelector('[data-source]').href"),'https://github.com/mishandreevy/supersearch');
    assert.equal(await ui("document.getElementById('system-status').hidden"),true);owner.window.maximize();await delay(100);assert.equal(await ui("document.getElementById('system-status').hidden"),true);
    owner.window.setFullScreen(true);await until(()=>ui("!document.getElementById('system-status').hidden"),'fullscreen clock');owner.window.setFullScreen(false);await until(()=>ui("document.getElementById('system-status').hidden"),'clock hidden on exit');
    fs.writeFileSync('/tmp/supersearch-electron-about.png',(await owner.ui.capturePage()).toPNG());mark('four panel positions, source link, dark theme and fullscreen-only status');

    if(!config().ephemeral_profile){
      const extension=path.join(DATA,'fixture-extension');fs.mkdirSync(extension);fs.writeFileSync(path.join(extension,'manifest.json'),JSON.stringify({manifest_version:3,name:'Local fixture extension',version:'1.0',action:{default_popup:'popup.html'}}));fs.writeFileSync(path.join(extension,'popup.html'),'<h1>Local extension</h1>');
      const original=dialog.showOpenDialog;dialog.showOpenDialog=async()=>({canceled:false,filePaths:[extension]});
      try{const choice=await action(owner,'extension_choose',{kind:'folder'});const loaded=await action(owner,'extension_install',{token:choice.token});assert.equal((await action(owner,'extensions_list',{}))[0].name,'Local fixture extension');await action(owner,'extension_remove',{id:loaded.id});assert.equal((await action(owner,'extensions_list',{})).length,0);}finally{dialog.showOpenDialog=original;}
      mark('real local Manifest V3 extension installation and removal');
    }
    console.log('EXTENDED ELECTRON CHECKS OK: '+checks.length+' groups');
  }finally{server.close();tls.close();}
}
module.exports={run};
```

### engine/smoke_layout.js
```javascript
'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {until,delay}=require('./smoke');

async function run({owner,action,config}){
  const ui=code=>owner.ui.executeJavaScript(code);
  await until(()=>owner.tabs.length&&owner.area,'initial layout');
  await action(owner,'navigate',{text:'supersearch:start'});
  await until(()=>ui("(()=>{const image=document.querySelector('.home-logo');return !!image&&image.complete&&image.naturalHeight>0&&Math.abs(image.naturalWidth/image.naturalHeight-1271/158)<.05})()"),'original homepage logo');
  assert.equal(await ui("new URL(document.querySelector('.home-logo').src).pathname"),'/logo.svg');
  const svg=fs.readFileSync(path.join(__dirname,'../assets/logo.svg'),'utf8');assert.ok(svg.includes('viewBox="0 0 1271.000000 158.000000"'));
  assert.equal(await ui("new URL(document.querySelector('.home-logo').src).search"),'');
  fs.writeFileSync('/tmp/supersearch-electron-home-logo.png',(await owner.ui.capturePage()).toPNG());
  for(let index=0;index<12;index++)await action(owner,'new_tab',{url:'supersearch:start'});
  for(const tab of owner.tabs)tab.panes[0].title='A long website title that should stay inside the tab panel';
  // Cover both edges, scale extremes, icon-only mode and the smallest supported window.
  const cases=[
    ['top',false,100,1250,850,'en',210],['bottom',false,100,1250,850,'de',120],
    ['top',true,100,1250,850,'ru',210],['bottom',true,75,720,540,'fr',210],
    ['top',false,175,720,540,'de',600],['bottom',false,175,720,540,'es',120],
    ['top',true,175,720,540,'ru',210],['bottom',true,175,720,540,'en',210],
    ['top',false,75,720,540,'fr',120],['bottom',false,100,720,540,'ru',210],
    ['left',false,175,720,540,'en',210],['right',false,175,720,540,'en',210],
  ];
  for(const [edge,collapsed,scale,width,height,language,panelHeight] of cases){
    owner.window.setSize(width,height);
    await action(owner,'settings_apply',{sidebar_position:edge,sidebar_collapsed:collapsed,ui_scale:scale,language,sidebar_height:panelHeight});
    await until(()=>ui(`S.config.sidebar_position===${JSON.stringify(edge)}&&S.config.ui_scale===${scale}&&S.config.language===${JSON.stringify(language)}`),'panel settings');
    await delay(160);
    const result=await ui(`(()=>{
      const rect=selector=>document.querySelector(selector).getBoundingClientRect();
      const panel=rect('#sidebar'),viewport=rect('#viewport');
      const within=(a,b)=>a.left>=b.left-1&&a.top>=b.top-1&&a.right<=b.right+1&&a.bottom<=b.bottom+1;
      const controls=['#collapse','#new-tab','#bookmarks-button','#downloads-button','#settings-button'];
      const failures=controls.filter(selector=>!within(rect(selector),panel));
      const menu=rect('#collapse'),plus=rect('#new-tab');
      return {failures,adjacent:Math.abs(menu.top-plus.top)<1&&plus.left>=menu.right-1&&plus.left-menu.right<8,
        activeRect:rect('.tab.active').toJSON(),tabsRect:rect('#tabs').toJSON(),activeInside:within(rect('.tab.active'),rect('#tabs')),tabsInside:within(rect('#tabs'),panel),viewportInside:within(viewport,{left:0,top:0,right:innerWidth,bottom:innerHeight}),
        viewportHeight:viewport.height,viewportWidth:viewport.width,headerHeight:rect('.sidebar-top').height,
        stripHeight:panel.height,titlebarTop:rect('#titlebar').top,panelTop:panel.top,
        windowControlsSeparate:rect('.sidebar-bottom').right<=rect('.window-buttons').left+1,
        singleRow:[...document.querySelectorAll('.tab')].every(node=>Math.abs(node.getBoundingClientRect().top-rect('.tab').top)<1),
        hiddenLabels:[...document.querySelectorAll('.tab .title')].every(node=>getComputedStyle(node).display==='none'),
        toolbarInside:within(rect('#navigation'),{left:0,top:0,right:innerWidth,bottom:innerHeight}),
        addressInside:within(rect('#address'),rect('#navigation'))};
    })()`);
    if(!result.activeInside)console.log('Layout geometry: '+JSON.stringify(result));
    const label=[edge,collapsed?'collapsed':'expanded',scale+'%',width+'×'+height,language].join(' ');
    assert.deepEqual(result.failures,[],label+' controls overflow');assert.ok(result.adjacent,label+' menu and plus separated');
    assert.ok(result.tabsInside,label+' tab scroller overflow');assert.ok(result.activeInside,label+' active tab is hidden after moving/resizing the panel');assert.ok(result.viewportInside,label+' viewport overflow');
    assert.ok(result.viewportHeight>60&&result.viewportWidth>80,label+' page has no usable area');
    assert.ok(result.toolbarInside&&result.addressInside,label+' address toolbar overflow');
    if(['top','bottom'].includes(edge)){assert.ok(result.headerHeight<=32,label+' header buttons stretch');assert.ok(result.stripHeight<=42,label+' strip is taller than one tab row');assert.ok(result.singleRow,label+' tabs wrap to more than one row');}
    if(edge==='top'){assert.ok(Math.abs(result.titlebarTop-result.panelTop)<1,label+' extra titlebar row above tabs');assert.ok(result.windowControlsSeparate,label+' panel actions overlap window controls');}
    if(collapsed)assert.ok(result.hiddenLabels,label+' collapsed tabs show text');
    const native=owner.area,bounds=owner.window.getContentBounds();
    assert.ok(native.x>=0&&native.y>=0&&native.x+native.width<=bounds.width&&native.y+native.height<=bounds.height,label+' native bounds overflow');
    console.log('PASS: '+label);
  }
  await action(owner,'settings_apply',{sidebar_position:'top',sidebar_collapsed:false,ui_scale:100,language:'en',sidebar_height:140});
  owner.window.setSize(1250,850);await delay(150);
  fs.writeFileSync('/tmp/supersearch-electron-top-panel.png',(await owner.ui.capturePage()).toPNG());
  await action(owner,'settings_apply',{theme:'dark'});await until(()=>ui("document.querySelector('.home-logo').complete&&document.body.classList.contains('dark-logo')"),'original logo visible in dark mode');
  assert.equal(await ui("new URL(document.querySelector('.home-logo').src).pathname"),'/logo.svg');
  await action(owner,'settings_apply',{titlebar_show_expand:true});owner.window.setFullScreen(true);
  await until(()=>owner.window.isFullScreen(),'true fullscreen');await delay(250);
  assert.equal(await ui("(()=>{const actions=document.querySelector('.sidebar-bottom').getBoundingClientRect(),bar=document.getElementById('titlebar').getBoundingClientRect();return actions.right<=bar.left+1})()"),true);owner.window.setFullScreen(false);
  assert.equal(config().theme,'dark');
  console.log('ELECTRON LAYOUT CHECKS OK: original supplied logo, compact single-row strips, shared top window-control row, both horizontal edges, bounded controls, adjacent menu/plus, 75–175% scale, long labels, collapsed icons and clipped native bounds');
}
module.exports={run};
```

### engine/smoke_modes.js
```javascript
'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const http=require('node:http');
const {once}=require('node:events');
const {until,delay}=require('./smoke');

async function run({owner,action,backend,config}){
  const ui=code=>owner.ui.executeJavaScript(code);
  await until(()=>owner.tabs.length&&owner.area,'initial mode UI');
  if(process.env.SUPERSEARCH_TEST_MODE==='javascript-off'){
    const server=http.createServer((_request,response)=>{response.writeHead(200,{'content-type':'text/html'});response.end('<h1 id="plain">Plain HTML still works</h1><script>document.getElementById("plain").textContent="WRONG"</script>');});
    server.listen(0,'127.0.0.1');await once(server,'listening');
    try{
      await action(owner,'navigate',{text:'http://127.0.0.1:'+server.address().port});const pane=owner.tabs[0].panes[0];await until(()=>pane.view&&!pane.loading,'no-JavaScript page');
      const contents=pane.view.webContents;assert.equal(contents.getLastWebPreferences().javascript,false);assert.ok(!pane.securityError);
      contents.debugger.attach('1.3');const document=await contents.debugger.sendCommand('DOM.getDocument',{depth:-1});const html=await contents.debugger.sendCommand('DOM.getOuterHTML',{nodeId:document.root.nodeId});contents.debugger.detach();
      assert.ok(html.outerHTML.includes('<h1 id="plain">Plain HTML still works</h1>'));
      await action(owner,'settings',{});await until(()=>ui("!!document.getElementById('settings-content')"),'settings with site JS disabled');
      console.log('ELECTRON NO-JS CHECKS OK: site scripts disabled, HTML renders, trusted UI stays functional');
    }finally{server.close();}
    return;
  }
  await until(()=>ui("!!document.getElementById('wizard-continue')"),'welcome wizard');
  for(const language of ['de','fr','es','ru','en']){
    await ui(`(()=>{const select=document.getElementById('wizard-language');select.value=${JSON.stringify(language)};select.dispatchEvent(new Event('change',{bubbles:true}));return true})()`);
    await until(()=>config().language===language,'language applied');await until(()=>ui('document.documentElement.lang==='+JSON.stringify(language)),'live UI language');
  }
  assert.equal(await ui("document.getElementById('wizard-continue').disabled"),true);
  await delay(200);fs.writeFileSync('/tmp/supersearch-welcome.png',(await owner.ui.capturePage()).toPNG());
  await ui("document.querySelector('[data-returning=no]').click();document.getElementById('wizard-continue').click();true");await until(()=>ui("!!document.getElementById('agreement')"),'agreement step');
  assert.equal(await ui("document.getElementById('wizard-continue').disabled"),true);await ui("document.getElementById('wizard-continue').click();true");assert.equal(await ui('wizardStep'),1);
  await ui("document.getElementById('agreement').click();document.getElementById('wizard-continue').click();true");await until(()=>ui("!!document.getElementById('wizard-tour')"),'optional tour choice');
  assert.equal(await ui("document.getElementById('wizard-tour').checked"),true);
  await ui("document.getElementById('wizard-continue').click();true");await until(()=>ui("!!document.getElementById('settings-content')"),'setup preferences');
  await ui("document.querySelector('[data-category=Appearance]').click();const select=document.querySelector('[data-setting=theme]');select.value='dark';select.dispatchEvent(new Event('change',{bubbles:true}));true");
  await until(()=>config().theme==='dark','live dark theme');assert.equal(await ui("document.documentElement.style.getPropertyValue('--bg')"),'#16181f');
  await ui("document.getElementById('wizard-continue').click();true");await until(()=>ui("!!document.getElementById('wizard-import')"),'profile import step');
  await ui("document.getElementById('wizard-continue').click();true");await until(()=>config().onboarding_complete,'setup complete');
  await until(()=>ui("!!document.getElementById('tour-layer')"),'automatic optional tour');
  await delay(200);fs.writeFileSync('/tmp/supersearch-tour.png',(await owner.ui.capturePage()).toPNG());
  for(let index=0;index<6;index++)await ui("document.querySelector('[data-tour-next]').click();true");
  await ui("document.querySelector('[data-tour-next]').click();true");await until(()=>config().tour_completed&&!config().tour_pending,'tour complete');
  await action(owner,'new_tab',{url:'about:blank'});const preserved=owner.active,count=owner.tabs.length;
  await action(owner,'settings',{});await until(()=>ui("!!document.getElementById('settings-content')"),'settings to replay tour');
  await ui("settingsCategory='About';renderSettingsContent();document.querySelector('[data-tour]').click();true");await until(()=>ui("!!document.getElementById('tour-layer')"),'manual tour');
  assert.equal(owner.tabs.length,count+1);assert.ok(owner.tabs.some(tab=>tab.id===preserved&&tab.panes[0].url==='about:blank'));
  await ui("document.querySelector('[data-tour-skip]').click();true");await until(()=>ui("!document.getElementById('tour-layer')"),'skip tour');
  assert.equal(config().suggestions,false);assert.equal(config().terms_version,'2026-11-02');assert.equal((await backend.call('state')).config.onboarding_complete,true);
  console.log('ELECTRON SETUP CHECKS OK: five languages, agreement gates Continue, immediate theme preview, new-user choice, optional seven-step tour, replay/skip, optional import and suggestions off by default');
}
module.exports={run};
```

### engine/translations/de.json
```json
{
  "Make it yours": "Ganz nach Ihren Wünschen",
  "Bring your browser data": "Browserdaten übernehmen",
  "Import what you need, or skip this step.": "Importieren Sie die gewünschten Daten oder überspringen Sie diesen Schritt.",
  "I accept the User Agreement": "Ich akzeptiere die Nutzungsbedingungen",
  "Changes preview immediately. Network settings may require a restart.": "Änderungen werden sofort angezeigt. Netzwerkeinstellungen können einen Neustart erfordern.",
  "Start browsing": "Surfen starten",
  "Continue": "Weiter",
  "Browser profile": "Browserprofil",
  "Choose a detected browser": "Erkannten Browser auswählen",
  "Choose profile folder": "Profilordner auswählen",
  "Choose password CSV": "Passwort-CSV auswählen",
  "Choose a browser profile or a password CSV.": "Wählen Sie ein Browserprofil oder eine Passwort-CSV.",
  "Import complete": "Import abgeschlossen",
  "Protected cookies and passwords cannot be read automatically. Password CSV files can be imported into the master-password vault.": "Geschützte Cookies und Passwörter können nicht automatisch gelesen werden. Passwort-CSV-Dateien lassen sich in den Tresor mit Masterpasswort importieren.",
  "Today": "Heute",
  "Domains": "Domains",
  "Direct connection — IP address is visible": "Direkte Verbindung — die IP-Adresse ist sichtbar",
  "Session profile": "Sitzungsprofil",
  "Persistent profile": "Dauerhaftes Profil",
  "Move up": "Nach oben",
  "Move down": "Nach unten",
  "Use the edit and remove buttons on each shortcut to change it.": "Verwenden Sie die Schaltflächen zum Bearbeiten und Entfernen an jeder Verknüpfung.",
  "No downloads yet.": "Noch keine Downloads.",
  "Nothing saved here yet.": "Hier ist noch nichts gespeichert.",
  "Show in folder": "Im Ordner anzeigen",
  "Open a website before adding a bookmark.": "Öffnen Sie zuerst eine Website.",
  "Delete selected data": "Ausgewählte Daten löschen",
  "The following data will be deleted:": "Folgende Daten werden gelöscht:",
  "Reset browser": "Browser zurücksetzen",
  "Remove data from this browser profile and start setup again.": "Daten dieses Profils entfernen und die Einrichtung erneut starten.",
  "Type Delete to confirm": "Zur Bestätigung Delete eingeben",
  "This deletes bookmarks, saved passwords, history, shortcuts, scripts, settings and website data in this engine profile. The browser will restart as a first launch.": "Löscht Lesezeichen, Passwörter, Verlauf, Verknüpfungen, Skripte, Einstellungen und Websitedaten dieses Profils. Der Browser startet mit der Ersteinrichtung neu.",
  "User data stays on your device.": "Ihre Daten bleiben auf Ihrem Gerät.",
  "Website permissions are denied by default.": "Websiteberechtigungen werden standardmäßig verweigert.",
  "Connecting…": "Verbindung wird hergestellt…",
  "blocking rules": "Blockierregeln",
  "unsupported rules skipped": "nicht unterstützte Regeln übersprungen",
  "Local extensions": "Lokale Erweiterungen",
  "Built-in": "Integriert",
  "Tracker blocking": "Trackerblockierung",
  "Encrypted password vault": "Verschlüsselter Passworttresor",
  "Private windows": "Private Fenster",
  "Compatible local extensions require a persistent profile. Chrome Web Store does not install directly into SuperSearch.": "Kompatible lokale Erweiterungen benötigen ein dauerhaftes Profil. Der Chrome Web Store installiert nicht direkt in SuperSearch.",
  "Switch to a persistent profile and restart before loading extensions.": "Wechseln Sie zu einem dauerhaften Profil und starten Sie den Browser neu.",
  "Extensions may read visited pages and send data over the network. Install only extensions you trust.": "Erweiterungen können besuchte Seiten lesen und Daten übertragen. Installieren Sie nur vertrauenswürdige Erweiterungen.",
  "The password manager is unavailable in private windows.": "Der Passwortmanager ist in privaten Fenstern nicht verfügbar.",
  "Passwords are encrypted locally. Filling checks the complete website origin.": "Passwörter werden lokal verschlüsselt. Beim Ausfüllen wird der vollständige Website-Ursprung geprüft.",
  "No saved passwords yet.": "Noch keine gespeicherten Passwörter.",
  "The vault is locked.": "Der Tresor ist gesperrt.",
  "Create a master password": "Masterpasswort festlegen",
  "Master password": "Masterpasswort",
  "Repeat master password": "Masterpasswort wiederholen",
  "New master password": "Neues Masterpasswort",
  "Enter your master password to unlock locally saved passwords.": "Geben Sie Ihr Masterpasswort ein, um gespeicherte Passwörter zu entsperren.",
  "Choose at least 12 characters. Your master password protects the local password vault.": "Verwenden Sie mindestens 12 Zeichen. Das Masterpasswort schützt den lokalen Passworttresor.",
  "Passwords do not match.": "Die Passwörter stimmen nicht überein.",
  "Saved password": "Gespeichertes Passwort",
  "Keep my tabs for the next launch": "Tabs beim nächsten Start wieder öffnen",
  "Private tabs are never saved.": "Private Tabs werden nie gespeichert.",
  "Are you sure you want to close this window?": "Möchten Sie dieses Fenster wirklich schließen?",
  "Close SuperSearch?": "SuperSearch schließen?",
  "Find on page": "Auf Seite suchen",
  "Address and search": "Adresse und Suche",
  "Tab panel position": "Position der Tableiste",
  "Address bar position": "Position der Adressleiste",
  "Split view size": "Aufteilung der geteilten Ansicht",
  "Left": "Links",
  "Right": "Rechts",
  "Top": "Oben",
  "Bottom": "Unten",
  "Drag a panel handle to a window edge. Press Escape to finish.": "Ziehen Sie den Panelgriff an einen Fensterrand. Escape beendet die Anpassung.",
  "Move panel": "Panel verschieben",
  "Search": "Suchen",
  "Search the web or enter an address": "Im Web suchen oder Adresse eingeben",
  "Setup": "Einrichtung",
  "Have you used SuperSearch before?": "Haben Sie SuperSearch schon benutzt?",
  "Yes, I am returning": "Ja, ich kehre zurück",
  "No, this is my first time": "Nein, dies ist mein erstes Mal",
  "Restore my data from a SuperSearch backup.": "Meine Daten aus einer SuperSearch-Sicherung wiederherstellen.",
  "Set up my browser and choose an optional tour.": "Meinen Browser einrichten und eine optionale Tour wählen.",
  "Choose an option to continue.": "Wählen Sie eine Option, um fortzufahren.",
  "Welcome back": "Willkommen zurück",
  "Choose the encrypted file you exported from Settings → Storage. Your data will be restored after a restart.": "Wählen Sie die unter Einstellungen → Speicher exportierte verschlüsselte Datei. Die Daten werden nach dem Neustart wiederhergestellt.",
  "You will need your backup password and, for saved passwords, your original vault master password.": "Sie benötigen das Sicherungspasswort und für gespeicherte Passwörter das ursprüngliche Masterpasswort des Tresors.",
  "Choose SuperSearch backup": "SuperSearch-Sicherung auswählen",
  "No backup file? You can continue with a fresh setup.": "Keine Sicherungsdatei? Sie können mit einer neuen Einrichtung fortfahren.",
  "Continue without a backup": "Ohne Sicherung fortfahren",
  "Let us show you around": "Lernen Sie den Browser kennen",
  "Discover where to search, manage tabs, control privacy and customize your workspace.": "Erfahren Sie, wo Sie suchen, Tabs verwalten, Datenschutz steuern und Ihren Arbeitsbereich anpassen.",
  "Show a short tour after setup": "Nach der Einrichtung eine kurze Tour zeigen",
  "You can skip it at any time or open it later in Settings → About.": "Sie können jederzeit überspringen oder die Tour später unter Einstellungen → Über öffnen.",
  "Backup and transfer": "Sichern und übertragen",
  "Keep an encrypted copy of your SuperSearch data or move it to another device.": "Sichern Sie Ihre SuperSearch-Daten verschlüsselt oder übertragen Sie sie auf ein anderes Gerät.",
  "Includes bookmarks, the encrypted password vault, history, saved settings, tabs, statistics, shortcuts and wallpaper. Website sessions, cache, extensions and downloaded files are not transferred.": "Enthält Lesezeichen, verschlüsselten Passworttresor, Verlauf, gespeicherte Einstellungen, Tabs, Statistik, Verknüpfungen und Hintergrund. Websitzungen, Cache, Erweiterungen und heruntergeladene Dateien werden nicht übertragen.",
  "Export browser data": "Browserdaten exportieren",
  "Restore browser data": "Browserdaten wiederherstellen",
  "The export is encrypted with a backup password. Keep this password somewhere safe; it cannot be recovered.": "Der Export wird mit einem Sicherungspasswort verschlüsselt. Bewahren Sie es sicher auf; es kann nicht wiederhergestellt werden.",
  "Only saved settings are exported. Your password vault keeps its existing master password.": "Nur gespeicherte Einstellungen werden exportiert. Der Tresor behält sein bisheriges Masterpasswort.",
  "Backup password": "Sicherungspasswort",
  "Repeat backup password": "Sicherungspasswort wiederholen",
  "Choose where to save": "Speicherort auswählen",
  "Encrypted backup saved.": "Verschlüsselte Sicherung gespeichert.",
  "Restoring replaces your current browser data and restarts SuperSearch. Existing website sessions will be cleared. Export your current data first if you want to keep it.": "Die Wiederherstellung ersetzt Ihre Browserdaten und startet SuperSearch neu. Websitzungen werden gelöscht. Exportieren Sie vorher Ihre aktuellen Daten, wenn Sie sie behalten möchten.",
  "Saved passwords still need the original vault master password. Extensions must be installed again.": "Gespeicherte Passwörter benötigen weiterhin das ursprüngliche Masterpasswort. Erweiterungen müssen neu installiert werden.",
  "Restore trusted UserScripts and styles too": "Vertrauenswürdige UserScripts und Stile ebenfalls wiederherstellen",
  "I understand that my current browser data will be replaced.": "Ich verstehe, dass meine aktuellen Browserdaten ersetzt werden.",
  "Restore and restart": "Wiederherstellen und neu starten",
  "Browser tour": "Browser-Tour",
  "A short guided tour of tabs, search, privacy and your browser settings.": "Eine kurze Tour zu Tabs, Suche, Datenschutz und Browsereinstellungen.",
  "Show me around": "Tour starten",
  "Skip tour": "Tour überspringen",
  "Finish tour": "Tour beenden",
  "Next": "Weiter",
  "Search and navigate": "Suchen und navigieren",
  "Type a website address or a search here. Search suggestions stay optional.": "Geben Sie eine Webadresse oder Suchanfrage ein. Suchvorschläge bleiben optional.",
  "Your tabs": "Ihre Tabs",
  "Open tabs with the plus button. Pin tabs, select several with Ctrl or Shift, and close selected tabs with Delete.": "Öffnen Sie Tabs mit Plus. Heften Sie Tabs an, wählen Sie mehrere mit Strg oder Umschalt und schließen Sie die Auswahl mit Entf.",
  "Privacy at hand": "Datenschutz griffbereit",
  "Open privacy settings here to choose your protection and connection preferences.": "Wählen Sie hier Ihre Schutz- und Verbindungseinstellungen.",
  "Keep useful pages": "Nützliche Seiten behalten",
  "Save the current page with the star or Ctrl+D. Organize bookmarks into folders.": "Speichern Sie die Seite mit dem Stern oder Strg+D. Ordnen Sie Lesezeichen in Ordnern.",
  "Your downloads": "Ihre Downloads",
  "Downloaded files arrive in your Downloads folder. Follow their progress here.": "Dateien werden im Downloadordner gespeichert. Verfolgen Sie hier den Fortschritt.",
  "Make SuperSearch yours": "SuperSearch nach Ihrem Geschmack",
  "Change appearance and panels, manage passwords, or export your data in Storage.": "Passen Sie Aussehen und Panels an, verwalten Sie Passwörter oder exportieren Sie Daten unter Speicher.",
  "Your start page": "Ihre Startseite",
  "Choose wallpaper and edit shortcuts. Your original logo and privacy statistics stay close at hand.": "Wählen Sie ein Hintergrundbild und bearbeiten Sie Verknüpfungen. Logo und Datenschutzstatistik bleiben im Blick."
}
```

### engine/translations/es.json
```json
{
  "Make it yours": "Hazlo tuyo",
  "Bring your browser data": "Trae tus datos del navegador",
  "Import what you need, or skip this step.": "Importa lo que necesites o salta este paso.",
  "I accept the User Agreement": "Acepto el acuerdo de usuario",
  "Changes preview immediately. Network settings may require a restart.": "Los cambios se ven de inmediato. Los ajustes de red pueden requerir reiniciar.",
  "Start browsing": "Empezar a navegar",
  "Continue": "Continuar",
  "Browser profile": "Perfil del navegador",
  "Choose a detected browser": "Elige un navegador detectado",
  "Choose profile folder": "Elegir carpeta del perfil",
  "Choose password CSV": "Elegir CSV de contraseñas",
  "Choose a browser profile or a password CSV.": "Elige un perfil o un CSV de contraseñas.",
  "Import complete": "Importación completada",
  "Protected cookies and passwords cannot be read automatically. Password CSV files can be imported into the master-password vault.": "No se pueden leer automáticamente cookies y contraseñas protegidas. Los CSV se pueden importar al almacén con contraseña maestra.",
  "Today": "Hoy",
  "Domains": "Dominios",
  "Direct connection — IP address is visible": "Conexión directa — la IP es visible",
  "Session profile": "Perfil de sesión",
  "Persistent profile": "Perfil persistente",
  "Move up": "Subir",
  "Move down": "Bajar",
  "Use the edit and remove buttons on each shortcut to change it.": "Usa los botones de editar y eliminar de cada acceso directo.",
  "No downloads yet.": "Aún no hay descargas.",
  "Nothing saved here yet.": "Todavía no hay nada guardado.",
  "Show in folder": "Mostrar en la carpeta",
  "Open a website before adding a bookmark.": "Abre un sitio antes de añadir un marcador.",
  "Delete selected data": "Eliminar datos seleccionados",
  "The following data will be deleted:": "Se eliminarán los siguientes datos:",
  "Reset browser": "Restablecer navegador",
  "Remove data from this browser profile and start setup again.": "Elimina los datos de este perfil y vuelve a configurarlo.",
  "Type Delete to confirm": "Escribe Delete para confirmar",
  "This deletes bookmarks, saved passwords, history, shortcuts, scripts, settings and website data in this engine profile. The browser will restart as a first launch.": "Elimina marcadores, contraseñas, historial, accesos directos, scripts, ajustes y datos de sitios de este perfil. El navegador se reinicia como la primera vez.",
  "User data stays on your device.": "Tus datos permanecen en tu dispositivo.",
  "Website permissions are denied by default.": "Los permisos de sitios se deniegan de forma predeterminada.",
  "Connecting…": "Conectando…",
  "blocking rules": "reglas de bloqueo",
  "unsupported rules skipped": "reglas no compatibles omitidas",
  "Local extensions": "Extensiones locales",
  "Built-in": "Integrado",
  "Tracker blocking": "Bloqueo de rastreadores",
  "Encrypted password vault": "Almacén de contraseñas cifrado",
  "Private windows": "Ventanas privadas",
  "Compatible local extensions require a persistent profile. Chrome Web Store does not install directly into SuperSearch.": "Las extensiones locales compatibles requieren un perfil persistente. Chrome Web Store no instala directamente en SuperSearch.",
  "Switch to a persistent profile and restart before loading extensions.": "Cambia a un perfil persistente y reinicia antes de cargar extensiones.",
  "Extensions may read visited pages and send data over the network. Install only extensions you trust.": "Las extensiones pueden leer páginas visitadas y enviar datos. Instala solo extensiones de confianza.",
  "The password manager is unavailable in private windows.": "El gestor de contraseñas no está disponible en ventanas privadas.",
  "Passwords are encrypted locally. Filling checks the complete website origin.": "Las contraseñas se cifran localmente. El autocompletado comprueba el origen exacto del sitio.",
  "No saved passwords yet.": "Aún no hay contraseñas guardadas.",
  "The vault is locked.": "El almacén está bloqueado.",
  "Create a master password": "Crear contraseña maestra",
  "Master password": "Contraseña maestra",
  "Repeat master password": "Repetir contraseña maestra",
  "New master password": "Nueva contraseña maestra",
  "Enter your master password to unlock locally saved passwords.": "Introduce tu contraseña maestra para abrir el almacén local.",
  "Choose at least 12 characters. Your master password protects the local password vault.": "Usa al menos 12 caracteres. La contraseña maestra protege el almacén local.",
  "Passwords do not match.": "Las contraseñas no coinciden.",
  "Saved password": "Contraseña guardada",
  "Keep my tabs for the next launch": "Conservar pestañas para el próximo inicio",
  "Private tabs are never saved.": "Las pestañas privadas nunca se guardan.",
  "Are you sure you want to close this window?": "¿Seguro que quieres cerrar esta ventana?",
  "Close SuperSearch?": "¿Cerrar SuperSearch?",
  "Find on page": "Buscar en la página",
  "Address and search": "Dirección y búsqueda",
  "Tab panel position": "Posición del panel de pestañas",
  "Address bar position": "Posición de la barra de direcciones",
  "Split view size": "Proporciones de la vista dividida",
  "Left": "Izquierda",
  "Right": "Derecha",
  "Top": "Arriba",
  "Bottom": "Abajo",
  "Drag a panel handle to a window edge. Press Escape to finish.": "Arrastra el asa del panel a un borde de la ventana. Escape termina la personalización.",
  "Move panel": "Mover panel",
  "Search": "Buscar",
  "Search the web or enter an address": "Busca en la web o escribe una dirección",
  "Setup": "Configuración",
  "Have you used SuperSearch before?": "¿Has usado SuperSearch antes?",
  "Yes, I am returning": "Sí, ya lo he usado",
  "No, this is my first time": "No, es mi primera vez",
  "Restore my data from a SuperSearch backup.": "Restaurar mis datos de una copia de SuperSearch.",
  "Set up my browser and choose an optional tour.": "Configurar el navegador y elegir una visita opcional.",
  "Choose an option to continue.": "Elige una opción para continuar.",
  "Welcome back": "Te damos la bienvenida de nuevo",
  "Choose the encrypted file you exported from Settings → Storage. Your data will be restored after a restart.": "Elige el archivo cifrado exportado en Ajustes → Almacenamiento. Los datos se restaurarán al reiniciar.",
  "You will need your backup password and, for saved passwords, your original vault master password.": "Necesitarás la contraseña de la copia y, para los accesos guardados, la contraseña maestra original de la bóveda.",
  "Choose SuperSearch backup": "Elegir copia de SuperSearch",
  "No backup file? You can continue with a fresh setup.": "¿No tienes una copia? Puedes continuar con una configuración nueva.",
  "Continue without a backup": "Continuar sin copia",
  "Let us show you around": "Conoce el navegador",
  "Discover where to search, manage tabs, control privacy and customize your workspace.": "Descubre la búsqueda, las pestañas, la privacidad y cómo personalizar tu espacio.",
  "Show a short tour after setup": "Mostrar una visita breve tras la configuración",
  "You can skip it at any time or open it later in Settings → About.": "Puedes omitirla o abrirla después en Ajustes → Acerca de.",
  "Backup and transfer": "Copia y transferencia",
  "Keep an encrypted copy of your SuperSearch data or move it to another device.": "Guarda una copia cifrada de tus datos o transfiérelos a otro dispositivo.",
  "Includes bookmarks, the encrypted password vault, history, saved settings, tabs, statistics, shortcuts and wallpaper. Website sessions, cache, extensions and downloaded files are not transferred.": "Incluye marcadores, bóveda cifrada, historial, ajustes guardados, pestañas, estadísticas, accesos y fondo. No transfiere sesiones web, caché, extensiones ni archivos descargados.",
  "Export browser data": "Exportar datos del navegador",
  "Restore browser data": "Restaurar datos del navegador",
  "The export is encrypted with a backup password. Keep this password somewhere safe; it cannot be recovered.": "La exportación se cifra con una contraseña. Guárdala en un lugar seguro; no se puede recuperar.",
  "Only saved settings are exported. Your password vault keeps its existing master password.": "Solo se exportan ajustes guardados. La bóveda conserva su contraseña maestra.",
  "Backup password": "Contraseña de la copia",
  "Repeat backup password": "Repetir contraseña de la copia",
  "Choose where to save": "Elegir dónde guardar",
  "Encrypted backup saved.": "Copia cifrada guardada.",
  "Restoring replaces your current browser data and restarts SuperSearch. Existing website sessions will be cleared. Export your current data first if you want to keep it.": "La restauración reemplaza los datos actuales y reinicia SuperSearch. Se borrarán las sesiones web. Exporta antes tus datos actuales si deseas conservarlos.",
  "Saved passwords still need the original vault master password. Extensions must be installed again.": "Los accesos guardados aún necesitan la contraseña maestra original. Debes reinstalar las extensiones.",
  "Restore trusted UserScripts and styles too": "Restaurar también UserScripts y estilos de confianza",
  "I understand that my current browser data will be replaced.": "Entiendo que se reemplazarán mis datos actuales.",
  "Restore and restart": "Restaurar y reiniciar",
  "Browser tour": "Visita del navegador",
  "A short guided tour of tabs, search, privacy and your browser settings.": "Una visita breve por pestañas, búsqueda, privacidad y ajustes.",
  "Show me around": "Mostrar visita",
  "Skip tour": "Omitir visita",
  "Finish tour": "Finalizar visita",
  "Next": "Siguiente",
  "Search and navigate": "Buscar y navegar",
  "Type a website address or a search here. Search suggestions stay optional.": "Escribe una dirección o búsqueda. Las sugerencias siguen siendo opcionales.",
  "Your tabs": "Tus pestañas",
  "Open tabs with the plus button. Pin tabs, select several with Ctrl or Shift, and close selected tabs with Delete.": "Abre pestañas con más. Fíjalas, selecciona varias con Ctrl o Mayús y ciérralas con Supr.",
  "Privacy at hand": "Privacidad a mano",
  "Open privacy settings here to choose your protection and connection preferences.": "Elige aquí tus ajustes de protección y conexión.",
  "Keep useful pages": "Guarda páginas útiles",
  "Save the current page with the star or Ctrl+D. Organize bookmarks into folders.": "Guarda la página con la estrella o Ctrl+D. Organiza los marcadores en carpetas.",
  "Your downloads": "Tus descargas",
  "Downloaded files arrive in your Downloads folder. Follow their progress here.": "Los archivos se guardan en Descargas. Sigue su progreso aquí.",
  "Make SuperSearch yours": "Personaliza SuperSearch",
  "Change appearance and panels, manage passwords, or export your data in Storage.": "Cambia el aspecto y los paneles, gestiona contraseñas o exporta datos en Almacenamiento.",
  "Your start page": "Tu página de inicio",
  "Choose wallpaper and edit shortcuts. Your original logo and privacy statistics stay close at hand.": "Elige un fondo y edita accesos. El logotipo y las estadísticas de privacidad están a mano."
}
```

### engine/translations/fr.json
```json
{
  "Make it yours": "Personnalisez votre navigateur",
  "Bring your browser data": "Transférez vos données",
  "Import what you need, or skip this step.": "Importez ce dont vous avez besoin ou ignorez cette étape.",
  "I accept the User Agreement": "J’accepte les conditions d’utilisation",
  "Changes preview immediately. Network settings may require a restart.": "Les modifications sont visibles immédiatement. Les paramètres réseau peuvent nécessiter un redémarrage.",
  "Start browsing": "Commencer à naviguer",
  "Continue": "Continuer",
  "Browser profile": "Profil du navigateur",
  "Choose a detected browser": "Choisir un navigateur détecté",
  "Choose profile folder": "Choisir le dossier du profil",
  "Choose password CSV": "Choisir un fichier CSV de mots de passe",
  "Choose a browser profile or a password CSV.": "Choisissez un profil ou un fichier CSV de mots de passe.",
  "Import complete": "Import terminé",
  "Protected cookies and passwords cannot be read automatically. Password CSV files can be imported into the master-password vault.": "Les cookies et mots de passe protégés ne peuvent pas être lus automatiquement. Les CSV peuvent être importés dans le coffre protégé par un mot de passe principal.",
  "Today": "Aujourd’hui",
  "Domains": "Domaines",
  "Direct connection — IP address is visible": "Connexion directe — l’adresse IP est visible",
  "Session profile": "Profil de session",
  "Persistent profile": "Profil persistant",
  "Move up": "Monter",
  "Move down": "Descendre",
  "Use the edit and remove buttons on each shortcut to change it.": "Utilisez les boutons de modification et de suppression de chaque raccourci.",
  "No downloads yet.": "Aucun téléchargement.",
  "Nothing saved here yet.": "Rien n’est encore enregistré ici.",
  "Show in folder": "Afficher dans le dossier",
  "Open a website before adding a bookmark.": "Ouvrez un site avant d’ajouter un favori.",
  "Delete selected data": "Supprimer les données sélectionnées",
  "The following data will be deleted:": "Les données suivantes seront supprimées :",
  "Reset browser": "Réinitialiser le navigateur",
  "Remove data from this browser profile and start setup again.": "Supprimez les données de ce profil et recommencez la configuration.",
  "Type Delete to confirm": "Saisissez Delete pour confirmer",
  "This deletes bookmarks, saved passwords, history, shortcuts, scripts, settings and website data in this engine profile. The browser will restart as a first launch.": "Supprime favoris, mots de passe, historique, raccourcis, scripts, paramètres et données des sites de ce profil. Le navigateur redémarre comme au premier lancement.",
  "User data stays on your device.": "Vos données restent sur votre appareil.",
  "Website permissions are denied by default.": "Les autorisations des sites sont refusées par défaut.",
  "Connecting…": "Connexion…",
  "blocking rules": "règles de blocage",
  "unsupported rules skipped": "règles non prises en charge ignorées",
  "Local extensions": "Extensions locales",
  "Built-in": "Intégré",
  "Tracker blocking": "Blocage des traqueurs",
  "Encrypted password vault": "Coffre de mots de passe chiffré",
  "Private windows": "Fenêtres privées",
  "Compatible local extensions require a persistent profile. Chrome Web Store does not install directly into SuperSearch.": "Les extensions locales compatibles nécessitent un profil persistant. Le Chrome Web Store n’installe pas directement dans SuperSearch.",
  "Switch to a persistent profile and restart before loading extensions.": "Passez à un profil persistant et redémarrez avant de charger des extensions.",
  "Extensions may read visited pages and send data over the network. Install only extensions you trust.": "Les extensions peuvent lire les pages visitées et transmettre des données. Installez uniquement des extensions de confiance.",
  "The password manager is unavailable in private windows.": "Le gestionnaire de mots de passe est indisponible en navigation privée.",
  "Passwords are encrypted locally. Filling checks the complete website origin.": "Les mots de passe sont chiffrés localement. Le remplissage vérifie l’origine exacte du site.",
  "No saved passwords yet.": "Aucun mot de passe enregistré.",
  "The vault is locked.": "Le coffre est verrouillé.",
  "Create a master password": "Créer un mot de passe principal",
  "Master password": "Mot de passe principal",
  "Repeat master password": "Répéter le mot de passe principal",
  "New master password": "Nouveau mot de passe principal",
  "Enter your master password to unlock locally saved passwords.": "Saisissez votre mot de passe principal pour ouvrir le coffre local.",
  "Choose at least 12 characters. Your master password protects the local password vault.": "Utilisez au moins 12 caractères. Le mot de passe principal protège votre coffre local.",
  "Passwords do not match.": "Les mots de passe ne correspondent pas.",
  "Saved password": "Mot de passe enregistré",
  "Keep my tabs for the next launch": "Conserver mes onglets pour le prochain lancement",
  "Private tabs are never saved.": "Les onglets privés ne sont jamais enregistrés.",
  "Are you sure you want to close this window?": "Voulez-vous vraiment fermer cette fenêtre ?",
  "Close SuperSearch?": "Fermer SuperSearch ?",
  "Find on page": "Rechercher dans la page",
  "Address and search": "Adresse et recherche",
  "Tab panel position": "Position du panneau d’onglets",
  "Address bar position": "Position de la barre d’adresse",
  "Split view size": "Proportions de la vue divisée",
  "Left": "À gauche",
  "Right": "À droite",
  "Top": "En haut",
  "Bottom": "En bas",
  "Drag a panel handle to a window edge. Press Escape to finish.": "Faites glisser la poignée vers un bord de la fenêtre. Échap termine la personnalisation.",
  "Move panel": "Déplacer le panneau",
  "Search": "Rechercher",
  "Search the web or enter an address": "Rechercher sur le Web ou saisir une adresse",
  "Setup": "Configuration",
  "Have you used SuperSearch before?": "Avez-vous déjà utilisé SuperSearch ?",
  "Yes, I am returning": "Oui, je reviens",
  "No, this is my first time": "Non, c’est ma première fois",
  "Restore my data from a SuperSearch backup.": "Restaurer mes données depuis une sauvegarde SuperSearch.",
  "Set up my browser and choose an optional tour.": "Configurer le navigateur et choisir une visite facultative.",
  "Choose an option to continue.": "Choisissez une option pour continuer.",
  "Welcome back": "Heureux de vous revoir",
  "Choose the encrypted file you exported from Settings → Storage. Your data will be restored after a restart.": "Choisissez le fichier chiffré exporté dans Paramètres → Stockage. Les données seront restaurées après le redémarrage.",
  "You will need your backup password and, for saved passwords, your original vault master password.": "Il vous faudra le mot de passe de sauvegarde et, pour les identifiants, le mot de passe maître du coffre d’origine.",
  "Choose SuperSearch backup": "Choisir une sauvegarde SuperSearch",
  "No backup file? You can continue with a fresh setup.": "Pas de sauvegarde ? Vous pouvez continuer avec une nouvelle configuration.",
  "Continue without a backup": "Continuer sans sauvegarde",
  "Let us show you around": "Découvrez le navigateur",
  "Discover where to search, manage tabs, control privacy and customize your workspace.": "Découvrez la recherche, les onglets, les réglages de confidentialité et la personnalisation.",
  "Show a short tour after setup": "Afficher une courte visite après la configuration",
  "You can skip it at any time or open it later in Settings → About.": "Vous pouvez passer la visite ou la rouvrir dans Paramètres → À propos.",
  "Backup and transfer": "Sauvegarde et transfert",
  "Keep an encrypted copy of your SuperSearch data or move it to another device.": "Conservez une copie chiffrée de vos données SuperSearch ou transférez-les vers un autre appareil.",
  "Includes bookmarks, the encrypted password vault, history, saved settings, tabs, statistics, shortcuts and wallpaper. Website sessions, cache, extensions and downloaded files are not transferred.": "Inclut favoris, coffre chiffré, historique, réglages enregistrés, onglets, statistiques, raccourcis et fond. Sessions web, cache, extensions et fichiers téléchargés ne sont pas transférés.",
  "Export browser data": "Exporter les données du navigateur",
  "Restore browser data": "Restaurer les données du navigateur",
  "The export is encrypted with a backup password. Keep this password somewhere safe; it cannot be recovered.": "L’export est chiffré avec un mot de passe de sauvegarde. Gardez-le en lieu sûr ; il est irrécupérable.",
  "Only saved settings are exported. Your password vault keeps its existing master password.": "Seuls les réglages enregistrés sont exportés. Le coffre conserve son mot de passe maître.",
  "Backup password": "Mot de passe de sauvegarde",
  "Repeat backup password": "Répéter le mot de passe",
  "Choose where to save": "Choisir où enregistrer",
  "Encrypted backup saved.": "Sauvegarde chiffrée enregistrée.",
  "Restoring replaces your current browser data and restarts SuperSearch. Existing website sessions will be cleared. Export your current data first if you want to keep it.": "La restauration remplace les données actuelles et redémarre SuperSearch. Les sessions web seront effacées. Exportez d’abord les données actuelles pour les conserver.",
  "Saved passwords still need the original vault master password. Extensions must be installed again.": "Les identifiants exigent toujours le mot de passe maître d’origine. Les extensions doivent être réinstallées.",
  "Restore trusted UserScripts and styles too": "Restaurer aussi les UserScripts et styles de confiance",
  "I understand that my current browser data will be replaced.": "Je comprends que les données actuelles seront remplacées.",
  "Restore and restart": "Restaurer et redémarrer",
  "Browser tour": "Visite du navigateur",
  "A short guided tour of tabs, search, privacy and your browser settings.": "Une courte visite des onglets, de la recherche, de la confidentialité et des réglages.",
  "Show me around": "Me faire visiter",
  "Skip tour": "Passer la visite",
  "Finish tour": "Terminer la visite",
  "Next": "Suivant",
  "Search and navigate": "Rechercher et naviguer",
  "Type a website address or a search here. Search suggestions stay optional.": "Saisissez une adresse ou une recherche. Les suggestions restent facultatives.",
  "Your tabs": "Vos onglets",
  "Open tabs with the plus button. Pin tabs, select several with Ctrl or Shift, and close selected tabs with Delete.": "Ouvrez avec le bouton plus. Épinglez les onglets, sélectionnez-en plusieurs avec Ctrl ou Maj et fermez la sélection avec Suppr.",
  "Privacy at hand": "La confidentialité à portée de main",
  "Open privacy settings here to choose your protection and connection preferences.": "Choisissez ici vos réglages de protection et de connexion.",
  "Keep useful pages": "Gardez les pages utiles",
  "Save the current page with the star or Ctrl+D. Organize bookmarks into folders.": "Enregistrez la page avec l’étoile ou Ctrl+D. Classez les favoris dans des dossiers.",
  "Your downloads": "Vos téléchargements",
  "Downloaded files arrive in your Downloads folder. Follow their progress here.": "Les fichiers sont enregistrés dans Téléchargements. Suivez ici leur progression.",
  "Make SuperSearch yours": "Personnalisez SuperSearch",
  "Change appearance and panels, manage passwords, or export your data in Storage.": "Modifiez l’apparence et les panneaux, gérez les mots de passe ou exportez vos données dans Stockage.",
  "Your start page": "Votre page d’accueil",
  "Choose wallpaper and edit shortcuts. Your original logo and privacy statistics stay close at hand.": "Choisissez un fond et modifiez les raccourcis. Logo et statistiques de confidentialité restent à portée de main."
}
```

### engine/translations/ru.json
```json
{
  "Make it yours": "Настройте под себя",
  "Bring your browser data": "Перенесите данные браузера",
  "Import what you need, or skip this step.": "Перенесите нужное или пропустите этот шаг.",
  "I accept the User Agreement": "Я принимаю пользовательское соглашение",
  "Changes preview immediately. Network settings may require a restart.": "Изменения видны сразу. Для сетевых настроек может потребоваться перезапуск.",
  "Start browsing": "Начать просмотр",
  "Continue": "Продолжить",
  "Browser profile": "Профиль браузера",
  "Choose a detected browser": "Выберите найденный браузер",
  "Choose profile folder": "Выбрать папку профиля",
  "Choose password CSV": "Выбрать CSV с паролями",
  "Choose a browser profile or a password CSV.": "Выберите профиль браузера или CSV с паролями.",
  "Import complete": "Перенос завершён",
  "Protected cookies and passwords cannot be read automatically. Password CSV files can be imported into the master-password vault.": "Защищённые cookies и пароли нельзя прочитать автоматически. Пароли из CSV можно перенести в хранилище с мастер-паролем.",
  "Today": "Сегодня",
  "Domains": "Домены",
  "Direct connection — IP address is visible": "Прямое подключение — IP-адрес виден сайтам",
  "Session profile": "Профиль на время сеанса",
  "Persistent profile": "Постоянный профиль",
  "Move up": "Переместить выше",
  "Move down": "Переместить ниже",
  "Use the edit and remove buttons on each shortcut to change it.": "Для изменения ярлыка используйте его кнопки редактирования и удаления.",
  "No downloads yet.": "Пока нет загрузок.",
  "Nothing saved here yet.": "Здесь пока ничего нет.",
  "Show in folder": "Показать в папке",
  "Open a website before adding a bookmark.": "Откройте сайт, чтобы добавить закладку.",
  "Delete selected data": "Удалить выбранные данные",
  "The following data will be deleted:": "Будут удалены следующие данные:",
  "Reset browser": "Сбросить браузер",
  "Remove data from this browser profile and start setup again.": "Удалить данные этого профиля и заново пройти настройку.",
  "Type Delete to confirm": "Для подтверждения введите Delete",
  "This deletes bookmarks, saved passwords, history, shortcuts, scripts, settings and website data in this engine profile. The browser will restart as a first launch.": "Будут удалены закладки, сохранённые пароли, история, ярлыки, скрипты, настройки и данные сайтов этого профиля. Браузер перезапустится как при первом запуске.",
  "User data stays on your device.": "Пользовательские данные хранятся на вашем устройстве.",
  "Website permissions are denied by default.": "Разрешения для сайтов по умолчанию запрещены.",
  "Connecting…": "Подключение…",
  "blocking rules": "правил блокировки",
  "unsupported rules skipped": "неподдерживаемых правил пропущено",
  "Local extensions": "Локальные расширения",
  "Built-in": "Встроено",
  "Tracker blocking": "Блокировка трекеров",
  "Encrypted password vault": "Зашифрованное хранилище паролей",
  "Private windows": "Приватные окна",
  "Compatible local extensions require a persistent profile. Chrome Web Store does not install directly into SuperSearch.": "Для совместимых локальных расширений нужен постоянный профиль. Установка напрямую из Chrome Web Store недоступна.",
  "Switch to a persistent profile and restart before loading extensions.": "Выберите постоянный профиль и перезапустите браузер перед загрузкой расширений.",
  "Extensions may read visited pages and send data over the network. Install only extensions you trust.": "Расширения могут читать посещаемые страницы и отправлять данные в сеть. Устанавливайте только те, которым доверяете.",
  "The password manager is unavailable in private windows.": "Менеджер паролей недоступен в приватных окнах.",
  "Passwords are encrypted locally. Filling checks the complete website origin.": "Пароли зашифрованы локально. Автозаполнение проверяет точный адрес источника сайта.",
  "No saved passwords yet.": "Пока нет сохранённых паролей.",
  "The vault is locked.": "Хранилище заблокировано.",
  "Create a master password": "Задайте мастер-пароль",
  "Master password": "Мастер-пароль",
  "Repeat master password": "Повторите мастер-пароль",
  "New master password": "Новый мастер-пароль",
  "Enter your master password to unlock locally saved passwords.": "Введите мастер-пароль, чтобы открыть локальное хранилище.",
  "Choose at least 12 characters. Your master password protects the local password vault.": "Используйте не менее 12 символов. Мастер-пароль защищает локальное хранилище паролей.",
  "Passwords do not match.": "Пароли не совпадают.",
  "Saved password": "Сохранённый пароль",
  "Keep my tabs for the next launch": "Сохранить вкладки для следующего запуска",
  "Private tabs are never saved.": "Приватные вкладки не сохраняются.",
  "Are you sure you want to close this window?": "Вы уверены, что хотите закрыть это окно?",
  "Close SuperSearch?": "Закрыть SuperSearch?",
  "Find on page": "Найти на странице",
  "Address and search": "Адрес и поиск",
  "Tab panel position": "Расположение панели вкладок",
  "Address bar position": "Расположение адресной строки",
  "Split view size": "Пропорции разделения окна",
  "Left": "Слева",
  "Right": "Справа",
  "Top": "Сверху",
  "Bottom": "Снизу",
  "Drag a panel handle to a window edge. Press Escape to finish.": "Перетащите ручку панели к краю окна. Escape завершает настройку.",
  "Move panel": "Переместить панель",
  "Search": "Поиск",
  "Search the web or enter an address": "Введите запрос или адрес сайта",
  "Setup": "Настройка",
  "Have you used SuperSearch before?": "Вы ранее пользовались SuperSearch?",
  "Yes, I am returning": "Да, я уже пользовался",
  "No, this is my first time": "Нет, это мой первый запуск",
  "Restore my data from a SuperSearch backup.": "Восстановить данные из экспорта SuperSearch.",
  "Set up my browser and choose an optional tour.": "Настроить браузер и выбрать ознакомительный тур.",
  "Choose an option to continue.": "Выберите вариант, чтобы продолжить.",
  "Welcome back": "С возвращением",
  "Choose the encrypted file you exported from Settings → Storage. Your data will be restored after a restart.": "Выберите зашифрованный файл, экспортированный в «Настройки → Хранилище». Данные восстановятся после перезапуска.",
  "You will need your backup password and, for saved passwords, your original vault master password.": "Понадобится пароль экспорта, а для сохранённых паролей — исходный мастер-пароль сейфа.",
  "Choose SuperSearch backup": "Выбрать экспорт SuperSearch",
  "No backup file? You can continue with a fresh setup.": "Нет файла экспорта? Можно продолжить настройку с нуля.",
  "Continue without a backup": "Продолжить без восстановления",
  "Let us show you around": "Познакомимся с браузером",
  "Discover where to search, manage tabs, control privacy and customize your workspace.": "Узнайте, где искать, управлять вкладками, настраивать приватность и оформление.",
  "Show a short tour after setup": "Показать короткий тур после настройки",
  "You can skip it at any time or open it later in Settings → About.": "Тур можно пропустить в любой момент или открыть позже в «Настройки → О браузере».",
  "Backup and transfer": "Резервная копия и перенос",
  "Keep an encrypted copy of your SuperSearch data or move it to another device.": "Сохраните зашифрованную копию данных SuperSearch или перенесите их на другое устройство.",
  "Includes bookmarks, the encrypted password vault, history, saved settings, tabs, statistics, shortcuts and wallpaper. Website sessions, cache, extensions and downloaded files are not transferred.": "Включает закладки, зашифрованный сейф паролей, историю, сохранённые настройки, вкладки, статистику, ярлыки и обои. Сеансы сайтов, кэш, расширения и скачанные файлы не переносятся.",
  "Export browser data": "Экспорт данных браузера",
  "Restore browser data": "Восстановить данные браузера",
  "The export is encrypted with a backup password. Keep this password somewhere safe; it cannot be recovered.": "Экспорт зашифрован паролем резервной копии. Сохраните пароль в надёжном месте: восстановить его нельзя.",
  "Only saved settings are exported. Your password vault keeps its existing master password.": "Экспортируются только сохранённые настройки. Сейф паролей сохраняет свой мастер-пароль.",
  "Backup password": "Пароль экспорта",
  "Repeat backup password": "Повторите пароль экспорта",
  "Choose where to save": "Выбрать место сохранения",
  "Encrypted backup saved.": "Зашифрованная копия сохранена.",
  "Restoring replaces your current browser data and restarts SuperSearch. Existing website sessions will be cleared. Export your current data first if you want to keep it.": "Восстановление заменит текущие данные и перезапустит SuperSearch. Сеансы сайтов будут очищены. Чтобы сохранить текущие данные, сначала экспортируйте их.",
  "Saved passwords still need the original vault master password. Extensions must be installed again.": "Для сохранённых паролей по-прежнему нужен исходный мастер-пароль сейфа. Расширения нужно установить заново.",
  "Restore trusted UserScripts and styles too": "Также восстановить доверенные UserScripts и стили",
  "I understand that my current browser data will be replaced.": "Я понимаю, что текущие данные браузера будут заменены.",
  "Restore and restart": "Восстановить и перезапустить",
  "Browser tour": "Знакомство с браузером",
  "A short guided tour of tabs, search, privacy and your browser settings.": "Короткий тур по вкладкам, поиску, приватности и настройкам браузера.",
  "Show me around": "Показать тур",
  "Skip tour": "Пропустить тур",
  "Finish tour": "Завершить тур",
  "Next": "Далее",
  "Search and navigate": "Поиск и переходы",
  "Type a website address or a search here. Search suggestions stay optional.": "Введите адрес сайта или поисковый запрос. Подсказки поиска включаются по желанию.",
  "Your tabs": "Ваши вкладки",
  "Open tabs with the plus button. Pin tabs, select several with Ctrl or Shift, and close selected tabs with Delete.": "Открывайте вкладки кнопкой «плюс». Закрепляйте их, выделяйте несколько с Ctrl или Shift и закрывайте выделенные клавишей Delete.",
  "Privacy at hand": "Приватность под рукой",
  "Open privacy settings here to choose your protection and connection preferences.": "Здесь можно выбрать настройки защиты и подключения.",
  "Keep useful pages": "Сохраняйте полезные страницы",
  "Save the current page with the star or Ctrl+D. Organize bookmarks into folders.": "Сохраните страницу звёздочкой или Ctrl+D. Распределяйте закладки по папкам.",
  "Your downloads": "Ваши загрузки",
  "Downloaded files arrive in your Downloads folder. Follow their progress here.": "Файлы сохраняются в папку загрузок. Здесь можно следить за скачиванием.",
  "Make SuperSearch yours": "Настройте SuperSearch под себя",
  "Change appearance and panels, manage passwords, or export your data in Storage.": "Меняйте оформление и панели, управляйте паролями и экспортируйте данные в «Хранилище».",
  "Your start page": "Ваша главная страница",
  "Choose wallpaper and edit shortcuts. Your original logo and privacy statistics stay close at hand.": "Выбирайте обои и редактируйте ярлыки. Логотип и статистика приватности всегда рядом."
}
```

### engine/ui.css
```css
:root{color-scheme:light;--bg:#f5f6fa;--panel:#fff;--fg:#182033;--accent:#2459b8;--soft:color-mix(in srgb,var(--accent) 17%,transparent);--radius:18px;--space:8px;--sidebar:240px;--titlebar:38px;--toolbar:38px;--tab:48px;--icon:24px;--home-width:960px;--tile:120px;--columns:6;font:13px system-ui,sans-serif}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);overflow:hidden}button,input,select,textarea{font:inherit;color:inherit}button{display:inline-flex;align-items:center;justify-content:center;gap:8px;background:var(--panel);border:1px solid var(--soft);border-radius:var(--radius);padding:9px 14px;min-height:36px;cursor:pointer;transition:background .15s,border-color .15s,transform .15s}button:hover{background:color-mix(in srgb,var(--accent) 8%,var(--panel));border-color:var(--accent)}button:active{transform:scale(.97)}button:disabled{opacity:.4;cursor:default;transform:none}button.primary{background:var(--accent);color:var(--on-accent,#fff);border-color:var(--accent)}button.danger{color:#be3548;border-color:#c6475960}button.ghost{background:transparent;border-color:transparent}button svg{width:20px;height:20px;flex:none}input,select,textarea{min-width:0;background:var(--panel);border:1px solid var(--soft);border-radius:var(--radius);padding:10px 14px;outline:none}input:focus,select:focus,textarea:focus{border-color:var(--accent);box-shadow:0 0 0 3px color-mix(in srgb,var(--accent) 13%,transparent)}input[type=checkbox]{appearance:none;width:20px;height:20px;border-radius:6px;padding:0;display:inline-grid;place-content:center;vertical-align:middle;cursor:pointer;flex:none}input[type=checkbox]:checked{background:var(--accent);border-color:var(--accent)}input[type=checkbox]:checked:after{content:'';width:9px;height:5px;border-left:2px solid var(--on-accent,#fff);border-bottom:2px solid var(--on-accent,#fff);transform:rotate(-45deg) translateY(-1px)}input.switch{width:42px;height:25px;border-radius:20px;display:block;position:relative;background:var(--bg)}input.switch:after{content:'';position:absolute;top:4px;left:4px;width:15px;height:15px;border:0;border-radius:50%;background:var(--fg);transform:none;transition:left .15s}input.switch:checked:after{left:21px;width:15px;height:15px;background:var(--on-accent,#fff);border:0;transform:none}select{appearance:none;padding-right:32px;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='14' height='14' fill='none' stroke='%23888' stroke-width='1.6'%3E%3Cpath d='m3 5 4 4 4-4'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 12px center}select option{background:var(--panel);color:var(--fg)}a{color:var(--accent)}:focus-visible{outline:2px solid var(--accent);outline-offset:3px}small,.muted{opacity:.72}h1,h2,h3,h4,p{margin-top:0}h1{font-size:30px}h2{font-size:23px}h3{font-size:17px}p{line-height:1.55}svg{vertical-align:middle}[hidden]{display:none!important}::-webkit-scrollbar{width:8px;height:8px}::-webkit-scrollbar-thumb{background:color-mix(in srgb,var(--accent) 40%,transparent);border-radius:10px}::-webkit-scrollbar-track{background:transparent}
#titlebar{height:var(--titlebar);display:flex;align-items:center;padding:0 6px 0 14px;gap:16px;user-select:none;-webkit-app-region:drag}#window-title{flex:1;font-size:12px}#system-status{display:flex;gap:14px;align-items:center;font-variant-numeric:tabular-nums}.window-buttons{display:flex;gap:5px}.window-buttons button{min-height:0;padding:0;width:30px;height:30px;border-radius:50%;border:0;-webkit-app-region:no-drag}.window-buttons button svg{width:17px;height:17px}#close:hover{background:#da4057;color:white}#workspace{height:calc(100vh - var(--titlebar));display:flex;padding:0 5px 5px 0;gap:8px}#sidebar{width:var(--sidebar);flex:none;background:var(--panel);border-radius:0 25px 25px 0;display:flex;flex-direction:column;padding:7px 4px;position:relative;min-width:52px}.sidebar-top{display:flex;gap:4px;margin-bottom:8px}.sidebar-top button{min-height:30px;padding:0;width:30px;border-radius:15px}#tabs{flex:1;overflow:auto;outline:0}.tab{width:100%;padding:8px 9px;min-height:var(--tab);justify-content:flex-start;margin:2px 0;border-color:transparent;overflow:hidden}.tab.selected{background:var(--soft);border-color:var(--accent)}.tab.active{background:var(--accent);color:var(--on-accent,#fff)}.tab img,.tab>.favicon{width:var(--icon);height:var(--icon);object-fit:contain;flex:none}.tab .title{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:left}.tab .pin{width:13px;height:13px;flex:none}.tab .close-tab{opacity:0;width:20px;height:20px;display:grid;place-items:center;flex:none;border-radius:50%}.tab:hover .close-tab{opacity:.8}.tab .close-tab:hover{background:#8884}.tab .close-tab svg{width:14px;height:14px}.sidebar-bottom{display:flex;flex-direction:column;gap:6px;margin-top:10px}.sidebar-bottom button{min-width:0;padding:9px 6px}.sidebar-bottom-row{display:flex;gap:5px}.sidebar-bottom-row button{flex:1;overflow:hidden}.badge{font-size:10px;padding:2px 5px;border-radius:10px;background:var(--accent);color:var(--on-accent,#fff)}#sidebar-resizer{position:absolute;right:-4px;top:40px;bottom:120px;width:8px;cursor:ew-resize}body:is(.collapsed,.auto-collapsed) #sidebar{width:52px}body:is(.collapsed,.auto-collapsed) .sidebar-top{gap:0}body:is(.collapsed,.auto-collapsed) .sidebar-top button{width:22px}body:is(.collapsed,.auto-collapsed) .tab{justify-content:center;padding:8px 4px}body:is(.collapsed,.auto-collapsed) .tab .title,body:is(.collapsed,.auto-collapsed) .tab .close-tab,body:is(.collapsed,.auto-collapsed) .tab .pin,body:is(.collapsed,.auto-collapsed) .sidebar-bottom .label{display:none}body:is(.collapsed,.auto-collapsed) .sidebar-bottom-row{flex-direction:column}body.sidebar-right #workspace{flex-direction:row-reverse;padding:0 0 5px 5px}body.sidebar-right #sidebar{border-radius:25px 0 0 25px}body.sidebar-right #sidebar-resizer{left:-4px;right:auto}#browser{flex:1;min-width:0;display:flex;flex-direction:column}#navigation{display:flex;align-items:center;gap:6px;padding:3px 0 6px;position:relative;z-index:20}#navigation>button{min-height:var(--toolbar);border-radius:999px;padding:6px 12px}#address-form{flex:1;min-width:80px;position:relative}#address{width:100%;border-radius:999px;min-height:var(--toolbar);padding:8px 20px;background:var(--panel)}#navigation .active{color:var(--accent);border-color:var(--accent)}#bookmark-bar{display:flex;gap:6px;min-height:0;padding-bottom:6px;overflow:hidden}#bookmark-bar button{font-size:12px;min-height:30px;padding:5px 10px;max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#viewport{flex:1;min-height:0;position:relative;border-radius:20px;overflow:hidden}body.nav-bottom #navigation{order:4;padding:7px 0 0}body.nav-bottom #bookmark-bar{order:3;padding:5px 0 0}#panes{display:flex;height:100%;gap:8px;position:relative}.pane{min-width:0;flex:1;height:100%;overflow:auto;position:relative;background:var(--bg)}.pane.focused{box-shadow:inset 0 0 0 1px var(--soft);border-radius:20px}.divider{position:absolute;left:calc(var(--split,50%) - 4px);width:8px;height:100%;z-index:3;cursor:ew-resize;background:var(--bg)}
.home{min-height:100%;max-width:var(--home-width);margin:auto;padding:22px 30px 24px;display:flex;flex-direction:column}.home-tools{display:flex;align-self:flex-end;gap:8px;flex-wrap:wrap;justify-content:flex-end}.home-tools button{font-size:12px;border-radius:999px}.home-center{flex:1;display:flex;flex-direction:column;align-items:center;padding:26px 0 32px;min-height:440px;justify-content:var(--home-align,center)}.home-logo{width:160px;height:160px;object-fit:contain;margin-bottom:12px}.home-search{display:flex;gap:10px;width:min(100%,650px);background:var(--panel);border:1px solid var(--soft);border-radius:999px;padding:8px;box-shadow:0 14px 45px #0002;position:relative;margin:8px 0 32px}.home-search input{border:0;box-shadow:none!important;background:transparent;flex:1;padding:9px 18px;font-size:16px}.home-search button{border-radius:999px}.tiles{display:grid;grid-template-columns:repeat(var(--columns),minmax(0,1fr));gap:13px;width:100%}.shortcut{position:relative}.shortcut .tile{width:100%;min-height:var(--tile);padding:21px 7px;flex-direction:column;gap:12px;border-radius:24px;font-size:12px;overflow:hidden;text-overflow:ellipsis}.tile-icon{width:54px;height:54px;border-radius:18px;background:var(--bg);display:grid;place-items:center}.tile-icon img,.tile-icon svg{width:32px;height:32px}.shortcut-tools{position:absolute;right:5px;top:4px;display:flex;opacity:0}.shortcut:hover .shortcut-tools,.shortcut:focus-within .shortcut-tools{opacity:1}.shortcut-tools button{padding:3px;min-height:0;border-radius:8px}.shortcut-tools button svg{width:14px;height:14px}.tile.add{border-style:dashed}.privacy-card{border:1px solid var(--soft);border-radius:28px;background:var(--panel);padding:24px 28px;box-shadow:0 16px 35px #0001;margin-top:18px}.privacy-totals{display:flex;align-items:center;gap:22px}.privacy-totals>.shield{width:36px;height:36px;color:var(--accent);flex:none}.privacy-lead{flex:1;min-width:100px}.privacy-lead small{display:block;margin-top:6px;font-size:11px}.stat{text-align:center;flex:none}.stat strong{font-size:32px;letter-spacing:-1px;color:var(--accent);display:block}.stat small{font-size:10px}.ip-row{display:flex;align-items:center;gap:15px;padding-top:18px;margin-top:20px;border-top:1px solid var(--soft)}.ip-symbol{width:44px;height:44px;border-radius:16px;display:grid;place-items:center;background:var(--bg);color:var(--accent)}.ip-details{flex:1;min-width:0}.ip-details small{font-size:11px;display:block}.ip-details code{font:600 clamp(15px,2vw,22px) ui-monospace,monospace;display:block;margin:5px 0;overflow-wrap:anywhere}.ip-row button{width:40px;height:40px;padding:0;border-radius:50%}.home.with-wallpaper{background:linear-gradient(#0007,#0009),var(--wallpaper);background-size:cover;background-position:center;max-width:none;color:var(--fg)}
.suggestions{position:absolute;z-index:300;top:calc(100% + 8px);left:0;right:0;border:1px solid var(--soft);border-radius:22px;padding:7px;background:var(--panel);color:var(--fg);max-height:330px;overflow:auto;box-shadow:0 16px 38px #0003}.suggestions button{display:flex;justify-content:flex-start;border:0;background:transparent;border-radius:14px;width:100%;padding:12px 14px;text-align:left;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.suggestions button:hover,.suggestions button.selected{background:var(--soft)}.suggestions button svg{color:var(--accent);width:19px;height:19px}.network-error{height:100%;display:grid;place-items:center;padding:32px}.error-card{width:min(100%,680px);padding:36px;border-radius:28px;background:var(--panel);border:1px solid var(--soft);box-shadow:0 14px 35px #0001}.error-card>.symbol{color:var(--accent);margin-bottom:20px}.symbol svg{width:48px;height:48px}.error-card code{display:block;overflow-wrap:anywhere;opacity:.7;margin-bottom:24px}.actions{display:flex;gap:8px;flex-wrap:wrap}.error-card details{margin-top:22px;font-size:12px;overflow-wrap:anywhere}
#screen{position:absolute;inset:0;background:var(--bg);padding:14px 18px;overflow:auto;z-index:5}.screen-title{display:flex;align-items:center;gap:14px;margin-bottom:15px}.screen-title h1{font-size:28px;margin:0}.screen-title .spacer{flex:1}.settings-search{width:100%;margin-bottom:16px;border-radius:999px}.settings-body{display:flex;gap:18px;align-items:flex-start}.settings-nav{width:175px;flex:none;position:sticky;top:0;display:flex;flex-direction:column;gap:6px}.settings-nav button{border:0;justify-content:flex-start;background:transparent;border-radius:15px;padding:11px 14px}.settings-nav button.active{background:var(--accent);color:var(--on-accent,#fff)}.settings-content{flex:1;min-width:0;padding-bottom:90px}.settings-content>h2{margin-bottom:8px}.settings-content>.summary{opacity:.7;margin-bottom:20px}.settings-card{background:var(--panel);border:1px solid var(--soft);border-radius:22px;padding:18px;margin-bottom:14px}.settings-card h3{font-weight:600;margin:0 0 8px}.settings-card>p{opacity:.7;font-size:12px}.settings-card summary{font-size:16px;font-weight:600;cursor:pointer;padding:2px}.setting-row{display:flex;align-items:center;gap:18px;padding:12px 0;border-bottom:1px solid color-mix(in srgb,var(--soft) 45%,transparent)}.setting-row:last-child{border-bottom:0}.setting-caption{flex:1;min-width:100px;cursor:default}.setting-caption small{display:block;font-size:12px;line-height:1.45;margin-top:5px}.setting-row input:not([type=checkbox]),.setting-row select{max-width:300px;width:40%}.setting-row .restart{font-size:10px;display:inline-block;padding:3px 7px;background:var(--soft);color:var(--accent);border-radius:8px;margin-top:6px}.settings-footer{position:sticky;bottom:0;background:var(--panel);border:1px solid var(--soft);border-radius:20px;padding:12px 15px;display:flex;gap:10px;align-items:center;z-index:8;margin-top:12px}.settings-footer .status{flex:1;font-size:12px}.color-controls{display:flex;gap:10px;flex-wrap:wrap}.color-controls label{display:flex;align-items:center;gap:7px;font-size:12px}.color-controls input{width:44px;height:36px;padding:3px;border-radius:10px}.empty{padding:45px;text-align:center;opacity:.7}.list-row{display:flex;align-items:center;gap:15px;padding:15px;background:var(--panel);border:1px solid var(--soft);border-radius:18px;margin:8px 0}.list-row .list-label{flex:1;min-width:0}.list-row .list-label strong,.list-row .list-label small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.list-row .list-label small{margin-top:4px;font-size:11px}.list-row progress{width:100%;height:7px;accent-color:var(--accent)}.list-row .actions{flex:none}.list-row .actions button{padding:7px 10px}.chart{display:flex;align-items:flex-end;gap:7px;height:160px;margin:25px 0 18px}.chart-day{display:flex;flex-direction:column;justify-content:flex-end;align-items:center;flex:1;height:100%;font-size:10px;gap:5px}.chart-bar{width:100%;min-height:2px;background:var(--accent);border-radius:8px 8px 3px 3px}.metric{font-size:42px;color:var(--accent);font-weight:700}.data-table{width:100%;border-collapse:collapse}.data-table td{padding:9px;border-bottom:1px solid var(--soft);overflow-wrap:anywhere}.data-table td:last-child{text-align:right}#password-offer{align-self:flex-end;width:min(540px,100%);border:1px solid var(--soft);border-radius:20px;padding:15px;background:var(--panel);box-shadow:0 10px 30px #0002;margin:5px 0 10px}#password-offer h3{margin-bottom:5px}#password-offer .actions{justify-content:flex-end;margin-top:12px}#find-bar{display:flex;gap:8px;padding:4px 0 9px;align-self:flex-end}#find-bar button{padding:5px 9px}
#modal-layer{position:fixed;inset:0;z-index:500;background:#0006;display:grid;place-items:center;padding:24px;backdrop-filter:blur(6px)}.dialog{background:var(--panel);color:var(--fg);border:1px solid var(--soft);border-radius:28px;padding:28px;width:min(620px,100%);max-height:90vh;overflow:auto;box-shadow:0 24px 100px #0005;animation:enter .18s ease}.dialog h2{margin-bottom:18px}.dialog label{display:flex;align-items:center;gap:10px;margin:12px 0}.dialog .field{display:block}.dialog .field input,.dialog .field select{display:block;width:100%;margin-top:7px}.dialog textarea{width:100%;min-height:240px}.dialog .actions{justify-content:flex-end;margin-top:24px}.error{color:#c84053;font-size:12px;margin:10px 0}.legal{white-space:pre-wrap;font:13px/1.6 system-ui;max-height:45vh;overflow:auto;padding:16px;background:var(--bg);border-radius:18px}.wizard{max-width:1050px;margin:0 auto;padding:20px 30px 32px}.wizard-header{display:flex;align-items:center;gap:18px;margin-bottom:35px}.wizard-header img{width:160px;height:55px;object-fit:contain}.wizard-header select{margin-left:auto}.steps{display:flex;gap:12px;align-items:center;margin-bottom:30px}.step{width:30px;height:30px;border-radius:50%;background:var(--soft);display:grid;place-items:center}.step.active{background:var(--accent);color:var(--on-accent,#fff)}.wizard-hero{font-size:40px;letter-spacing:-1px;max-width:700px;margin:24px 0}.wizard-lead{font-size:17px;opacity:.75;max-width:750px;margin-bottom:32px}.wizard-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:15px}.wizard-grid .settings-card svg{width:30px;height:30px;color:var(--accent);margin-bottom:20px}.wizard-footer{display:flex;gap:12px;align-items:center;justify-content:flex-end;margin-top:28px}.wizard-footer .spacer{flex:1}.wizard .settings-body{min-height:330px}.inline-options{display:flex;gap:14px;flex-wrap:wrap;margin:14px 0}.inline-options label{display:flex;align-items:center;gap:7px}.note{padding:12px 16px;border-radius:15px;background:var(--soft);font-size:12px;line-height:1.5}.shortcut-editor{max-height:300px;overflow:auto}.shortcut-editor .list-row{padding:10px}.shortcut-editor .list-row img{width:28px;height:28px}.toolbar-order{display:flex;gap:6px;flex-wrap:wrap}.toolbar-order button{font-size:11px}.toolbar-order button[draggable=true]{cursor:grab}.toolbar-order button.off{opacity:.45}#toasts{position:fixed;bottom:18px;left:50%;transform:translateX(-50%);z-index:1000;pointer-events:none}.toast{padding:13px 20px;background:var(--panel);border:1px solid var(--soft);border-radius:18px;box-shadow:0 10px 35px #0003;margin-top:8px;animation:enter .2s ease;max-width:650px;overflow-wrap:anywhere}#download-flight{position:fixed;width:30px;height:30px;z-index:900;pointer-events:none;color:var(--accent)}.download-pulse{animation:pulse .6s ease}.private-indicator{font-size:11px;color:var(--accent)}.about-logo{width:100px;height:100px;object-fit:contain}.about-title{display:flex;align-items:center;gap:22px}.engine-version{font-size:14px;line-height:1.7}.source-link{display:inline-block;overflow-wrap:anywhere;padding:12px 16px;background:var(--soft);border-radius:14px;margin:10px 0 20px}.copyright{font-size:12px;opacity:.7;margin-top:25px}
@keyframes enter{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}@keyframes pulse{50%{transform:scale(1.1);background:var(--soft)}}.no-animation *,.no-animation *:before,.no-animation *:after{animation:none!important;transition:none!important}.loading svg{animation:spin 1s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}@media(max-width:1000px){.tiles{grid-template-columns:repeat(3,minmax(0,1fr))}.privacy-totals{gap:12px;flex-wrap:wrap}.stat strong{font-size:26px}.settings-nav{width:140px}.setting-row{gap:10px}.wizard-grid{grid-template-columns:1fr}.wizard-hero{font-size:32px}}@media(max-width:780px){.settings-nav{width:46px}.settings-nav .label{display:none}.settings-nav button{padding:12px}.setting-row:not(.toggle){align-items:stretch;flex-direction:column;gap:8px}.setting-row input:not([type=checkbox]),.setting-row select{width:100%;max-width:none}.home{padding:18px}.home-tools button{padding:7px 10px}.home-search input{padding:7px 8px;font-size:14px}.privacy-card{padding:20px}.wizard{padding:15px}.wizard-header{gap:10px}.wizard-header img{width:120px}#navigation>button{padding:6px 8px}}

body.onboarding #sidebar,body.onboarding #navigation,body.onboarding #bookmark-bar{display:none!important}body.onboarding #viewport{border-radius:0}body.onboarding #workspace{padding:0}.tile.add{display:flex;flex-direction:column;gap:12px;min-height:var(--tile);padding:21px 7px;border-radius:24px;font-size:12px}.source-link:focus{outline:2px solid var(--accent)}


svg{width:20px;height:20px}.privacy-totals>.shield svg{width:36px;height:36px}#system-status svg{width:22px;height:22px}#download-flight svg{width:30px;height:30px}

/* One-row tab strips. The top strip shares its row with the window controls. */
:root{--strip-height:40px;--window-controls-width:82px}
#sidebar,#browser,#tabs{min-height:0}
#sidebar>*{min-width:0}
body:is(.sidebar-top-panel,.sidebar-bottom-panel) #workspace{flex-direction:column;padding:0 4px 4px;min-height:0}
body.sidebar-bottom-panel #workspace{flex-direction:column-reverse}
body.sidebar-top-panel:not(.onboarding) #workspace{height:100vh;padding-top:0}
body.sidebar-top-panel:not(.onboarding) #titlebar{position:absolute;top:0;right:4px;width:max-content;height:var(--strip-height);padding:0 5px;gap:8px;z-index:40;background:transparent!important}
body.sidebar-top-panel:not(.onboarding) #window-title{display:none}
body.sidebar-top-panel #system-status{gap:8px;font-size:11px}
body:is(.sidebar-top-panel,.sidebar-bottom-panel) #sidebar{
  display:grid;grid-template-columns:64px minmax(0,1fr) 100px;grid-template-rows:minmax(0,1fr);
  align-items:center;gap:6px;width:100%;min-width:0;height:var(--strip-height);max-height:var(--strip-height);
  padding:4px 6px;border-radius:12px 12px 0 0;overflow:hidden;-webkit-app-region:drag;
}
body.sidebar-top-panel #sidebar{padding-right:calc(var(--window-controls-width) + 12px)}
body.sidebar-bottom-panel #sidebar{border-radius:0 0 12px 12px}
body:is(.sidebar-top-panel,.sidebar-bottom-panel) .sidebar-top{align-items:center;height:auto;margin:0;gap:4px;-webkit-app-region:no-drag}
body:is(.sidebar-top-panel,.sidebar-bottom-panel) .sidebar-top button{flex:none;min-height:0;width:30px;height:30px;padding:0}
body:is(.sidebar-top-panel,.sidebar-bottom-panel) #tabs{display:flex;flex-wrap:nowrap;align-items:center;gap:4px;height:100%;min-width:0;overflow-x:auto;overflow-y:hidden;scrollbar-width:none;overscroll-behavior:contain;-webkit-app-region:drag}
body:is(.sidebar-top-panel,.sidebar-bottom-panel) #tabs::-webkit-scrollbar{display:none}
body:is(.sidebar-top-panel,.sidebar-bottom-panel) .tab{flex:0 0 200px;width:200px;max-width:100%;height:100%;min-height:0;margin:0;padding:4px 10px;border-radius:12px;-webkit-app-region:no-drag}
body:is(.sidebar-top-panel,.sidebar-bottom-panel) .tab img,body:is(.sidebar-top-panel,.sidebar-bottom-panel) .tab>.favicon{width:20px;height:20px}
body:is(.sidebar-top-panel,.sidebar-bottom-panel) .sidebar-bottom,
body:is(.sidebar-top-panel,.sidebar-bottom-panel) .sidebar-bottom-row{display:flex;flex-direction:row;align-items:center;gap:5px;margin:0;min-width:0;-webkit-app-region:no-drag}
body:is(.sidebar-top-panel,.sidebar-bottom-panel) .sidebar-bottom button{position:relative;flex:none;width:30px;height:30px;min-height:0;padding:4px;overflow:hidden;border-radius:50%}
body:is(.sidebar-top-panel,.sidebar-bottom-panel) .sidebar-bottom .label{display:none}
body:is(.sidebar-top-panel,.sidebar-bottom-panel) .badge{position:absolute;top:0;right:0;font-size:9px;padding:1px 3px}
body:is(.sidebar-top-panel,.sidebar-bottom-panel) #sidebar-resizer{display:none}
body:is(.sidebar-top-panel,.sidebar-bottom-panel):is(.collapsed,.compact-horizontal) #sidebar{grid-template-columns:44px minmax(0,1fr) 100px}
body:is(.sidebar-top-panel,.sidebar-bottom-panel):is(.collapsed,.compact-horizontal) .sidebar-top{gap:0}
body:is(.sidebar-top-panel,.sidebar-bottom-panel):is(.collapsed,.compact-horizontal) .sidebar-top button{width:22px}
body:is(.sidebar-top-panel,.sidebar-bottom-panel).collapsed .tab{flex:0 0 32px;width:32px;max-width:32px;padding:4px}
body:is(.sidebar-top-panel,.sidebar-bottom-panel) #sidebar:has([data-panel-grip]){grid-template-columns:100px minmax(0,1fr) 100px}
.home-logo{width:min(420px,90%);height:auto;max-height:80px;object-fit:contain}
body.dark-logo :is(.home-logo,.about-logo,.wizard-header img){filter:brightness(0) invert(1)}
body.compact-toolbar #navigation{gap:4px}
body.compact-toolbar #navigation>button{flex:none;width:30px;min-height:30px;padding:4px}
body.compact-toolbar #address-form{min-width:56px}
body.compact-toolbar #address{min-height:32px;padding:6px 10px}
body.compact-toolbar #passwords{display:none}
body[data-drop-edge=left] #workspace{box-shadow:inset 5px 0 var(--accent)}
body[data-drop-edge=right] #workspace{box-shadow:inset -5px 0 var(--accent)}
body[data-drop-edge=top] #workspace{box-shadow:inset 0 5px var(--accent)}
body[data-drop-edge=bottom] #workspace{box-shadow:inset 0 -5px var(--accent)}
[data-panel-grip]{cursor:grab;touch-action:none}
[data-panel-grip]:active{cursor:grabbing}

.welcome-choices{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin:20px 0}
.welcome-choice{padding:24px;text-align:left;align-items:flex-start;justify-content:flex-start;border:2px solid var(--soft);border-radius:24px}
.welcome-choice>svg{width:28px;height:28px;color:var(--accent)}
.welcome-choice span{flex:1;min-width:0}.welcome-choice strong,.welcome-choice small,.tour-choice small{display:block}
.welcome-choice small,.tour-choice small{line-height:1.5;opacity:.75;margin-top:8px}
.welcome-choice.chosen{background:var(--soft);border-color:var(--accent)}
.tour-choice{display:flex;align-items:flex-start;gap:16px;cursor:pointer}
#tour-layer{position:fixed;inset:0;z-index:600;isolation:isolate}
.tour-focus{position:fixed;border:3px solid var(--accent);border-radius:18px;box-shadow:0 0 0 200vmax #0009;pointer-events:none;z-index:0}
.tour-card{position:absolute;bottom:22px;left:50%;transform:translateX(-50%);width:min(580px,calc(100% - 24px));max-height:60vh;overflow:auto;padding:24px;background:var(--panel);color:var(--fg);border:1px solid var(--soft);border-radius:26px;box-shadow:0 18px 70px #0006;z-index:1;animation:tour-enter .2s ease}
.tour-card small{color:var(--accent);font-weight:600}.tour-card h2{margin:12px 0}.tour-card p{line-height:1.6}.tour-card .actions{margin-top:22px;flex-wrap:nowrap;gap:7px}.tour-card .spacer{flex:1}.tour-card button{padding:8px 12px}
@keyframes tour-enter{from{opacity:0;translate:0 10px}to{opacity:1;translate:0 0}}
@media(max-width:650px){.welcome-choices{grid-template-columns:1fr}.welcome-choice{padding:16px}.tour-card{padding:18px;bottom:10px}}
```

### engine/ui.js
```javascript
'use strict';
const api=window.supersearch;
const $=selector=>document.querySelector(selector);
const $$=selector=>[...document.querySelectorAll(selector)];
const esc=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
let B,S,previousActive=null,settingsDraft=null,settingsCategory='General',settingsQuery='',settingsStatus='',selected=new Set(),anchor=0,modalResolve=null,wallpaper='',paneSignature='',screenSignature='',offerSignature='',clockTimer=null;
let settingsEdited=new Set(),customizing=false;
let wizardRevision=0,tabLayoutSignature='';
function revealActiveTab(){requestAnimationFrame(()=>document.querySelector('.tab.active')?.scrollIntoView({block:'nearest',inline:'nearest'}));}
let returningUser=null,showTour=true,tourIndex=0,tourRunning=false;
let wizardStep=0,agreement=false,wizardLegal='',detectedProfiles=null,manualProfile='',passwordCSV='',suggestionGeneration=0,tabSignature='';
const RESTART=new Set(['webrtc','javascript','tor','doh','proxy','ephemeral_profile']);
const t=source=>B?.translations[S?.config.language||'en']?.[source]||source;
const icon=name=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${B?.icons[name]||B?.icons.globe||''}</svg>`;
const logoURL=()=> 'ss-app://assets/logo.svg';
const button=(name,label,attributes='')=>`<button ${attributes}>${icon(name)}<span class="label">${esc(t(label))}</span></button>`;
const invoke=async(operation,data={})=>{try{return await api.call(operation,data);}catch(error){toast(error.message||'The operation failed.');throw error;}};
function toast(message){const element=document.createElement('div');element.className='toast';element.textContent=t(message);$('#toasts').append(element);setTimeout(()=>element.remove(),5000);}
function titleFor(tab){const pane=tab.panes[tab.active]||tab.panes[0];return pane.title||pane.url||t('New tab');}
function currentTab(){return S?.tabs.find(tab=>tab.id===S.active)||S?.tabs[0];}
function currentPane(){const tab=currentTab();return tab?.panes[tab.active]||null;}
function colors(config){return {...B.palettes[config.theme],...config.colors};}
function luminance(hex){const value=parseInt(hex.slice(1),16),channels=[value>>16,(value>>8)&255,value&255].map(value=>{value/=255;return value<=.04045?value/12.92:((value+.055)/1.055)**2.4;});return channels[0]*.2126+channels[1]*.7152+channels[2]*.0722;}
function applyTheme(config){
  const palette=colors(config),style=document.documentElement.style;
  style.setProperty('--ui-scale',config.ui_scale/100);
  for(const [key,value] of Object.entries(palette))style.setProperty('--'+key,value);
  style.setProperty('--on-accent',luminance(palette.accent)>.179?'#000000':'#ffffff');
  for(const [name,value] of Object.entries({radius:config.shape==='square'?0:config.shape==='pill'?40:config.radius,space:config.spacing,sidebar:config.sidebar_width,'sidebar-height':config.sidebar_height,titlebar:config.titlebar_height,toolbar:config.toolbar_size,tab:config.tab_height,icon:config.icon_size,'home-width':config.home_width,tile:config.home_tile_size}))style.setProperty('--'+name,value+'px');
  style.setProperty('--columns',config.home_columns);style.setProperty('--split',config.split_ratio+'%');style.setProperty('--home-align',config.home_align==='top'?'flex-start':'center');
  document.body.style.fontFamily=config.font==='Sans Serif'?'system-ui,sans-serif':config.font;
  document.documentElement.style.colorScheme=config.theme==='light'?'light':'dark';
  document.body.classList.toggle('dark-logo',config.theme!=='light');
  document.body.classList.toggle('collapsed',config.sidebar_collapsed);document.body.classList.toggle('no-animation',!config.animations);
  document.body.classList.toggle('onboarding',!config.onboarding_complete);
  document.body.classList.toggle('sidebar-right',config.sidebar_position==='right');document.body.classList.toggle('sidebar-top-panel',config.sidebar_position==='top');document.body.classList.toggle('sidebar-bottom-panel',config.sidebar_position==='bottom');document.body.classList.toggle('nav-bottom',config.navigation_position==='bottom');
  document.documentElement.lang=config.language;
  updateResponsive();
  const layoutKey=JSON.stringify([config.sidebar_position,config.sidebar_collapsed,config.sidebar_width,config.sidebar_height,config.ui_scale,config.tab_height,config.icon_size]);
  if(layoutKey!==tabLayoutSignature){tabLayoutSignature=layoutKey;revealActiveTab();}
}
function updateResponsive(){
  if(!S)return;
  const width=window.innerWidth;
  document.body.classList.toggle('compact-horizontal',width<860);
  document.body.classList.toggle('compact-toolbar',width<700);
  document.body.classList.toggle('auto-collapsed',width<700&&['left','right'].includes(S.config.sidebar_position));
}
window.addEventListener('resize',()=>{updateResponsive();revealActiveTab();});
function updateBounds(){document.documentElement.style.setProperty('--window-controls-width',Math.ceil($('#titlebar').getBoundingClientRect().width)+'px');const rect=$('#viewport').getBoundingClientRect();api.call('bounds',{x:rect.x,y:rect.y,width:rect.width,height:rect.height}).catch(()=>{});}
new ResizeObserver(updateBounds).observe($('#viewport'));
new ResizeObserver(updateBounds).observe($('#titlebar'));
new ResizeObserver(revealActiveTab).observe($('#tabs'));

function render(state){
  if(!B)return;const wasUnlocked=S?.vault?.unlocked;S=state;if(wasUnlocked&&!S.vault.unlocked&&$('#modal-layer input[type=password]'))closeDialog(null);applyTheme(state.config);
  if(settingsDraft)for(const [key,value] of Object.entries(S.config))if(!settingsEdited.has(key))settingsDraft[key]=structuredClone(value);
  const changed=previousActive!==S.active;if(changed){selected=new Set([S.active]);closeSuggestions();previousActive=S.active;}
  const pane=currentPane();if(changed||!document.hasFocus()||document.activeElement!==$('#address'))$('#address').value=pane?.url||'';
  $('#window-title').textContent=S.config.titlebar_show_title?'SuperSearch'+(S.private?' · '+t('Private window'):''):'';
  $('#titlebar').style.background=S.config.titlebar_accent?'var(--panel)':'var(--bg)';
  $('#expand').hidden=!S.config.titlebar_show_expand;$('#expand').innerHTML=icon(S.fullscreen?'restore':S.config.window_expand_mode==='fullscreen'?'fullscreen':S.maximized?'restore':'maximize');
  for(const [id,name] of Object.entries({minimize:'minimize',close:'close',collapse:'menu','new-tab':'plus',back:'back',forward:'forward',reload:'reload',shield:'shield',split:'split',passwords:'key',menu:'more','find-close':'close'}))$('#'+id).innerHTML=icon(name);
  $('#bookmark').innerHTML=icon(S.bookmarks.some(entry=>entry.url===pane?.url)?'star-filled':'star');
  $('#back').disabled=!pane?.canBack;$('#forward').disabled=!pane?.canForward;$('#reload').classList.toggle('loading',!!pane?.loading);
  const nav={back:$('#back'),forward:$('#forward'),reload:$('#reload'),address:$('#address-form'),shield:$('#shield'),split:$('#split'),passwords:$('#passwords'),bookmark:$('#bookmark'),menu:$('#menu')};
  const order=[...new Set([...S.config.nav_order,...Object.keys(nav)])];for(const key of order)if(nav[key]){$('#navigation').append(nav[key]);nav[key].hidden=S.config.nav_hidden.includes(key)&&!['address','menu'].includes(key);}
  $('#downloads-button').innerHTML=icon('download')+`<span class="label">${esc(t('Downloads'))}</span>`+(S.downloads.some(entry=>entry.state==='progressing')?'<span class="badge">'+S.downloads.filter(entry=>entry.state==='progressing').length+'</span>':'');
  $('#settings-button').innerHTML=icon('settings')+`<span class="label">${esc(t('Settings'))}</span>`;
  for(const [id,label] of [['settings-button','Settings'],['downloads-button','Downloads'],['bookmarks-button','Bookmarks']])$('#'+id).title=t(label);
  $('#bookmarks-button').innerHTML=icon('star')+`<span class="label">${esc(t('Bookmarks'))}</span>`;
  renderTabs();renderBookmarks();renderOffer();renderPanes();renderScreen();renderClock();
  for(const image of $$('.home-logo'))if(image.src!==logoURL())image.src=logoURL();
  for(const image of $$('.about-logo,.wizard-header img'))if(image.src!==logoURL())image.src=logoURL();
  if(S.modal?.type==='close'&&!$('#modal-layer [data-close-dialog]'))showClose();
  requestAnimationFrame(updateBounds);
  if(S.config.onboarding_complete&&S.config.tour_pending&&!S.private&&!tourRunning)startTour();
}
function renderTabs(){
  const signature=JSON.stringify([S.tabs,S.active,S.config.language,S.config.sidebar_collapsed,[...selected]]);if(signature===tabSignature)return;tabSignature=signature;
  const listing=$('#tabs'),scrollTop=listing.scrollTop,scrollLeft=listing.scrollLeft,changed=listing.dataset.active!==S.active;
  listing.dataset.active=S.active;listing.innerHTML=S.tabs.map(tab=>{
    const pane=tab.panes[tab.active],favicon=pane.icon?`<img src="${esc(pane.icon)}" alt="">`:`<span class="favicon">${icon('globe')}</span>`;
    return `<button class="tab ${tab.id===S.active?'active':''} ${selected.has(tab.id)?'selected':''}" data-tab="${esc(tab.id)}" role="tab" aria-selected="${tab.id===S.active}" title="${esc((tab.pinned?t('Pinned tab')+' · ':'')+titleFor(tab))}">${favicon}<span class="title">${esc(titleFor(tab))}</span>${tab.pinned?icon('pin').replace('<svg ','<svg class="pin" '):''}<span class="close-tab" data-close="${esc(tab.id)}" title="${esc(t('Close'))}">${icon('close')}</span></button>`;
  }).join('');
  listing.scrollTop=scrollTop;listing.scrollLeft=scrollLeft;
  if(changed)listing.querySelector('.tab.active')?.scrollIntoView({block:'nearest',inline:'nearest'});
  for(const element of listing.querySelectorAll('[data-tab]')){
    element.onclick=event=>{
      if(event.target.closest('[data-close]')){invoke('close_tabs',{ids:[element.dataset.tab]});return;}
      const index=S.tabs.findIndex(tab=>tab.id===element.dataset.tab);
      if(event.shiftKey){const low=Math.min(anchor,index),high=Math.max(anchor,index);if(!event.ctrlKey&&!event.metaKey)selected.clear();for(let i=low;i<=high;i++)selected.add(S.tabs[i].id);renderTabs();}
      else if(event.ctrlKey||event.metaKey){selected.has(element.dataset.tab)?selected.delete(element.dataset.tab):selected.add(element.dataset.tab);anchor=index;renderTabs();}
      else{anchor=index;selected=new Set([element.dataset.tab]);invoke('select',{id:element.dataset.tab});}
      listing.focus();
    };
    element.oncontextmenu=async event=>{event.preventDefault();if(!selected.has(element.dataset.tab))selected=new Set([element.dataset.tab]);renderTabs();const result=await showDialog(t('Tabs'),`<div class="actions">${button('pin','Pin / unpin selected tabs','data-option="pin"')}${button('close','Close selected tabs','data-option="close"')}</div>`,null,{submit:false,setup:form=>{form.querySelector('[data-option=pin]').onclick=()=>{invoke('pin',{ids:[...selected]});closeDialog(true);};form.querySelector('[data-option=close]').onclick=()=>{invoke('close_tabs',{ids:[...selected]});closeDialog(true);};}});};
  }
}
$('#tabs').addEventListener('keydown',event=>{if(event.key==='Delete'){event.preventDefault();invoke('close_tabs',{ids:[...selected]});}});
function renderBookmarks(){
  const bar=$('#bookmark-bar');bar.hidden=!S.config.bookmark_bar||!S.config.onboarding_complete;
  const signature=JSON.stringify(S.bookmarks);if(bar.dataset.signature===signature)return;bar.dataset.signature=signature;
  bar.innerHTML=button('folder','Bookmarks','data-library')+S.bookmarks.filter(entry=>entry.folder==='Bookmarks toolbar').slice(0,8).map(entry=>`<button data-url="${esc(entry.url)}" title="${esc(entry.url)}">${esc(entry.title)}</button>`).join('');
  bar.querySelector('[data-library]').onclick=()=>invoke('bookmarks');for(const element of bar.querySelectorAll('[data-url]'))element.onclick=()=>invoke('new_tab',{url:element.dataset.url});
}
function renderPanes(){
  const tab=currentTab();if(!tab)return;
  const signature=JSON.stringify([tab.id,tab.active,tab.panes.map(pane=>[pane.url,pane.error]),S.shortcuts,S.config.home_columns,S.config.home_width,S.config.home_logo,S.config.home_search,S.config.home_stats,S.config.home_ip,S.config.home_tile_size,S.config.home_align,S.config.wallpaper,S.config.language]);
  if(signature!==paneSignature){
    paneSignature=signature;$('#panes').innerHTML=tab.panes.map((pane,index)=>`<div class="pane ${index===tab.active?'focused':''}" data-pane="${index}" style="flex:${tab.panes.length===2?(index?100-S.config.split_ratio:S.config.split_ratio):1}">${pane.url==='supersearch:start'?homeHTML():pane.error?errorHTML(pane.error):''}</div>`).join('')+(tab.panes.length===2?'<div class="divider" tabindex="0" role="separator" aria-label="Resize split view"></div>':'');
    for(const element of $$('.pane')){element.addEventListener('pointerdown',()=>{if(Number(element.dataset.pane)!==currentTab().active)api.call('pane',{index:Number(element.dataset.pane)});});if(element.querySelector('.home'))bindHome(element);if(element.querySelector('.error-card'))bindError(element);}
    const divider=$('.divider');if(divider)divider.onpointerdown=event=>{event.preventDefault();divider.setPointerCapture(event.pointerId);api.call('ui_modal',{open:true});divider.onpointermove=move=>{const rect=$('#viewport').getBoundingClientRect(),ratio=Math.max(20,Math.min(80,Math.round((move.clientX-rect.x)/rect.width*100)));document.documentElement.style.setProperty('--split',ratio+'%');divider.dataset.ratio=ratio;};divider.onpointerup=()=>{divider.onpointermove=null;api.call('ui_modal',{open:false});invoke('settings_apply',{split_ratio:Number(divider.dataset.ratio||50)});};};
    if(S.config.wallpaper&&!wallpaper)api.call('wallpaper_data').then(value=>{wallpaper=value;applyWallpaper();});else applyWallpaper();
  }
  for(const element of $$('.pane')){const index=Number(element.dataset.pane);element.style.flex=tab.panes.length===2?(index?100-S.config.split_ratio:S.config.split_ratio):1;}
  for(const element of $$('.home'))updateHomeStats(element);
}
function homeHTML(){
  return `<div class="home"><div class="home-tools">${button('settings','Customize start page','data-home="customize"')}${button('image','Wallpaper','data-home="wallpaper"')}${button('reload','Reset background','data-home="reset-wallpaper"')}</div><div class="home-center">${S.config.home_logo?`<img class="home-logo" src="${logoURL()}" alt="SuperSearch">`:""}${S.config.home_search?`<form class="home-search"><input name="q" aria-label="${esc(t('Search'))}" placeholder="${esc(t('Search the web or enter an address'))}" autocomplete="off" required><button type="submit" class="primary">${esc(t('Search'))}${icon('forward')}</button></form>`:''}<div class="tiles">${S.shortcuts.map(entry=>`<div class="shortcut"><button class="tile" data-shortcut="${esc(entry.id)}"><span class="tile-icon"><img src="${esc(entry.icon)}" alt=""></span>${esc(entry.title)}</button><div class="shortcut-tools"><button data-edit="${esc(entry.id)}" title="${esc(t('Edit'))}">${icon('edit')}</button><button data-remove="${esc(entry.id)}" title="${esc(t('Delete'))}">${icon('close')}</button></div></div>`).join('')}<button class="tile add" data-home="add-shortcut"><span class="tile-icon">${icon('plus')}</span>${esc(t('Add'))}</button></div></div>${S.config.home_stats?`<footer class="privacy-card"><div class="privacy-totals"><span class="shield">${icon('shield')}</span><div class="privacy-lead"><strong>${esc(t('Blocked trackers'))}</strong><small>${esc(S.private?t('Private window'):S.route.ephemeral?t('Session profile'):t('Persistent profile'))} · ${esc(S.route.tor?'Tor':S.route.proxy?t('Proxy'):t('Direct connection — IP address is visible'))}</small></div><div class="stat"><strong data-stat="total">0</strong><small>${esc(t('Total'))}</small></div><div class="stat"><strong data-stat="today">0</strong><small>${esc(t('Today'))}</small></div><div class="stat"><strong data-stat="domains">0</strong><small>${esc(t('Domains'))}</small></div></div>${S.config.home_ip?`<div class="ip-row"><div class="ip-symbol">${icon('globe')}</div><div class="ip-details"><small>${esc(t('Your public IP'))}</small><code data-ip dir="ltr" aria-live="polite"></code><small data-ip-status></small></div><button data-home="refresh-ip" title="${esc(t('Refresh IP address'))}">${icon('reload')}</button></div>`:''}</footer>`:''}</div>`;
}
function updateHomeStats(home){
  const values={total:S.stats.total,today:S.private?S.stats.today:S.stats.daily?.at(-1)?.[1]||0,domains:S.stats.domains};for(const [key,value] of Object.entries(values)){const element=home.querySelector(`[data-stat=${key}]`);if(element)element.textContent=Number(value||0).toLocaleString();}
  const ip=home.querySelector('[data-ip]');if(ip)ip.textContent=S.ip.address||t(S.ip.state==='loading'?'Checking…':S.ip.state==='error'?'Unavailable':'Not checked yet');
  const status=home.querySelector('[data-ip-status]');if(status)status.textContent=t(S.ip.state==='error'?'Could not check the address. Check your connection and try again.':'Public connection address · provided by ipify');
  const refresh=home.querySelector('[data-home=refresh-ip]');if(refresh){refresh.disabled=S.ip.state==='loading';refresh.classList.toggle('loading',S.ip.state==='loading');}
}
function applyWallpaper(){for(const element of $$('.home')){element.classList.toggle('with-wallpaper',!!wallpaper&&!!S.config.wallpaper);element.style.setProperty('--wallpaper',wallpaper&&S.config.wallpaper?`url("${wallpaper}")`:'none');}}
function bindHome(element){
  const form=element.querySelector('.home-search');if(form){form.onsubmit=event=>{event.preventDefault();invoke('navigate',{text:form.elements.q.value});};suggestions(form.elements.q,text=>invoke('navigate',{text}));}
  for(const button of element.querySelectorAll('[data-shortcut]'))button.onclick=()=>invoke('navigate',{text:S.shortcuts.find(entry=>entry.id===button.dataset.shortcut).url});
  for(const button of element.querySelectorAll('[data-edit]'))button.onclick=()=>editShortcut(button.dataset.edit);
  for(const button of element.querySelectorAll('[data-remove]'))button.onclick=()=>invoke('shortcuts',S.shortcuts.filter(entry=>entry.id!==button.dataset.remove).map(({icon,...entry})=>entry));
  for(const button of element.querySelectorAll('[data-home]'))button.onclick=async()=>{
    const action=button.dataset.home;if(action==='refresh-ip')invoke('ip_refresh');if(action==='customize')customizeHome();if(action==='add-shortcut')editShortcut();
    if(action==='wallpaper'){wallpaper=await invoke('wallpaper')||wallpaper;applyWallpaper();}if(action==='reset-wallpaper'){await invoke('wallpaper_reset');wallpaper='';applyWallpaper();}
  };
}
function errorHTML(error){
  let title='This page is out of reach',description='The connection could not be completed. Check your internet connection or try again in a moment.',symbol='wifi-off';
  if(error.code<=-200&&error.code>=-299||[-107,-112,-113,-117,-123,-129].includes(error.code)){title='Secure connection unavailable';description='The website could not provide a valid secure connection. Check your device clock or try again later.';symbol='shield';}
  else if(S.config.proxy||S.config.tor||[-111,-115,-130,-136].includes(error.code)){title='Check your private connection';description='Your proxy or Tor service may be unavailable. Check that it is running and review your network settings.';symbol='shield';}
  else if(error.code===-105){title='We could not find this website';description='Check the address and your DNS or internet connection, then try again.';symbol='globe';}
  else if([-106,-109].includes(error.code)){title='You are offline';description='Connect to Wi-Fi or your wired network, then try this page again.';}
  else if([-7,-118].includes(error.code)){title='This website took too long';description='The website did not respond in time. Give it a moment and try again.';symbol='globe';}
  return `<div class="network-error"><div class="error-card"><div class="symbol">${icon(symbol)}</div><h1>${esc(t(title))}</h1><p>${esc(t(description))}</p><code>${esc(error.url)}</code><div class="actions">${button('reload','Try again','data-error="retry" class="primary"')}${button('settings','Network settings','data-error="settings"')}${button('home','Start page','data-error="home"')}</div><details><summary>${esc(t('Technical details'))}</summary><p>${esc(error.description)} · ${error.code}</p></details></div></div>`;
}
function bindError(element){for(const button of element.querySelectorAll('[data-error]'))button.onclick=()=>{if(button.dataset.error==='settings'){settingsCategory='Privacy';invoke('settings');}else invoke(button.dataset.error);};}

function closeSuggestions(){suggestionGeneration++;$$('.suggestions').forEach(element=>element.remove());api.call('overlay',{height:0}).catch(()=>{});}
function suggestions(input,choose){
  let timer=null,list=null,selection=-1,values=[];
  function hide(){clearTimeout(timer);if(list)list.remove();list=null;selection=-1;input.setAttribute('aria-expanded','false');input.removeAttribute('aria-activedescendant');if(input.id==='address')api.call('overlay',{height:0}).catch(()=>{});}
  input.setAttribute('role','combobox');input.setAttribute('aria-autocomplete','list');input.setAttribute('aria-expanded','false');
  input.addEventListener('input',()=>{hide();const generation=++suggestionGeneration,query=input.value,tab=S.active;if(!S.config.suggestions||S.private||!query.trim()||query.length>160||query.includes('://')||query.includes('@'))return;
    timer=setTimeout(async()=>{if(generation!==suggestionGeneration||!document.hasFocus()||document.activeElement!==input)return;try{const result=await api.call('suggest',{query});if(generation!==suggestionGeneration||tab!==S.active||!document.hasFocus()||document.activeElement!==input||query!==input.value||!S.config.suggestions||S.private)return;values=result;if(!values.length)return;
      list=document.createElement('div');list.className='suggestions';list.id='suggestions-'+generation;list.setAttribute('role','listbox');
      for(const [index,text] of values.entries()){const button=document.createElement('button');button.type='button';button.id=list.id+'-'+index;button.innerHTML=icon('search');const span=document.createElement('span');span.textContent=text;button.append(span);button.setAttribute('role','option');button.onmousedown=event=>event.preventDefault();button.onclick=()=>{input.value=text;hide();choose(text);};list.append(button);}
      input.parentElement.append(list);input.setAttribute('aria-controls',list.id);input.setAttribute('aria-expanded','true');
      if(input.id==='address'){const rect=list.getBoundingClientRect(),area=$('#viewport').getBoundingClientRect();api.call('overlay',{height:Math.max(0,rect.bottom-area.top+8)});}
    }catch{}},200);
  });
  input.addEventListener('keydown',event=>{
    if(event.key==='Escape'||event.key==='Tab'){hide();return;}
    if(!list||!values.length)return;
    if(['ArrowDown','ArrowUp'].includes(event.key)){event.preventDefault();selection=selection<0?(event.key==='ArrowDown'?0:values.length-1):(selection+(event.key==='ArrowDown'?1:-1)+values.length)%values.length;[...list.children].forEach((element,index)=>{element.classList.toggle('selected',index===selection);element.setAttribute('aria-selected',String(index===selection));});input.setAttribute('aria-activedescendant',list.children[selection].id);list.children[selection].scrollIntoView({block:'nearest'});}
    else if(event.key==='Enter'&&selection>=0){event.preventDefault();const text=values[selection];input.value=text;hide();choose(text);}
  });
  input.addEventListener('blur',()=>{suggestionGeneration++;hide();});input.form?.addEventListener('submit',()=>{suggestionGeneration++;hide();});
}

function showDialog(title,content,onSubmit,{submit=true,submitLabel='Save',setup=null}={}){
  if(modalResolve)closeDialog(null);
  const layer=$('#modal-layer');layer.hidden=false;layer.innerHTML=`<form class="dialog"><h2>${esc(title)}</h2>${content}<p class="error" data-dialog-error hidden></p><div class="actions"><button type="button" data-cancel>${esc(t('Cancel'))}</button>${submit?`<button type="submit" class="primary">${esc(t(submitLabel))}</button>`:''}</div></form>`;
  api.call('ui_modal',{open:true}).catch(()=>{});const form=layer.querySelector('form');
  form.querySelector('[data-cancel]').onclick=()=>closeDialog(null);
  form.onsubmit=async event=>{event.preventDefault();const error=form.querySelector('[data-dialog-error]'),button=form.querySelector('[type=submit]');if(button)button.disabled=true;form.dataset.busy='true';form.querySelector('[data-cancel]').disabled=true;error.hidden=true;
    try{const result=onSubmit?await onSubmit(form):true;if(result!==false)closeDialog(result);}catch(problem){error.textContent=problem.message;error.hidden=false;}finally{delete form.dataset.busy;if(button)button.disabled=false;form.querySelector('[data-cancel]').disabled=false;}};
  if(setup)setup(form);setTimeout(()=>form.querySelector('input:not([type=checkbox]),select,button')?.focus(),0);
  return new Promise(resolve=>{modalResolve=resolve;});
}
function closeDialog(value){const layer=$('#modal-layer');for(const input of layer.querySelectorAll('input[type=password]'))input.value='';layer.hidden=true;layer.replaceChildren();api.call('ui_modal',{open:false}).catch(()=>{});const resolve=modalResolve;modalResolve=null;resolve?.(value);}
async function confirm(title,message,submitLabel='Continue'){return !!await showDialog(t(title),`<p>${esc(t(message))}</p>`,()=>true,{submitLabel});}
async function bookmarkDialog(entry=null){const pane=currentPane();if(!entry&&!/^https?:/.test(pane?.url||'')){toast(t('Open a website before adding a bookmark.'));return;}
  const existing=entry||S.bookmarks.find(value=>value.url===pane.url)||{url:pane.url,title:pane.title,folder:'Bookmarks toolbar'};
  return showDialog(t('Bookmark'),`<label class="field">${esc(t('Name'))}<input name="title" value="${esc(existing.title)}" required></label><label class="field">${esc(t('Address'))}<input name="url" value="${esc(existing.url)}" required></label><label class="field">${esc(t('Folder'))}<input name="folder" list="bookmark-folders" value="${esc(existing.folder||'Bookmarks toolbar')}"><datalist id="bookmark-folders"><option>Bookmarks toolbar</option><option>Other bookmarks</option>${[...new Set(S.bookmarks.map(value=>value.folder))].map(value=>`<option>${esc(value)}</option>`).join('')}</datalist></label>`,async form=>{await api.call('bookmarks_save',{url:form.elements.url.value,title:form.elements.title.value,folder:form.elements.folder.value,original_url:existing.url});return true;});
}
async function editShortcut(id=null){const entry=S.shortcuts.find(value=>value.id===id)||{id:crypto.randomUUID(),title:'',url:'https://'};
  await showDialog(t('Shortcut'),`<label class="field">${esc(t('Name'))}<input name="title" required value="${esc(entry.title)}"></label><label class="field">${esc(t('Address'))}<input name="url" required value="${esc(entry.url)}"></label>`,async form=>{const value={id:entry.id,title:form.elements.title.value,url:form.elements.url.value};const entries=S.shortcuts.map(({icon,...entry})=>entry);const index=entries.findIndex(entry=>entry.id===value.id);if(index>=0)entries[index]=value;else entries.push(value);await api.call('shortcuts',entries);return true;});
}
async function customizeHome(){
  await showDialog(t('Customize the start page'),`<div class="shortcut-editor">${S.shortcuts.map(entry=>`<div class="list-row"><img src="${esc(entry.icon)}" alt=""><span class="list-label">${esc(entry.title)}</span><button type="button" data-up="${esc(entry.id)}" title="${esc(t('Move up'))}">${icon('chevron-up')}</button><button type="button" data-down="${esc(entry.id)}" title="${esc(t('Move down'))}">${icon('chevron-down')}</button></div>`).join('')}</div><div class="note">${esc(t('Use the edit and remove buttons on each shortcut to change it.'))}</div><label class="field">${esc(t('Columns'))}<input name="columns" type="number" min="2" max="8" value="${S.config.home_columns}"></label><label class="field">${esc(t('Tile size'))}<input name="size" type="number" min="72" max="200" value="${S.config.home_tile_size}"></label>${[['logo','Logo'],['search','Search field'],['stats','Privacy counters'],['ip','Show public IP (contacts ipify)']].map(([key,label])=>`<label><input name="${key}" type="checkbox" ${S.config['home_'+key]?'checked':''}>${esc(t(label))}</label>`).join('')}`,async form=>{await api.call('settings_apply',{home_columns:Number(form.elements.columns.value),home_tile_size:Number(form.elements.size.value),home_logo:form.elements.logo.checked,home_search:form.elements.search.checked,home_stats:form.elements.stats.checked,home_ip:form.elements.ip.checked});return true;},{submitLabel:'Apply',setup:form=>{
    for(const element of form.querySelectorAll('[data-up],[data-down]'))element.onclick=async()=>{const id=element.dataset.up||element.dataset.down,delta=element.dataset.up?-1:1,entries=S.shortcuts.map(({icon,...entry})=>entry),index=entries.findIndex(entry=>entry.id===id),next=index+delta;if(next<0||next>=entries.length)return;[entries[index],entries[next]]=[entries[next],entries[index]];await api.call('shortcuts',entries);const row=element.closest('.list-row'),sibling=delta<0?row.previousElementSibling:row.nextElementSibling;if(sibling)delta<0?sibling.before(row):sibling.after(row);};
  }});
}

const META={
 General:[
  ['Search and language',[['language','Language','', 'select'],['search','Search engine','', 'select'],['suggestions','Search suggestions','Typed queries are sent to DuckDuckGo when this is on. Suggestions stay off in private windows.']]],
  ['Startup and tabs',[['homepage','Open new tabs with','Enter supersearch:start for the built-in start page.'],['restore_tabs','Restore saved tabs on the next launch','Reopen saved ordinary tabs. Pinned tabs are remembered separately; private tabs are not saved.'],['confirm_close','Confirm before closing a window']]],
  ['History and bookmarks',[['remember_history','Save browsing history','Keep a local list of visited pages. Private windows are never recorded.'],['bookmark_bar','Show the bookmarks toolbar']]],
 ],
 Privacy:[],
 Appearance:[
  ['Theme',[['theme','Theme','The theme changes browser controls. Websites keep their own colors.','select']]],
  ['Text and size',[['font','Font'],['ui_scale','Size of browser controls','', 'number',75,175],['page_zoom','Website zoom','', 'number',25,250],['animations','Interface animations']]],
  ['Window and full screen',[['titlebar_show_expand','Show the expand button in the title bar'],['window_expand_mode','Expand button and title bar double-click','Maximize keeps system panels visible. Full screen hides them. F11 always enters full screen.','select'],['titlebar_system_status','Show time and battery only in full screen','Hidden in normal and maximized windows. Charge is shown only when a battery is detected.'],['titlebar_show_title','Show the title in the title bar'],['titlebar_accent','Use the surface color for the title bar'],['titlebar_height','Title bar height','', 'number',28,64]]],
  ['Start page',[['home_logo','Show the logo'],['home_search','Show the search field'],['home_stats','Show privacy counters'],['home_ip','Show public IP on the start page','Contacts ipify through your current proxy or Tor when the start page is visible. The address stays in memory. Turn this off to avoid these requests.']]],
  ['Start page layout',[['home_align','Content alignment','', 'select'],['home_columns','Shortcut columns','', 'number',2,8],['home_tile_size','Shortcut tile size','', 'number',72,200],['home_width','Start page content width','', 'number',600,1600]],true],
  ['Panels and toolbar',[['sidebar_position','Tab panel position','', 'select'],['navigation_position','Address bar position','', 'select'],['sidebar_width','Tab panel width','', 'number',160,640],['sidebar_collapsed','Collapse tab panel'],['tab_height','Tab height','', 'number',32,88],['icon_size','Icon size','', 'number',16,48],['toolbar_size','Address bar height','', 'number',24,64],['split_ratio','Split view size','', 'number',20,80]],true],
  ['Fine-tune spacing and corners',[['shape','Control shape','', 'select'],['radius','Corner roundness','', 'number',0,40],['spacing','Spacing','', 'number',0,24]],true],
 ]
};
const CATEGORIES=[['General','settings','Search, language, startup and everyday browsing.'],['Privacy','shield','Choose how SuperSearch protects your browsing.'],['Appearance','image','Make the browser comfortable to look at and use.'],['Storage','storage','Import your data, clean up or start over.'],['Extensions','puzzle','Manage optional tools and trusted website customizations.'],['Statistics','chart','See which tracking requests have been blocked.'],['About','info','Version, browser engine and privacy documents.']];
function options(key){return {language:Object.entries(B.languages),search:['DuckDuckGo','Google','Brave','Wikipedia'],theme:[['light','Light'],['dark','Dark'],['oled','Pure black']],doh:['Off','Cloudflare','Quad9','Google'],preset:Object.entries(B.preset_labels),window_expand_mode:[['maximized','Maximize window'],['fullscreen','Full screen']],home_align:[['center','Centered'],['top','Near the top']],shape:[['rounded','Rounded'],['pill','Pill'],['square','Square']],sidebar_position:[['left','Left'],['right','Right'],['top','Top'],['bottom','Bottom']],navigation_position:[['top','Top'],['bottom','Bottom']]}[key]||[];}
function settingRow(entry){
  const [key,label,description='',type,min,max]=entry,value=settingsDraft[key],isBoolean=typeof value==='boolean'||key==='suggestions';let control;
  if(isBoolean)control=`<input type="checkbox" class="switch" data-setting="${key}" id="setting-${key}" ${value?'checked':''} aria-label="${esc(t(label))}">`;
  else if(type==='select')control=`<select data-setting="${key}" id="setting-${key}">${options(key).map(option=>{const [value,title]=Array.isArray(option)?option:[option,option];return `<option value="${esc(value)}" ${settingsDraft[key]===value?'selected':''}>${esc(key==='language'?title:t(title))}</option>`;}).join('')}</select>`;
  else control=`<input data-setting="${key}" id="setting-${key}" type="${type==='number'?'number':'text'}" value="${esc(value)}" ${min!==undefined?`min="${min}" max="${max}"`:''}>`;
  return `<div class="setting-row ${isBoolean?'toggle':''}" data-search="${esc((key+' '+label+' '+description+' '+t(label)+' '+t(description)).toLowerCase())}"><label class="setting-caption" for="setting-${key}">${esc(t(label))}${description?`<small>${esc(t(description))}</small>`:''}${RESTART.has(key)?`<span class="restart">${esc(t('Restart required'))}</span>`:''}</label>${control}</div>`;
}
function settingsHTML(wizard=false){
  settingsDraft??=structuredClone(S.config);
  return `${wizard?'':`<div class="screen-title">${button('back','Back','data-screen-back')}<h1>${esc(t('Settings'))}</h1></div>`}<input class="settings-search" id="settings-search" placeholder="${esc(t('Find a setting'))}" value="${esc(settingsQuery)}"><div class="settings-body"><nav class="settings-nav">${CATEGORIES.map(([name,symbol])=>`<button data-category="${name}" class="${settingsCategory===name?'active':''}" title="${esc(t(name))}">${icon(symbol)}<span class="label">${esc(t(name))}</span></button>`).join('')}</nav><div class="settings-content" id="settings-content"></div></div>${wizard?'':`<footer class="settings-footer"><span class="status" id="settings-status"></span><button data-settings="restart" ${S.restart?'':'hidden'}>${esc(t('Restart'))}</button><button data-settings="cancel">${esc(t('Cancel'))}</button><button class="primary" data-settings="apply">${esc(t('Apply'))}</button></footer>`}`;
}
function categoryCards(name){
  if(name==='Privacy'){
    const keys=group=>group.map(key=>[key,...B.privacy_options[key]]);
    return [['Protection level',[['preset','Protection level',B.preset_help[settingsDraft.preset],'select']]],
      ['Everyday protection',keys(['block_ads','https_only','strip_params','block_referrers','gpc'])],
      ['Website data',keys(['ephemeral_profile','third_party'])],
      ['Connection details',[...keys(['tor']),['doh','Secure DNS provider','', 'select'],['proxy','Proxy address','socks5://127.0.0.1:1080']],true],
      ['Advanced website protections',keys(['fingerprint','webrtc','geolocation','javascript','webgl','canvas','allow_popups']),true]];
  }
  return META[name]||[];
}
function renderSettingsContent(){
  const host=$('#settings-content');if(!host)return;
  const summary=CATEGORIES.find(entry=>entry[0]===settingsCategory)?.[2]||'';
  const cards=categoryCards(settingsCategory);
  host.innerHTML=`<h2>${esc(t(settingsCategory))}</h2><p class="summary">${esc(t(summary))}</p>`+cards.map(([heading,entries,advanced])=>{
    const body=entries.map(settingRow).join('');return advanced?`<details class="settings-card" data-settings-card><summary>${esc(t(heading))}</summary>${body}</details>`:`<section class="settings-card" data-settings-card><h3>${esc(t(heading))}</h3>${body}</section>`;
  }).join('');
  if(settingsCategory==='Privacy')host.insertAdjacentHTML('beforeend',`<section class="settings-card"><p>${esc(t('Website permissions are denied by default.'))}</p><div class="actions">${button('shield','Update filters','data-setting-action="filters"')}${button('globe','Test proxy','data-setting-action="proxy"')}</div><p class="note" data-operation-result hidden></p></section>`);
  if(settingsCategory==='General')host.insertAdjacentHTML('beforeend',`<section class="settings-card"><h3>${esc(t('Passwords and shortcuts'))}</h3><div class="actions">${button('key','Password manager','data-setting-action="passwords"')}${button('info','Keyboard shortcuts','data-setting-action="shortcuts"')}</div></section>`);
  if(settingsCategory==='Appearance'){
    const palette={...B.palettes[settingsDraft.theme],...settingsDraft.colors};
    host.insertAdjacentHTML('beforeend',`<details class="settings-card"><summary>${esc(t('Custom colors'))}</summary><div class="color-controls">${[['bg','Background'],['panel','Surface'],['fg','Text'],['accent','Accent']].map(([key,label])=>`<label>${esc(t(label))}<input type="color" data-color="${key}" value="${esc(palette[key])}"></label>`).join('')}</div></details><section class="settings-card"><h3>${esc(t('Start page'))}</h3><div class="actions">${button('settings','Edit shortcuts and wallpaper','data-setting-action="home"')}${button('image','Choose wallpaper','data-setting-action="wallpaper"')}${button('reload','Reset background','data-setting-action="wallpaper-reset"')}${button('settings','Move panels with the mouse','data-setting-action="move-panels"')}</div></section><details class="settings-card"><summary>${esc(t('Address bar buttons'))}</summary><p>${esc(t('Drag rows to change the order. Uncheck a button to hide it.'))}</p><div class="toolbar-order">${settingsDraft.nav_order.map(key=>`<button type="button" draggable="true" data-nav="${key}" class="${settingsDraft.nav_hidden.includes(key)?'off':''}">${esc(t(key==='address'?'Address':key[0].toUpperCase()+key.slice(1)))}</button>`).join('')}</div></details>`);
  }
  if(settingsCategory==='Storage')renderStorage(host);
  if(settingsCategory==='Extensions')renderExtensions(host);
  if(settingsCategory==='Statistics')renderStatistics(host);
  if(settingsCategory==='About')renderAbout(host);
  bindSettings(host);filterSettings(false);updateSettingsFooter();
}
function bindSettings(host){
  for(const element of host.querySelectorAll('[data-setting]'))element.onchange=async()=>{
    const key=element.dataset.setting;settingsEdited.add(key);settingsDraft[key]=element.type==='checkbox'?element.checked:element.type==='number'?Number(element.value):element.value;settingsStatus='';
    if(key==='preset'){Object.assign(settingsDraft,B.presets[settingsDraft.preset]);Object.keys(B.presets[settingsDraft.preset]).forEach(key=>settingsEdited.add(key));}if(key==='theme'){settingsDraft.colors={};settingsEdited.add('colors');}
    if(!S.config.onboarding_complete){try{await api.call('settings_apply',{[key]:settingsDraft[key],...(key==='theme'?{colors:{}}:key==='preset'?B.presets[settingsDraft.preset]:{})});}catch(error){settingsStatus=error.message;}}
    if(key==='preset'||key==='theme')renderSettingsContent();else updateSettingsFooter();
  };
  for(const input of host.querySelectorAll('[data-color]'))input.onchange=()=>{settingsEdited.add('colors');settingsDraft.colors={...settingsDraft.colors,[input.dataset.color]:input.value};updateSettingsFooter();};
  for(const element of host.querySelectorAll('[data-setting-action]'))element.onclick=async()=>{
    const action=element.dataset.settingAction;try{
      if(action==='passwords')invoke('passwords');if(action==='shortcuts')keyboardHelp();if(action==='home')customizeHome();if(action==='move-panels'){await invoke('web');beginCustomization();}
      if(action==='wallpaper'){wallpaper=await invoke('wallpaper')||wallpaper;settingsDraft.wallpaper=S.config.wallpaper;applyWallpaper();}
      if(action==='wallpaper-reset'){await invoke('wallpaper_reset');wallpaper='';settingsDraft.wallpaper='';applyWallpaper();}
      if(action==='filters'||action==='proxy'){
        element.disabled=true;const result=host.querySelector('[data-operation-result]');result.hidden=false;result.textContent=t('Connecting…');
        try{const value=await api.call(action==='filters'?'filters_update':'proxy_test',action==='proxy'?{proxy:settingsDraft.proxy,tor:settingsDraft.tor}:{});result.textContent=action==='proxy'?'IP: '+value:`${value.rules.toLocaleString()} ${t('blocking rules')} · ${value.skipped.toLocaleString()} ${t('unsupported rules skipped')}`;}catch(error){result.textContent=error.message;}finally{element.disabled=false;}
      }
    }catch(error){toast(error.message);}
  };
  let dragKey=null;for(const button of host.querySelectorAll('[data-nav]')){
    button.ondragstart=()=>{dragKey=button.dataset.nav;};button.ondragover=event=>event.preventDefault();button.ondrop=event=>{event.preventDefault();if(!dragKey)return;const values=settingsDraft.nav_order.filter(key=>key!==dragKey),index=values.indexOf(button.dataset.nav);values.splice(index,0,dragKey);settingsDraft.nav_order=values;settingsEdited.add('nav_order');renderSettingsContent();};
    button.onclick=()=>{const key=button.dataset.nav;if(['address','menu'].includes(key))return;settingsEdited.add('nav_hidden');settingsDraft.nav_hidden=settingsDraft.nav_hidden.includes(key)?settingsDraft.nav_hidden.filter(value=>value!==key):[...settingsDraft.nav_hidden,key];button.classList.toggle('off',settingsDraft.nav_hidden.includes(key));updateSettingsFooter();};
  }
}
function dirtySettings(){return settingsDraft?[...settingsEdited].filter(key=>JSON.stringify(settingsDraft[key])!==JSON.stringify(S.config[key])):[];}
function updateSettingsFooter(){const label=$('#settings-status');if(!label)return;const dirty=dirtySettings();label.textContent=settingsStatus||t(dirty.length===1?'1 unsaved change':dirty.length?'{count} unsaved changes':S.restart?'Saved. Restart to finish applying these changes.':'All changes saved.').replace('{count}',dirty.length);const apply=$('[data-settings=apply]');if(apply)apply.disabled=!dirty.length;$('[data-settings=restart]').hidden=!S.restart;}
function bindSettingsShell(){
  for(const element of $$('[data-category]'))element.onclick=()=>{settingsCategory=element.dataset.category;renderSettingsContent();$$('[data-category]').forEach(value=>value.classList.toggle('active',value===element));};
  $('#settings-search').oninput=event=>{settingsQuery=event.target.value;filterSettings(true);};
  $('[data-screen-back]')?.addEventListener('click',()=>invoke('web'));
  $('[data-settings=cancel]')?.addEventListener('click',()=>{settingsDraft=null;settingsEdited.clear();settingsStatus='';invoke('web');});
  $('[data-settings=apply]')?.addEventListener('click',async()=>{try{const changes=Object.fromEntries(dirtySettings().map(key=>[key,settingsDraft[key]]));const result=await api.call('settings_apply',changes);S.config=result.config;settingsDraft=structuredClone(result.config);settingsEdited.clear();settingsStatus='';renderSettingsContent();updateSettingsFooter();}catch(error){settingsStatus=error.message;updateSettingsFooter();}});
  $('[data-settings=restart]')?.addEventListener('click',()=>invoke('restart'));
}
function filterSettings(jump){
  const normalize=value=>String(value).toLowerCase().normalize('NFD').replace(/\p{Diacritic}/gu,'');
  const query=normalize(settingsQuery.trim()),terms=query.split(/\s+/).filter(Boolean),matches=text=>terms.every(term=>normalize(text).includes(term));
  const extras={General:['Passwords and shortcuts','Password manager','Keyboard shortcuts'],Privacy:['Test proxy','Update filters'],Appearance:['Custom colors','Wallpaper','Address bar buttons'],Storage:['Storage','Export browser data','Restore browser data','Backup password','Import from another browser','Reset browser',...CLEANUP.flatMap(([,label,help])=>[label,help])],Extensions:['Extensions','User scripts and styles','JavaScript CSS UserScripts','Local extensions'],Statistics:['Statistics','Tracking requests blocked','Top blocked domains'],About:['About','Source code','GitHub Chromium Electron version','Privacy Policy','User Agreement','Browser tour']};
  const extraText=name=>(extras[name]||[]).map(text=>text+' '+t(text)).join(' ');
  const searchable=name=>[name,t(name),extraText(name),...categoryCards(name).flatMap(([heading,entries])=>[heading,t(heading),...entries.flatMap(([key,label,help=''])=>[key,label,t(label),help,t(help)])])].join(' ');
  if(query&&jump&&!matches(searchable(settingsCategory))){const next=CATEGORIES.find(([name])=>matches(searchable(name)));if(next){settingsCategory=next[0];renderSettingsContent();$$('[data-category]').forEach(button=>button.classList.toggle('active',button.dataset.category===settingsCategory));return;}}
  const host=$('#settings-content');if(!host)return;host.querySelector('[data-no-settings]')?.remove();
  let count=0;const context=settingsCategory+' '+t(settingsCategory);
  for(const row of host.querySelectorAll('.setting-row[data-search]')){row.hidden=!!query&&!matches(row.dataset.search+' '+context);if(!row.hidden){count++;if(query){const details=row.closest('details');if(details){if(!details.hasAttribute('data-before-search'))details.dataset.beforeSearch=String(details.open);details.open=true;}}}}
  for(const card of host.querySelectorAll('[data-settings-card]'))card.hidden=!!query&&![...card.querySelectorAll('.setting-row')].some(row=>!row.hidden);
  for(const card of host.querySelectorAll('.settings-card:not([data-settings-card])'))card.hidden=!!query&&!matches(card.textContent+' '+extraText(settingsCategory)+' '+context);
  if(!query)for(const details of host.querySelectorAll('details[data-before-search]')){details.open=details.dataset.beforeSearch==='true';delete details.dataset.beforeSearch;}
  if(query&&!count&&!matches(extraText(settingsCategory)+' '+context))host.insertAdjacentHTML('beforeend',`<div class="empty" data-no-settings>${esc(t('No settings found. Try another word or clear the search.'))}</div>`);
}

const CLEANUP=[['cookies','Cookies and website data','Signs you out of websites. Your online accounts are not deleted.'],['cache','Temporary files (cache)','Remove saved page resources. Websites may load more slowly at first.'],['accounts','Saved passwords','Delete the local password vault and its master password.'],['history','History and statistics','Remove browsing history, saved tab sessions and blocking totals.'],['bookmarks','Bookmarks','Remove saved website bookmarks.'],['pinned_tabs','Pinned tabs','Forget tabs pinned for future launches.'],['downloads','Download history','Remove the list of downloads. Files are kept.'],['download_files','Downloaded files','Delete only files recorded as unchanged SuperSearch downloads.']];
function renderStorage(host){host.insertAdjacentHTML('beforeend',`<section class="settings-card"><h3>${esc(t('Backup and transfer'))}</h3><p>${esc(t('Keep an encrypted copy of your SuperSearch data or move it to another device.'))}</p><p>${esc(t('Includes bookmarks, the encrypted password vault, history, saved settings, tabs, statistics, shortcuts and wallpaper. Website sessions, cache, extensions and downloaded files are not transferred.'))}</p><div class="actions">${button('download','Export browser data','data-backup-export')}${button('import','Restore browser data','data-backup-restore')}</div></section><section class="settings-card"><h3>${esc(t('Clean up local data'))}</h3><p>${esc(t('Choose what to remove. Deletion happens only after you confirm.'))}</p><p>${esc(t('The browser restarts after cleanup so cookies and cached files can be removed safely.'))}</p>${CLEANUP.map(([key,label,help])=>`<label class="setting-row"><span class="setting-caption">${esc(t(label))}<small>${esc(t(help))}</small></span><input type="checkbox" data-clean="${key}"></label>`).join('')}<button class="danger" data-clean-button disabled>${esc(t('Delete selected data'))}</button></section><section class="settings-card"><h3>${esc(t('Import from another browser'))}</h3><p>${esc(t('Bring bookmarks and supported data from a Chromium browser.'))}</p>${button('import','Import data','data-import-button')}</section><section class="settings-card"><h3>${esc(t('Start over'))}</h3><p>${esc(t('Remove data from this browser profile and start setup again.'))}</p><button class="danger" data-reset>${esc(t('Reset browser'))}</button></section>`);
  host.querySelector('[data-backup-export]').onclick=exportBackup;
  host.querySelector('[data-backup-restore]').onclick=restoreBackup;
  for(const element of host.querySelectorAll('[data-clean]'))element.onchange=()=>host.querySelector('[data-clean-button]').disabled=!host.querySelector('[data-clean]:checked');
  host.querySelector('[data-clean-button]').onclick=async()=>{const categories=[...host.querySelectorAll('[data-clean]:checked')].map(element=>element.dataset.clean),names=categories.map(key=>t(CLEANUP.find(row=>row[0]===key)[1]));if(await showDialog(t('Delete selected data'),`<p>${esc(t('The following data will be deleted:'))}</p><ul>${names.map(name=>'<li>'+esc(name)+'</li>').join('')}</ul>`,()=>true,{submitLabel:'Delete'}))invoke('maintenance',{categories});};
  host.querySelector('[data-reset]').onclick=()=>showDialog(t('Reset browser'),`<p>${esc(t('This deletes bookmarks, saved passwords, history, shortcuts, scripts, settings and website data in this engine profile. The browser will restart as a first launch.'))}</p><label class="field">${esc(t('Type Delete to confirm'))}<input name="confirmation" autocomplete="off" required></label>`,async form=>{if(form.elements.confirmation.value!=='Delete')throw Error(t('Type Delete to confirm'));await api.call('maintenance',{categories:['reset','download_files'],confirmation:'Delete'});return true;},{submitLabel:'Delete'});
  host.querySelector('[data-import-button]').onclick=()=>importDialog();
}
async function exportBackup(){
  await showDialog(t('Export browser data'),`<p>${esc(t('The export is encrypted with a backup password. Keep this password somewhere safe; it cannot be recovered.'))}</p><p class="note">${esc(t('Only saved settings are exported. Your password vault keeps its existing master password.'))}</p><label class="field">${esc(t('Backup password'))}<input name="password" type="password" minlength="12" maxlength="1024" autocomplete="new-password" required></label><label class="field">${esc(t('Repeat backup password'))}<input name="repeat" type="password" minlength="12" maxlength="1024" autocomplete="new-password" required></label>`,async form=>{if(form.elements.password.value!==form.elements.repeat.value)throw Error(t('Passwords do not match.'));const result=await api.call('backup_export',{password:form.elements.password.value});if(!result)return false;toast(t('Encrypted backup saved.'));return true;},{submitLabel:'Choose where to save'});
}
async function restoreBackup(){
  const choice=await invoke('backup_choose');if(!choice)return;
  await showDialog(t('Restore browser data'),`<p><strong>${esc(choice.name)}</strong></p><p>${esc(t('Restoring replaces your current browser data and restarts SuperSearch. Existing website sessions will be cleared. Export your current data first if you want to keep it.'))}</p><p class="note">${esc(t('Saved passwords still need the original vault master password. Extensions must be installed again.'))}</p><label class="field">${esc(t('Backup password'))}<input name="password" type="password" maxlength="1024" autocomplete="off" required></label><label><input name="scripts" type="checkbox">${esc(t('Restore trusted UserScripts and styles too'))}</label><label><input name="confirm" type="checkbox" required>${esc(t('I understand that my current browser data will be replaced.'))}</label>`,async form=>{if(!form.elements.confirm.checked)return false;await api.call('backup_restore',{token:choice.token,password:form.elements.password.value,include_scripts:form.elements.scripts.checked,confirmation:'Replace',accepted_terms:agreement?'2026-11-02':''});return true;},{submitLabel:'Restore and restart'});
}
async function importHTML(){detectedProfiles??=await api.call('profiles');return `<label class="field">${esc(t('Browser profile'))}<select name="profile"><option value="">${esc(t('Choose a detected browser'))}</option>${detectedProfiles.map(([name,value])=>`<option value="${esc(value)}">${esc(name)}</option>`).join('')}</select></label><div class="actions">${button('folder','Choose profile folder','type="button" data-pick-profile')}${button('file','Choose password CSV','type="button" data-pick-csv')}</div><p data-import-path class="muted">${esc(manualProfile||passwordCSV)}</p><div class="inline-options">${[['bookmarks','Bookmarks'],['history','History'],['downloads','Downloads'],['cookies','Cookies'],['preferences','Settings']].map(([key,label])=>`<label><input type="checkbox" name="import-${key}" checked>${esc(t(label))}</label>`).join('')}</div><p class="note">${esc(t('Protected cookies and passwords cannot be read automatically. Password CSV files can be imported into the master-password vault.'))}</p><p data-import-report></p>`;}
function bindImport(form){
  form.querySelector('[data-pick-profile]').onclick=async()=>{manualProfile=await invoke('choose_profile')||manualProfile;form.querySelector('[data-import-path]').textContent=manualProfile;};
  form.querySelector('[data-pick-csv]').onclick=async()=>{passwordCSV=await invoke('choose_csv')||passwordCSV;form.querySelector('[data-import-path]').textContent=passwordCSV;};
}
async function executeImport(form){
  if(passwordCSV&&!await ensureVault())return false;
  const profile=manualProfile||form.querySelector('[name=profile]').value;if(!profile&&!passwordCSV)throw Error(t('Choose a browser profile or a password CSV.'));
  const selected=[...form.querySelectorAll('input[name^="import-"]:checked')].map(element=>element.name.slice(7));
  const result=await api.call('import',{profile:profile||null,csv:passwordCSV||null,selected});
  const report=Object.entries(result.counts).map(([key,value])=>t(key[0].toUpperCase()+key.slice(1))+': '+value).join(' · ')+'\n'+result.notices.join('\n');
  form.querySelector('[data-import-report]').textContent=report;toast(t('Import complete'));return result;
}
async function importDialog(){await showDialog(t('Import from another browser'),await importHTML(),async form=>{await executeImport(form);return false;},{submitLabel:'Import',setup:bindImport});}
function renderExtensions(host){host.insertAdjacentHTML('beforeend',`<section class="settings-card"><h3>${esc(t('Built-in protection'))}</h3><p>${esc(t('Ad blocking, secure connections and link cleanup are already included.'))}</p><p>${icon('check')} ${esc(t('Tracker blocking'))} · ${esc(t('Built-in'))}</p><p>${icon('check')} ${esc(t('Encrypted password vault'))} · ${esc(t('Built-in'))}</p><p>${icon('check')} ${esc(t('Private windows'))} · ${esc(t('Built-in'))}</p></section><section class="settings-card"><h3>${esc(t('User scripts and styles'))}</h3><p>${esc(t('Install only code you trust. Installation and removal apply immediately.'))}</p><div data-script-list></div>${button('import','Install UserScript','data-install-script')}${settingRow(['userscripts_private','Run UserScripts in private windows','Trusted scripts can also read information on private pages when this is on.'])}</section><section class="settings-card"><h3>${esc(t('Local extensions'))}</h3><p>${esc(t('Compatible local extensions require a persistent profile. Chrome Web Store does not install directly into SuperSearch.'))}</p>${button('puzzle','Manage local extensions','data-extensions')}</section>`);
  const scripts=async()=>{const values=await api.call('scripts'),listing=host.querySelector('[data-script-list]');if(!listing)return;listing.innerHTML=values.map(name=>`<div class="list-row"><span class="list-label">${esc(name)}</span><button data-remove-script="${esc(name)}">${icon('trash')}</button></div>`).join('');for(const button of listing.querySelectorAll('[data-remove-script]'))button.onclick=async()=>{await invoke('script_remove',{name:button.dataset.removeScript});scripts();};};scripts();host.querySelector('[data-install-script]').onclick=async()=>{await invoke('script_install');scripts();};host.querySelector('[data-extensions]').onclick=()=>extensionsDialog();
}
async function extensionsDialog(){
  if(S.config.ephemeral_profile){toast(t('Switch to a persistent profile and restart before loading extensions.'));return;}
    const entries=await invoke('extensions_list');
  await showDialog(t('Local extensions'),`<div data-extension-list>${entries.map(entry=>`<div class="list-row"><span class="list-label">${esc(entry.name)}<small>${esc(entry.id)}</small></span>${entry.popup?`<button type="button" data-extension-open="${esc(entry.id)}">${icon('forward')}</button>`:''}<button type="button" data-extension-remove="${esc(entry.id)}">${icon('trash')}</button></div>`).join('')}</div><div class="actions">${button('folder','Install folder','type="button" data-extension-folder')}${button('file','Install ZIP','type="button" data-extension-zip')}</div><p class="note">${esc(t('Extensions may read visited pages and send data over the network. Install only extensions you trust.'))}</p>`,null,{submit:false,setup:form=>{
    for(const [selector,kind] of [['[data-extension-folder]','folder'],['[data-extension-zip]','zip']])form.querySelector(selector).onclick=async()=>{try{const info=await api.call('extension_choose',{kind});if(!info)return;closeDialog(null);if(await confirm('Install this extension?',info.name+'\n'+info.permissions.join(', '),'Install')){await invoke('extension_install',{token:info.token});extensionsDialog();}}catch(error){toast(error.message);}};
    for(const button of form.querySelectorAll('[data-extension-open]'))button.onclick=()=>{closeDialog(null);invoke('extension_open',{id:button.dataset.extensionOpen});};for(const button of form.querySelectorAll('[data-extension-remove]'))button.onclick=async()=>{await invoke('extension_remove',{id:button.dataset.extensionRemove});closeDialog(null);extensionsDialog();};
  }});
}
function renderStatistics(host){const stats=S.stats,maximum=Math.max(1,...stats.daily.map(row=>row[1]));host.insertAdjacentHTML('beforeend',`<section class="settings-card"><h3>${esc(t('Tracking requests blocked'))}</h3><div class="metric">${Number(stats.total).toLocaleString()}</div><div class="chart">${stats.daily.map(([day,count])=>`<div class="chart-day" title="${esc(day)}: ${count}"><small>${count}</small><div class="chart-bar" style="height:${Math.max(2,count/maximum*115)}px"></div><small>${esc(day.slice(8))}</small></div>`).join('')}</div><h3>${esc(t('Top blocked domains'))}</h3><table class="data-table">${stats.top.map(([domain,count])=>`<tr><td>${esc(domain)}</td><td>${count.toLocaleString()}</td></tr>`).join('')}</table></section>`);}
function renderAbout(host){host.insertAdjacentHTML('beforeend',`<section class="settings-card"><div class="about-title"><img class="about-logo" src="${logoURL()}" alt="SuperSearch"><div><h2>SuperSearch ${esc(S.versions.SuperSearch)}</h2><p>${esc(t('Private by choice. Comfortable by design.'))}</p></div></div><h3>${esc(t('Source code'))}</h3><a class="source-link" href="https://github.com/mishandreevy/supersearch" data-source>https://github.com/mishandreevy/supersearch</a><p>${esc(t('SuperSearch brings your everyday web into a personal workspace, with thoughtful privacy controls, secure local storage and an interface that adapts to you.'))}</p><table class="data-table engine-version">${Object.entries(S.versions).map(([key,value])=>`<tr><td>${esc(key)}</td><td>${esc(value)}</td></tr>`).join('')}</table><p class="copyright">MIT · Python + Electron / Chromium · ${esc(t('User data stays on your device.'))}</p></section><section class="settings-card"><h3>${esc(t('Privacy documents'))}</h3><div class="actions">${button('shield','Read Privacy Policy','data-legal="PRIVACY.md"')}${button('file','Read User Agreement','data-legal="TERMS.md"')}</div></section>`);
  host.querySelector('[data-source]').onclick=event=>{event.preventDefault();invoke('source');};for(const button of host.querySelectorAll('[data-legal]'))button.onclick=()=>showLegal(button.dataset.legal);host.insertAdjacentHTML('beforeend',`<section class="settings-card"><h3>${esc(t('Browser tour'))}</h3><p>${esc(t('A short guided tour of tabs, search, privacy and your browser settings.'))}</p>${button('info','Show me around','data-tour')}</section>`);host.querySelector('[data-tour]').onclick=()=>startTour();
}
async function showLegal(name){const text=await invoke('legal',{name});await showDialog(t(name==='TERMS.md'?'User Agreement':'Privacy Policy'),`<div class="legal">${esc(text)}</div>`,null,{submit:false});}

function renderScreen(){
  const screen=$('#screen');if(!S.config.onboarding_complete){screen.hidden=false;const signature='wizard-'+wizardStep+'-'+S.config.language;if(screenSignature!==signature){screenSignature=signature;renderWizard();}return;}
  if(!S.page){screen.hidden=true;screenSignature='';return;}screen.hidden=false;
  const signature=JSON.stringify([S.page,S.config.language,S.page==='downloads'?S.downloads:S.page==='bookmarks'?S.bookmarks:S.page==='history'?S.history:S.page==='passwords'?S.vault:null]);
  if(signature===screenSignature){if(S.page==='settings')updateSettingsFooter();return;}screenSignature=signature;
  if(S.page==='settings'){screen.innerHTML=settingsHTML();bindSettingsShell();renderSettingsContent();return;}
  screen.innerHTML=`<div class="screen-title">${button('back','Back','data-screen-back')}<h1>${esc(t(S.page[0].toUpperCase()+S.page.slice(1)))}</h1><span class="spacer"></span></div><div id="page-content"></div>`;screen.querySelector('[data-screen-back]').onclick=()=>invoke('web');const host=$('#page-content');
  if(S.page==='downloads')renderDownloads(host);if(S.page==='bookmarks'||S.page==='history')renderLibrary(host,S.page==='bookmarks');if(S.page==='passwords')renderPasswords(host);
}
function renderDownloads(host){host.innerHTML=S.downloads.length?S.downloads.map(entry=>`<div class="list-row">${icon('file')}<div class="list-label"><strong>${esc(entry.name||entry.path.split(/[\\/]/).at(-1))}</strong><small>${esc(t(entry.state||'interrupted'))} · ${formatBytes(entry.received||0)} / ${formatBytes(entry.total||0)}</small>${entry.state==='progressing'?`<progress value="${entry.received}" max="${Math.max(1,entry.total)}"></progress>`:''}</div><div class="actions">${entry.state==='progressing'?`<button data-download="${esc(entry.id)}" data-action="${entry.paused?'resume':'pause'}">${icon(entry.paused?'play':'pause')}</button><button data-download="${esc(entry.id)}" data-action="cancel">${icon('close')}</button>`:''}<button data-download="${esc(entry.id)}" data-action="folder" title="${esc(t('Show in folder'))}">${icon('folder')}</button></div></div>`).join(''):`<div class="empty">${esc(t('No downloads yet.'))}</div>`;for(const button of host.querySelectorAll('[data-download]'))button.onclick=()=>invoke('download_action',{id:button.dataset.download,action:button.dataset.action});}
function formatBytes(value){if(value<1024)return value+' B';if(value<1048576)return (value/1024).toFixed(1)+' KB';return (value/1048576).toFixed(1)+' MB';}
function renderLibrary(host,bookmarks){
  const entries=bookmarks?S.bookmarks:S.history;host.innerHTML=`<input class="settings-search" placeholder="${esc(t('Search'))}" data-library-search>`+(entries.length?entries.map((entry,index)=>`<div class="list-row" data-library-row><div class="list-label"><strong>${esc(entry.title)}</strong><small>${esc(entry.url)}${bookmarks?' · '+esc(entry.folder||''):''}</small></div><div class="actions"><button data-open="${index}">${icon('forward')}</button>${bookmarks?`<button data-edit-bookmark="${index}">${icon('edit')}</button><button data-remove-bookmark="${index}">${icon('trash')}</button>`:''}</div></div>`).join(''):`<div class="empty">${esc(t('Nothing saved here yet.'))}</div>`);
  host.querySelector('[data-library-search]').oninput=event=>{const query=event.target.value.toLowerCase();for(const row of host.querySelectorAll('[data-library-row]'))row.hidden=!row.textContent.toLowerCase().includes(query);};for(const button of host.querySelectorAll('[data-open]'))button.onclick=()=>invoke('navigate',{text:entries[button.dataset.open].url});for(const button of host.querySelectorAll('[data-edit-bookmark]'))button.onclick=()=>bookmarkDialog(entries[button.dataset.editBookmark]);for(const button of host.querySelectorAll('[data-remove-bookmark]'))button.onclick=()=>invoke('bookmarks_remove',{url:entries[button.dataset.removeBookmark].url});
}
async function ensureVault(){
  if(S.private){toast(t('The password manager is unavailable in private windows.'));return false;}
  const status=await api.call('vault_status');if(status.unlocked)return true;
  return !!await showDialog(t(status.exists?'Unlock passwords':'Create a master password'),`<p>${esc(t(status.exists?'Enter your master password to unlock locally saved passwords.':'Choose at least 12 characters. Your master password protects the local password vault.'))}</p><label class="field">${esc(t('Master password'))}<input name="master" type="password" minlength="${status.exists?1:12}" autocomplete="off" required></label>${status.exists?'':`<label class="field">${esc(t('Repeat master password'))}<input name="repeat" type="password" autocomplete="off" required></label>`}`,async form=>{if(!status.exists&&form.elements.master.value!==form.elements.repeat.value)throw Error(t('Passwords do not match.'));await api.call(status.exists?'vault_unlock':'vault_create',{password:form.elements.master.value});form.elements.master.value='';if(form.elements.repeat)form.elements.repeat.value='';return true;},{submitLabel:status.exists?'Unlock':'Create'});
}
function renderPasswords(host){
  if(S.private){host.innerHTML=`<p class="note">${esc(t('The password manager is unavailable in private windows.'))}</p>`;return;}
  host.innerHTML=`<div class="actions">${button('key','Unlock passwords','data-unlock')}${button('lock','Lock vault','data-lock')}${button('plus','Add password','data-add-password')}${button('key','Change master password','data-change-master')}</div><p class="note">${esc(t('Passwords are encrypted locally. Filling checks the complete website origin.'))}</p><div data-password-list></div>`;
  const refresh=async()=>{const status=await api.call('vault_status'),listing=host.querySelector('[data-password-list]');if(!listing)return;if(!status.unlocked){listing.innerHTML=`<div class="empty">${esc(t('The vault is locked.'))}</div>`;return;}
    const entries=await api.call('vault_list');listing.innerHTML=entries.length?entries.map((entry,index)=>`<div class="list-row"><div class="list-label"><strong>${esc(entry.origin)}</strong><small>${esc(entry.username)}</small></div><div class="actions"><button data-fill-password="${index}" title="${esc(t('Fill password'))}">${icon('key')}</button><button data-edit-password="${index}" title="${esc(t('Edit'))}">${icon('edit')}</button><button data-delete-password="${index}" title="${esc(t('Delete'))}">${icon('trash')}</button></div></div>`).join(''):`<div class="empty">${esc(t('No saved passwords yet.'))}</div>`;
    for(const button of listing.querySelectorAll('[data-fill-password]'))button.onclick=()=>invoke('password_fill',entries[button.dataset.fillPassword]);for(const button of listing.querySelectorAll('[data-edit-password]'))button.onclick=async()=>{await editPassword(await api.call('vault_get',entries[button.dataset.editPassword]));refresh();};for(const button of listing.querySelectorAll('[data-delete-password]'))button.onclick=async()=>{if(await confirm('Delete password?','This removes the saved login from the local vault.','Delete')){await invoke('vault_remove',entries[button.dataset.deletePassword]);refresh();}};
  };
  host.querySelector('[data-unlock]').onclick=async()=>{await ensureVault();refresh();};host.querySelector('[data-lock]').onclick=async()=>{await invoke('vault_lock');refresh();};host.querySelector('[data-add-password]').onclick=async()=>{if(await ensureVault()){await editPassword();refresh();}};host.querySelector('[data-change-master]').onclick=async()=>{if(!await ensureVault())return;await showDialog(t('Change master password'),`<label class="field">${esc(t('New master password'))}<input name="password" type="password" minlength="12" required></label><label class="field">${esc(t('Repeat master password'))}<input name="repeat" type="password" required></label>`,async form=>{if(form.elements.password.value!==form.elements.repeat.value)throw Error(t('Passwords do not match.'));await api.call('vault_change',{password:form.elements.password.value});return true;});};refresh();
}
async function editPassword(entry=null){const previous=entry?[entry.origin,entry.username]:null;
  await showDialog(t('Saved password'),`<label class="field">${esc(t('Website'))}<input name="origin" required value="${esc(entry?.origin||'https://')}"></label><label class="field">${esc(t('Username'))}<input name="username" value="${esc(entry?.username||'')}"></label><label class="field">${esc(t('Password'))}<input name="password" type="password" required autocomplete="off"></label>`,async form=>{await api.call('vault_save',{origin:form.elements.origin.value,username:form.elements.username.value,password:form.elements.password.value,previous});return true;},{setup:form=>{if(entry)form.elements.password.value=entry.password;}});if(entry)entry.password='';
}
function renderOffer(){
  const signature=JSON.stringify(S.passwordOffer);if(signature===offerSignature)return;offerSignature=signature;const host=$('#password-offer');host.hidden=!S.passwordOffer;if(!S.passwordOffer){host.replaceChildren();return;}
  host.innerHTML=`<h3>${icon('key')} ${esc(t('Save password?'))}</h3><p>${esc(S.passwordOffer.origin)} · ${esc(S.passwordOffer.username)}</p><div class="actions"><button data-offer="decline">${esc(t('Not now'))}</button><button class="primary" data-offer="save">${esc(t('Save'))}</button></div>`;
  host.querySelector('[data-offer=decline]').onclick=()=>invoke('password_decline');host.querySelector('[data-offer=save]').onclick=async()=>{if(await ensureVault())invoke('password_save');};requestAnimationFrame(updateBounds);
}
function showClose(){showDialog(t('Close SuperSearch?'),`<div data-close-dialog><p>${esc(t('Are you sure you want to close this window?'))}</p><label><input name="save" type="checkbox" ${S.modal.save?'checked':''}>${esc(t('Keep my tabs for the next launch'))}</label>${S.private?`<p class="muted">${esc(t('Private tabs are never saved.'))}</p>`:''}</div>`,async form=>{await api.call('close_confirm',{save:form.elements.save.checked});return true;},{submitLabel:'Close',setup:form=>{form.querySelector('[data-cancel]').onclick=()=>{closeDialog(null);invoke('close_cancel');};}});}

async function renderWizard(){
  const revision=++wizardRevision;
  const screen=$('#screen'),languageOptions=Object.entries(B.languages).map(([key,label])=>`<option value="${key}" ${S.config.language===key?'selected':''}>${label}</option>`).join('');
  let content='';
  if(wizardStep===0)content=`<div class="symbol">${icon('shield')}</div><h1 class="wizard-hero">${esc(t('Your web. Your choices.'))}</h1><p class="wizard-lead">${esc(t('Discover a calmer, more personal way to browse. SuperSearch brings privacy controls, secure local password storage and a flexible workspace together in one thoughtfully designed browser. Keep your everyday web close, your choices in your hands, and your interface exactly the way you like it.'))}</p><h2>${esc(t('Have you used SuperSearch before?'))}</h2><div class="welcome-choices" role="group" aria-label="${esc(t('Have you used SuperSearch before?'))}">${[['yes','import','Yes, I am returning','Restore my data from a SuperSearch backup.'],['no','globe','No, this is my first time','Set up my browser and choose an optional tour.']].map(([value,symbol,title,help])=>`<button type="button" data-returning="${value}" aria-pressed="${returningUser===(value==='yes')}" class="welcome-choice ${returningUser===(value==='yes')?'chosen':''}">${icon(symbol)}<span><strong>${esc(t(title))}</strong><small>${esc(t(help))}</small></span>${returningUser===(value==='yes')?icon('check'):''}</button>`).join('')}</div>${returningUser===null?`<p class="muted">${esc(t('Choose an option to continue.'))}</p>`:''}`;
  if(wizardStep===1){wizardLegal||=await api.call('legal',{name:'TERMS.md'});content=`<h1>${esc(t('User Agreement'))}</h1><div class="legal">${esc(wizardLegal)}</div><p><button data-wizard-policy>${esc(t('Read Privacy Policy'))}</button></p><label class="setting-row"><span>${esc(t('I accept the User Agreement'))}</span><input id="agreement" type="checkbox" ${agreement?'checked':''}></label>`;}
  if(wizardStep===2)content=returningUser?`<div class="symbol">${icon('import')}</div><h1>${esc(t('Welcome back'))}</h1><p class="wizard-lead">${esc(t('Choose the encrypted file you exported from Settings → Storage. Your data will be restored after a restart.'))}</p><section class="settings-card"><h3>${esc(t('Restore browser data'))}</h3><p>${esc(t('You will need your backup password and, for saved passwords, your original vault master password.'))}</p>${button('folder','Choose SuperSearch backup','data-wizard-restore')}</section><p>${esc(t('No backup file? You can continue with a fresh setup.'))}</p>`:`<div class="symbol">${icon('info')}</div><h1>${esc(t('Let us show you around'))}</h1><p class="wizard-lead">${esc(t('Discover where to search, manage tabs, control privacy and customize your workspace.'))}</p><label class="settings-card tour-choice"><input id="wizard-tour" type="checkbox" ${showTour?'checked':''}><span><strong>${esc(t('Show a short tour after setup'))}</strong><small>${esc(t('You can skip it at any time or open it later in Settings → About.'))}</small></span></label>`;
  if(wizardStep===3){settingsDraft??=structuredClone(S.config);settingsDraft.suggestions??=false;content=`<h1>${esc(t('Make it yours'))}</h1><p>${esc(t('Changes preview immediately. Network settings may require a restart.'))}</p>${settingsHTML(true)}`;}
  if(wizardStep===4)content=`<h1>${esc(t('Bring your browser data'))}</h1><p>${esc(t('Import what you need, or skip this step.'))}</p><form id="wizard-import">${await importHTML()}<button class="primary" type="submit">${esc(t('Import'))}</button></form>`;
  if(revision!==wizardRevision||S.config.onboarding_complete)return;
  const nextLabel=wizardStep===4?'Start browsing':wizardStep===2&&returningUser?'Continue without a backup':'Continue';
  screen.innerHTML=`<div class="wizard"><header class="wizard-header"><img src="${logoURL()}" alt="SuperSearch"><select id="wizard-language" aria-label="Language">${languageOptions}</select></header><div class="steps">${[0,1,2,3,4].map(step=>`<span class="step ${step===wizardStep?'active':''}">${step+1}</span>`).join('')}</div>${content}<footer class="wizard-footer"><button data-wizard-back ${wizardStep===0?'hidden':''}>${esc(t('Back'))}</button><span class="spacer"></span><button class="primary" id="wizard-continue" ${wizardStep===0&&returningUser===null||wizardStep===1&&!agreement?'disabled':''}>${esc(t(nextLabel))}${icon('forward')}</button></footer></div>`;
  $('#wizard-language').onchange=async event=>{await api.call('settings_apply',{language:event.target.value});if(settingsDraft)settingsDraft.language=event.target.value;screenSignature='';renderScreen();};
  for(const choice of $$('[data-returning]'))choice.onclick=()=>{returningUser=choice.dataset.returning==='yes';showTour=!returningUser;screenSignature='';renderScreen();};
  $('[data-wizard-back]').onclick=()=>{wizardStep--;screenSignature='';renderScreen();};
  $('#agreement')?.addEventListener('change',event=>{agreement=event.target.checked;$('#wizard-continue').disabled=!agreement;});
  $('[data-wizard-policy]')?.addEventListener('click',()=>showLegal('PRIVACY.md'));
  $('[data-wizard-restore]')?.addEventListener('click',restoreBackup);
  $('#wizard-tour')?.addEventListener('change',event=>{showTour=event.target.checked;});
  if(wizardStep===3){bindSettingsShell();renderSettingsContent();}
  if(wizardStep===4){const form=$('#wizard-import');bindImport(form);form.onsubmit=async event=>{event.preventDefault();try{await executeImport(form);}catch(error){toast(error.message);}};}
  $('#wizard-continue').onclick=async()=>{try{
    if(wizardStep===0&&returningUser===null||wizardStep===1&&!agreement)return;
    if(wizardStep===3){await api.call('settings_apply',settingsDraft);settingsDraft=null;}
    if(wizardStep<4){wizardStep++;screenSignature='';renderScreen();}
    else{await api.call('settings_apply',{onboarding_complete:true,terms_version:'2026-11-02',suggestions:S.config.suggestions??false,tour_pending:!returningUser&&showTour,tour_completed:!showTour||!!returningUser});screenSignature='';renderScreen();if(S.restart)await api.call('restart');else api.call('home');}
  }catch(error){toast(error.message);}};
}
const TOUR=[
  ['#address','Search and navigate','Type a website address or a search here. Search suggestions stay optional.'],
  ['#tabs','Your tabs','Open tabs with the plus button. Pin tabs, select several with Ctrl or Shift, and close selected tabs with Delete.'],
  ['#shield','Privacy at hand','Open privacy settings here to choose your protection and connection preferences.'],
  ['#bookmark','Keep useful pages','Save the current page with the star or Ctrl+D. Organize bookmarks into folders.'],
  ['#downloads-button','Your downloads','Downloaded files arrive in your Downloads folder. Follow their progress here.'],
  ['#settings-button','Make SuperSearch yours','Change appearance and panels, manage passwords, or export your data in Storage.'],
  ['.home-tools','Your start page','Choose wallpaper and edit shortcuts. Your original logo and privacy statistics stay close at hand.']
];
async function startTour(){
  if(tourRunning||S.private||!S.config.onboarding_complete)return;
  tourRunning=true;tourIndex=0;
  try{if(modalResolve)closeDialog(null);if(currentPane()?.url==='supersearch:start')await api.call('home');else await api.call('new_tab',{url:'supersearch:start'});await api.call('ui_modal',{open:true});drawTour();}catch(error){tourRunning=false;toast(error.message);}
}
function drawTour(){
  if(!tourRunning)return;
  let layer=$('#tour-layer');if(!layer){layer=document.createElement('div');layer.id='tour-layer';layer.setAttribute('role','dialog');layer.setAttribute('aria-modal','true');document.body.append(layer);}
  const [selector,title,description]=TOUR[tourIndex];
  layer.innerHTML=`<div class="tour-focus" aria-hidden="true"></div><section class="tour-card"><small>${tourIndex+1} / ${TOUR.length}</small><h2>${esc(t(title))}</h2><p>${esc(t(description))}</p><div class="actions"><button data-tour-skip>${esc(t('Skip tour'))}</button><span class="spacer"></span><button data-tour-back ${tourIndex===0?'disabled':''}>${esc(t('Back'))}</button><button class="primary" data-tour-next>${esc(t(tourIndex===TOUR.length-1?'Finish tour':'Next'))}</button></div></section>`;
  layer.querySelector('[data-tour-skip]').onclick=finishTour;
  layer.querySelector('[data-tour-back]').onclick=()=>{tourIndex--;drawTour();};
  layer.querySelector('[data-tour-next]').onclick=()=>{if(tourIndex===TOUR.length-1)finishTour();else{tourIndex++;drawTour();}};
  positionTour();layer.querySelector('[data-tour-next]').focus();
}
function positionTour(){
  if(!tourRunning)return;const layer=$('#tour-layer');if(!layer)return;
  const target=$(TOUR[tourIndex][0]),focus=layer.querySelector('.tour-focus');
  if(!target||!target.getBoundingClientRect().width){focus.hidden=true;return;}
  const rect=target.getBoundingClientRect();focus.hidden=false;
  Object.assign(focus.style,{left:Math.max(2,rect.x-4)+'px',top:Math.max(2,rect.y-4)+'px',width:Math.min(innerWidth-8,rect.width+8)+'px',height:Math.min(innerHeight-8,rect.height+8)+'px'});
}
async function finishTour(){
  tourRunning=false;$('#tour-layer')?.remove();await api.call('ui_modal',{open:false});await invoke('settings_apply',{tour_pending:false,tour_completed:true});
}
window.addEventListener('resize',positionTour);
document.addEventListener('keydown',event=>{if(!tourRunning)return;if(event.key==='Escape'){event.preventDefault();finishTour();}if(event.key==='Tab'){const buttons=[...$('#tour-layer').querySelectorAll('button:not(:disabled)')],index=buttons.indexOf(document.activeElement);event.preventDefault();buttons[(index+(event.shiftKey?-1:1)+buttons.length)%buttons.length].focus();}});

function renderClock(){
  const host=$('#system-status'),show=S.fullscreen&&S.config.titlebar_system_status;host.hidden=!show;
  if(!show){if(clockTimer)clearInterval(clockTimer);clockTimer=null;host.replaceChildren();return;}
  const update=()=>{host.innerHTML=`<span>${new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',hour12:false})}</span>`+(S.battery?`${icon(S.battery.charging?'battery-charging':'battery')}<span>${S.battery.percent}%</span>`:'');};update();if(!clockTimer)clockTimer=setInterval(update,1000);
}
async function keyboardHelp(){const keys=[['Ctrl+T','New tab'],['Ctrl+W / Ctrl+F4','Close tab'],['Ctrl+L','Address and search'],['Ctrl+D','Bookmark'],['Ctrl+H','History'],['Ctrl+,','Settings'],['Ctrl+J','Downloads'],['Ctrl+Shift+N','New private window'],['Ctrl+\\','Split view'],['Ctrl+Shift+K','Pin selected tabs'],['Ctrl+Tab / Ctrl+Shift+Tab','Switch tabs'],['Ctrl+1…9','Select tab'],['Ctrl+F','Find on page'],['F11','Full screen'],['F5','Reload'],['Ctrl / Shift + click','Select multiple tabs'],['Delete','Close selected tabs']];await showDialog(t('Keyboard shortcuts'),`<table class="data-table">${keys.map(([key,label])=>`<tr><td><code>${esc(key)}</code></td><td>${esc(t(label))}</td></tr>`).join('')}</table>`,null,{submit:false});}
async function browserMenu(){
  await showDialog(t('Menu'),`<div class="actions">${[['settings','Customize interface','appearance'],['image','Customize start page','home-editor'],['lock','New private window','private'],['download','Downloads','downloads'],['key','Saved passwords','passwords'],['split','Split view','split'],['info','Keyboard shortcuts','keys'],['home','Start page','home'],['fullscreen','Full screen','fullscreen']].map(([symbol,label,action])=>button(symbol,label,`type="button" data-menu-action="${action}"`)).join('')}</div>`,null,{submit:false,setup:form=>{for(const button of form.querySelectorAll('[data-menu-action]'))button.onclick=()=>{const action=button.dataset.menuAction;closeDialog(null);if(action==='appearance'){settingsCategory='Appearance';invoke('settings');}else if(action==='home-editor')customizeHome();else if(action==='keys')keyboardHelp();else invoke(action);};}});
}

$('#address-form').onsubmit=event=>{event.preventDefault();closeSuggestions();invoke('navigate',{text:$('#address').value});};suggestions($('#address'),text=>invoke('navigate',{text}));
for(const [id,action] of Object.entries({minimize:'minimize',expand:'expand',close:'close_window','new-tab':'new_tab',back:'back',forward:'forward',reload:'reload',split:'split','settings-button':'settings','downloads-button':'downloads','bookmarks-button':'bookmarks',passwords:'passwords'}))$('#'+id).onclick=()=>invoke(action);
$('#collapse').onclick=()=>invoke('settings_apply',{sidebar_collapsed:!S.config.sidebar_collapsed});$('#shield').onclick=()=>{settingsCategory='Privacy';invoke('settings');};$('#bookmark').onclick=()=>bookmarkDialog();$('#menu').onclick=()=>browserMenu();
$('#titlebar').ondblclick=event=>{if(!event.target.closest('button'))invoke('expand');};
$('#sidebar').ondblclick=event=>{if(S.config.sidebar_position==='top'&&!event.target.closest('button'))invoke('expand');};
$('#tabs').addEventListener('wheel',event=>{if(['top','bottom'].includes(S.config.sidebar_position)&&Math.abs(event.deltaY)>Math.abs(event.deltaX)){$('#tabs').scrollLeft+=event.deltaY;event.preventDefault();}},{passive:false});
$('#find-text').oninput=event=>api.call('find',{text:event.target.value});$('#find-close').onclick=()=>{$('#find-bar').hidden=true;api.call('stop_find');updateBounds();};
$('#sidebar-resizer').onpointerdown=event=>{
  const handle=event.currentTarget,position=S.config.sidebar_position,horizontal=['top','bottom'].includes(position);
  if(horizontal)return;
  const start=horizontal?event.clientY:event.clientX,key=horizontal?'sidebar_height':'sidebar_width',initial=S.config[key];let value=initial;
  handle.setPointerCapture(event.pointerId);
  handle.onpointermove=move=>{const delta=((horizontal?move.clientY:move.clientX)-start)*(position==='right'||position==='bottom'?-1:1);value=Math.round(Math.max(horizontal?120:160,Math.min(horizontal?600:640,initial+delta)));document.documentElement.style.setProperty(horizontal?'--sidebar-height':'--sidebar',value+'px');updateBounds();};
  handle.onpointerup=()=>{handle.onpointermove=null;invoke('settings_apply',{[key]:value});};
};
function finishCustomization(){customizing=false;document.body.removeAttribute('data-drop-edge');$$('[data-panel-grip]').forEach(element=>element.remove());api.call('ui_modal',{open:false});}
function beginCustomization(){
  if(customizing)return;customizing=true;api.call('ui_modal',{open:true});
  toast(t('Drag a panel handle to a window edge. Press Escape to finish.'));
  for(const [selector,kind] of [['.sidebar-top','sidebar'],['#navigation','navigation']]){
    const grip=document.createElement('button');grip.dataset.panelGrip=kind;grip.innerHTML=icon('menu');grip.title=t('Move panel');$(selector).append(grip);
    grip.onpointerdown=event=>{event.preventDefault();grip.setPointerCapture(event.pointerId);let edge=kind==='sidebar'?S.config.sidebar_position:S.config.navigation_position;
      grip.onpointermove=move=>{const rect=$('#workspace').getBoundingClientRect(),distances={left:move.clientX-rect.left,right:rect.right-move.clientX,top:move.clientY-rect.top,bottom:rect.bottom-move.clientY};edge=Object.keys(distances).filter(key=>kind==='sidebar'||['top','bottom'].includes(key)).sort((a,b)=>distances[a]-distances[b])[0];document.body.dataset.dropEdge=edge;};
      grip.onpointerup=()=>{finishCustomization();invoke('settings_apply',{[kind==='sidebar'?'sidebar_position':'navigation_position']:edge});};
    };
  }
}
document.addEventListener('keydown',event=>{
  if(event.key==='Escape'&&customizing)finishCustomization();
  if(event.key==='Escape'&&modalResolve&&$('#modal-layer form')?.dataset.busy!=='true'){closeDialog(null);if(S.modal)invoke('close_cancel');}
  if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='f'&&$('#settings-search')&&(!S.config.onboarding_complete||S.page==='settings')){event.preventDefault();$('#settings-search')?.focus();}
});
window.addEventListener('blur',closeSuggestions);
api.subscribe(render);
api.event(message=>{
  if(message.type==='error')toast(message.message);
  if(message.type==='settings_find'){$('#settings-search')?.focus();$('#settings-search')?.select();}
  if(message.type==='customize'){invoke('web').then(beginCustomization);}
  if(message.type==='keyboard_help')keyboardHelp();if(message.type==='tour')startTour();
  if(message.type==='focus_address'){$('#address').focus();$('#address').select();}
  if(message.type==='bookmark')bookmarkDialog();if(message.type==='pin_selection')invoke('pin',{ids:selected.size?[...selected]:[S.active]});
  if(message.type==='find'){$('#find-bar').hidden=false;$('#find-text').focus();updateBounds();}
  if(message.type==='download-start'){
    const target=$('#downloads-button'),end=target.getBoundingClientRect(),flight=$('#download-flight');target.classList.add('download-pulse');setTimeout(()=>target.classList.remove('download-pulse'),650);
    if(S.config.animations){flight.innerHTML=icon('file');flight.hidden=false;const animation=flight.animate([{left:(message.click.x/(S.config.ui_scale/100))+'px',top:(message.click.y/(S.config.ui_scale/100))+'px',transform:'scale(1)',opacity:1},{left:(end.x+end.width/2)+'px',top:(end.y+end.height/2)+'px',transform:'scale(.3)',opacity:.2}],{duration:650,easing:'cubic-bezier(.3,.5,.2,1)'});animation.onfinish=()=>flight.hidden=true;}
  }
});
api.call('bootstrap').then(value=>{B=value.bootstrap;render(value.state);api.call('ui_ready');}).catch(error=>{$('#screen').hidden=false;$('#screen').textContent=error.message;});
```

### main.py
```python
"""Start the verified Electron/Chromium browser and its local Python service."""
import os
import sys


def wait_for_restart():
    """Wait for the previous process to release Chromium's profile lock."""
    if '--wait-for-pid' not in sys.argv:
        return
    index = sys.argv.index('--wait-for-pid')
    try:
        pid = int(sys.argv[index + 1])
        if pid <= 0 or pid == os.getpid():
            raise ValueError('Invalid restart PID')
    except (IndexError, ValueError) as exc:
        raise RuntimeError('Invalid restart arguments') from exc
    del sys.argv[index:index + 2]
    if sys.platform == 'win32':
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        kernel.WaitForSingleObject.restype = wintypes.DWORD
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        handle = kernel.OpenProcess(0x00100000, False, pid)
        if handle:
            try:
                if kernel.WaitForSingleObject(handle, 30000) != 0:
                    raise RuntimeError('Previous SuperSearch process is still running')
            finally:
                kernel.CloseHandle(handle)
    else:
        import time
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                return
            time.sleep(.1)
        raise RuntimeError('Previous SuperSearch process is still running')


def main():
    wait_for_restart()
    if "--qt" in sys.argv:
        raise SystemExit("The Qt version has been removed. Start SuperSearch without --qt.")
    from core.electron_launcher import launch
    launch(sys.argv[1:])


if __name__=="__main__":main()
```

### requirements.txt
```text
# Local data service. The Chromium/Electron runtime is pinned in engine/runtime.json.
requests[socks]>=2.31.0
cryptography>=43.0.0
Pillow>=10.4.0
```

### run.bat
```bat
@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
    py -3 -m venv .venv
    if errorlevel 1 exit /b 1
)
.venv\Scripts\python.exe tools\check_runtime.py
if errorlevel 1 (
    .venv\Scripts\python.exe -c "import sys; sys.exit('Python 3.10 or newer is required for this browser runtime.') if sys.version_info < (3, 10) else None"
    if errorlevel 1 exit /b 1
    .venv\Scripts\python.exe -m pip install --upgrade -r requirements.txt
    if errorlevel 1 exit /b 1
    .venv\Scripts\python.exe tools\check_runtime.py
    if errorlevel 1 exit /b 1
)
.venv\Scripts\python.exe main.py %*
```

### run.sh
```bash
#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if [ ! -x .venv/bin/python ]; then
    python3 -m venv .venv
fi
if ! .venv/bin/python tools/check_runtime.py; then
    .venv/bin/python -c 'import sys; sys.exit("Python 3.10 or newer is required for this browser runtime.") if sys.version_info < (3, 10) else None'
    .venv/bin/python -m pip install --upgrade -r requirements.txt
    .venv/bin/python tools/check_runtime.py
fi
exec .venv/bin/python main.py "$@"
```

### settings/config.py
```python
"""Local configuration and dictionary translations."""
import json
import os
from copy import deepcopy
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = Path(os.environ.get('SUPERSEARCH_DATA', ROOT / 'data'))
DATA.mkdir(parents=True,exist_ok=True)
DEFAULTS = dict(language='en', search='DuckDuckGo', homepage='supersearch:start',
                suggestions=None, theme='light', colors={}, font='Sans Serif', radius=18,
                spacing=8, dark_sites=False, preset='standard', block_ads=True,
                fingerprint=True, webrtc=True, geolocation=True, javascript=False,
                https_only=True, strip_params=True, third_party=True, doh='Off',
                proxy='', tor=False, wallpaper='', bookmark_bar=True,
                config_version=3, onboarding_complete=False, tour_pending=False, tour_completed=False, terms_version='', titlebar_height=38,
                titlebar_show_title=True, titlebar_accent=False, ephemeral_profile=True, remember_history=False,
                titlebar_show_expand=False,window_expand_mode='maximized',titlebar_system_status=True,
                block_referrers=True, gpc=True, webgl=True, canvas=True,
                userscripts_private=False, allow_popups=False, animations=True,
                ui_scale=100, page_zoom=100, sidebar_width=240, sidebar_height=210, sidebar_collapsed=False,
                tab_height=48, icon_size=24, toolbar_size=38, shape='rounded',
                home_columns=6, home_tile_size=120, home_width=960, home_logo=True,
                home_search=True, home_stats=True, home_ip=True, home_align='center',
                layout_state='', window_geometry='', layout_locked=True,
                nav_order=['back','forward','reload','address','shield','split','passwords','bookmark','menu'],
                nav_hidden=[], extension_enabled=[], confirm_close=True, restore_tabs=False)

PRESETS = {
    'standard': dict(block_ads=True, fingerprint=True, webrtc=True, geolocation=True,
                     javascript=False, https_only=True, strip_params=True, third_party=True, tor=False, doh='Off', webgl=True, canvas=True),
    'strict': dict(block_ads=True, fingerprint=True, webrtc=True, geolocation=True,
                   javascript=False, https_only=True, strip_params=True, third_party=True,
                   doh='Quad9', tor=False, ephemeral_profile=True, remember_history=False, webgl=False, canvas=False),
    'paranoia': dict(block_ads=True, fingerprint=True, webrtc=True, geolocation=True,
                     javascript=True, https_only=True, strip_params=True, third_party=True,
                     tor=True, doh='Off', ephemeral_profile=True, remember_history=False, webgl=False, canvas=False, suggestions=False),
}
PALETTES = {
    'dark': dict(bg='#16181f', panel='#222530', fg='#eceef5', accent='#8bafff'),
    'light': dict(bg='#f5f6fa', panel='#ffffff', fg='#182033', accent='#2459b8'),
    'oled': dict(bg='#000000', panel='#101010', fg='#eeeeee', accent='#91b4ff'),
}
# English is the fallback for technical labels; all navigation is translated.
WORDS = {
    'en': dict(settings='Settings', privacy='Privacy', appearance='Appearance', general='General',
               extensions='Extensions', statistics='Statistics', about='About', new_tab='New tab',
               history='History', bookmarks='Bookmarks', blocked='Blocked trackers', close='Close',
               restart='requires restart', language='Language', search='Search engine', homepage='Homepage',
               suggestions='Search suggestions', dark_sites='Dark websites', update='Update filters',
               test='Test proxy', install='Install UserScript', private='Private window', total='Total',
               daily='Daily blocks (last 14 days)', top='Top blocked domains', remove='Remove'),
    'ru': dict(settings='Настройки', privacy='Приватность', appearance='Оформление', general='Общие',
               extensions='Расширения', statistics='Статистика', about='О программе', new_tab='Новая вкладка',
               history='История', bookmarks='Закладки', blocked='Заблокировано трекеров', close='Закрыть',
               restart='нужен перезапуск', language='Язык', search='Поисковик', homepage='Домашняя страница',
               suggestions='Подсказки поиска', dark_sites='Тёмные сайты', update='Обновить фильтры',
               test='Проверить прокси', install='Установить UserScript', private='Приватное окно', total='Всего',
               daily='Блокировки за 14 дней', top='Чаще блокируемые домены', remove='Удалить'),
    'de': dict(settings='Einstellungen', privacy='Datenschutz', appearance='Darstellung', general='Allgemein',
               extensions='Erweiterungen', statistics='Statistik', about='Über', new_tab='Neuer Tab',
               history='Verlauf', bookmarks='Lesezeichen', blocked='Blockierte Tracker', close='Schließen',
               restart='Neustart erforderlich', language='Sprache', search='Suchmaschine', homepage='Startseite',
               suggestions='Suchvorschläge', dark_sites='Dunkle Webseiten', update='Filter aktualisieren',
               test='Proxy testen', install='UserScript installieren', private='Privates Fenster', total='Gesamt',
               daily='Letzte 14 Tage', top='Häufigste Domains', remove='Entfernen'),
    'fr': dict(settings='Paramètres', privacy='Confidentialité', appearance='Apparence', general='Général',
               extensions='Extensions', statistics='Statistiques', about='À propos', new_tab='Nouvel onglet',
               history='Historique', bookmarks='Favoris', blocked='Traqueurs bloqués', close='Fermer',
               restart='redémarrage requis', language='Langue', search='Moteur de recherche', homepage='Accueil',
               suggestions='Suggestions', dark_sites='Sites sombres', update='Actualiser les filtres',
               test='Tester le proxy', install='Installer UserScript', private='Fenêtre privée', total='Total',
               daily='14 derniers jours', top='Domaines bloqués', remove='Supprimer'),
    'es': dict(settings='Ajustes', privacy='Privacidad', appearance='Apariencia', general='General',
               extensions='Extensiones', statistics='Estadísticas', about='Acerca de', new_tab='Nueva pestaña',
               history='Historial', bookmarks='Marcadores', blocked='Rastreadores bloqueados', close='Cerrar',
               restart='requiere reinicio', language='Idioma', search='Buscador', homepage='Inicio',
               suggestions='Sugerencias', dark_sites='Sitios oscuros', update='Actualizar filtros',
               test='Probar proxy', install='Instalar UserScript', private='Ventana privada', total='Total',
               daily='Últimos 14 días', top='Dominios bloqueados', remove='Eliminar'),
}


def read_json(path, default):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return default


def write_json(path, value):
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(str(temp), str(path))


class Config(dict):
    def __init__(self):
        super().__init__(deepcopy(DEFAULTS))
        saved = read_json(DATA / 'settings.json', {})
        if isinstance(saved, dict):
            self.update(saved)
            if saved.get('config_version', 0) < 3:
                self.update(theme='light', colors={}, dark_sites=False, config_version=3)
        self['dark_sites'] = False

    def save(self):
        write_json(DATA / 'settings.json', self)

    def palette(self):
        return dict(PALETTES.get(self['theme'], PALETTES['dark']), **self['colors'])


config = Config()
LANGUAGE = config['language']


def tr(key):
    return WORDS.get(config['language'], WORDS['en']).get(key, WORDS['en'].get(key, key))
```

### settings/i18n.py
```python
"""English source text with explicit dictionaries and immediate widget relabeling."""
import json
from pathlib import Path
from settings.config import config, WORDS

LANGUAGES = {'en':'English','ru':'Русский','de':'Deutsch','fr':'Français','es':'Español'}
CATALOG_DIR = Path(__file__).resolve().parent / 'translations'
_catalogs = {}
_reverse_sources = None
_word_keys = {value:key for key,value in WORDS['en'].items()}


def catalog(language):
    if language not in _catalogs:
        path=CATALOG_DIR/(language+'.json')
        try:
            _catalogs[language]=json.loads(path.read_text(encoding='utf-8'))
        except (OSError,ValueError):
            _catalogs[language]={}
    return _catalogs[language]


def english(text):
    global _reverse_sources
    for words in WORDS.values():
        suffix=' ('+words.get('restart','requires restart')+')'
        if text.endswith(suffix):
            return english(text[:-len(suffix)])+' (requires restart)'
    if _reverse_sources is None:
        reverse={}
        for words in WORDS.values():
            for key,value in words.items():reverse.setdefault(value,WORDS['en'].get(key,value))
        for language in LANGUAGES:
            if language=='en':continue
            for source,localized in catalog(language).items():reverse.setdefault(localized,source)
        _reverse_sources=reverse
    return _reverse_sources.get(text,text)


def translate(text):
    source=english(text)
    language=config['language']
    suffix=' (requires restart)'
    if source.endswith(suffix):
        return translate(source[:-len(suffix)])+' ('+WORDS.get(language,WORDS['en'])['restart']+')'
    if language=='en':
        return source
    if source in _word_keys:
        return WORDS.get(language,{}).get(_word_keys[source],source)
    return catalog(language).get(source,source)
```

### settings/metadata.py
```python
"""Plain-data privacy descriptions and presets for the browser interface."""
PRESET_LABELS={'standard':'Balanced','strict':'Stronger','paranoia':'Maximum'}

PRESET_HELP={
 'standard':'Recommended for everyday browsing. Blocks known trackers and keeps most websites working.',
 'strict':'Adds tighter website restrictions. Some graphics and sign-in features may not work.',
 'paranoia':'Requires a running Tor service and turns off website JavaScript. Many websites will not work.'}

PRIVACY_OPTIONS={
 'block_ads':('Block ads and trackers','Stop requests to known advertising and tracking services.'),
 'https_only':('Use secure connections only','Upgrade HTTP addresses to HTTPS. Websites without HTTPS will not open.'),
 'strip_params':('Remove tracking tags from links','Clean common advertising parameters from website addresses.'),
 'third_party':('Limit tracking between websites','Block third-party cookies and storage. Some embedded sign-ins may not work.'),
 'block_referrers':('Hide the previous website address','Do not send websites the address of the page you came from.'),
 'gpc':('Ask websites not to track me','Send privacy preference signals. Websites decide whether to honor them.'),
 'ephemeral_profile':('Forget website data when I close SuperSearch','Cookies stay in memory, so you may need to sign in again after a restart. Bookmarks and saved passwords are kept.'),
 'fingerprint':('Reduce browser fingerprinting','Make some device details harder to read. This cannot prevent every form of fingerprinting.'),
 'webrtc':('Restrict direct browser connections','Limits WebRTC network exposure. Voice and video calls may not work.'),
 'geolocation':('Extra location blocking','Block the location API in website scripts. Website permissions are already denied by default.'),
 'javascript':('Turn off website JavaScript','Many websites and sign-in forms stop working. Leave this off for everyday browsing.'),
 'webgl':('Allow 3D graphics on websites','Needed by some maps, games and visual tools. It can reveal graphics-device details.'),
 'canvas':('Allow sites to read drawn images','Needed by some drawing and verification tools. It can reveal device details.'),
 'allow_popups':('Let websites open new windows','Links and scripts that open another window may be blocked when this is off.'),
 'tor':('Use Tor for connections','Start Tor on this device first. Uses 127.0.0.1:9050 and takes priority over the proxy address.'),
}
```

### settings/translations/de.json
```json
{
  "Welcome to SuperSearch": "Willkommen bei SuperSearch",
  "About the browser": "Über den Browser",
  "Agreement": "Vereinbarung",
  "Setup": "Einrichtung",
  "Import": "Importieren",
  "Done": "Fertig",
  "Your web. Your choices.": "Dein Web. Deine Entscheidungen.",
  "Local data": "Lokale Daten",
  "Your workspace": "Dein Arbeitsbereich",
  "An easy switch": "Ein einfacher Wechsel",
  "Protect passwords with a master password and forget website data after each session.": "Schütze Passwörter mit einem Hauptpasswort und vergiss Websitedaten nach jeder Sitzung.",
  "Move panels, resize controls and make the start page your own.": "Verschiebe Bereiche, ändere die Größe der Bedienelemente und gestalte deine Startseite.",
  "Bring bookmarks and compatible data from your selected Chromium profile.": "Übernimm Lesezeichen und kompatible Daten aus deinem ausgewählten Chromium-Profil.",
  "I accept the user agreement and have read the privacy policy": "Ich akzeptiere die Nutzungsvereinbarung und habe die Datenschutzerklärung gelesen",
  "Theme": "Design",
  "light": "Hell",
  "dark": "Dunkel",
  "oled": "OLED",
  "standard": "Standard",
  "strict": "Streng",
  "paranoia": "Paranoia",
  "Off": "Aus",
  "Search engine": "Suchmaschine",
  "Search suggestions": "Suchvorschläge",
  "Choose whether you want search suggestions": "Wähle, ob du Suchvorschläge möchtest",
  "No, keep typing private until I search": "Nein, Eingaben erst beim Suchen senden",
  "Yes, show DuckDuckGo suggestions": "Ja, DuckDuckGo-Vorschläge anzeigen",
  "Forget website data after exit (session profile)": "Websitedaten nach dem Beenden vergessen (Sitzungsprofil)",
  "Save browsing history": "Browserverlauf speichern",
  "Network": "Netzwerk",
  "Standard secure connection": "Normale sichere Verbindung",
  "Tor via 127.0.0.1:9050": "Tor über 127.0.0.1:9050",
  "Tor requires a separately running Tor service. Without it, websites cannot load. Setup keeps JavaScript available for modern websites.": "Tor benötigt einen separat laufenden Tor-Dienst. Ohne ihn werden Websites nicht geladen. Die Einrichtung lässt JavaScript für moderne Websites aktiviert.",
  "Ready for your first search": "Bereit für deine erste Suche",
  "Back": "Zurück",
  "Continue": "Weiter",
  "Start browsing": "Surfen starten",
  "Changes preview immediately. Startup network settings apply when the browser restarts.": "Änderungen werden sofort angezeigt. Netzwerk-Startparameter gelten nach einem Neustart.",
  "Choose a profile folder manually": "Profilordner manuell auswählen",
  "Detect browsers again": "Browser erneut suchen",
  "Default or Profile 1 folder": "Ordner Default oder Profile 1",
  "Folder": "Ordner",
  "Bookmarks and folders": "Lesezeichen und Ordner",
  "History": "Verlauf",
  "Download history (files are not copied)": "Downloadverlauf (Dateien werden nicht kopiert)",
  "Readable cookies (protected cookies are skipped)": "Lesbare Cookies (geschützte werden übersprungen)",
  "Compatible general settings": "Kompatible allgemeine Einstellungen",
  "Optional password CSV": "Optionale Passwort-CSV",
  "Password CSV": "Passwort-CSV",
  "Import everything available from this browser": "Alle verfügbaren Daten dieses Browsers importieren",
  "Import selected data": "Ausgewählte Daten importieren",
  "You can skip import and run it later in Storage settings.": "Du kannst den Import überspringen und später unter Speicher ausführen.",
  "Chromium profile": "Chromium-Profil",
  "Choose a profile folder or password CSV.": "Wähle einen Profilordner oder eine Passwort-CSV.",
  "Imported: ": "Importiert: ",
  "Settings": "Einstellungen",
  "Privacy": "Datenschutz",
  "Appearance": "Darstellung",
  "General": "Allgemein",
  "Extensions": "Erweiterungen",
  "Statistics": "Statistik",
  "Storage": "Speicher",
  "About": "Über",
  "Preset": "Voreinstellung",
  "Tracker / advertising filters": "Tracker- und Werbefilter",
  "Anti-fingerprinting JS (best effort)": "JavaScript gegen Fingerprinting (nach Möglichkeit)",
  "Block WebRTC": "WebRTC blockieren",
  "Block geolocation JS": "Geolokalisierung per JavaScript blockieren",
  "Disable all JavaScript": "JavaScript vollständig deaktivieren",
  "HTTPS only": "Nur HTTPS",
  "Remove tracking parameters": "Tracking-Parameter entfernen",
  "Block third-party cookies / storage": "Cookies und Speicher von Drittanbietern blockieren",
  "Tor SOCKS5 — 127.0.0.1:9050": "Tor SOCKS5 — 127.0.0.1:9050",
  "Session profile: website data stays in memory": "Sitzungsprofil: Websitedaten bleiben im Arbeitsspeicher",
  "Do not send Referer headers": "Keine Referer-Header senden",
  "Global Privacy Control and Do Not Track signals": "Global Privacy Control und Do Not Track",
  "Allow WebGL (may expose GPU information)": "WebGL erlauben (kann GPU-Informationen offenlegen)",
  "Allow canvas readback (required by some websites)": "Canvas-Auslesen erlauben (für manche Websites nötig)",
  "Allow JavaScript popups": "JavaScript-Popups erlauben",
  "Run UserScripts in private windows": "UserScripts in privaten Fenstern ausführen",
  "DNS over HTTPS": "DNS über HTTPS",
  "Proxy": "Proxy",
  "Test proxy": "Proxy testen",
  "Update filters": "Filter aktualisieren",
  "requires restart": "Neustart erforderlich",
  "Background": "Hintergrund",
  "Surface": "Fläche",
  "Text": "Text",
  "Accent": "Akzent",
  "Font": "Schrift",
  "Control shape": "Form der Bedienelemente",
  "Rounded": "Abgerundet",
  "Pill": "Kapsel",
  "Square": "Eckig",
  "Interface animations": "Oberflächenanimationen",
  "Show the title in the title bar": "Titel in der Titelleiste anzeigen",
  "Use the surface color for the title bar": "Flächenfarbe für die Titelleiste verwenden",
  "Corner radius": "Eckenradius",
  "Spacing": "Abstände",
  "Interface scale, %": "Oberflächenskalierung, %",
  "Page zoom, %": "Seitenzoom, %",
  "Tab panel width": "Breite der Tableiste",
  "Horizontal panel height": "Höhe horizontaler Bereiche",
  "Tab height": "Tabhöhe",
  "Icon size": "Symbolgröße",
  "Address bar height": "Höhe der Adressleiste",
  "Title bar height": "Höhe der Titelleiste",
  "Drag rows to arrange toolbar buttons. Check a row to show its button.": "Ziehe Zeilen, um die Schaltflächen anzuordnen. Ein Häkchen zeigt die Schaltfläche an.",
  "Move panels with the mouse": "Bereiche mit der Maus verschieben",
  "Reset panel layout": "Bereichsanordnung zurücksetzen",
  "Start page": "Startseite",
  "Content alignment": "Inhaltsausrichtung",
  "Show the logo": "Logo anzeigen",
  "Show the search field": "Suchfeld anzeigen",
  "Show privacy counters": "Datenschutzzähler anzeigen",
  "Shortcut columns": "Spalten der Verknüpfungen",
  "Shortcut tile size": "Größe der Verknüpfungskacheln",
  "Start page content width": "Inhaltsbreite der Startseite",
  "Edit shortcuts and wallpaper": "Verknüpfungen und Hintergrund bearbeiten",
  "Choose wallpaper": "Hintergrundbild auswählen",
  "Language": "Sprache",
  "Homepage": "Startseite",
  "Confirm before closing a window": "Schließen eines Fensters bestätigen",
  "Restore saved tabs on the next launch": "Gespeicherte Tabs beim nächsten Start wiederherstellen",
  "Show the bookmarks toolbar": "Lesezeichenleiste anzeigen",
  "The theme styles the browser interface. Websites keep their own colors.": "Das Design gilt für die Browseroberfläche. Websites behalten ihre eigenen Farben.",
  "Suggestions send typed queries to DuckDuckGo (normal windows only).": "Vorschläge senden eingegebene Suchtexte an DuckDuckGo (nur normale Fenster).",
  "UserScript installation and removal are explicit actions that apply immediately.": "Installation und Entfernen von UserScripts werden sofort ausgeführt.",
  "Manifest V3 extension manager": "Verwaltung für Manifest-V3-Erweiterungen",
  "Install UserScript": "UserScript installieren",
  "Remove": "Entfernen",
  "Total": "Gesamt",
  "Daily blocks (last 14 days)": "Blockierungen pro Tag (letzte 14 Tage)",
  "Top blocked domains": "Am häufigsten blockierte Domains",
  "Domain": "Domain",
  "Manage local data": "Lokale Daten verwalten",
  "Cookies and site data — sign out of websites": "Cookies und Websitedaten — von Websites abmelden",
  "Page and graphics cache": "Seiten- und Grafikcache",
  "Local passwords and master password": "Lokale Passwörter und Hauptpasswort",
  "History and statistics": "Verlauf und Statistik",
  "Bookmarks": "Lesezeichen",
  "Pinned tabs": "Angeheftete Tabs",
  "Download history": "Downloadverlauf",
  "Files downloaded by SuperSearch": "Von SuperSearch heruntergeladene Dateien",
  "Delete selected data and restart": "Ausgewählte Daten löschen und neu starten",
  "Reset the entire browser": "Browser vollständig zurücksetzen",
  "Import from another browser": "Aus einem anderen Browser importieren",
  "Select Apply to save your changes.": "Wähle Anwenden, um die Änderungen zu speichern.",
  "Apply": "Anwenden",
  "Close": "Schließen",
  "Cancel": "Abbrechen",
  "Restart": "Neu starten",
  "You have unapplied changes.": "Es gibt noch nicht übernommene Änderungen.",
  "Settings applied.": "Einstellungen übernommen.",
  "Pinned tab": "Angehefteter Tab",
  "Pin selected tabs": "Ausgewählte Tabs anheften",
  "Unpin selected tabs": "Ausgewählte Tabs lösen",
  "Close selected tabs": "Ausgewählte Tabs schließen",
  "Keyboard shortcuts": "Tastenkombinationen",
  "Shortcut": "Tastenkürzel",
  "Action": "Aktion",
  "New tab": "Neuer Tab",
  "Close current tab": "Aktuellen Tab schließen",
  "Close window": "Fenster schließen",
  "Next tab": "Nächster Tab",
  "Previous tab": "Vorheriger Tab",
  "Switch to a numbered tab": "Zu einem nummerierten Tab wechseln",
  "Switch to the last tab": "Zum letzten Tab wechseln",
  "Pin or unpin selected tabs": "Ausgewählte Tabs anheften oder lösen",
  "Select individual tabs": "Einzelne Tabs auswählen",
  "Select a range of tabs": "Einen Bereich von Tabs auswählen",
  "Select all tabs when the tab panel is focused": "Alle Tabs auswählen, wenn die Tableiste fokussiert ist",
  "Close selected tabs when the tab panel is focused": "Ausgewählte Tabs bei fokussierter Tableiste schließen",
  "Focus address bar": "Adressleiste fokussieren",
  "Bookmark the current page": "Aktuelle Seite als Lesezeichen speichern",
  "Toggle bookmarks toolbar": "Lesezeichenleiste ein- oder ausblenden",
  "New private window": "Neues privates Fenster",
  "Customize panel layout": "Bereichsanordnung anpassen",
  "Toggle split view": "Geteilte Ansicht umschalten",
  "Reload": "Neu laden",
  "Full screen": "Vollbild",
  "Page zoom": "Seitenzoom",
  "Read Privacy Policy": "Datenschutzerklärung lesen",
  "Read User Agreement": "Nutzungsvereinbarung lesen",
  "Discover a calmer, more personal way to browse. SuperSearch brings privacy controls, secure local password storage and a flexible workspace together in one thoughtfully designed browser. Keep your everyday web close, your choices in your hands, and your interface exactly the way you like it.": "Entdecke entspanntes, persönliches Surfen. SuperSearch vereint Datenschutz, sichere lokale Passwortspeicherung und einen flexiblen Arbeitsbereich in einem durchdachten Browser. Behalte dein alltägliches Web im Blick, deine Entscheidungen in der Hand und gestalte die Oberfläche genau nach deinen Wünschen.",
  "Your choices are already previewed. Select Start browsing to finish setup and save them. Startup network or profile changes may restart the browser once. Your tabs, shortcuts and privacy controls are ready when you are.": "Deine Auswahl wird bereits angezeigt. Wähle Surfen starten, um die Einrichtung abzuschließen und zu speichern. Änderungen an Startparametern oder Profilen können einen Neustart erfordern. Tabs, Verknüpfungen und Datenschutzfunktionen stehen bereit.",
  "Select a Chromium profile and data categories. The source browser is not changed. Passwords require a CSV exported by the source browser; the file contains unencrypted passwords. Protected cookies and account sessions may require signing in again.": "Wähle ein Chromium-Profil und die Datenkategorien. Der ursprüngliche Browser wird nicht verändert. Passwörter benötigen eine vom Browser exportierte CSV mit unverschlüsselten Passwörtern. Geschützte Cookies und Kontositzungen können eine erneute Anmeldung erfordern.",
  "Choose which data to delete. Cookies and site data are cleared after Chromium closes; the browser restarts automatically. Signing out does not delete your accounts with website providers.": "Wähle die zu löschenden Daten. Cookies und Websitedaten werden nach dem Schließen von Chromium entfernt; der Browser startet automatisch neu. Das Abmelden löscht deine Konten bei den Website-Anbietern nicht.",
  "Default deny: camera, microphone, location, notifications.\nJS spoofing is best effort; sites and workers can bypass it.\nDoH / Chromium flags depend on the bundled engine. Tor must be running.\nFilter syntax: ||domain^, @@ exceptions, literal substrings.\nCosmetic rules, modifiers, regex and wildcards are skipped.\nProxy tests use requests, not Chromium. SOCKS4 resolves DNS locally.\nSuggestions are disabled in private windows. Private block counts stay in RAM.": "Standardmäßig gesperrt: Kamera, Mikrofon, Standort und Benachrichtigungen.\nJavaScript-Schutz ist nach Möglichkeit wirksam; Websites und Worker können ihn umgehen.\nDoH und Chromium-Startparameter hängen vom enthaltenen Modul ab. Tor muss laufen.\nFiltersyntax: ||domain^, @@-Ausnahmen und wörtliche Teilzeichenfolgen.\nKosmetische Regeln, Modifikatoren, reguläre Ausdrücke und Platzhalter werden übersprungen.\nProxy-Tests verwenden requests statt Chromium. SOCKS4 löst DNS lokal auf.\nVorschläge sind in privaten Fenstern deaktiviert. Private Zähler bleiben im RAM.",
  "Qt 6.10+ supports compatible local Manifest V3 extensions.\nChrome Web Store does not install directly into SuperSearch.\nExtensions require a persistent profile and are unavailable in the session profile.\nBuilt-in: filtering, HTTPS-only, URL cleanup and denied permissions.\nUserScripts run on websites; install only code you trust.": "Qt 6.10+ unterstützt kompatible lokale Manifest-V3-Erweiterungen.\nDer Chrome Web Store installiert nicht direkt in SuperSearch.\nErweiterungen benötigen ein dauerhaftes Profil und sind im Sitzungsprofil nicht verfügbar.\nEnthalten: Filter, HTTPS, URL-Bereinigung und gesperrte Berechtigungen.\nUserScripts laufen auf Websites; installiere nur vertrauenswürdigen Code.",
  "Address": "Adresse",
  "Passwords": "Passwörter",
  "Bookmark": "Lesezeichen",
  "Menu": "Menü",
  "center": "Zentriert",
  "top": "Oben",
  "Reset SuperSearch": "SuperSearch zurücksetzen",
  "All browser user data will be deleted": "Alle Browser-Benutzerdaten werden gelöscht",
  "Also delete files downloaded by SuperSearch": "Auch von SuperSearch heruntergeladene Dateien löschen",
  "Other files in your Downloads folder are preserved. Modified or replaced files are skipped.": "Andere Dateien im Downloadordner bleiben erhalten. Geänderte oder ersetzte Dateien werden übersprungen.",
  "Type Delete": "Delete eingeben",
  "Delete data and start over": "Daten löschen und neu beginnen",
  "Delete the selected data?": "Ausgewählte Daten löschen?",
  "The selected data will be deleted and the browser will restart.": "Die ausgewählten Daten werden gelöscht und der Browser wird neu gestartet.",
  "Enter a complete homepage URL or supersearch:start.": "Eine vollständige Startseiten-URL oder supersearch:start eingeben.",
  "Use socks5/http/socks4://host:port without credentials.": "socks5/http/socks4://host:port ohne Zugangsdaten verwenden.",
  "Configure a proxy or enable Tor first.": "Zuerst einen Proxy einrichten oder Tor aktivieren.",
  "Text/background contrast must be at least 4.5:1.": "Der Text-Hintergrund-Kontrast muss mindestens 4,5:1 betragen.",
  "Connecting to api.ipify.org…": "Verbindung zu api.ipify.org…",
  "Downloading EasyList + EasyPrivacy…": "EasyList + EasyPrivacy herunterladen…",
  "Private by choice. Comfortable by design.": "Privatsphäre nach Wahl. Komfort durch Design.",
  "SuperSearch brings your everyday web into a personal workspace, with thoughtful privacy controls, secure local storage and an interface that adapts to you.": "SuperSearch verbindet dein tägliches Web mit einem persönlichen Arbeitsbereich, durchdachtem Datenschutz, sicherer lokaler Speicherung und einer anpassbaren Oberfläche.",
  "Privacy: session profiles, tracker filtering and optional search suggestions put your browsing choices in your hands.": "Datenschutz: Sitzungsprofile, Trackerfilter und optionale Suchvorschläge geben dir die Kontrolle über dein Surfen.",
  "Security: an encrypted master-password vault, explicit website permissions and HTTPS preferences help protect the way you browse.": "Sicherheit: Ein verschlüsselter Tresor mit Hauptpasswort, ausdrückliche Website-Berechtigungen und HTTPS-Einstellungen schützen dein Surfen.",
  "Convenience: tabs, split view, bookmarks, automatic downloads and browser import keep your favorite pages close.": "Komfort: Tabs, geteilte Ansicht, Lesezeichen, automatische Downloads und Browserimport halten deine Lieblingsseiten griffbereit.",
  "Customization: arrange panels, shape controls, pick a theme and create your own start page.": "Anpassung: Ordne Bereiche an, gestalte Bedienelemente, wähle ein Design und erstelle deine eigene Startseite.",
  "Built with Python, PySide6 and QtWebEngine (Chromium). Open source under the MIT license.": "Entwickelt mit Python, PySide6 und QtWebEngine (Chromium). Quelloffen unter der MIT-Lizenz.",
  "Settings, bookmarks, local passwords and the master password, cookies, website sessions, history, statistics, wallpapers, shortcuts, extensions and UserScripts will be deleted. The browser will restart and show first-run setup again. This action cannot be undone.": "Einstellungen, Lesezeichen, lokale Passwörter samt Hauptpasswort, Cookies, Website-Sitzungen, Verlauf, Statistiken, Hintergrundbilder, Verknüpfungen, Erweiterungen und UserScripts werden gelöscht. Der Browser startet mit der Ersteinrichtung neu. Dies kann nicht rückgängig gemacht werden.",
  "Back / forward": "Zurück / Vorwärts",
  "Password menu": "Passwortmenü",
  "Panel layout saved.": "Panelanordnung gespeichert.",
  "Drag panels by their handles. Drag borders to resize. Ctrl+Shift+U finishes customization.": "Verschiebe Bereiche an ihren Griffen. Ziehe die Ränder zum Vergrößern. Ctrl+Shift+U beendet die Anpassung.",
  "Suggestions are optional and off by default. When enabled, typed queries are sent to DuckDuckGo.": "Suchvorschläge sind optional und standardmäßig ausgeschaltet. Bei Aktivierung werden eingegebene Suchanfragen an DuckDuckGo gesendet.",
  "Try again": "Erneut versuchen",
  "Network settings": "Netzwerkeinstellungen",
  "Back to start page": "Zur Startseite",
  "Technical details": "Technische Details",
  "Error code": "Fehlercode",
  "Your privacy settings remain active.": "Deine Datenschutzeinstellungen bleiben aktiv.",
  "Secure connection unavailable": "Sichere Verbindung nicht verfügbar",
  "The website could not provide a valid secure connection. Check your device clock or try again later.": "Die Website konnte keine gültige sichere Verbindung herstellen. Prüfe die Uhrzeit deines Geräts oder versuche es später erneut.",
  "This request was blocked": "Diese Anfrage wurde blockiert",
  "A browser privacy rule or a network policy prevented this page from opening. You can review your settings.": "Eine Datenschutzregel oder Netzwerkrichtlinie hat das Öffnen verhindert. Du kannst deine Einstellungen prüfen.",
  "Check your private connection": "Prüfe deine private Verbindung",
  "Your proxy or Tor service may be unavailable. Check that it is running and review your network settings.": "Dein Proxy oder Tor-Dienst ist möglicherweise nicht verfügbar. Prüfe, ob der Dienst läuft, und kontrolliere deine Netzwerkeinstellungen.",
  "We could not find this website": "Diese Website wurde nicht gefunden",
  "Check the address and your DNS or internet connection, then try again.": "Prüfe die Adresse sowie deine DNS- oder Internetverbindung und versuche es erneut.",
  "You are offline": "Du bist offline",
  "Connect to Wi-Fi or your wired network, then try this page again.": "Verbinde dich mit WLAN oder einem kabelgebundenen Netzwerk und lade die Seite erneut.",
  "This website took too long": "Diese Website braucht zu lange",
  "The website did not respond in time. Give it a moment and try again.": "Die Website hat nicht rechtzeitig geantwortet. Warte einen Moment und versuche es erneut.",
  "This page is out of reach": "Diese Seite ist nicht erreichbar",
  "The connection could not be completed. Check your internet connection or try again in a moment.": "Die Verbindung konnte nicht hergestellt werden. Prüfe deine Internetverbindung oder versuche es gleich erneut.",
  "Chromium security patches": "Chromium-Sicherheitskorrekturen",
  "Save password?": "Passwort speichern?",
  "Update password?": "Passwort aktualisieren?",
  "Save password": "Passwort speichern",
  "Update password": "Passwort aktualisieren",
  "Username": "Benutzername",
  "Password": "Passwort",
  "Show password": "Passwort anzeigen",
  "Not now": "Nicht jetzt",
  "Encrypted on this device. Saved only when you choose Save.": "Auf diesem Gerät verschlüsselt. Speicherung nur nach deiner Bestätigung.",
  "Master password": "Hauptpasswort",
  "Repeat password": "Passwort wiederholen",
  "Unlock your local vault to save this password.": "Entsperre deinen lokalen Tresor, um dieses Passwort zu speichern.",
  "Create a master password of at least 12 characters to protect saved passwords.": "Erstelle ein Hauptpasswort mit mindestens 12 Zeichen, um gespeicherte Passwörter zu schützen.",
  "Unlock and save": "Entsperren und speichern",
  "Create vault and save": "Tresor erstellen und speichern",
  "Enter a password to save.": "Gib ein zu speicherndes Passwort ein.",
  "Use at least 12 characters. The passwords must match.": "Mindestens 12 Zeichen. Die Passwörter müssen übereinstimmen.",
  "Password saved locally.": "Passwort lokal gespeichert.",
  "Incorrect master password or damaged vault.": "Falsches Hauptpasswort oder beschädigter Tresor.",
  "Show the expand button in the title bar": "Schaltfläche zum Vergrößern in der Titelleiste anzeigen",
  "Expand button and title bar double-click": "Vergrößern-Schaltfläche und Doppelklick auf die Titelleiste",
  "Maximize window": "Fenster maximieren",
  "Restore window": "Fenstergröße wiederherstellen",
  "Minimize": "Minimieren",
  "Charging": "Wird geladen",
  "On battery": "Akkubetrieb",
  "Show time and battery only in full screen": "Uhrzeit und Akku nur im Vollbildmodus anzeigen",
  "Find a setting": "Einstellung suchen",
  "No settings found. Try another word or clear the search.": "Keine Einstellungen gefunden. Versuche ein anderes Wort oder lösche die Suche.",
  "{count} matching settings": "{count} passende Einstellungen",
  "{count} unsaved changes": "{count} ungespeicherte Änderungen",
  "All changes saved.": "Alle Änderungen gespeichert.",
  "Check the highlighted setting.": "Prüfe die markierte Einstellung.",
  "Restart required": "Neustart erforderlich",
  "Choose how SuperSearch protects your browsing.": "Wähle, wie SuperSearch dein Surfen schützt.",
  "Make the browser comfortable to look at and use.": "Gestalte den Browser übersichtlich und bequem.",
  "Search, language, startup and everyday browsing.": "Suche, Sprache, Start und tägliches Surfen.",
  "Manage optional tools and trusted website customizations.": "Verwalte optionale Werkzeuge und vertrauenswürdige Website-Anpassungen.",
  "See which tracking requests have been blocked.": "Sieh nach, welche Tracking-Anfragen blockiert wurden.",
  "Import your data, clean up or start over.": "Importiere Daten, räume auf oder beginne neu.",
  "Version, browser engine and privacy documents.": "Version, Browser-Engine und Datenschutzdokumente.",
  "Protection level": "Schutzniveau",
  "Choose a starting point. You can adjust the switches below.": "Wähle eine Grundlage. Die Schalter darunter lassen sich einzeln anpassen.",
  "Balanced": "Ausgewogen",
  "Stronger": "Verstärkt",
  "Maximum": "Maximal",
  "Recommended for everyday browsing. Blocks known trackers and keeps most websites working.": "Für den Alltag empfohlen: blockiert bekannte Tracker und erhält die Funktion der meisten Websites.",
  "Adds tighter website restrictions. Some graphics and sign-in features may not work.": "Schränkt Websites stärker ein. Manche Grafik- und Anmeldefunktionen können ausfallen.",
  "Requires a running Tor service and turns off website JavaScript. Many websites will not work.": "Benötigt einen laufenden Tor-Dienst und deaktiviert Website-JavaScript. Viele Websites funktionieren nicht.",
  "Everyday protection": "Schutz im Alltag",
  "Block ads and trackers": "Werbung und Tracker blockieren",
  "Stop requests to known advertising and tracking services.": "Blockiert Anfragen an bekannte Werbe- und Trackingdienste.",
  "Use secure connections only": "Nur sichere Verbindungen nutzen",
  "Upgrade HTTP addresses to HTTPS. Websites without HTTPS will not open.": "Ersetzt HTTP durch HTTPS. Websites ohne HTTPS werden nicht geöffnet.",
  "Remove tracking tags from links": "Tracking-Tags aus Links entfernen",
  "Clean common advertising parameters from website addresses.": "Entfernt verbreitete Werbeparameter aus Website-Adressen.",
  "Limit tracking between websites": "Websiteübergreifendes Tracking begrenzen",
  "Block third-party cookies and storage. Some embedded sign-ins may not work.": "Blockiert Drittanbieter-Cookies und -Speicher. Eingebettete Anmeldungen können ausfallen.",
  "Hide the previous website address": "Vorherige Website-Adresse verbergen",
  "Do not send websites the address of the page you came from.": "Sendet Websites nicht die Adresse deiner vorherigen Seite.",
  "Ask websites not to track me": "Websites bitten, mich nicht zu verfolgen",
  "Send privacy preference signals. Websites decide whether to honor them.": "Sendet Datenschutzwünsche. Websites entscheiden, ob sie diese beachten.",
  "Blocking lists": "Blockierlisten",
  "Download fresh EasyList and EasyPrivacy rules when you want an update.": "Lädt auf Wunsch aktuelle Regeln von EasyList und EasyPrivacy herunter.",
  "Website data": "Website-Daten",
  "Forget website data when I close SuperSearch": "Website-Daten nach dem Schließen vergessen",
  "Cookies stay in memory, so you may need to sign in again after a restart. Bookmarks and saved passwords are kept.": "Cookies bleiben im Arbeitsspeicher. Nach einem Neustart kann eine neue Anmeldung nötig sein. Lesezeichen und Passwörter bleiben erhalten.",
  "Website permissions": "Website-Berechtigungen",
  "Camera, microphone, location and notification permissions are denied by default.": "Kamera, Mikrofon, Standort und Benachrichtigungen sind standardmäßig gesperrt.",
  "Your connection": "Deine Verbindung",
  "Normal connection. Websites can see your public IP address.": "Normale Verbindung. Websites sehen deine öffentliche IP-Adresse.",
  "A proxy is configured. Its service must be available to open websites.": "Ein Proxy ist eingerichtet. Sein Dienst muss erreichbar sein.",
  "Tor is selected. Tor must be running or websites cannot open.": "Tor ist ausgewählt. Ohne laufenden Tor-Dienst öffnen sich keine Websites.",
  "Connection settings": "Verbindungseinstellungen",
  "Connection details": "Verbindungsdetails",
  "For people using a proxy, Tor or a custom DNS provider.": "Für Proxy, Tor oder einen eigenen DNS-Anbieter.",
  "Secure DNS (DNS over HTTPS)": "Sicheres DNS (DNS über HTTPS)",
  "Choose who resolves website names. Tor connections use their own DNS route.": "Wähle den Dienst zur Namensauflösung. Tor verwendet eine eigene DNS-Route.",
  "Use the system setting": "Systemeinstellung verwenden",
  "Proxy server": "Proxy-Server",
  "Paste an HTTP, SOCKS5 or SOCKS4 address. Leave blank for a normal connection.": "Füge eine HTTP-, SOCKS5- oder SOCKS4-Adresse ein. Für normale Verbindungen leer lassen.",
  "Use Tor for connections": "Tor für Verbindungen verwenden",
  "Start Tor on this device first. Uses 127.0.0.1:9050 and takes priority over the proxy address.": "Starte zuerst Tor. Verwendet 127.0.0.1:9050 und hat Vorrang vor der Proxy-Adresse.",
  "Check the proxy": "Proxy prüfen",
  "Makes a test request to api.ipify.org through the chosen proxy or Tor.": "Sendet über den gewählten Proxy oder Tor eine Testanfrage an api.ipify.org.",
  "Advanced website protections": "Erweiterter Website-Schutz",
  "These settings can affect how websites work.": "Diese Einstellungen können die Funktion von Websites beeinflussen.",
  "Reduce browser fingerprinting": "Browser-Fingerprinting reduzieren",
  "Make some device details harder to read. This cannot prevent every form of fingerprinting.": "Erschwert das Auslesen mancher Gerätedetails. Verhindert nicht jede Art von Fingerprinting.",
  "Restrict direct browser connections": "Direkte Browserverbindungen begrenzen",
  "Limits WebRTC network exposure. Voice and video calls may not work.": "Begrenzt die WebRTC-Netzwerkfreigabe. Sprach- und Videoanrufe können ausfallen.",
  "Extra location blocking": "Zusätzliche Standortblockierung",
  "Block the location API in website scripts. Website permissions are already denied by default.": "Blockiert die Standort-API in Website-Skripten. Berechtigungen sind bereits standardmäßig gesperrt.",
  "Turn off website JavaScript": "Website-JavaScript deaktivieren",
  "Many websites and sign-in forms stop working. Leave this off for everyday browsing.": "Viele Websites und Anmeldungen funktionieren dann nicht. Für den Alltag ausgeschaltet lassen.",
  "Allow 3D graphics on websites": "3D-Grafik auf Websites erlauben",
  "Needed by some maps, games and visual tools. It can reveal graphics-device details.": "Für manche Karten, Spiele und Grafikwerkzeuge nötig. Kann Gerätedetails offenlegen.",
  "Allow sites to read drawn images": "Auslesen gezeichneter Bilder erlauben",
  "Needed by some drawing and verification tools. It can reveal device details.": "Für manche Zeichen- und Prüfwerkzeuge nötig. Kann Gerätedetails offenlegen.",
  "Let websites open new windows": "Neue Fenster durch Websites erlauben",
  "Links and scripts that open another window may be blocked when this is off.": "Links und Skripte für neue Fenster können sonst blockiert werden.",
  "How protection works": "So funktioniert der Schutz",
  "Fingerprinting protection is best effort. Supported filters: domain rules, exceptions and literal text; cosmetic rules and advanced syntax are skipped.": "Fingerprinting-Schutz ist keine Garantie. Filter unterstützen Domains, Ausnahmen und Text; kosmetische und komplexe Regeln werden übersprungen.",
  "The theme changes browser controls. Websites keep their own colors.": "Das Design ändert die Browseroberfläche. Websites behalten ihre Farben.",
  "Light": "Hell",
  "Dark": "Dunkel",
  "Pure black": "Reines Schwarz",
  "Custom colors": "Eigene Farben",
  "Choose your own colors. Text must remain readable.": "Wähle eigene Farben. Der Text muss lesbar bleiben.",
  "Text and size": "Text und Größe",
  "Size of browser controls": "Größe der Browser-Bedienelemente",
  "Website zoom": "Website-Zoom",
  "Window and full screen": "Fenster und Vollbild",
  "Maximize keeps system panels visible. Full screen hides them. F11 always enters full screen.": "Maximieren lässt Systemleisten sichtbar. Vollbild blendet sie aus. F11 aktiviert immer Vollbild.",
  "Hidden in normal and maximized windows. Charge is shown only when a battery is detected.": "In normalen und maximierten Fenstern verborgen. Akkuanzeige nur bei erkanntem Akku.",
  "Shortcuts and wallpaper": "Verknüpfungen und Hintergrundbild",
  "Changes in the editor are saved when you confirm them.": "Änderungen im Editor werden nach deiner Bestätigung gespeichert.",
  "Start page layout": "Layout der Startseite",
  "Centered": "Zentriert",
  "Near the top": "Oben",
  "Panels and toolbar": "Bereiche und Symbolleiste",
  "Move buttons and panels to suit the way you browse.": "Ordne Schaltflächen und Bereiche passend zu deiner Nutzung an.",
  "Address bar buttons": "Schaltflächen der Adressleiste",
  "Drag rows to change the order. Uncheck a button to hide it.": "Ziehe Zeilen für eine neue Reihenfolge. Entferne das Häkchen, um eine Schaltfläche auszublenden.",
  "Reset panel positions": "Bereichspositionen zurücksetzen",
  "Changes the layout now. Other browser data is kept.": "Ändert das Layout sofort. Andere Browserdaten bleiben erhalten.",
  "Fine-tune spacing and corners": "Abstände und Ecken fein einstellen",
  "Corner roundness": "Eckenrundung",
  "Search and language": "Suche und Sprache",
  "Typed queries are sent to DuckDuckGo when this is on. Suggestions stay off in private windows.": "Eingaben werden dann an DuckDuckGo gesendet. In privaten Fenstern bleiben Vorschläge aus.",
  "Startup and tabs": "Start und Tabs",
  "Open new tabs with": "Neue Tabs öffnen mit",
  "SuperSearch start page": "SuperSearch-Startseite",
  "A website I choose": "Eine ausgewählte Website",
  "Website address": "Website-Adresse",
  "Reopen saved ordinary tabs. Pinned tabs are remembered separately; private tabs are not saved.": "Öffnet gespeicherte normale Tabs. Pins werden separat gespeichert, private Tabs nicht.",
  "History and bookmarks": "Verlauf und Lesezeichen",
  "Keep a local list of visited pages. Private windows are never recorded.": "Speichert besuchte Seiten lokal. Private Fenster werden nie aufgezeichnet.",
  "Passwords and shortcuts": "Passwörter und Tastenkürzel",
  "Password manager": "Passwortverwaltung",
  "View or edit the encrypted local vault. A master password is required.": "Zeige oder bearbeite den verschlüsselten lokalen Tresor. Ein Hauptpasswort ist nötig.",
  "Built-in protection": "Integrierter Schutz",
  "Ad blocking, secure connections and link cleanup are already included.": "Werbeblockierung, sichere Verbindungen und Linkbereinigung sind bereits enthalten.",
  "Optional extensions": "Optionale Erweiterungen",
  "Manage local extensions": "Lokale Erweiterungen verwalten",
  "Chrome Web Store does not install directly into SuperSearch. Compatible local extensions require a persistent profile.": "Der Chrome Web Store installiert nicht direkt in SuperSearch. Lokale Erweiterungen benötigen ein dauerhaftes Profil.",
  "User scripts and styles": "Benutzerskripte und Stile",
  "Install only code you trust. Installation and removal apply immediately.": "Installiere nur vertrauenswürdigen Code. Installation und Entfernung gelten sofort.",
  "Installed scripts": "Installierte Skripte",
  "Trusted scripts can also read information on private pages when this is on.": "Vertrauenswürdige Skripte können dann auch Daten privater Seiten lesen.",
  "Tracking requests blocked": "Blockierte Tracking-Anfragen",
  "Website": "Website",
  "Clean up local data": "Lokale Daten bereinigen",
  "Choose what to remove. Deletion happens only after you confirm.": "Wähle, was entfernt werden soll. Gelöscht wird erst nach Bestätigung.",
  "Bring bookmarks and supported data from a Chromium browser.": "Übernimm Lesezeichen und unterstützte Daten aus einem Chromium-Browser.",
  "Privacy documents": "Datenschutzdokumente",
  "Enter a complete website address, for example https://example.com.": "Gib eine vollständige Adresse ein, zum Beispiel https://example.com.",
  "Enter a proxy address such as socks5://127.0.0.1:1080, without a username or password.": "Gib eine Proxy-Adresse wie socks5://127.0.0.1:1080 ohne Zugangsdaten ein.",
  "Proxy error: {message}": "Proxy-Fehler: {message}",
  "Proxy IP: {address}": "Proxy-IP: {address}",
  "{count} blocking rules loaded; {skipped} unsupported rules skipped.": "{count} Blockierregeln geladen; {skipped} nicht unterstützte Regeln übersprungen.",
  "Cookies and website data": "Cookies und Website-Daten",
  "Signs you out of websites. Your online accounts are not deleted.": "Meldet dich von Websites ab. Deine Onlinekonten werden nicht gelöscht.",
  "Temporary files (cache)": "Temporäre Dateien (Cache)",
  "Remove saved page resources. Websites may load more slowly at first.": "Entfernt gespeicherte Seitenressourcen. Websites können anfangs langsamer laden.",
  "Saved passwords": "Gespeicherte Passwörter",
  "Delete the local password vault and its master password.": "Löscht den lokalen Passworttresor samt Hauptpasswort.",
  "Remove browsing history, saved tab sessions and blocking totals.": "Entfernt Verlauf, gespeicherte Tab-Sitzungen und Blockierstatistik.",
  "Delete saved bookmarks and their folders.": "Löscht gespeicherte Lesezeichen und ihre Ordner.",
  "Remove saved pins and their entries in the saved tab session.": "Entfernt Pins und ihre Einträge in der gespeicherten Tab-Sitzung.",
  "Remove the list of downloads. Keep the downloaded files.": "Entfernt die Downloadliste. Heruntergeladene Dateien bleiben erhalten.",
  "Downloaded files": "Heruntergeladene Dateien",
  "Delete unchanged files recorded by SuperSearch. Other files are kept.": "Löscht unveränderte, von SuperSearch erfasste Dateien. Andere Dateien bleiben erhalten.",
  "The browser restarts after cleanup so cookies and cached files can be removed safely.": "Der Browser startet nach der Bereinigung neu, um Cookies und Cache sicher zu entfernen.",
  "Start over": "Neu beginnen",
  "Remove all browser data and return to first-run setup.": "Entfernt alle Browserdaten und öffnet die Ersteinrichtung erneut.",
  "Split-view": "Geteilte Ansicht",
  "Forward": "Vorwärts",
  "cookies cookie site data": "Cookies Website-Daten",
  "proxy network internet connection": "Proxy Netzwerk Internet Verbindung",
  "DNS network internet connection": "DNS Netzwerk Internet Verbindung",
  "tor onion network internet connection": "Tor Onion Netzwerk Internet Verbindung",
  "cookies cache passwords accounts history bookmarks downloads reset Delete pinned": "Cookies Cache Passwörter Konten Verlauf Lesezeichen Downloads zurücksetzen Delete angeheftet",
  "Saved. Restart to finish applying these changes.": "Gespeichert. Starte neu, um diese Änderungen vollständig anzuwenden.",
  "To remove website data saved earlier, use Storage.": "Entferne zuvor gespeicherte Website-Daten im Bereich Speicher.",
  "Readable colors": "Gut lesbare Farben",
  "These colors make text hard to read. Choose colors with a stronger contrast.": "Diese Farben erschweren das Lesen. Wähle einen stärkeren Kontrast.",
  "1 unsaved change": "1 ungespeicherte Änderung",
  "1 matching setting": "1 passende Einstellung",
  "Your public IP": "Ihre öffentliche IP",
  "Refresh IP address": "IP-Adresse aktualisieren",
  "Checking…": "Wird geprüft…",
  "Unavailable": "Nicht verfügbar",
  "Not checked yet": "Noch nicht geprüft",
  "Could not check the address. Check your connection and try again.": "Die Adresse konnte nicht ermittelt werden. Prüfen Sie die Verbindung und versuchen Sie es erneut.",
  "Public connection address · provided by ipify": "Öffentliche Verbindungsadresse · von ipify",
  "Show public IP on the start page": "Öffentliche IP auf der Startseite anzeigen",
  "Contacts ipify through your current proxy or Tor when the start page is visible. The address stays in memory. Turn this off to avoid these requests.": "Kontaktiert ipify über den aktuellen Proxy oder Tor, wenn die Startseite sichtbar ist. Die Adresse bleibt im Arbeitsspeicher. Ausschalten verhindert diese Anfragen.",
  "Show public IP (contacts ipify)": "Öffentliche IP anzeigen (Anfrage an ipify)",
  "Source code": "Quellcode",
  "Security patches are backported from newer Chromium releases. The engine base version is listed separately.": "Sicherheitskorrekturen werden aus neueren Chromium-Versionen zurückportiert. Die Basisversion der Engine wird separat angezeigt."
}
```

### settings/translations/es.json
```json
{
  "Welcome to SuperSearch": "Te damos la bienvenida a SuperSearch",
  "About the browser": "Acerca del navegador",
  "Agreement": "Acuerdo",
  "Setup": "Configuración",
  "Import": "Importar",
  "Done": "Listo",
  "Your web. Your choices.": "Tu web. Tus decisiones.",
  "Local data": "Datos locales",
  "Your workspace": "Tu espacio de trabajo",
  "An easy switch": "Un cambio sencillo",
  "Protect passwords with a master password and forget website data after each session.": "Protege tus contraseñas con una contraseña maestra y olvida los datos de los sitios después de cada sesión.",
  "Move panels, resize controls and make the start page your own.": "Mueve paneles, cambia el tamaño de los controles y personaliza tu página de inicio.",
  "Bring bookmarks and compatible data from your selected Chromium profile.": "Importa marcadores y datos compatibles del perfil de Chromium que elijas.",
  "I accept the user agreement and have read the privacy policy": "Acepto el acuerdo de usuario y he leído la política de privacidad",
  "Theme": "Tema",
  "light": "Claro",
  "dark": "Oscuro",
  "oled": "OLED",
  "standard": "Estándar",
  "strict": "Estricto",
  "paranoia": "Paranoia",
  "Off": "Desactivado",
  "Search engine": "Motor de búsqueda",
  "Search suggestions": "Sugerencias de búsqueda",
  "Choose whether you want search suggestions": "Elige si quieres sugerencias de búsqueda",
  "No, keep typing private until I search": "No, mantener la escritura privada hasta buscar",
  "Yes, show DuckDuckGo suggestions": "Sí, mostrar sugerencias de DuckDuckGo",
  "Forget website data after exit (session profile)": "Olvidar los datos de los sitios al salir (perfil de sesión)",
  "Save browsing history": "Guardar el historial de navegación",
  "Network": "Red",
  "Standard secure connection": "Conexión segura estándar",
  "Tor via 127.0.0.1:9050": "Tor mediante 127.0.0.1:9050",
  "Tor requires a separately running Tor service. Without it, websites cannot load. Setup keeps JavaScript available for modern websites.": "Tor necesita un servicio Tor ejecutándose por separado. Sin él, los sitios no se cargarán. La configuración mantiene JavaScript disponible para los sitios modernos.",
  "Ready for your first search": "Todo listo para tu primera búsqueda",
  "Back": "Atrás",
  "Continue": "Continuar",
  "Start browsing": "Empezar a navegar",
  "Changes preview immediately. Startup network settings apply when the browser restarts.": "Los cambios se muestran al instante. Los parámetros de red de inicio se aplican al reiniciar.",
  "Choose a profile folder manually": "Elegir manualmente una carpeta de perfil",
  "Detect browsers again": "Volver a detectar navegadores",
  "Default or Profile 1 folder": "Carpeta Default o Profile 1",
  "Folder": "Carpeta",
  "Bookmarks and folders": "Marcadores y carpetas",
  "History": "Historial",
  "Download history (files are not copied)": "Historial de descargas (no se copian los archivos)",
  "Readable cookies (protected cookies are skipped)": "Cookies legibles (se omiten las protegidas)",
  "Compatible general settings": "Ajustes generales compatibles",
  "Optional password CSV": "CSV de contraseñas opcional",
  "Password CSV": "CSV de contraseñas",
  "Import everything available from this browser": "Importar todos los datos disponibles de este navegador",
  "Import selected data": "Importar los datos seleccionados",
  "You can skip import and run it later in Storage settings.": "Puedes omitir la importación y ejecutarla después en los ajustes de almacenamiento.",
  "Chromium profile": "Perfil de Chromium",
  "Choose a profile folder or password CSV.": "Elige una carpeta de perfil o un CSV de contraseñas.",
  "Imported: ": "Importado: ",
  "Settings": "Ajustes",
  "Privacy": "Privacidad",
  "Appearance": "Apariencia",
  "General": "General",
  "Extensions": "Extensiones",
  "Statistics": "Estadísticas",
  "Storage": "Almacenamiento",
  "About": "Acerca de",
  "Preset": "Preajuste",
  "Tracker / advertising filters": "Filtros de rastreadores y publicidad",
  "Anti-fingerprinting JS (best effort)": "JavaScript contra huellas digitales (mejor esfuerzo)",
  "Block WebRTC": "Bloquear WebRTC",
  "Block geolocation JS": "Bloquear la geolocalización por JavaScript",
  "Disable all JavaScript": "Desactivar todo JavaScript",
  "HTTPS only": "Solo HTTPS",
  "Remove tracking parameters": "Eliminar parámetros de seguimiento",
  "Block third-party cookies / storage": "Bloquear cookies y almacenamiento de terceros",
  "Tor SOCKS5 — 127.0.0.1:9050": "Tor SOCKS5 — 127.0.0.1:9050",
  "Session profile: website data stays in memory": "Perfil de sesión: los datos de los sitios permanecen en memoria",
  "Do not send Referer headers": "No enviar cabeceras Referer",
  "Global Privacy Control and Do Not Track signals": "Señales Global Privacy Control y Do Not Track",
  "Allow WebGL (may expose GPU information)": "Permitir WebGL (puede revelar información de la GPU)",
  "Allow canvas readback (required by some websites)": "Permitir la lectura de canvas (necesaria para algunos sitios)",
  "Allow JavaScript popups": "Permitir ventanas emergentes de JavaScript",
  "Run UserScripts in private windows": "Ejecutar UserScripts en ventanas privadas",
  "DNS over HTTPS": "DNS sobre HTTPS",
  "Proxy": "Proxy",
  "Test proxy": "Probar el proxy",
  "Update filters": "Actualizar filtros",
  "requires restart": "requiere reinicio",
  "Background": "Fondo",
  "Surface": "Superficie",
  "Text": "Texto",
  "Accent": "Acento",
  "Font": "Fuente",
  "Control shape": "Forma de los controles",
  "Rounded": "Redondeada",
  "Pill": "Cápsula",
  "Square": "Rectangular",
  "Interface animations": "Animaciones de la interfaz",
  "Show the title in the title bar": "Mostrar el título en la barra superior",
  "Use the surface color for the title bar": "Usar el color de superficie en la barra superior",
  "Corner radius": "Radio de las esquinas",
  "Spacing": "Espaciado",
  "Interface scale, %": "Escala de interfaz, %",
  "Page zoom, %": "Zoom de página, %",
  "Tab panel width": "Anchura del panel de pestañas",
  "Horizontal panel height": "Altura del panel horizontal",
  "Tab height": "Altura de las pestañas",
  "Icon size": "Tamaño de los iconos",
  "Address bar height": "Altura de la barra de direcciones",
  "Title bar height": "Altura de la barra superior",
  "Drag rows to arrange toolbar buttons. Check a row to show its button.": "Arrastra las filas para ordenar los botones. Marca una fila para mostrar su botón.",
  "Move panels with the mouse": "Mover paneles con el ratón",
  "Reset panel layout": "Restablecer la disposición de los paneles",
  "Start page": "Página de inicio",
  "Content alignment": "Alineación del contenido",
  "Show the logo": "Mostrar el logo",
  "Show the search field": "Mostrar el campo de búsqueda",
  "Show privacy counters": "Mostrar contadores de privacidad",
  "Shortcut columns": "Columnas de accesos directos",
  "Shortcut tile size": "Tamaño de los accesos directos",
  "Start page content width": "Anchura del contenido de inicio",
  "Edit shortcuts and wallpaper": "Editar accesos directos y fondo",
  "Choose wallpaper": "Elegir fondo de pantalla",
  "Language": "Idioma",
  "Homepage": "Página de inicio",
  "Confirm before closing a window": "Confirmar antes de cerrar una ventana",
  "Restore saved tabs on the next launch": "Restaurar pestañas guardadas al iniciar",
  "Show the bookmarks toolbar": "Mostrar la barra de marcadores",
  "The theme styles the browser interface. Websites keep their own colors.": "El tema cambia la interfaz del navegador. Los sitios conservan sus propios colores.",
  "Suggestions send typed queries to DuckDuckGo (normal windows only).": "Las sugerencias envían las consultas escritas a DuckDuckGo (solo ventanas normales).",
  "UserScript installation and removal are explicit actions that apply immediately.": "La instalación y eliminación de UserScripts son acciones explícitas e inmediatas.",
  "Manifest V3 extension manager": "Gestor de extensiones Manifest V3",
  "Install UserScript": "Instalar UserScript",
  "Remove": "Eliminar",
  "Total": "Total",
  "Daily blocks (last 14 days)": "Bloqueos diarios (últimos 14 días)",
  "Top blocked domains": "Dominios más bloqueados",
  "Domain": "Dominio",
  "Manage local data": "Gestionar datos locales",
  "Cookies and site data — sign out of websites": "Cookies y datos de sitios — cerrar las sesiones",
  "Page and graphics cache": "Caché de páginas y gráficos",
  "Local passwords and master password": "Contraseñas locales y contraseña maestra",
  "History and statistics": "Historial y estadísticas",
  "Bookmarks": "Marcadores",
  "Pinned tabs": "Pestañas fijadas",
  "Download history": "Historial de descargas",
  "Files downloaded by SuperSearch": "Archivos descargados por SuperSearch",
  "Delete selected data and restart": "Eliminar los datos seleccionados y reiniciar",
  "Reset the entire browser": "Restablecer todo el navegador",
  "Import from another browser": "Importar desde otro navegador",
  "Select Apply to save your changes.": "Selecciona Aplicar para guardar los cambios.",
  "Apply": "Aplicar",
  "Close": "Cerrar",
  "Cancel": "Cancelar",
  "Restart": "Reiniciar",
  "You have unapplied changes.": "Hay cambios sin aplicar.",
  "Settings applied.": "Ajustes aplicados.",
  "Pinned tab": "Pestaña fijada",
  "Pin selected tabs": "Fijar pestañas seleccionadas",
  "Unpin selected tabs": "Desfijar pestañas seleccionadas",
  "Close selected tabs": "Cerrar pestañas seleccionadas",
  "Keyboard shortcuts": "Atajos de teclado",
  "Shortcut": "Atajo",
  "Action": "Acción",
  "New tab": "Nueva pestaña",
  "Close current tab": "Cerrar pestaña actual",
  "Close window": "Cerrar ventana",
  "Next tab": "Siguiente pestaña",
  "Previous tab": "Pestaña anterior",
  "Switch to a numbered tab": "Cambiar a una pestaña numerada",
  "Switch to the last tab": "Cambiar a la última pestaña",
  "Pin or unpin selected tabs": "Fijar o desfijar pestañas seleccionadas",
  "Select individual tabs": "Seleccionar pestañas individuales",
  "Select a range of tabs": "Seleccionar un intervalo de pestañas",
  "Select all tabs when the tab panel is focused": "Seleccionar todas las pestañas con el panel enfocado",
  "Close selected tabs when the tab panel is focused": "Cerrar pestañas seleccionadas con el panel enfocado",
  "Focus address bar": "Enfocar la barra de direcciones",
  "Bookmark the current page": "Guardar la página en marcadores",
  "Toggle bookmarks toolbar": "Mostrar u ocultar la barra de marcadores",
  "New private window": "Nueva ventana privada",
  "Customize panel layout": "Personalizar la disposición de paneles",
  "Toggle split view": "Alternar vista dividida",
  "Reload": "Recargar",
  "Full screen": "Pantalla completa",
  "Page zoom": "Zoom de página",
  "Read Privacy Policy": "Leer la política de privacidad",
  "Read User Agreement": "Leer el acuerdo de usuario",
  "Discover a calmer, more personal way to browse. SuperSearch brings privacy controls, secure local password storage and a flexible workspace together in one thoughtfully designed browser. Keep your everyday web close, your choices in your hands, and your interface exactly the way you like it.": "Descubre una navegación más tranquila y personal. SuperSearch reúne controles de privacidad, contraseñas locales protegidas y un espacio de trabajo flexible en un navegador cuidado. Ten tu web cotidiana a mano, conserva el control de tus decisiones y adapta la interfaz a tu gusto.",
  "Your choices are already previewed. Select Start browsing to finish setup and save them. Startup network or profile changes may restart the browser once. Your tabs, shortcuts and privacy controls are ready when you are.": "Tus elecciones ya se muestran. Selecciona Empezar a navegar para completar y guardar la configuración. Algunos cambios de red o perfil pueden reiniciar el navegador una vez. Tus pestañas, accesos directos y controles de privacidad ya están preparados.",
  "Select a Chromium profile and data categories. The source browser is not changed. Passwords require a CSV exported by the source browser; the file contains unencrypted passwords. Protected cookies and account sessions may require signing in again.": "Elige un perfil de Chromium y las categorías de datos. El navegador de origen no se modifica. Las contraseñas requieren un CSV exportado por ese navegador, que contiene contraseñas sin cifrar. Las cookies protegidas y las sesiones pueden requerir iniciar sesión de nuevo.",
  "Choose which data to delete. Cookies and site data are cleared after Chromium closes; the browser restarts automatically. Signing out does not delete your accounts with website providers.": "Elige los datos que quieres eliminar. Las cookies y datos de los sitios se borran después de cerrar Chromium y el navegador se reinicia. Cerrar sesión no elimina tus cuentas con los proveedores de los sitios.",
  "Default deny: camera, microphone, location, notifications.\nJS spoofing is best effort; sites and workers can bypass it.\nDoH / Chromium flags depend on the bundled engine. Tor must be running.\nFilter syntax: ||domain^, @@ exceptions, literal substrings.\nCosmetic rules, modifiers, regex and wildcards are skipped.\nProxy tests use requests, not Chromium. SOCKS4 resolves DNS locally.\nSuggestions are disabled in private windows. Private block counts stay in RAM.": "Se deniegan por defecto cámara, micrófono, ubicación y notificaciones.\nEl enmascaramiento JavaScript es limitado; sitios y workers pueden evitarlo.\nDoH y los parámetros de Chromium dependen del motor incluido. Tor debe estar activo.\nSintaxis de filtros: ||domain^, excepciones @@ y subcadenas literales.\nSe omiten reglas cosméticas, modificadores, expresiones regulares y comodines.\nLas pruebas de proxy usan requests, no Chromium. SOCKS4 resuelve DNS localmente.\nLas sugerencias se desactivan en privado. Los contadores privados permanecen en memoria.",
  "Qt 6.10+ supports compatible local Manifest V3 extensions.\nChrome Web Store does not install directly into SuperSearch.\nExtensions require a persistent profile and are unavailable in the session profile.\nBuilt-in: filtering, HTTPS-only, URL cleanup and denied permissions.\nUserScripts run on websites; install only code you trust.": "Qt 6.10+ admite extensiones locales Manifest V3 compatibles.\nChrome Web Store no instala directamente en SuperSearch.\nLas extensiones requieren un perfil persistente y no están disponibles en el perfil de sesión.\nIncluye filtros, HTTPS, limpieza de URL y denegación de permisos.\nLos UserScripts se ejecutan en los sitios; instala solo código fiable.",
  "Address": "Dirección",
  "Passwords": "Contraseñas",
  "Bookmark": "Marcador",
  "Menu": "Menú",
  "center": "Centrado",
  "top": "Arriba",
  "Reset SuperSearch": "Restablecer SuperSearch",
  "All browser user data will be deleted": "Se eliminarán todos los datos de usuario del navegador",
  "Also delete files downloaded by SuperSearch": "Eliminar también los archivos descargados con SuperSearch",
  "Other files in your Downloads folder are preserved. Modified or replaced files are skipped.": "Se conservan los demás archivos de Descargas. Se omiten los archivos modificados o reemplazados.",
  "Type Delete": "Escribe Delete",
  "Delete data and start over": "Eliminar los datos y empezar de nuevo",
  "Delete the selected data?": "¿Eliminar los datos seleccionados?",
  "The selected data will be deleted and the browser will restart.": "Se eliminarán los datos seleccionados y el navegador se reiniciará.",
  "Enter a complete homepage URL or supersearch:start.": "Introduce una URL completa o supersearch:start.",
  "Use socks5/http/socks4://host:port without credentials.": "Usa socks5/http/socks4://servidor:puerto sin credenciales.",
  "Configure a proxy or enable Tor first.": "Primero configura un proxy o activa Tor.",
  "Text/background contrast must be at least 4.5:1.": "El contraste entre texto y fondo debe ser como mínimo de 4,5:1.",
  "Connecting to api.ipify.org…": "Conectando con api.ipify.org…",
  "Downloading EasyList + EasyPrivacy…": "Descargando EasyList + EasyPrivacy…",
  "Private by choice. Comfortable by design.": "Privacidad por elección. Comodidad por diseño.",
  "SuperSearch brings your everyday web into a personal workspace, with thoughtful privacy controls, secure local storage and an interface that adapts to you.": "SuperSearch reúne tu Web cotidiana en un espacio personal, con controles de privacidad, almacenamiento local seguro y una interfaz que se adapta a ti.",
  "Privacy: session profiles, tracker filtering and optional search suggestions put your browsing choices in your hands.": "Privacidad: los perfiles de sesión, el filtrado de rastreadores y las sugerencias opcionales te dan el control de tu navegación.",
  "Security: an encrypted master-password vault, explicit website permissions and HTTPS preferences help protect the way you browse.": "Seguridad: una bóveda cifrada con contraseña maestra, permisos explícitos y preferencias HTTPS ayudan a proteger tu navegación.",
  "Convenience: tabs, split view, bookmarks, automatic downloads and browser import keep your favorite pages close.": "Comodidad: pestañas, vista dividida, marcadores, descargas automáticas e importación mantienen tus páginas favoritas a mano.",
  "Customization: arrange panels, shape controls, pick a theme and create your own start page.": "Personalización: organiza los paneles, ajusta los controles, elige un tema y crea tu propia página de inicio.",
  "Built with Python, PySide6 and QtWebEngine (Chromium). Open source under the MIT license.": "Creado con Python, PySide6 y QtWebEngine (Chromium). Código abierto bajo la licencia MIT.",
  "Settings, bookmarks, local passwords and the master password, cookies, website sessions, history, statistics, wallpapers, shortcuts, extensions and UserScripts will be deleted. The browser will restart and show first-run setup again. This action cannot be undone.": "Se eliminarán los ajustes, marcadores, contraseñas locales y maestra, cookies, sesiones, historial, estadísticas, fondos, accesos directos, extensiones y UserScripts. El navegador se reiniciará con la configuración inicial. Esta acción no se puede deshacer.",
  "Back / forward": "Atrás / adelante",
  "Password menu": "Menú de contraseñas",
  "Panel layout saved.": "Distribución de paneles guardada.",
  "Drag panels by their handles. Drag borders to resize. Ctrl+Shift+U finishes customization.": "Arrastra los paneles por sus asas y los bordes para cambiar el tamaño. Ctrl+Shift+U termina la personalización.",
  "Suggestions are optional and off by default. When enabled, typed queries are sent to DuckDuckGo.": "Las sugerencias son opcionales y están desactivadas por defecto. Al activarlas, las consultas escritas se envían a DuckDuckGo.",
  "Try again": "Volver a intentar",
  "Network settings": "Ajustes de red",
  "Back to start page": "Volver al inicio",
  "Technical details": "Detalles técnicos",
  "Error code": "Código de error",
  "Your privacy settings remain active.": "Tus ajustes de privacidad siguen activos.",
  "Secure connection unavailable": "Conexión segura no disponible",
  "The website could not provide a valid secure connection. Check your device clock or try again later.": "El sitio no pudo ofrecer una conexión segura válida. Comprueba la fecha y hora del dispositivo o inténtalo más tarde.",
  "This request was blocked": "Esta solicitud se ha bloqueado",
  "A browser privacy rule or a network policy prevented this page from opening. You can review your settings.": "Una regla de privacidad o una política de red impidió abrir esta página. Puedes revisar tus ajustes.",
  "Check your private connection": "Comprueba tu conexión privada",
  "Your proxy or Tor service may be unavailable. Check that it is running and review your network settings.": "Es posible que tu proxy o servicio Tor no esté disponible. Comprueba que esté en funcionamiento y revisa los ajustes de red.",
  "We could not find this website": "No se ha encontrado este sitio",
  "Check the address and your DNS or internet connection, then try again.": "Comprueba la dirección y tu DNS o conexión a Internet y vuelve a intentarlo.",
  "You are offline": "No tienes conexión",
  "Connect to Wi-Fi or your wired network, then try this page again.": "Conéctate a una red Wi-Fi o por cable y vuelve a abrir la página.",
  "This website took too long": "Este sitio tardó demasiado",
  "The website did not respond in time. Give it a moment and try again.": "El sitio no respondió a tiempo. Espera un momento y vuelve a intentarlo.",
  "This page is out of reach": "No se puede acceder a esta página",
  "The connection could not be completed. Check your internet connection or try again in a moment.": "No se pudo completar la conexión. Comprueba tu conexión a Internet o vuelve a intentarlo en un momento.",
  "Chromium security patches": "Parches de seguridad de Chromium",
  "Save password?": "¿Guardar contraseña?",
  "Update password?": "¿Actualizar contraseña?",
  "Save password": "Guardar contraseña",
  "Update password": "Actualizar contraseña",
  "Username": "Nombre de usuario",
  "Password": "Contraseña",
  "Show password": "Mostrar contraseña",
  "Not now": "Ahora no",
  "Encrypted on this device. Saved only when you choose Save.": "Cifrada en este dispositivo. Solo se guarda con tu confirmación.",
  "Master password": "Contraseña maestra",
  "Repeat password": "Repite la contraseña",
  "Unlock your local vault to save this password.": "Desbloquea tu bóveda local para guardar esta contraseña.",
  "Create a master password of at least 12 characters to protect saved passwords.": "Crea una contraseña maestra de al menos 12 caracteres para proteger las contraseñas guardadas.",
  "Unlock and save": "Desbloquear y guardar",
  "Create vault and save": "Crear bóveda y guardar",
  "Enter a password to save.": "Introduce una contraseña para guardar.",
  "Use at least 12 characters. The passwords must match.": "Al menos 12 caracteres. Las contraseñas deben coincidir.",
  "Password saved locally.": "Contraseña guardada localmente.",
  "Incorrect master password or damaged vault.": "Contraseña maestra incorrecta o bóveda dañada.",
  "Show the expand button in the title bar": "Mostrar el botón de ampliación en la barra de título",
  "Expand button and title bar double-click": "Botón de ampliación y doble clic en la barra de título",
  "Maximize window": "Maximizar ventana",
  "Restore window": "Restaurar ventana",
  "Minimize": "Minimizar",
  "Charging": "Cargando",
  "On battery": "Usando batería",
  "Show time and battery only in full screen": "Mostrar la hora y la batería solo en pantalla completa",
  "Find a setting": "Buscar un ajuste",
  "No settings found. Try another word or clear the search.": "No se encontraron ajustes. Prueba otra palabra o borra la búsqueda.",
  "{count} matching settings": "{count} ajustes encontrados",
  "{count} unsaved changes": "{count} cambios sin guardar",
  "All changes saved.": "Todos los cambios están guardados.",
  "Check the highlighted setting.": "Revisa el ajuste indicado.",
  "Restart required": "Requiere reinicio",
  "Choose how SuperSearch protects your browsing.": "Elige cómo protege SuperSearch tu navegación.",
  "Make the browser comfortable to look at and use.": "Adapta el aspecto y la comodidad del navegador.",
  "Search, language, startup and everyday browsing.": "Búsqueda, idioma, inicio y navegación diaria.",
  "Manage optional tools and trusted website customizations.": "Gestiona herramientas opcionales y personalizaciones de confianza.",
  "See which tracking requests have been blocked.": "Consulta qué solicitudes de rastreo se bloquearon.",
  "Import your data, clean up or start over.": "Importa tus datos, limpia o empieza de nuevo.",
  "Version, browser engine and privacy documents.": "Versión, motor del navegador y documentos de privacidad.",
  "Protection level": "Nivel de protección",
  "Choose a starting point. You can adjust the switches below.": "Elige un punto de partida. Puedes ajustar las opciones de abajo.",
  "Balanced": "Equilibrado",
  "Stronger": "Reforzado",
  "Maximum": "Máximo",
  "Recommended for everyday browsing. Blocks known trackers and keeps most websites working.": "Recomendado para el día a día: bloquea rastreadores conocidos y mantiene la mayoría de los sitios funcionando.",
  "Adds tighter website restrictions. Some graphics and sign-in features may not work.": "Añade restricciones. Algunas funciones gráficas y de inicio de sesión pueden fallar.",
  "Requires a running Tor service and turns off website JavaScript. Many websites will not work.": "Requiere un servicio Tor activo y desactiva JavaScript. Muchos sitios no funcionarán.",
  "Everyday protection": "Protección diaria",
  "Block ads and trackers": "Bloquear anuncios y rastreadores",
  "Stop requests to known advertising and tracking services.": "Bloquea solicitudes a servicios conocidos de anuncios y rastreo.",
  "Use secure connections only": "Usar solo conexiones seguras",
  "Upgrade HTTP addresses to HTTPS. Websites without HTTPS will not open.": "Cambia HTTP por HTTPS. Los sitios sin HTTPS no se abrirán.",
  "Remove tracking tags from links": "Quitar etiquetas de rastreo de los enlaces",
  "Clean common advertising parameters from website addresses.": "Elimina parámetros publicitarios habituales de las direcciones.",
  "Limit tracking between websites": "Limitar el rastreo entre sitios",
  "Block third-party cookies and storage. Some embedded sign-ins may not work.": "Bloquea cookies y almacenamiento de terceros. Algunos accesos integrados pueden fallar.",
  "Hide the previous website address": "Ocultar la dirección de la página anterior",
  "Do not send websites the address of the page you came from.": "No envía al sitio la dirección de la página de la que vienes.",
  "Ask websites not to track me": "Pedir a los sitios que no me rastreen",
  "Send privacy preference signals. Websites decide whether to honor them.": "Envía tus preferencias de privacidad. Los sitios deciden si las respetan.",
  "Blocking lists": "Listas de bloqueo",
  "Download fresh EasyList and EasyPrivacy rules when you want an update.": "Descarga reglas recientes de EasyList y EasyPrivacy cuando lo solicitas.",
  "Website data": "Datos de sitios",
  "Forget website data when I close SuperSearch": "Olvidar los datos de sitios al cerrar SuperSearch",
  "Cookies stay in memory, so you may need to sign in again after a restart. Bookmarks and saved passwords are kept.": "Las cookies quedan en memoria. Quizá tengas que volver a iniciar sesión tras reiniciar. Se conservan marcadores y contraseñas.",
  "Website permissions": "Permisos de sitios",
  "Camera, microphone, location and notification permissions are denied by default.": "Cámara, micrófono, ubicación y notificaciones están denegados por defecto.",
  "Your connection": "Tu conexión",
  "Normal connection. Websites can see your public IP address.": "Conexión normal. Los sitios ven tu IP pública.",
  "A proxy is configured. Its service must be available to open websites.": "Hay un proxy configurado. Debe estar disponible para abrir sitios.",
  "Tor is selected. Tor must be running or websites cannot open.": "Tor está seleccionado. Su servicio debe estar activo para abrir sitios.",
  "Connection settings": "Ajustes de conexión",
  "Connection details": "Detalles de conexión",
  "For people using a proxy, Tor or a custom DNS provider.": "Para un proxy, Tor o un proveedor DNS personalizado.",
  "Secure DNS (DNS over HTTPS)": "DNS seguro (DNS sobre HTTPS)",
  "Choose who resolves website names. Tor connections use their own DNS route.": "Elige quién resuelve los nombres de sitios. Tor usa su propia ruta DNS.",
  "Use the system setting": "Usar el ajuste del sistema",
  "Proxy server": "Servidor proxy",
  "Paste an HTTP, SOCKS5 or SOCKS4 address. Leave blank for a normal connection.": "Pega una dirección HTTP, SOCKS5 o SOCKS4. Déjala vacía para una conexión normal.",
  "Use Tor for connections": "Usar Tor para las conexiones",
  "Start Tor on this device first. Uses 127.0.0.1:9050 and takes priority over the proxy address.": "Inicia Tor primero. Usa 127.0.0.1:9050 y tiene prioridad sobre el proxy.",
  "Check the proxy": "Comprobar el proxy",
  "Makes a test request to api.ipify.org through the chosen proxy or Tor.": "Envía una solicitud de prueba a api.ipify.org mediante el proxy elegido o Tor.",
  "Advanced website protections": "Protecciones avanzadas de sitios",
  "These settings can affect how websites work.": "Estos ajustes pueden afectar al funcionamiento de los sitios.",
  "Reduce browser fingerprinting": "Reducir la identificación del navegador",
  "Make some device details harder to read. This cannot prevent every form of fingerprinting.": "Dificulta leer algunos datos del dispositivo. No impide todas las formas de identificación.",
  "Restrict direct browser connections": "Limitar conexiones directas del navegador",
  "Limits WebRTC network exposure. Voice and video calls may not work.": "Limita la exposición de red de WebRTC. Las llamadas de voz y vídeo pueden fallar.",
  "Extra location blocking": "Bloqueo adicional de ubicación",
  "Block the location API in website scripts. Website permissions are already denied by default.": "Bloquea la API de ubicación en scripts. Los permisos ya están denegados por defecto.",
  "Turn off website JavaScript": "Desactivar JavaScript en sitios",
  "Many websites and sign-in forms stop working. Leave this off for everyday browsing.": "Muchos sitios y accesos dejarán de funcionar. Déjalo desactivado para el uso diario.",
  "Allow 3D graphics on websites": "Permitir gráficos 3D en sitios",
  "Needed by some maps, games and visual tools. It can reveal graphics-device details.": "Necesario para algunos mapas, juegos y herramientas. Puede revelar datos gráficos.",
  "Allow sites to read drawn images": "Permitir leer imágenes dibujadas",
  "Needed by some drawing and verification tools. It can reveal device details.": "Necesario para algunas herramientas de dibujo y verificación. Puede revelar datos del dispositivo.",
  "Let websites open new windows": "Permitir que los sitios abran ventanas",
  "Links and scripts that open another window may be blocked when this is off.": "Si está desactivado, se pueden bloquear enlaces y scripts que abren ventanas.",
  "How protection works": "Cómo funciona la protección",
  "Fingerprinting protection is best effort. Supported filters: domain rules, exceptions and literal text; cosmetic rules and advanced syntax are skipped.": "La protección contra identificación no es una garantía. Filtros: dominios, excepciones y texto; se omiten reglas cosméticas y complejas.",
  "The theme changes browser controls. Websites keep their own colors.": "El tema cambia el navegador. Los sitios conservan sus colores.",
  "Light": "Claro",
  "Dark": "Oscuro",
  "Pure black": "Negro puro",
  "Custom colors": "Colores personalizados",
  "Choose your own colors. Text must remain readable.": "Elige tus colores. El texto debe seguir siendo legible.",
  "Text and size": "Texto y tamaño",
  "Size of browser controls": "Tamaño de controles del navegador",
  "Website zoom": "Zoom de sitios",
  "Window and full screen": "Ventana y pantalla completa",
  "Maximize keeps system panels visible. Full screen hides them. F11 always enters full screen.": "Maximizar mantiene los paneles del sistema. Pantalla completa los oculta. F11 siempre activa pantalla completa.",
  "Hidden in normal and maximized windows. Charge is shown only when a battery is detected.": "Oculto en ventanas normales y maximizadas. Solo muestra carga si detecta batería.",
  "Shortcuts and wallpaper": "Accesos directos y fondo",
  "Changes in the editor are saved when you confirm them.": "Los cambios del editor se guardan al confirmarlos allí.",
  "Start page layout": "Distribución de la página de inicio",
  "Centered": "Centrado",
  "Near the top": "Arriba",
  "Panels and toolbar": "Paneles y barra de herramientas",
  "Move buttons and panels to suit the way you browse.": "Coloca botones y paneles como te resulte cómodo.",
  "Address bar buttons": "Botones de la barra de direcciones",
  "Drag rows to change the order. Uncheck a button to hide it.": "Arrastra las filas para cambiar el orden. Desmarca un botón para ocultarlo.",
  "Reset panel positions": "Restablecer posiciones de paneles",
  "Changes the layout now. Other browser data is kept.": "Cambia la distribución ahora. Se conservan los demás datos.",
  "Fine-tune spacing and corners": "Ajustar espacios y esquinas",
  "Corner roundness": "Redondeo de esquinas",
  "Search and language": "Búsqueda e idioma",
  "Typed queries are sent to DuckDuckGo when this is on. Suggestions stay off in private windows.": "Las consultas escritas se envían a DuckDuckGo. Las sugerencias siguen desactivadas en privado.",
  "Startup and tabs": "Inicio y pestañas",
  "Open new tabs with": "Abrir nuevas pestañas con",
  "SuperSearch start page": "Página de inicio de SuperSearch",
  "A website I choose": "Un sitio que elija",
  "Website address": "Dirección del sitio",
  "Reopen saved ordinary tabs. Pinned tabs are remembered separately; private tabs are not saved.": "Reabre pestañas normales guardadas. Las fijadas se recuerdan aparte; las privadas no se guardan.",
  "History and bookmarks": "Historial y marcadores",
  "Keep a local list of visited pages. Private windows are never recorded.": "Guarda localmente las páginas visitadas. Las ventanas privadas nunca se registran.",
  "Passwords and shortcuts": "Contraseñas y atajos",
  "Password manager": "Gestor de contraseñas",
  "View or edit the encrypted local vault. A master password is required.": "Consulta o edita la bóveda local cifrada. Requiere contraseña maestra.",
  "Built-in protection": "Protección integrada",
  "Ad blocking, secure connections and link cleanup are already included.": "El bloqueo de anuncios, las conexiones seguras y la limpieza de enlaces ya están incluidos.",
  "Optional extensions": "Extensiones opcionales",
  "Manage local extensions": "Gestionar extensiones locales",
  "Chrome Web Store does not install directly into SuperSearch. Compatible local extensions require a persistent profile.": "Chrome Web Store no instala directamente en SuperSearch. Las extensiones locales requieren un perfil persistente.",
  "User scripts and styles": "Scripts y estilos de usuario",
  "Install only code you trust. Installation and removal apply immediately.": "Instala solo código de confianza. La instalación y eliminación son inmediatas.",
  "Installed scripts": "Scripts instalados",
  "Trusted scripts can also read information on private pages when this is on.": "Los scripts de confianza también podrán leer información de páginas privadas.",
  "Tracking requests blocked": "Solicitudes de rastreo bloqueadas",
  "Website": "Sitio",
  "Clean up local data": "Limpiar datos locales",
  "Choose what to remove. Deletion happens only after you confirm.": "Elige qué eliminar. Solo se borra tras confirmar.",
  "Bring bookmarks and supported data from a Chromium browser.": "Trae marcadores y datos compatibles de un navegador Chromium.",
  "Privacy documents": "Documentos de privacidad",
  "Enter a complete website address, for example https://example.com.": "Introduce una dirección completa, por ejemplo https://example.com.",
  "Enter a proxy address such as socks5://127.0.0.1:1080, without a username or password.": "Introduce una dirección como socks5://127.0.0.1:1080 sin usuario ni contraseña.",
  "Proxy error: {message}": "Error de proxy: {message}",
  "Proxy IP: {address}": "IP del proxy: {address}",
  "{count} blocking rules loaded; {skipped} unsupported rules skipped.": "{count} reglas de bloqueo cargadas; {skipped} reglas no compatibles omitidas.",
  "Cookies and website data": "Cookies y datos de sitios",
  "Signs you out of websites. Your online accounts are not deleted.": "Cierra tus sesiones en sitios. No elimina tus cuentas en línea.",
  "Temporary files (cache)": "Archivos temporales (caché)",
  "Remove saved page resources. Websites may load more slowly at first.": "Elimina recursos guardados. Los sitios pueden cargar más lento al principio.",
  "Saved passwords": "Contraseñas guardadas",
  "Delete the local password vault and its master password.": "Elimina la bóveda local y su contraseña maestra.",
  "Remove browsing history, saved tab sessions and blocking totals.": "Elimina historial, sesiones de pestañas y estadísticas de bloqueo.",
  "Delete saved bookmarks and their folders.": "Elimina marcadores guardados y sus carpetas.",
  "Remove saved pins and their entries in the saved tab session.": "Elimina las fijaciones y sus entradas en la sesión guardada.",
  "Remove the list of downloads. Keep the downloaded files.": "Elimina la lista de descargas. Conserva los archivos descargados.",
  "Downloaded files": "Archivos descargados",
  "Delete unchanged files recorded by SuperSearch. Other files are kept.": "Elimina archivos sin modificar registrados por SuperSearch. Conserva los demás.",
  "The browser restarts after cleanup so cookies and cached files can be removed safely.": "El navegador se reinicia tras limpiar para eliminar cookies y caché de forma segura.",
  "Start over": "Empezar de nuevo",
  "Remove all browser data and return to first-run setup.": "Elimina todos los datos y vuelve a la configuración inicial.",
  "Split-view": "Vista dividida",
  "Forward": "Adelante",
  "cookies cookie site data": "cookies datos sitios",
  "proxy network internet connection": "proxy red internet conexión",
  "DNS network internet connection": "DNS red internet conexión",
  "tor onion network internet connection": "Tor onion red internet conexión",
  "cookies cache passwords accounts history bookmarks downloads reset Delete pinned": "cookies caché contraseñas cuentas historial marcadores descargas restablecer Delete fijadas",
  "Saved. Restart to finish applying these changes.": "Guardado. Reinicia para terminar de aplicar estos cambios.",
  "To remove website data saved earlier, use Storage.": "Para eliminar datos de sitios guardados antes, abre Almacenamiento.",
  "Readable colors": "Colores legibles",
  "These colors make text hard to read. Choose colors with a stronger contrast.": "Estos colores dificultan la lectura. Elige un contraste mayor.",
  "1 unsaved change": "1 cambio sin guardar",
  "1 matching setting": "1 ajuste encontrado",
  "Your public IP": "Tu IP pública",
  "Refresh IP address": "Actualizar dirección IP",
  "Checking…": "Comprobando…",
  "Unavailable": "No disponible",
  "Not checked yet": "Aún sin comprobar",
  "Could not check the address. Check your connection and try again.": "No se pudo comprobar la dirección. Revisa tu conexión e inténtalo de nuevo.",
  "Public connection address · provided by ipify": "Dirección pública de conexión · proporcionada por ipify",
  "Show public IP on the start page": "Mostrar IP pública en la página de inicio",
  "Contacts ipify through your current proxy or Tor when the start page is visible. The address stays in memory. Turn this off to avoid these requests.": "Contacta con ipify a través del proxy actual o Tor cuando se ve la página de inicio. La dirección permanece en memoria. Desactívalo para evitar estas solicitudes.",
  "Show public IP (contacts ipify)": "Mostrar IP pública (contacta con ipify)",
  "Source code": "Código fuente",
  "Security patches are backported from newer Chromium releases. The engine base version is listed separately.": "Las correcciones de seguridad se adaptan de versiones más recientes de Chromium. La versión base del motor se muestra por separado."
}
```

### settings/translations/fr.json
```json
{
  "Welcome to SuperSearch": "Bienvenue dans SuperSearch",
  "About the browser": "À propos du navigateur",
  "Agreement": "Accord",
  "Setup": "Configuration",
  "Import": "Importer",
  "Done": "Terminé",
  "Your web. Your choices.": "Votre Web. Vos choix.",
  "Local data": "Données locales",
  "Your workspace": "Votre espace de travail",
  "An easy switch": "Un changement facile",
  "Protect passwords with a master password and forget website data after each session.": "Protégez vos mots de passe avec un mot de passe principal et oubliez les données des sites après chaque session.",
  "Move panels, resize controls and make the start page your own.": "Déplacez les panneaux, redimensionnez les commandes et personnalisez votre page d’accueil.",
  "Bring bookmarks and compatible data from your selected Chromium profile.": "Importez les favoris et les données compatibles du profil Chromium choisi.",
  "I accept the user agreement and have read the privacy policy": "J’accepte l’accord d’utilisation et j’ai lu la politique de confidentialité",
  "Theme": "Thème",
  "light": "Clair",
  "dark": "Sombre",
  "oled": "OLED",
  "standard": "Standard",
  "strict": "Strict",
  "paranoia": "Paranoïa",
  "Off": "Désactivé",
  "Search engine": "Moteur de recherche",
  "Search suggestions": "Suggestions de recherche",
  "Choose whether you want search suggestions": "Choisissez si vous souhaitez des suggestions",
  "No, keep typing private until I search": "Non, garder la saisie privée jusqu’à la recherche",
  "Yes, show DuckDuckGo suggestions": "Oui, afficher les suggestions DuckDuckGo",
  "Forget website data after exit (session profile)": "Oublier les données des sites à la fermeture (profil de session)",
  "Save browsing history": "Enregistrer l’historique de navigation",
  "Network": "Réseau",
  "Standard secure connection": "Connexion sécurisée standard",
  "Tor via 127.0.0.1:9050": "Tor via 127.0.0.1:9050",
  "Tor requires a separately running Tor service. Without it, websites cannot load. Setup keeps JavaScript available for modern websites.": "Tor nécessite un service Tor exécuté séparément. Sans lui, les sites ne se chargent pas. La configuration conserve JavaScript pour les sites modernes.",
  "Ready for your first search": "Prêt pour votre première recherche",
  "Back": "Retour",
  "Continue": "Continuer",
  "Start browsing": "Commencer à naviguer",
  "Changes preview immediately. Startup network settings apply when the browser restarts.": "Les changements sont immédiatement visibles. Les paramètres réseau de démarrage s’appliquent au redémarrage.",
  "Choose a profile folder manually": "Choisir manuellement un dossier de profil",
  "Detect browsers again": "Rechercher à nouveau les navigateurs",
  "Default or Profile 1 folder": "Dossier Default ou Profile 1",
  "Folder": "Dossier",
  "Bookmarks and folders": "Favoris et dossiers",
  "History": "Historique",
  "Download history (files are not copied)": "Historique des téléchargements (sans copie des fichiers)",
  "Readable cookies (protected cookies are skipped)": "Cookies lisibles (les cookies protégés sont ignorés)",
  "Compatible general settings": "Paramètres généraux compatibles",
  "Optional password CSV": "CSV de mots de passe facultatif",
  "Password CSV": "CSV de mots de passe",
  "Import everything available from this browser": "Importer toutes les données disponibles de ce navigateur",
  "Import selected data": "Importer les données sélectionnées",
  "You can skip import and run it later in Storage settings.": "Vous pouvez ignorer l’import et le lancer plus tard dans les paramètres de stockage.",
  "Chromium profile": "Profil Chromium",
  "Choose a profile folder or password CSV.": "Choisissez un dossier de profil ou un CSV de mots de passe.",
  "Imported: ": "Importé : ",
  "Settings": "Paramètres",
  "Privacy": "Confidentialité",
  "Appearance": "Apparence",
  "General": "Général",
  "Extensions": "Extensions",
  "Statistics": "Statistiques",
  "Storage": "Stockage",
  "About": "À propos",
  "Preset": "Préréglage",
  "Tracker / advertising filters": "Filtres de traqueurs et de publicité",
  "Anti-fingerprinting JS (best effort)": "JavaScript anti-empreinte (au mieux)",
  "Block WebRTC": "Bloquer WebRTC",
  "Block geolocation JS": "Bloquer la géolocalisation JavaScript",
  "Disable all JavaScript": "Désactiver tout JavaScript",
  "HTTPS only": "HTTPS uniquement",
  "Remove tracking parameters": "Supprimer les paramètres de suivi",
  "Block third-party cookies / storage": "Bloquer les cookies et le stockage tiers",
  "Tor SOCKS5 — 127.0.0.1:9050": "Tor SOCKS5 — 127.0.0.1:9050",
  "Session profile: website data stays in memory": "Profil de session : les données des sites restent en mémoire",
  "Do not send Referer headers": "Ne pas envoyer d’en-têtes Referer",
  "Global Privacy Control and Do Not Track signals": "Signaux Global Privacy Control et Do Not Track",
  "Allow WebGL (may expose GPU information)": "Autoriser WebGL (peut révéler des informations sur le GPU)",
  "Allow canvas readback (required by some websites)": "Autoriser la lecture du canvas (nécessaire à certains sites)",
  "Allow JavaScript popups": "Autoriser les fenêtres JavaScript",
  "Run UserScripts in private windows": "Exécuter les UserScripts en fenêtre privée",
  "DNS over HTTPS": "DNS via HTTPS",
  "Proxy": "Proxy",
  "Test proxy": "Tester le proxy",
  "Update filters": "Actualiser les filtres",
  "requires restart": "redémarrage requis",
  "Background": "Arrière-plan",
  "Surface": "Surface",
  "Text": "Texte",
  "Accent": "Accent",
  "Font": "Police",
  "Control shape": "Forme des commandes",
  "Rounded": "Arrondie",
  "Pill": "Pilule",
  "Square": "Rectangulaire",
  "Interface animations": "Animations de l’interface",
  "Show the title in the title bar": "Afficher le titre dans la barre de titre",
  "Use the surface color for the title bar": "Utiliser la couleur de surface dans la barre de titre",
  "Corner radius": "Rayon des coins",
  "Spacing": "Espacement",
  "Interface scale, %": "Échelle de l’interface, %",
  "Page zoom, %": "Zoom des pages, %",
  "Tab panel width": "Largeur du panneau d’onglets",
  "Horizontal panel height": "Hauteur du panneau horizontal",
  "Tab height": "Hauteur des onglets",
  "Icon size": "Taille des icônes",
  "Address bar height": "Hauteur de la barre d’adresse",
  "Title bar height": "Hauteur de la barre de titre",
  "Drag rows to arrange toolbar buttons. Check a row to show its button.": "Déplacez les lignes pour organiser les boutons. Cochez une ligne pour afficher son bouton.",
  "Move panels with the mouse": "Déplacer les panneaux avec la souris",
  "Reset panel layout": "Réinitialiser la disposition des panneaux",
  "Start page": "Page d’accueil",
  "Content alignment": "Alignement du contenu",
  "Show the logo": "Afficher le logo",
  "Show the search field": "Afficher le champ de recherche",
  "Show privacy counters": "Afficher les compteurs de confidentialité",
  "Shortcut columns": "Colonnes de raccourcis",
  "Shortcut tile size": "Taille des tuiles de raccourcis",
  "Start page content width": "Largeur du contenu de l’accueil",
  "Edit shortcuts and wallpaper": "Modifier les raccourcis et le fond d’écran",
  "Choose wallpaper": "Choisir un fond d’écran",
  "Language": "Langue",
  "Homepage": "Page d’accueil",
  "Confirm before closing a window": "Confirmer avant de fermer une fenêtre",
  "Restore saved tabs on the next launch": "Restaurer les onglets au prochain lancement",
  "Show the bookmarks toolbar": "Afficher la barre des favoris",
  "The theme styles the browser interface. Websites keep their own colors.": "Le thème habille l’interface du navigateur. Les sites gardent leurs propres couleurs.",
  "Suggestions send typed queries to DuckDuckGo (normal windows only).": "Les suggestions envoient la saisie à DuckDuckGo (fenêtres normales uniquement).",
  "UserScript installation and removal are explicit actions that apply immediately.": "L’installation et la suppression des UserScripts sont des actions explicites et immédiates.",
  "Manifest V3 extension manager": "Gestionnaire d’extensions Manifest V3",
  "Install UserScript": "Installer un UserScript",
  "Remove": "Supprimer",
  "Total": "Total",
  "Daily blocks (last 14 days)": "Blocages quotidiens (14 derniers jours)",
  "Top blocked domains": "Domaines les plus bloqués",
  "Domain": "Domaine",
  "Manage local data": "Gérer les données locales",
  "Cookies and site data — sign out of websites": "Cookies et données des sites — se déconnecter des sites",
  "Page and graphics cache": "Cache des pages et des graphiques",
  "Local passwords and master password": "Mots de passe locaux et mot de passe principal",
  "History and statistics": "Historique et statistiques",
  "Bookmarks": "Favoris",
  "Pinned tabs": "Onglets épinglés",
  "Download history": "Historique des téléchargements",
  "Files downloaded by SuperSearch": "Fichiers téléchargés par SuperSearch",
  "Delete selected data and restart": "Supprimer les données sélectionnées et redémarrer",
  "Reset the entire browser": "Réinitialiser tout le navigateur",
  "Import from another browser": "Importer depuis un autre navigateur",
  "Select Apply to save your changes.": "Sélectionnez Appliquer pour enregistrer les changements.",
  "Apply": "Appliquer",
  "Close": "Fermer",
  "Cancel": "Annuler",
  "Restart": "Redémarrer",
  "You have unapplied changes.": "Des changements ne sont pas encore appliqués.",
  "Settings applied.": "Paramètres appliqués.",
  "Pinned tab": "Onglet épinglé",
  "Pin selected tabs": "Épingler les onglets sélectionnés",
  "Unpin selected tabs": "Désépingler les onglets sélectionnés",
  "Close selected tabs": "Fermer les onglets sélectionnés",
  "Keyboard shortcuts": "Raccourcis clavier",
  "Shortcut": "Raccourci",
  "Action": "Action",
  "New tab": "Nouvel onglet",
  "Close current tab": "Fermer l’onglet actif",
  "Close window": "Fermer la fenêtre",
  "Next tab": "Onglet suivant",
  "Previous tab": "Onglet précédent",
  "Switch to a numbered tab": "Passer à un onglet numéroté",
  "Switch to the last tab": "Passer au dernier onglet",
  "Pin or unpin selected tabs": "Épingler ou désépingler les onglets sélectionnés",
  "Select individual tabs": "Sélectionner des onglets séparément",
  "Select a range of tabs": "Sélectionner une plage d’onglets",
  "Select all tabs when the tab panel is focused": "Sélectionner tous les onglets lorsque le panneau est actif",
  "Close selected tabs when the tab panel is focused": "Fermer les onglets sélectionnés lorsque le panneau est actif",
  "Focus address bar": "Activer la barre d’adresse",
  "Bookmark the current page": "Ajouter la page aux favoris",
  "Toggle bookmarks toolbar": "Afficher ou masquer la barre des favoris",
  "New private window": "Nouvelle fenêtre privée",
  "Customize panel layout": "Personnaliser les panneaux",
  "Toggle split view": "Activer ou désactiver la vue partagée",
  "Reload": "Actualiser",
  "Full screen": "Plein écran",
  "Page zoom": "Zoom des pages",
  "Read Privacy Policy": "Lire la politique de confidentialité",
  "Read User Agreement": "Lire l’accord d’utilisation",
  "Discover a calmer, more personal way to browse. SuperSearch brings privacy controls, secure local password storage and a flexible workspace together in one thoughtfully designed browser. Keep your everyday web close, your choices in your hands, and your interface exactly the way you like it.": "Découvrez une navigation plus sereine et personnelle. SuperSearch réunit des contrôles de confidentialité, un stockage local sécurisé des mots de passe et un espace de travail flexible dans un navigateur soigné. Gardez votre Web quotidien à portée de main et une interface qui vous ressemble.",
  "Your choices are already previewed. Select Start browsing to finish setup and save them. Startup network or profile changes may restart the browser once. Your tabs, shortcuts and privacy controls are ready when you are.": "Vos choix sont déjà visibles. Sélectionnez Commencer à naviguer pour terminer et enregistrer la configuration. Certains changements de réseau ou de profil peuvent nécessiter un redémarrage. Vos onglets, raccourcis et contrôles de confidentialité sont prêts.",
  "Select a Chromium profile and data categories. The source browser is not changed. Passwords require a CSV exported by the source browser; the file contains unencrypted passwords. Protected cookies and account sessions may require signing in again.": "Choisissez un profil Chromium et les catégories de données. Le navigateur source reste inchangé. Les mots de passe nécessitent un CSV exporté par ce navigateur, contenant des mots de passe non chiffrés. Les cookies protégés et les sessions peuvent nécessiter une nouvelle connexion.",
  "Choose which data to delete. Cookies and site data are cleared after Chromium closes; the browser restarts automatically. Signing out does not delete your accounts with website providers.": "Choisissez les données à supprimer. Les cookies et données des sites sont effacés après la fermeture de Chromium, puis le navigateur redémarre. La déconnexion ne supprime pas vos comptes chez les fournisseurs.",
  "Default deny: camera, microphone, location, notifications.\nJS spoofing is best effort; sites and workers can bypass it.\nDoH / Chromium flags depend on the bundled engine. Tor must be running.\nFilter syntax: ||domain^, @@ exceptions, literal substrings.\nCosmetic rules, modifiers, regex and wildcards are skipped.\nProxy tests use requests, not Chromium. SOCKS4 resolves DNS locally.\nSuggestions are disabled in private windows. Private block counts stay in RAM.": "Refus par défaut : caméra, microphone, localisation et notifications.\nLe masquage JavaScript est limité ; les sites et workers peuvent le contourner.\nDoH et les paramètres Chromium dépendent du moteur inclus. Tor doit être actif.\nSyntaxe des filtres : ||domain^, exceptions @@ et sous-chaînes littérales.\nLes règles cosmétiques, modificateurs, expressions régulières et jokers sont ignorés.\nLes tests de proxy utilisent requests, pas Chromium. SOCKS4 résout le DNS localement.\nLes suggestions sont désactivées en privé. Les compteurs privés restent en mémoire.",
  "Qt 6.10+ supports compatible local Manifest V3 extensions.\nChrome Web Store does not install directly into SuperSearch.\nExtensions require a persistent profile and are unavailable in the session profile.\nBuilt-in: filtering, HTTPS-only, URL cleanup and denied permissions.\nUserScripts run on websites; install only code you trust.": "Qt 6.10+ prend en charge les extensions locales Manifest V3 compatibles.\nLe Chrome Web Store n’installe pas directement dans SuperSearch.\nLes extensions nécessitent un profil persistant et ne sont pas disponibles avec le profil de session.\nIntégré : filtres, HTTPS, nettoyage des URL et refus des autorisations.\nLes UserScripts s’exécutent sur les sites ; n’installez que du code fiable.",
  "Address": "Adresse",
  "Passwords": "Mots de passe",
  "Bookmark": "Marque-page",
  "Menu": "Menu",
  "center": "Centré",
  "top": "En haut",
  "Reset SuperSearch": "Réinitialiser SuperSearch",
  "All browser user data will be deleted": "Toutes les données utilisateur du navigateur seront supprimées",
  "Also delete files downloaded by SuperSearch": "Supprimer aussi les fichiers téléchargés par SuperSearch",
  "Other files in your Downloads folder are preserved. Modified or replaced files are skipped.": "Les autres fichiers du dossier Téléchargements sont conservés. Les fichiers modifiés ou remplacés sont ignorés.",
  "Type Delete": "Saisissez Delete",
  "Delete data and start over": "Supprimer les données et recommencer",
  "Delete the selected data?": "Supprimer les données sélectionnées ?",
  "The selected data will be deleted and the browser will restart.": "Les données sélectionnées seront supprimées et le navigateur redémarrera.",
  "Enter a complete homepage URL or supersearch:start.": "Saisissez une URL complète ou supersearch:start.",
  "Use socks5/http/socks4://host:port without credentials.": "Utilisez socks5/http/socks4://hôte:port sans identifiants.",
  "Configure a proxy or enable Tor first.": "Configurez un proxy ou activez Tor d’abord.",
  "Text/background contrast must be at least 4.5:1.": "Le contraste texte/fond doit être d’au moins 4,5:1.",
  "Connecting to api.ipify.org…": "Connexion à api.ipify.org…",
  "Downloading EasyList + EasyPrivacy…": "Téléchargement d’EasyList + EasyPrivacy…",
  "Private by choice. Comfortable by design.": "La confidentialité par choix. Le confort par conception.",
  "SuperSearch brings your everyday web into a personal workspace, with thoughtful privacy controls, secure local storage and an interface that adapts to you.": "SuperSearch réunit votre Web quotidien dans un espace personnel, avec des contrôles de confidentialité, un stockage local sécurisé et une interface qui s’adapte à vous.",
  "Privacy: session profiles, tracker filtering and optional search suggestions put your browsing choices in your hands.": "Confidentialité : les profils de session, le filtrage des traqueurs et les suggestions facultatives vous donnent le contrôle de votre navigation.",
  "Security: an encrypted master-password vault, explicit website permissions and HTTPS preferences help protect the way you browse.": "Sécurité : un coffre chiffré par mot de passe principal, des autorisations explicites et les préférences HTTPS protègent votre navigation.",
  "Convenience: tabs, split view, bookmarks, automatic downloads and browser import keep your favorite pages close.": "Confort : les onglets, la vue partagée, les favoris, les téléchargements automatiques et l’importation gardent vos pages à portée de main.",
  "Customization: arrange panels, shape controls, pick a theme and create your own start page.": "Personnalisation : organisez les panneaux, ajustez les commandes, choisissez un thème et créez votre page d’accueil.",
  "Built with Python, PySide6 and QtWebEngine (Chromium). Open source under the MIT license.": "Créé avec Python, PySide6 et QtWebEngine (Chromium). Code ouvert sous licence MIT.",
  "Settings, bookmarks, local passwords and the master password, cookies, website sessions, history, statistics, wallpapers, shortcuts, extensions and UserScripts will be deleted. The browser will restart and show first-run setup again. This action cannot be undone.": "Les paramètres, favoris, mots de passe locaux et principal, cookies, sessions de sites, historique, statistiques, fonds d’écran, raccourcis, extensions et UserScripts seront supprimés. Le navigateur redémarrera avec la configuration initiale. Cette action est irréversible.",
  "Back / forward": "Précédent / suivant",
  "Password menu": "Menu des mots de passe",
  "Panel layout saved.": "Disposition des panneaux enregistrée.",
  "Drag panels by their handles. Drag borders to resize. Ctrl+Shift+U finishes customization.": "Déplacez les panneaux par leurs poignées et redimensionnez-les par leurs bords. Ctrl+Shift+U termine la personnalisation.",
  "Suggestions are optional and off by default. When enabled, typed queries are sent to DuckDuckGo.": "Les suggestions sont facultatives et désactivées par défaut. Lorsqu’elles sont activées, les requêtes saisies sont envoyées à DuckDuckGo.",
  "Try again": "Réessayer",
  "Network settings": "Paramètres réseau",
  "Back to start page": "Retour à l’accueil",
  "Technical details": "Détails techniques",
  "Error code": "Code d’erreur",
  "Your privacy settings remain active.": "Vos paramètres de confidentialité restent actifs.",
  "Secure connection unavailable": "Connexion sécurisée indisponible",
  "The website could not provide a valid secure connection. Check your device clock or try again later.": "Le site n’a pas pu établir une connexion sécurisée valide. Vérifiez l’horloge de votre appareil ou réessayez plus tard.",
  "This request was blocked": "Cette requête a été bloquée",
  "A browser privacy rule or a network policy prevented this page from opening. You can review your settings.": "Une règle de confidentialité ou une politique réseau a empêché l’ouverture de cette page. Vous pouvez vérifier vos paramètres.",
  "Check your private connection": "Vérifiez votre connexion privée",
  "Your proxy or Tor service may be unavailable. Check that it is running and review your network settings.": "Votre proxy ou service Tor est peut-être indisponible. Vérifiez qu’il fonctionne et contrôlez vos paramètres réseau.",
  "We could not find this website": "Ce site est introuvable",
  "Check the address and your DNS or internet connection, then try again.": "Vérifiez l’adresse et votre DNS ou connexion Internet, puis réessayez.",
  "You are offline": "Vous êtes hors ligne",
  "Connect to Wi-Fi or your wired network, then try this page again.": "Connectez-vous au Wi-Fi ou à un réseau filaire, puis réessayez cette page.",
  "This website took too long": "Ce site met trop de temps à répondre",
  "The website did not respond in time. Give it a moment and try again.": "Le site n’a pas répondu à temps. Patientez un instant et réessayez.",
  "This page is out of reach": "Cette page est inaccessible",
  "The connection could not be completed. Check your internet connection or try again in a moment.": "La connexion n’a pas pu être établie. Vérifiez votre connexion Internet ou réessayez dans un instant.",
  "Chromium security patches": "Correctifs de sécurité Chromium",
  "Save password?": "Enregistrer le mot de passe ?",
  "Update password?": "Mettre à jour le mot de passe ?",
  "Save password": "Enregistrer le mot de passe",
  "Update password": "Mettre à jour le mot de passe",
  "Username": "Nom d’utilisateur",
  "Password": "Mot de passe",
  "Show password": "Afficher le mot de passe",
  "Not now": "Pas maintenant",
  "Encrypted on this device. Saved only when you choose Save.": "Chiffré sur cet appareil. Enregistré uniquement avec votre confirmation.",
  "Master password": "Mot de passe principal",
  "Repeat password": "Répétez le mot de passe",
  "Unlock your local vault to save this password.": "Déverrouillez votre coffre local pour enregistrer ce mot de passe.",
  "Create a master password of at least 12 characters to protect saved passwords.": "Créez un mot de passe principal d’au moins 12 caractères pour protéger les mots de passe enregistrés.",
  "Unlock and save": "Déverrouiller et enregistrer",
  "Create vault and save": "Créer le coffre et enregistrer",
  "Enter a password to save.": "Saisissez un mot de passe à enregistrer.",
  "Use at least 12 characters. The passwords must match.": "Au moins 12 caractères. Les mots de passe doivent être identiques.",
  "Password saved locally.": "Mot de passe enregistré localement.",
  "Incorrect master password or damaged vault.": "Mot de passe principal incorrect ou coffre endommagé.",
  "Show the expand button in the title bar": "Afficher le bouton d’agrandissement dans la barre de titre",
  "Expand button and title bar double-click": "Bouton d’agrandissement et double-clic sur la barre de titre",
  "Maximize window": "Agrandir la fenêtre",
  "Restore window": "Restaurer la fenêtre",
  "Minimize": "Réduire",
  "Charging": "En charge",
  "On battery": "Sur batterie",
  "Show time and battery only in full screen": "Afficher l’heure et la batterie uniquement en plein écran",
  "Find a setting": "Rechercher un paramètre",
  "No settings found. Try another word or clear the search.": "Aucun paramètre trouvé. Essayez un autre mot ou effacez la recherche.",
  "{count} matching settings": "{count} paramètres correspondants",
  "{count} unsaved changes": "{count} modifications non enregistrées",
  "All changes saved.": "Toutes les modifications sont enregistrées.",
  "Check the highlighted setting.": "Vérifiez le paramètre signalé.",
  "Restart required": "Redémarrage nécessaire",
  "Choose how SuperSearch protects your browsing.": "Choisissez comment SuperSearch protège votre navigation.",
  "Make the browser comfortable to look at and use.": "Adaptez l’apparence et le confort du navigateur.",
  "Search, language, startup and everyday browsing.": "Recherche, langue, démarrage et navigation quotidienne.",
  "Manage optional tools and trusted website customizations.": "Gérez les outils facultatifs et les personnalisations de sites fiables.",
  "See which tracking requests have been blocked.": "Consultez les requêtes de suivi bloquées.",
  "Import your data, clean up or start over.": "Importez vos données, faites le ménage ou recommencez.",
  "Version, browser engine and privacy documents.": "Version, moteur du navigateur et documents de confidentialité.",
  "Protection level": "Niveau de protection",
  "Choose a starting point. You can adjust the switches below.": "Choisissez une base. Vous pouvez ajuster les options ci-dessous.",
  "Balanced": "Équilibré",
  "Stronger": "Renforcé",
  "Maximum": "Maximum",
  "Recommended for everyday browsing. Blocks known trackers and keeps most websites working.": "Recommandé au quotidien : bloque les traqueurs connus et préserve la plupart des sites.",
  "Adds tighter website restrictions. Some graphics and sign-in features may not work.": "Ajoute des restrictions. Certaines fonctions graphiques et connexions peuvent ne pas fonctionner.",
  "Requires a running Tor service and turns off website JavaScript. Many websites will not work.": "Nécessite un service Tor actif et désactive JavaScript. De nombreux sites ne fonctionneront pas.",
  "Everyday protection": "Protection au quotidien",
  "Block ads and trackers": "Bloquer les publicités et traqueurs",
  "Stop requests to known advertising and tracking services.": "Bloque les requêtes vers les services publicitaires et de suivi connus.",
  "Use secure connections only": "Utiliser uniquement des connexions sécurisées",
  "Upgrade HTTP addresses to HTTPS. Websites without HTTPS will not open.": "Remplace HTTP par HTTPS. Les sites sans HTTPS ne s’ouvriront pas.",
  "Remove tracking tags from links": "Retirer les marqueurs de suivi des liens",
  "Clean common advertising parameters from website addresses.": "Retire les paramètres publicitaires courants des adresses.",
  "Limit tracking between websites": "Limiter le suivi entre sites",
  "Block third-party cookies and storage. Some embedded sign-ins may not work.": "Bloque les cookies et stockages tiers. Certaines connexions intégrées peuvent échouer.",
  "Hide the previous website address": "Masquer l’adresse de la page précédente",
  "Do not send websites the address of the page you came from.": "Ne transmet pas aux sites l’adresse de la page d’origine.",
  "Ask websites not to track me": "Demander aux sites de ne pas me suivre",
  "Send privacy preference signals. Websites decide whether to honor them.": "Envoie vos préférences de confidentialité. Les sites décident de les respecter ou non.",
  "Blocking lists": "Listes de blocage",
  "Download fresh EasyList and EasyPrivacy rules when you want an update.": "Télécharge les règles récentes d’EasyList et d’EasyPrivacy à votre demande.",
  "Website data": "Données des sites",
  "Forget website data when I close SuperSearch": "Oublier les données des sites à la fermeture",
  "Cookies stay in memory, so you may need to sign in again after a restart. Bookmarks and saved passwords are kept.": "Les cookies restent en mémoire. Une reconnexion peut être nécessaire après redémarrage. Favoris et mots de passe sont conservés.",
  "Website permissions": "Autorisations des sites",
  "Camera, microphone, location and notification permissions are denied by default.": "Caméra, microphone, localisation et notifications sont refusés par défaut.",
  "Your connection": "Votre connexion",
  "Normal connection. Websites can see your public IP address.": "Connexion normale. Les sites voient votre adresse IP publique.",
  "A proxy is configured. Its service must be available to open websites.": "Un proxy est configuré. Il doit être disponible pour ouvrir les sites.",
  "Tor is selected. Tor must be running or websites cannot open.": "Tor est sélectionné. Son service doit fonctionner pour ouvrir les sites.",
  "Connection settings": "Paramètres de connexion",
  "Connection details": "Détails de connexion",
  "For people using a proxy, Tor or a custom DNS provider.": "Pour un proxy, Tor ou un fournisseur DNS personnalisé.",
  "Secure DNS (DNS over HTTPS)": "DNS sécurisé (DNS sur HTTPS)",
  "Choose who resolves website names. Tor connections use their own DNS route.": "Choisissez le service de résolution des noms. Tor utilise son propre circuit DNS.",
  "Use the system setting": "Utiliser le réglage système",
  "Proxy server": "Serveur proxy",
  "Paste an HTTP, SOCKS5 or SOCKS4 address. Leave blank for a normal connection.": "Collez une adresse HTTP, SOCKS5 ou SOCKS4. Laissez vide pour une connexion normale.",
  "Use Tor for connections": "Utiliser Tor pour les connexions",
  "Start Tor on this device first. Uses 127.0.0.1:9050 and takes priority over the proxy address.": "Lancez d’abord Tor. Utilise 127.0.0.1:9050 et remplace l’adresse du proxy.",
  "Check the proxy": "Vérifier le proxy",
  "Makes a test request to api.ipify.org through the chosen proxy or Tor.": "Envoie une requête de test à api.ipify.org via le proxy choisi ou Tor.",
  "Advanced website protections": "Protections avancées des sites",
  "These settings can affect how websites work.": "Ces paramètres peuvent modifier le fonctionnement des sites.",
  "Reduce browser fingerprinting": "Réduire l’empreinte du navigateur",
  "Make some device details harder to read. This cannot prevent every form of fingerprinting.": "Rend certains détails de l’appareil moins lisibles. Ne bloque pas toutes les empreintes.",
  "Restrict direct browser connections": "Limiter les connexions directes du navigateur",
  "Limits WebRTC network exposure. Voice and video calls may not work.": "Limite l’exposition réseau de WebRTC. Les appels vocaux et vidéo peuvent échouer.",
  "Extra location blocking": "Blocage supplémentaire de la localisation",
  "Block the location API in website scripts. Website permissions are already denied by default.": "Bloque l’API de localisation dans les scripts. Les autorisations sont déjà refusées par défaut.",
  "Turn off website JavaScript": "Désactiver JavaScript sur les sites",
  "Many websites and sign-in forms stop working. Leave this off for everyday browsing.": "De nombreux sites et formulaires cesseront de fonctionner. Laissez cette option désactivée au quotidien.",
  "Allow 3D graphics on websites": "Autoriser la 3D sur les sites",
  "Needed by some maps, games and visual tools. It can reveal graphics-device details.": "Nécessaire à certaines cartes, jeux et outils. Peut révéler des détails graphiques.",
  "Allow sites to read drawn images": "Autoriser la lecture des images dessinées",
  "Needed by some drawing and verification tools. It can reveal device details.": "Nécessaire à certains outils de dessin et de vérification. Peut révéler des détails de l’appareil.",
  "Let websites open new windows": "Autoriser les sites à ouvrir des fenêtres",
  "Links and scripts that open another window may be blocked when this is off.": "Sinon, les liens et scripts ouvrant une fenêtre peuvent être bloqués.",
  "How protection works": "Fonctionnement de la protection",
  "Fingerprinting protection is best effort. Supported filters: domain rules, exceptions and literal text; cosmetic rules and advanced syntax are skipped.": "La protection contre les empreintes n’est pas garantie. Filtres : domaines, exceptions et texte ; règles cosmétiques et complexes ignorées.",
  "The theme changes browser controls. Websites keep their own colors.": "Le thème modifie le navigateur. Les sites gardent leurs couleurs.",
  "Light": "Clair",
  "Dark": "Sombre",
  "Pure black": "Noir pur",
  "Custom colors": "Couleurs personnalisées",
  "Choose your own colors. Text must remain readable.": "Choisissez vos couleurs. Le texte doit rester lisible.",
  "Text and size": "Texte et taille",
  "Size of browser controls": "Taille des commandes du navigateur",
  "Website zoom": "Zoom des sites",
  "Window and full screen": "Fenêtre et plein écran",
  "Maximize keeps system panels visible. Full screen hides them. F11 always enters full screen.": "Agrandir conserve les panneaux système. Le plein écran les masque. F11 active toujours le plein écran.",
  "Hidden in normal and maximized windows. Charge is shown only when a battery is detected.": "Masqué dans les fenêtres normales et agrandies. Charge affichée uniquement si une batterie est détectée.",
  "Shortcuts and wallpaper": "Raccourcis et fond d’écran",
  "Changes in the editor are saved when you confirm them.": "Les modifications de l’éditeur sont enregistrées après confirmation.",
  "Start page layout": "Disposition de la page d’accueil",
  "Centered": "Centré",
  "Near the top": "En haut",
  "Panels and toolbar": "Panneaux et barre d’outils",
  "Move buttons and panels to suit the way you browse.": "Placez boutons et panneaux selon vos habitudes.",
  "Address bar buttons": "Boutons de la barre d’adresse",
  "Drag rows to change the order. Uncheck a button to hide it.": "Déplacez les lignes pour changer l’ordre. Décochez un bouton pour le masquer.",
  "Reset panel positions": "Réinitialiser la disposition des panneaux",
  "Changes the layout now. Other browser data is kept.": "Modifie immédiatement la disposition. Les autres données sont conservées.",
  "Fine-tune spacing and corners": "Ajuster les espaces et les angles",
  "Corner roundness": "Arrondi des angles",
  "Search and language": "Recherche et langue",
  "Typed queries are sent to DuckDuckGo when this is on. Suggestions stay off in private windows.": "Les saisies sont alors envoyées à DuckDuckGo. Les suggestions restent désactivées en privé.",
  "Startup and tabs": "Démarrage et onglets",
  "Open new tabs with": "Ouvrir les nouveaux onglets avec",
  "SuperSearch start page": "Page d’accueil SuperSearch",
  "A website I choose": "Un site de mon choix",
  "Website address": "Adresse du site",
  "Reopen saved ordinary tabs. Pinned tabs are remembered separately; private tabs are not saved.": "Rouvre les onglets normaux enregistrés. Les épingles sont mémorisées séparément, les onglets privés ne le sont pas.",
  "History and bookmarks": "Historique et favoris",
  "Keep a local list of visited pages. Private windows are never recorded.": "Conserve les pages visitées localement. Les fenêtres privées ne sont jamais enregistrées.",
  "Passwords and shortcuts": "Mots de passe et raccourcis",
  "Password manager": "Gestionnaire de mots de passe",
  "View or edit the encrypted local vault. A master password is required.": "Consultez ou modifiez le coffre local chiffré. Le mot de passe principal est nécessaire.",
  "Built-in protection": "Protection intégrée",
  "Ad blocking, secure connections and link cleanup are already included.": "Le blocage publicitaire, les connexions sécurisées et le nettoyage des liens sont déjà inclus.",
  "Optional extensions": "Extensions facultatives",
  "Manage local extensions": "Gérer les extensions locales",
  "Chrome Web Store does not install directly into SuperSearch. Compatible local extensions require a persistent profile.": "Le Chrome Web Store n’installe pas directement dans SuperSearch. Les extensions locales nécessitent un profil persistant.",
  "User scripts and styles": "Scripts et styles utilisateur",
  "Install only code you trust. Installation and removal apply immediately.": "Installez uniquement du code fiable. Installation et suppression sont immédiates.",
  "Installed scripts": "Scripts installés",
  "Trusted scripts can also read information on private pages when this is on.": "Les scripts fiables pourront aussi lire des données sur les pages privées.",
  "Tracking requests blocked": "Requêtes de suivi bloquées",
  "Website": "Site",
  "Clean up local data": "Nettoyer les données locales",
  "Choose what to remove. Deletion happens only after you confirm.": "Choisissez les données à supprimer. Une confirmation est nécessaire.",
  "Bring bookmarks and supported data from a Chromium browser.": "Importez les favoris et données compatibles d’un navigateur Chromium.",
  "Privacy documents": "Documents de confidentialité",
  "Enter a complete website address, for example https://example.com.": "Saisissez une adresse complète, par exemple https://example.com.",
  "Enter a proxy address such as socks5://127.0.0.1:1080, without a username or password.": "Saisissez une adresse proxy comme socks5://127.0.0.1:1080 sans identifiants.",
  "Proxy error: {message}": "Erreur du proxy : {message}",
  "Proxy IP: {address}": "IP du proxy : {address}",
  "{count} blocking rules loaded; {skipped} unsupported rules skipped.": "{count} règles de blocage chargées ; {skipped} règles non prises en charge ignorées.",
  "Cookies and website data": "Cookies et données des sites",
  "Signs you out of websites. Your online accounts are not deleted.": "Vous déconnecte des sites. Vos comptes en ligne ne sont pas supprimés.",
  "Temporary files (cache)": "Fichiers temporaires (cache)",
  "Remove saved page resources. Websites may load more slowly at first.": "Supprime les ressources enregistrées. Les sites peuvent être plus lents au début.",
  "Saved passwords": "Mots de passe enregistrés",
  "Delete the local password vault and its master password.": "Supprime le coffre local et son mot de passe principal.",
  "Remove browsing history, saved tab sessions and blocking totals.": "Supprime l’historique, les sessions d’onglets et les statistiques de blocage.",
  "Delete saved bookmarks and their folders.": "Supprime les favoris et leurs dossiers.",
  "Remove saved pins and their entries in the saved tab session.": "Supprime les épingles et leurs entrées dans la session enregistrée.",
  "Remove the list of downloads. Keep the downloaded files.": "Supprime la liste des téléchargements. Les fichiers sont conservés.",
  "Downloaded files": "Fichiers téléchargés",
  "Delete unchanged files recorded by SuperSearch. Other files are kept.": "Supprime les fichiers inchangés enregistrés par SuperSearch. Les autres sont conservés.",
  "The browser restarts after cleanup so cookies and cached files can be removed safely.": "Le navigateur redémarre après le nettoyage pour supprimer cookies et cache correctement.",
  "Start over": "Recommencer",
  "Remove all browser data and return to first-run setup.": "Supprime toutes les données et relance la configuration initiale.",
  "Split-view": "Vue partagée",
  "Forward": "Suivant",
  "cookies cookie site data": "cookies données sites",
  "proxy network internet connection": "proxy réseau internet connexion",
  "DNS network internet connection": "DNS réseau internet connexion",
  "tor onion network internet connection": "Tor onion réseau internet connexion",
  "cookies cache passwords accounts history bookmarks downloads reset Delete pinned": "cookies cache mots passe comptes historique favoris téléchargements réinitialiser Delete épinglés",
  "Saved. Restart to finish applying these changes.": "Enregistré. Redémarrez pour terminer l’application de ces changements.",
  "To remove website data saved earlier, use Storage.": "Pour supprimer les données des sites enregistrées auparavant, ouvrez Stockage.",
  "Readable colors": "Couleurs lisibles",
  "These colors make text hard to read. Choose colors with a stronger contrast.": "Ces couleurs rendent le texte difficile à lire. Choisissez un contraste plus fort.",
  "1 unsaved change": "1 modification non enregistrée",
  "1 matching setting": "1 paramètre correspondant",
  "Your public IP": "Votre IP publique",
  "Refresh IP address": "Actualiser l’adresse IP",
  "Checking…": "Vérification…",
  "Unavailable": "Indisponible",
  "Not checked yet": "Pas encore vérifiée",
  "Could not check the address. Check your connection and try again.": "Impossible de vérifier l’adresse. Vérifiez votre connexion et réessayez.",
  "Public connection address · provided by ipify": "Adresse publique de connexion · fournie par ipify",
  "Show public IP on the start page": "Afficher l’IP publique sur la page d’accueil",
  "Contacts ipify through your current proxy or Tor when the start page is visible. The address stays in memory. Turn this off to avoid these requests.": "Contacte ipify via votre proxy actuel ou Tor lorsque la page d’accueil est visible. L’adresse reste en mémoire. Désactivez cette option pour éviter ces requêtes.",
  "Show public IP (contacts ipify)": "Afficher l’IP publique (contacte ipify)",
  "Source code": "Code source",
  "Security patches are backported from newer Chromium releases. The engine base version is listed separately.": "Les correctifs de sécurité sont rétroportés depuis des versions plus récentes de Chromium. La version de base du moteur est indiquée séparément."
}
```

### settings/translations/legacy_folders.json
```json
{"Панель закладок":"Bookmarks toolbar","Другие закладки":"Other bookmarks"}
```

### settings/translations/ru.json
```json
{
  "Reset SuperSearch": "Полный сброс SuperSearch",
  "All browser user data will be deleted": "Все пользовательские данные браузера будут удалены",
  "Settings, bookmarks, local passwords and the master password, cookies, website sessions, history, statistics, wallpapers, shortcuts, extensions and UserScripts will be deleted. The browser will restart and show first-run setup again. This action cannot be undone.": "Удалятся настройки, закладки, локальные пароли и мастер-пароль, cookies, входы на сайты, история, статистика, обои, ярлыки, расширения и UserScripts. Браузер перезапустится и снова покажет первый запуск. Это действие нельзя отменить.",
  "Also delete files downloaded by SuperSearch": "Удалить также файлы, скачанные SuperSearch",
  "Other files in your Downloads folder are preserved. Modified or replaced files are skipped.": "Другие файлы в системной папке «Загрузки» не удаляются. Изменённые или заменённые файлы пропускаются.",
  "Type Delete": "Введите Delete",
  "Delete data and start over": "Удалить данные и начать заново",
  "Cancel": "Отмена",
  "Manage local data": "Управление локальными данными",
  "Choose which data to delete. Cookies and site data are cleared after Chromium closes; the browser restarts automatically. Signing out does not delete your accounts with website providers.": "Выберите данные для удаления. Cookies и данные сайтов очищаются после закрытия Chromium; браузер перезапустится автоматически. Выход с сайтов не отменяет регистрацию у их владельцев.",
  "Delete selected data and restart": "Удалить выбранное и перезапустить",
  "Reset the entire browser": "Полностью сбросить браузер",
  "Cookies and site data — sign out of websites": "Cookies и данные сайтов — выйти со всех сайтов",
  "Page and graphics cache": "Кэш страниц и графики",
  "Local passwords and master password": "Локальные пароли и мастер-пароль",
  "History and statistics": "История и статистика",
  "Bookmarks": "Закладки",
  "Download history": "Список загрузок",
  "Files downloaded by SuperSearch": "Файлы, скачанные SuperSearch",
  "Delete the selected data?": "Удалить выбранные данные?",
  "The selected data will be deleted and the browser will restart.": "Выбранные данные будут удалены. Браузер перезапустится.",
  "Delete": "Удалить",
  "Customize the start page": "Настроить главную страницу",
  "Alignment": "Расположение",
  "Apply": "Применить",
  "Shortcut": "Сочетание клавиш",
  "Name": "Название",
  "Address": "Адрес",
  "From bookmarks": "Из закладок",
  "Page:": "Страница:",
  "Add": "Добавить",
  "Edit": "Изменить",
  "Defaults": "Стандартные",
  "Columns": "Колонки",
  "Tile size": "Размер плитки",
  "Content width": "Ширина содержимого",
  "Logo": "Логотип",
  "Search field": "Строка поиска",
  "Privacy counters": "Счётчики приватности",
  "Shortcuts": "Ярлыки",
  "There are no bookmarks yet.": "Пока нет закладок.",
  "Enter an HTTP or HTTPS URL without embedded credentials.": "Введите адрес HTTP или HTTPS без логина и пароля в URL.",
  "Start page": "Главная страница",
  "Bookmarks toolbar": "Панель закладок",
  "Other bookmarks": "Другие закладки",
  "Folder": "Папка",
  "Done": "Готово",
  "Delete bookmark": "Удалить закладку",
  "Edit bookmark": "Изменить закладку",
  "Bookmark added": "Закладка добавлена",
  "Search bookmarks…": "Поиск по закладкам…",
  "Enter a valid website address.": "Введите корректный адрес сайта.",
  "Open": "Открыть",
  "Delete this bookmark?": "Удалить закладку?",
  "Imported record": "Импортированная запись",
  "Completed": "Завершено",
  "Cancelled": "Отменено",
  "Pause": "Пауза",
  "Downloading…": "Скачивание…",
  "Open folder": "Открыть папку",
  "Downloads": "Загрузки",
  "Clear completed items": "Убрать завершённые из списка",
  "Error: ": "Ошибка: ",
  "Continue": "Продолжить",
  "Files are saved to your system Downloads folder. This list is kept for the current session only.": "Файлы сохраняются в системную папку «Загрузки». Список хранится только в этой сессии.",
  "Imported record · file ": "Импортированная запись · файл ",
  " MB": " МБ",
  "found": "найден",
  "not found": "не найден",
  "Could not save download: ": "Не удалось сохранить загрузку: ",
  "Minimize": "Свернуть",
  "Close": "Закрыть",
  "</span>Add</a>": "</span>Добавить</a>",
  "}\n    @keyframes enter{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}\n    @media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}\n    </style></head><body><main><div class=\"tools\"><a href=\"supersearch:customize\">Customize start page</a><a href=\"supersearch:wallpaper\">": "}\n    @keyframes enter{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}\n    @media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}\n    </style></head><body><main><div class=\"tools\"><a href=\"supersearch:customize\">Настроить главную</a><a href=\"supersearch:wallpaper\">",
  " Wallpaper</a><a href=\"supersearch:wallpaper-reset\">Reset background</a></div>\n    <div class=\"center\"><div class=\"logo\">": " Обои</a><a href=\"supersearch:wallpaper-reset\">Сбросить фон</a></div>\n    <div class=\"center\"><div class=\"logo\">",
  "</div><form action=\"https://supersearch.invalid/search\" method=\"get\"><input name=\"q\" aria-label=\"Search\" placeholder=\"Search the web or enter an address\" autocomplete=\"off\" required><button type=\"submit\">Search ": "</div><form action=\"https://supersearch.invalid/search\" method=\"get\"><input name=\"q\" aria-label=\"Поиск\" placeholder=\"Поиск в интернете или адрес сайта\" autocomplete=\"off\" required><button type=\"submit\">Найти ",
  "</div><small>TOTAL</small></div><div class=\"stat\"><div class=\"number\" id=\"blocked-today\">": "</div><small>ВСЕГО</small></div><div class=\"stat\"><div class=\"number\" id=\"blocked-today\">",
  "</div><small>TODAY</small></div><div class=\"stat\"><div class=\"number\" id=\"blocked-domains\">": "</div><small>СЕГОДНЯ</small></div><div class=\"stat\"><div class=\"number\" id=\"blocked-domains\">",
  "</div><small>DOMAINS</small></div></footer></main></body></html>": "</div><small>ДОМЕНОВ</small></div></footer></main></body></html>",
  "</a><div class=\"edit\"><a aria-label=\"Edit ": "</a><div class=\"edit\"><a aria-label=\"Изменить ",
  "</a><a aria-label=\"Remove ": "</a><a aria-label=\"Удалить ",
  "Start page wallpaper": "Обои главной страницы",
  "Images (*.png *.jpg *.jpeg *.webp *.bmp)": "Изображения (*.png *.jpg *.jpeg *.webp *.bmp)",
  "Private window · in-memory statistics": "Приватное окно · статистика в памяти",
  "Tor proxy": "Tor-прокси",
  "Session profile": "Сеансовый профиль",
  "Persistent profile": "Постоянный профиль",
  "Proxy": "Прокси",
  "Direct connection — IP address is visible": "Прямое соединение — IP не скрыт",
  "Choose an image smaller than 30 MB.": "Выберите изображение размером до 30 МБ.",
  "The image resolution is too large.": "Слишком большое разрешение изображения.",
  "Could not read the image.": "Не удалось прочитать изображение.",
  "Could not save the wallpaper.": "Не удалось сохранить обои.",
  "Wallpaper": "Обои",
  "Chrome Web Store does not install extensions directly. <a href=\"extensions\">Compatibility and local extensions</a>": "Chrome Web Store не устанавливает расширения напрямую. <a href=\"extensions\">Совместимость и локальные расширения</a>",
  "Standard connection": "Обычное подключение",
  "Network settings": "Настройки сети",
  "Downloads · Ctrl+J": "Загрузки · Ctrl+J",
  "Back · Alt+Left": "Назад · Alt+Left",
  "Forward · Alt+Right": "Вперёд · Alt+Right",
  "Reload · F5": "Обновить · F5",
  "Local passwords": "Локальные пароли",
  "Menu / customize interface": "Меню / настройка интерфейса",
  "Back": "Назад",
  "Password manager": "Менеджер паролей",
  "Save a login from this page": "Сохранить логин с этой страницы",
  "Fill a saved password": "Заполнить сохранённый пароль",
  "Lock password vault": "Заблокировать хранилище",
  "Save this password?": "Сохранить пароль?",
  "Fill password": "Заполнить пароль",
  "Account:": "Учётная запись:",
  "Could not restart the application.": "Не удалось перезапустить приложение.",
  "Tor or a proxy is configured; its service must be running. ": "Выбран Tor или прокси: нужен запущенный сервис. ",
  "Could not load the page. ": "Не удалось загрузить страницу. ",
  "Passwords": "Пароли",
  "Password capture and filling are disabled in private windows.": "В приватном окне сохранение и заполнение паролей отключены.",
  " in the encrypted local vault?": " в зашифрованном локальном хранилище?",
  "There are no saved passwords for this website.": "Для этого сайта нет сохранённых паролей.",
  "Downloads · active: ": "Загрузки · активно: ",
  "Clear local history?": "Очистить локальную историю?",
  "Delete browsing history and blocking statistics? Bookmarks, passwords and downloaded files are preserved.": "Удалить историю посещений и статистику блокировок? Закладки, пароли и скачанные файлы сохранятся.",
  "JavaScript is disabled; some websites may not work.": "JavaScript отключён; часть сайтов не работает.",
  "There is no direct fallback if the proxy is unavailable.": "При недоступном прокси прямого обхода нет.",
  "Save the login for ": "Сохранить логин для ",
  "(no username)": "(без логина)",
  "Master password": "Мастер-пароль",
  "Set a master password with at least 12 characters.\nIt encrypts your local vault. The password cannot be recovered.": "Задайте мастер-пароль — минимум 12 символов.\nОн шифрует локальное хранилище. Восстановления пароля нет.",
  "Repeat password": "Повторите пароль",
  "Save password": "Сохранить пароль",
  "Website": "Сайт",
  "Username": "Имя пользователя",
  "Password": "Пароль",
  "Show password": "Показать пароль",
  "Open this entry's website in a regular window. The complete origin must match.": "Откройте сайт этой записи в обычном окне. Адрес должен совпадать полностью.",
  "Change master password": "Изменить мастер-пароль",
  "Use at least 12 characters. The passwords must match.": "Минимум 12 символов. Пароли должны совпадать.",
  "Unlock passwords": "Разблокировать пароли",
  "Master password:": "Мастер-пароль:",
  "No supported login form was found. Filling is unavailable when JavaScript is disabled.": "На странице не найдена доступная форма входа. При отключённом JavaScript заполнение недоступно.",
  "Unlock": "Разблокировать",
  "View entry": "Открыть запись",
  "Fill": "Заполнить",
  "Lock": "Заблокировать",
  "Encrypted locally · locks after 5 minutes without vault activity": "Зашифровано локально • автоблокировка через 5 минут без операций",
  "Vault unlocked": "Хранилище разблокировано",
  "Vault locked": "Хранилище заблокировано",
  "Delete the selected entry?": "Удалить выбранную запись?",
  "Enabling an extension crashes the installed Qt 6.12.0 Linux build. Installation and activation are disabled on this build. UserScripts and built-in modules remain available.": "В установленной Qt 6.12.0 на Linux включение расширения вызывает нативный сбой. Установка и активация отключены для этой сборки. Доступны UserScripts и встроенные модули.",
  "The manifest.json file is too large.": "Слишком большой manifest.json.",
  "Only Manifest V3 extensions are supported.": "Поддерживаются только расширения Manifest V3.",
  "The extension name is missing.": "Не задано имя расширения.",
  "Manifest V3 extensions": "Расширения Manifest V3",
  "Chrome Web Store does not install extensions directly into SuperSearch.\nQt 6.10+ supports compatible local Manifest V3 packages.\nExtensions may read visited pages and send data over the network.": "Chrome Web Store не устанавливает расширения в SuperSearch напрямую.\nQt 6.10+ поддерживает совместимые локальные пакеты Manifest V3.\nРасширения могут читать посещаемые страницы и отправлять данные в сеть.",
  "Install ZIP": "Установить ZIP",
  "Install folder": "Установить папку",
  "Enable / disable": "Вкл. / выкл.",
  "Open popup": "Открыть меню",
  "Operation complete. New extensions stay disabled until explicitly enabled.": "Операция завершена. Новые расширения отключены до явного включения.",
  "Extension folder": "Папка расширения",
  "The extension archive is too large.": "Слишком большой архив расширения.",
  "Extensions require Qt 6.10+ and a persistent profile. The private session profile is the default; changing it requires a restart.": "Для расширений нужен Qt 6.10+ и постоянный профиль. Сеансовый профиль включён по умолчанию для приватности; его можно изменить в настройках с перезапуском.",
  "Extension ZIP": "ZIP расширения",
  "\nRequested permissions: ": "\nЗапрашиваемый доступ: ",
  "Install this extension?": "Установить расширение?",
  "Installing…": "Установка…",
  "Extensions": "Расширения",
  "Symbolic links are not allowed in extensions.": "Символические ссылки в расширении не разрешены.",
  "Invalid paths in the extension archive.": "Недопустимые пути в архиве расширения.",
  "Remove ": "Удалить ",
  "Tabs": "Вкладки",
  "Address bar": "Адресная панель",
  "Customize interface": "Настроить интерфейс",
  "Move panels": "Перемещать панели",
  "Reset layout": "Сбросить расположение",
  "Customize start page": "Настроить главную",
  "New private window": "Новое приватное окно",
  "New isolated session": "Новая изолированная сессия",
  "Clear history and counters": "Очистить историю и счётчики",
  "Drag panels by their handles. Drag borders to resize. Ctrl+Shift+U finishes customization.": "Перетаскивайте панели за заголовки, а границы — для изменения размера. Ctrl+Shift+U завершает настройку.",
  "Panel layout saved.": "Расположение панелей сохранено.",
  "Page zoom: ": "Масштаб страницы: ",
  "Yes": "Да",
  "No": "Нет",
  "OK": "Понятно",
  "Save": "Сохранить",
  "Discard": "Не сохранять",
  "Select a Chromium profile and data categories. The source browser is not changed. Passwords require a CSV exported by the source browser; the file contains unencrypted passwords. Protected cookies and account sessions may require signing in again.": "Выберите профиль Chromium и категории. Исходный браузер не изменяется. Для паролей нужен CSV, экспортированный самим браузером; файл содержит открытые пароли. Защищённые cookies и входы в аккаунты могут потребовать повторной авторизации.",
  "Choose a profile folder manually": "Выбрать папку профиля вручную",
  "Default or Profile 1 folder": "Папка Default или Profile 1",
  "Optional password CSV": "Необязательно: CSV паролей",
  "Password CSV": "CSV паролей",
  "Import selected data": "Импортировать выбранное",
  "You can skip import and run it later in Storage settings.": "Импорт можно пропустить и выполнить позднее в разделе «Хранилище».",
  "Chromium profile": "Профиль Chromium",
  "Welcome to SuperSearch": "Добро пожаловать в SuperSearch",
  "About the browser  /  Agreement  /  Setup  /  Import  /  Done": "О браузере  /  Соглашение  /  Настройка  /  Перенос  /  Готово",
  "Your web. Your choices.": "Ваш интернет. Ваши правила.",
  "SuperSearch keeps settings and bookmarks on your device, blocks known trackers and gives you a comfortable, customizable workspace. Website data stays in memory by default. Search suggestions are enabled with your permission. Direct connections expose your IP address.": "SuperSearch хранит настройки и закладки на вашем устройстве, блокирует известные трекеры и позволяет собрать удобный интерфейс. По умолчанию данные сайтов остаются только в памяти. Подсказки включаются с вашего согласия. Прямое соединение не скрывает IP-адрес.",
  "I accept the user agreement and have read the privacy policy": "Я ознакомился с условиями использования и обработкой локальных данных",
  "Theme": "Тема",
  "Search engine": "Поисковик",
  "Search suggestions": "Подсказки",
  "Forget website data after exit (session profile)": "Забывать данные сайтов после выхода (сеансовый профиль)",
  "Save browsing history": "Сохранять историю посещений",
  "Network": "Сеть",
  "Tor requires a separately running Tor service. Without it, websites cannot load. Setup keeps JavaScript available for modern websites.": "Для Tor должен быть запущен отдельный Tor-сервис. Если его нет, сайты не откроются. Мастер запуска не включает полное отключение JavaScript, чтобы сайты работали.",
  "Ready for your first search": "Готово к первому поиску",
  "Settings apply when you select Start browsing. Network changes may require the browser to restart. Move panels, edit shortcuts, and manage all local data in Storage settings.": "Настройки применятся после нажатия «Начать работу». При изменении сетевого режима браузер перезапустится. Панели можно передвигать, ярлыки — редактировать, а все локальные данные удалить в разделе «Хранилище».",
  "About the browser": "О браузере",
  "Agreement": "Соглашение",
  "Setup": "Настройка",
  "Import": "Перенос",
  "Bookmarks and folders": "Закладки и папки",
  "History": "История",
  "Download history (files are not copied)": "История загрузок (без копирования файлов)",
  "Readable cookies (protected cookies are skipped)": "Доступные cookies (защищённые будут пропущены)",
  "Compatible general settings": "Совместимые общие настройки",
  "Choose a profile folder or password CSV.": "Выберите папку профиля или CSV паролей.",
  "Local data": "Локальные данные",
  "Protect passwords with a master password and forget website data after each session.": "Пароли защищены мастер-паролем, а данные сайтов можно забывать после каждой сессии.",
  "Your workspace": "Свой интерфейс",
  "Move panels, resize controls and make the start page your own.": "Перемещайте панели, меняйте размер элементов и собирайте главную страницу под себя.",
  "An easy switch": "Простой переход",
  "Bring bookmarks and compatible data from your selected Chromium profile.": "Перенесите закладки и совместимые данные из выбранного профиля Chromium.",
  "Choose whether you want search suggestions": "Выберите: нужны ли подсказки?",
  "No, keep typing private until I search": "Нет, не отправлять текст до поиска",
  "Yes, show DuckDuckGo suggestions": "Да, получать подсказки DuckDuckGo",
  "Standard secure connection": "Обычное защищённое подключение",
  "Tor via 127.0.0.1:9050": "Tor через 127.0.0.1:9050",
  "Start browsing": "Начать работу",
  "\nIf the profile is busy, close the source browser and try again.": "\nЕсли профиль занят, закройте исходный браузер и повторите.",
  "Import failed: ": "Импорт не выполнен: ",
  "Could not save imported data: ": "Не удалось сохранить импорт: ",
  "Imported: ": "Импортировано: ",
  "Session profile: website data stays in memory": "Сеансовый профиль: данные сайтов только в памяти",
  "Do not send Referer headers": "Не отправлять Referer",
  "Global Privacy Control and Do Not Track signals": "Сигналы Global Privacy Control и Do Not Track",
  "Allow WebGL (may expose GPU information)": "Разрешить WebGL (может раскрывать сведения о GPU)",
  "Allow canvas readback (required by some websites)": "Разрешить чтение canvas (нужно некоторым сайтам)",
  "Allow JavaScript popups": "Разрешить всплывающие окна JavaScript",
  "Run UserScripts in private windows": "Запускать UserScripts в приватных окнах",
  "Select Apply to save your changes.": "Изменения вступят в силу после нажатия «Применить».",
  "Restart": "Перезапустить",
  "Control shape": "Форма элементов",
  "Interface animations": "Анимации интерфейса",
  "Show the title in the title bar": "Название в верхней панели",
  "Use the surface color for the title bar": "Выделить верхнюю панель цветом поверхности",
  "Forward": "Вперёд",
  "Reload": "Обновить",
  "Privacy": "Приватность",
  "Bookmark": "Закладка",
  "Menu": "Меню",
  "Move panels with the mouse": "Перемещать панели мышью",
  "Reset panel layout": "Сбросить расположение панелей",
  "Manifest V3 extension manager": "Менеджер расширений Manifest V3",
  "Import from another browser": "Перенос из другого браузера",
  "You have unapplied changes.": "Есть неприменённые изменения.",
  "Settings": "Настройки",
  "Enter a complete homepage URL or supersearch:start.": "Введите полный адрес домашней страницы или supersearch:start.",
  "Settings applied.": "Настройки применены.",
  "Rounded": "Скруглённая",
  "Pill": "Капсула",
  "Square": "Прямоугольная",
  "Corner radius": "Скругление",
  "Spacing": "Отступы",
  "Interface scale, %": "Масштаб интерфейса, %",
  "Page zoom, %": "Масштаб страниц, %",
  "Tab panel width": "Ширина панели вкладок",
  "Horizontal panel height": "Высота горизонтальной панели",
  "Tab height": "Высота вкладки",
  "Icon size": "Размер иконок",
  "Address bar height": "Высота адресной панели",
  "Title bar height": "Высота верхней панели окна",
  "Drag rows to arrange toolbar buttons. Check a row to show its button.": "Порядок кнопок: перетаскивайте строки. Галочка показывает кнопку.",
  "The theme styles the browser interface. Websites keep their own colors.": "Тема применяется к интерфейсу браузера. Цвета сайтов определяются самими сайтами.",
  "UserScript installation and removal are explicit actions that apply immediately.": "Установка и удаление UserScripts выполняются сразу отдельными кнопками.",
  "Storage": "Хранилище",
  " Restart to apply startup network settings.": " Для сетевых параметров или языка нужен перезапуск.",
  "The vault already exists.": "Хранилище уже существует.",
  "The master password must contain at least 12 characters.": "Мастер-пароль должен содержать минимум 12 символов.",
  "The vault is locked.": "Хранилище заблокировано.",
  "A website address and password are required.": "Нужны адрес сайта и пароль.",
  "Unsupported vault format.": "Неподдерживаемый формат хранилища.",
  "Invalid salt format.": "Неверный формат соли.",
  "Invalid entry format.": "Неверный формат записей.",
  "Incorrect master password or damaged vault.": "Неверный мастер-пароль или повреждённое хранилище.",
  "The vault is damaged.": "Хранилище повреждено.",
  "Invalid cleanup operation.": "Недопустимая операция очистки.",
  "The cleanup request is not authenticated.": "Не подтверждён запрос очистки.",
  "Cleanup does not follow symbolic links outside the browser data directory.": "Очистка не следует по символическим ссылкам за пределы данных браузера.",
  "Only HTTP and HTTPS addresses without embedded credentials are allowed.": "Разрешены только адреса HTTP и HTTPS без паролей в URL.",
  "Chrome account sync, payment details, protected keys and active sessions are not automatically transferred. Passwords are imported from an explicitly selected CSV into the encrypted vault.": "Синхронизация аккаунта Chrome, платёжные данные, защищённые ключи и активные сеансы автоматически не переносятся. Пароли импортируются из явно выбранного CSV в зашифрованное хранилище.",
  "Protected cookies: ": "Защищённые cookies: ",
  " — sign in to these websites again.": " — потребуется повторный вход на сайты.",
  "This browser's download history format is not supported.": "Формат истории загрузок этого браузера не поддерживается.",
  "Imported / ": "Импорт / ",
  "Close SuperSearch?": "Закрыть SuperSearch?",
  "Are you sure you want to close this window?": "Вы уверены, что хотите закрыть это окно?",
  "Keep my tabs for the next launch (URLs are saved locally)": "Сохранить вкладки для следующего запуска (адреса хранятся локально)",
  "Close window": "Закрыть окно",
  "Private tabs are not saved.": "Приватные вкладки не сохраняются.",
  "Discover a calmer, more personal way to browse. SuperSearch brings privacy controls, secure local password storage and a flexible workspace together in one thoughtfully designed browser. Keep your everyday web close, your choices in your hands, and your interface exactly the way you like it.": "Откройте удобный и персональный интернет. SuperSearch объединяет контроль приватности, защищённые локальные пароли и гибкое рабочее пространство. Всё необходимое для повседневного браузинга — в интерфейсе, который вы настраиваете сами.",
  "Import everything available from this browser": "Перенести все доступные данные из этого браузера",
  "Changes preview immediately. Startup network settings apply when the browser restarts.": "Изменения отображаются сразу. Сетевые параметры запуска применяются после перезапуска.",
  "Confirm before closing a window": "Спрашивать перед закрытием окна",
  "Restore saved tabs on the next launch": "Восстанавливать сохранённые вкладки при запуске",
  "Show the bookmarks toolbar": "Показывать панель закладок",
  "Pinned tabs": "Закреплённые вкладки",
  "Pinned tab": "Закреплённая вкладка",
  "Pin selected tabs": "Закрепить выделенные вкладки",
  "Unpin selected tabs": "Открепить выделенные вкладки",
  "Close selected tabs": "Закрыть выделенные вкладки",
  "Keyboard shortcuts": "Горячие клавиши",
  "Action": "Действие",
  "Detect browsers again": "Найти браузеры снова",
  "Private by choice. Comfortable by design.": "Приватность — ваш выбор. Удобство — часть дизайна.",
  "SuperSearch brings your everyday web into a personal workspace, with thoughtful privacy controls, secure local storage and an interface that adapts to you.": "SuperSearch объединяет повседневный интернет и личное рабочее пространство: контроль приватности, защищённое локальное хранилище и интерфейс, который подстраивается под вас.",
  "Privacy: session profiles, tracker filtering and optional search suggestions put your browsing choices in your hands.": "Приватность: профили сеанса, фильтрация трекеров и необязательные подсказки поиска помогают управлять браузингом.",
  "Security: an encrypted master-password vault, explicit website permissions and HTTPS preferences help protect the way you browse.": "Безопасность: зашифрованное хранилище с мастер-паролем, явные разрешения сайтов и настройки HTTPS защищают вашу работу.",
  "Convenience: tabs, split view, bookmarks, automatic downloads and browser import keep your favorite pages close.": "Удобство: вкладки, разделённый экран, закладки, автоматические загрузки и импорт сохраняют любимые страницы под рукой.",
  "Customization: arrange panels, shape controls, pick a theme and create your own start page.": "Персонализация: перемещайте панели, меняйте форму элементов, выбирайте тему и создавайте свою стартовую страницу.",
  "Built with Python, PySide6 and QtWebEngine (Chromium). Open source under the MIT license.": "Создано на Python, PySide6 и QtWebEngine (Chromium). Открытый исходный код под лицензией MIT.",
  "Next tab": "Следующая вкладка",
  "Previous tab": "Предыдущая вкладка",
  "New tab": "Новая вкладка",
  "Close current tab": "Закрыть текущую вкладку",
  "Switch to a numbered tab": "Перейти к вкладке по номеру",
  "Switch to the last tab": "Перейти к последней вкладке",
  "Pin or unpin selected tabs": "Закрепить или открепить выделенные вкладки",
  "Select individual tabs": "Выделить отдельные вкладки",
  "Select a range of tabs": "Выделить диапазон вкладок",
  "Select all tabs when the tab panel is focused": "Выделить все вкладки, когда фокус на их списке",
  "Close selected tabs when the tab panel is focused": "Закрыть выделенные вкладки, когда фокус на их списке",
  "Focus address bar": "Перейти в адресную строку",
  "Bookmark the current page": "Добавить текущую страницу в закладки",
  "Toggle bookmarks toolbar": "Показать или скрыть панель закладок",
  "Customize panel layout": "Изменить расположение панелей",
  "Toggle split view": "Включить или выключить разделённый экран",
  "Full screen": "Полноэкранный режим",
  "Page zoom": "Масштаб страницы",
  "Back / forward": "Назад / вперёд",
  "Password menu": "Меню паролей",
  "Suggestions are optional and off by default. When enabled, typed queries are sent to DuckDuckGo.": "Подсказки необязательны и по умолчанию выключены. При включении введённые запросы отправляются в DuckDuckGo.",
  "Try again": "Повторить",
  "Back to start page": "На стартовую страницу",
  "Technical details": "Технические подробности",
  "Error code": "Код ошибки",
  "Your privacy settings remain active.": "Ваши настройки приватности продолжают действовать.",
  "Secure connection unavailable": "Не удалось установить защищённое соединение",
  "The website could not provide a valid secure connection. Check your device clock or try again later.": "Не удалось подтвердить безопасность соединения с сайтом. Проверьте дату и время на устройстве или попробуйте позже.",
  "This request was blocked": "Запрос заблокирован",
  "A browser privacy rule or a network policy prevented this page from opening. You can review your settings.": "Страница не открылась из-за правила приватности браузера или сетевой политики. Вы можете проверить настройки.",
  "Check your private connection": "Проверьте приватное подключение",
  "Your proxy or Tor service may be unavailable. Check that it is running and review your network settings.": "Прокси или служба Tor могут быть недоступны. Убедитесь, что служба запущена, и проверьте настройки сети.",
  "We could not find this website": "Не удалось найти сайт",
  "Check the address and your DNS or internet connection, then try again.": "Проверьте адрес сайта, настройки DNS и подключение к интернету, затем повторите попытку.",
  "You are offline": "Нет подключения к интернету",
  "Connect to Wi-Fi or your wired network, then try this page again.": "Подключитесь к Wi-Fi или проводной сети, затем попробуйте открыть страницу снова.",
  "This website took too long": "Сайт не ответил вовремя",
  "The website did not respond in time. Give it a moment and try again.": "Время ожидания ответа сайта истекло. Немного подождите и повторите попытку.",
  "This page is out of reach": "Не удалось открыть страницу",
  "The connection could not be completed. Check your internet connection or try again in a moment.": "Не удалось установить соединение. Проверьте подключение к интернету или повторите попытку чуть позже.",
  "Chromium security patches": "Исправления безопасности Chromium",
  "Save password?": "Сохранить пароль?",
  "Update password?": "Обновить пароль?",
  "Update password": "Обновить пароль",
  "Not now": "Не сейчас",
  "Encrypted on this device. Saved only when you choose Save.": "Шифруется на этом устройстве. Сохранение — только по вашему выбору.",
  "Unlock your local vault to save this password.": "Разблокируйте локальное хранилище для сохранения пароля.",
  "Create a master password of at least 12 characters to protect saved passwords.": "Создайте мастер-пароль не короче 12 символов для защиты сохранённых паролей.",
  "Unlock and save": "Разблокировать и сохранить",
  "Create vault and save": "Создать и сохранить",
  "Enter a password to save.": "Введите пароль для сохранения.",
  "Password saved locally.": "Пароль сохранён на устройстве.",
  "Show the expand button in the title bar": "Показывать кнопку разворачивания в шапке",
  "Expand button and title bar double-click": "Кнопка разворачивания и двойной щелчок по шапке",
  "Maximize window": "Развернуть окно",
  "Restore window": "Восстановить размер окна",
  "Charging": "Заряжается",
  "On battery": "Питание от батареи",
  "Show time and battery only in full screen": "Показывать время и заряд только в полноэкранном режиме",
  "Find a setting": "Найти настройку",
  "No settings found. Try another word or clear the search.": "Ничего не найдено. Попробуйте другое слово или очистите поиск.",
  "{count} matching settings": "Найдено настроек: {count}",
  "{count} unsaved changes": "Несохранённых изменений: {count}",
  "All changes saved.": "Все изменения сохранены.",
  "Check the highlighted setting.": "Проверьте выделенную настройку.",
  "Restart required": "Нужен перезапуск",
  "Choose how SuperSearch protects your browsing.": "Выберите, как SuperSearch защищает вашу работу в интернете.",
  "Make the browser comfortable to look at and use.": "Настройте внешний вид и удобство браузера.",
  "Search, language, startup and everyday browsing.": "Поиск, язык, запуск браузера и повседневная работа.",
  "Manage optional tools and trusted website customizations.": "Управление дополнительными инструментами и настройкой сайтов.",
  "See which tracking requests have been blocked.": "Посмотрите, какие запросы трекеров были заблокированы.",
  "Import your data, clean up or start over.": "Перенесите данные, освободите место или начните заново.",
  "Version, browser engine and privacy documents.": "Версия, движок браузера и документы о приватности.",
  "Protection level": "Уровень защиты",
  "Choose a starting point. You can adjust the switches below.": "Выберите начальный набор настроек. Любой переключатель ниже можно изменить.",
  "Balanced": "Сбалансированный",
  "Stronger": "Усиленный",
  "Maximum": "Максимальный",
  "Recommended for everyday browsing. Blocks known trackers and keeps most websites working.": "Для повседневной работы: блокирует известные трекеры и сохраняет совместимость с большинством сайтов.",
  "Adds tighter website restrictions. Some graphics and sign-in features may not work.": "Ограничивает больше возможностей сайтов. Некоторые изображения, приложения и формы входа могут не работать.",
  "Requires a running Tor service and turns off website JavaScript. Many websites will not work.": "Требует запущенной службы Tor и отключает JavaScript. Многие сайты не будут работать.",
  "Everyday protection": "Повседневная защита",
  "Block ads and trackers": "Блокировать рекламу и трекеры",
  "Stop requests to known advertising and tracking services.": "Блокирует запросы к известным рекламным сервисам и трекерам.",
  "Use secure connections only": "Использовать только защищённые соединения",
  "Upgrade HTTP addresses to HTTPS. Websites without HTTPS will not open.": "Заменяет HTTP на HTTPS. Сайты без HTTPS не откроются.",
  "Remove tracking tags from links": "Убирать метки отслеживания из ссылок",
  "Clean common advertising parameters from website addresses.": "Удаляет распространённые рекламные метки из адресов сайтов.",
  "Limit tracking between websites": "Ограничить отслеживание между сайтами",
  "Block third-party cookies and storage. Some embedded sign-ins may not work.": "Блокирует сторонние cookies и хранилища. Встроенные формы входа могут не работать.",
  "Hide the previous website address": "Не передавать адрес предыдущей страницы",
  "Do not send websites the address of the page you came from.": "Сайт не получит адрес страницы, с которой вы на него перешли.",
  "Ask websites not to track me": "Просить сайты не отслеживать меня",
  "Send privacy preference signals. Websites decide whether to honor them.": "Передаёт сайтам ваш выбор приватности. Сайты сами решают, соблюдать ли его.",
  "Blocking lists": "Списки блокировки",
  "Download fresh EasyList and EasyPrivacy rules when you want an update.": "Загружает свежие правила EasyList и EasyPrivacy по вашему запросу.",
  "Website data": "Данные сайтов",
  "Forget website data when I close SuperSearch": "Забывать данные сайтов после закрытия SuperSearch",
  "Cookies stay in memory, so you may need to sign in again after a restart. Bookmarks and saved passwords are kept.": "Cookies хранятся в памяти: после перезапуска может понадобиться повторный вход. Закладки и пароли сохраняются.",
  "Website permissions": "Разрешения сайтов",
  "Camera, microphone, location and notification permissions are denied by default.": "Камера, микрофон, геолокация и уведомления по умолчанию запрещены.",
  "Your connection": "Ваше подключение",
  "Normal connection. Websites can see your public IP address.": "Обычное подключение. Сайты видят ваш внешний IP-адрес.",
  "A proxy is configured. Its service must be available to open websites.": "Настроен прокси. Чтобы открывать сайты, прокси должен быть доступен.",
  "Tor is selected. Tor must be running or websites cannot open.": "Выбран Tor. Без запущенной службы Tor сайты не откроются.",
  "Connection settings": "Настройки подключения",
  "Connection details": "Параметры подключения",
  "For people using a proxy, Tor or a custom DNS provider.": "Для подключения через прокси, Tor или выбранный DNS-сервис.",
  "Secure DNS (DNS over HTTPS)": "Защищённый DNS (DNS over HTTPS)",
  "Choose who resolves website names. Tor connections use their own DNS route.": "Выберите сервис, который определяет адреса сайтов. У Tor свой маршрут DNS.",
  "Use the system setting": "Использовать настройку системы",
  "Proxy server": "Прокси-сервер",
  "Paste an HTTP, SOCKS5 or SOCKS4 address. Leave blank for a normal connection.": "Вставьте адрес HTTP, SOCKS5 или SOCKS4. Для обычного подключения оставьте поле пустым.",
  "Use Tor for connections": "Подключаться через Tor",
  "Start Tor on this device first. Uses 127.0.0.1:9050 and takes priority over the proxy address.": "Сначала запустите Tor на устройстве. Используется 127.0.0.1:9050; адрес прокси при этом игнорируется.",
  "Check the proxy": "Проверка прокси",
  "Makes a test request to api.ipify.org through the chosen proxy or Tor.": "Отправляет проверочный запрос к api.ipify.org через выбранный прокси или Tor.",
  "Advanced website protections": "Дополнительная защита на сайтах",
  "These settings can affect how websites work.": "Эти параметры могут повлиять на работу сайтов.",
  "Reduce browser fingerprinting": "Затруднить сбор отпечатка браузера",
  "Make some device details harder to read. This cannot prevent every form of fingerprinting.": "Скрывает часть сведений об устройстве. Полностью исключить сбор отпечатка нельзя.",
  "Restrict direct browser connections": "Ограничить прямые соединения браузера",
  "Limits WebRTC network exposure. Voice and video calls may not work.": "Ограничивает передачу сетевых данных через WebRTC. Звонки и видеосвязь могут не работать.",
  "Extra location blocking": "Дополнительно блокировать геолокацию",
  "Block the location API in website scripts. Website permissions are already denied by default.": "Отключает геолокацию в скриптах сайтов. Разрешения сайтов уже запрещены по умолчанию.",
  "Turn off website JavaScript": "Отключить JavaScript на сайтах",
  "Many websites and sign-in forms stop working. Leave this off for everyday browsing.": "Многие сайты и формы входа перестанут работать. Для повседневной работы оставьте выключенным.",
  "Allow 3D graphics on websites": "Разрешить 3D-графику на сайтах",
  "Needed by some maps, games and visual tools. It can reveal graphics-device details.": "Нужно для некоторых карт, игр и графических приложений. Может раскрывать сведения о видеоустройстве.",
  "Allow sites to read drawn images": "Разрешить сайтам считывать нарисованные изображения",
  "Needed by some drawing and verification tools. It can reveal device details.": "Нужно некоторым редакторам и проверкам безопасности. Может раскрывать сведения об устройстве.",
  "Let websites open new windows": "Разрешить сайтам открывать новые окна",
  "Links and scripts that open another window may be blocked when this is off.": "При выключении ссылки и скрипты, открывающие новое окно, могут блокироваться.",
  "How protection works": "Как работает защита",
  "Fingerprinting protection is best effort. Supported filters: domain rules, exceptions and literal text; cosmetic rules and advanced syntax are skipped.": "Защита от отпечатка не гарантирует анонимность. Фильтры поддерживают домены, исключения и текст; косметические и сложные правила пропускаются.",
  "The theme changes browser controls. Websites keep their own colors.": "Тема меняет интерфейс браузера. Цвета сайтов остаются прежними.",
  "Light": "Светлая",
  "Dark": "Тёмная",
  "Pure black": "Чистый чёрный",
  "Custom colors": "Свои цвета",
  "Choose your own colors. Text must remain readable.": "Выберите свои цвета. Текст должен оставаться читаемым.",
  "Text and size": "Текст и масштаб",
  "Size of browser controls": "Размер элементов браузера",
  "Website zoom": "Масштаб страниц",
  "Window and full screen": "Окно и полный экран",
  "Maximize keeps system panels visible. Full screen hides them. F11 always enters full screen.": "Развёрнутое окно сохраняет системные панели. Полный экран скрывает их. F11 всегда включает полный экран.",
  "Hidden in normal and maximized windows. Charge is shown only when a battery is detected.": "В обычном и развёрнутом окне скрыто. Заряд показывается только при обнаружении батареи.",
  "Shortcuts and wallpaper": "Ярлыки и обои",
  "Changes in the editor are saved when you confirm them.": "Изменения в редакторе сохраняются после подтверждения в нём.",
  "Start page layout": "Расположение на стартовой странице",
  "Centered": "По центру",
  "Near the top": "Сверху",
  "Panels and toolbar": "Панели и кнопки",
  "Move buttons and panels to suit the way you browse.": "Расположите кнопки и панели так, как вам удобно.",
  "Address bar buttons": "Кнопки адресной строки",
  "Drag rows to change the order. Uncheck a button to hide it.": "Перетаскивайте строки для изменения порядка. Снимите галочку, чтобы скрыть кнопку.",
  "Reset panel positions": "Сбросить расположение панелей",
  "Changes the layout now. Other browser data is kept.": "Сразу меняет расположение панелей. Остальные данные сохраняются.",
  "Fine-tune spacing and corners": "Подробная настройка размеров и скруглений",
  "Corner roundness": "Степень скругления",
  "Search and language": "Поиск и язык",
  "Typed queries are sent to DuckDuckGo when this is on. Suggestions stay off in private windows.": "При включении введённые запросы отправляются в DuckDuckGo. В приватных окнах подсказки выключены.",
  "Startup and tabs": "Запуск и вкладки",
  "Open new tabs with": "Открывать в новых вкладках",
  "SuperSearch start page": "Стартовая страница SuperSearch",
  "A website I choose": "Выбранный сайт",
  "Website address": "Адрес сайта",
  "Reopen saved ordinary tabs. Pinned tabs are remembered separately; private tabs are not saved.": "Восстанавливает сохранённые обычные вкладки. Закреплённые запоминаются отдельно, приватные не сохраняются.",
  "History and bookmarks": "История и закладки",
  "Keep a local list of visited pages. Private windows are never recorded.": "Сохраняет список посещённых страниц на устройстве. Приватные окна не записываются.",
  "Passwords and shortcuts": "Пароли и горячие клавиши",
  "View or edit the encrypted local vault. A master password is required.": "Просмотр и изменение локального зашифрованного хранилища. Нужен мастер-пароль.",
  "Built-in protection": "Встроенная защита",
  "Ad blocking, secure connections and link cleanup are already included.": "Блокировка рекламы, защищённые соединения и очистка ссылок уже встроены.",
  "Optional extensions": "Дополнительные расширения",
  "Manage local extensions": "Управление локальными расширениями",
  "Chrome Web Store does not install directly into SuperSearch. Compatible local extensions require a persistent profile.": "Chrome Web Store не устанавливает расширения напрямую. Совместимым локальным расширениям нужен постоянный профиль.",
  "User scripts and styles": "Пользовательские скрипты и стили",
  "Install only code you trust. Installation and removal apply immediately.": "Устанавливайте только доверенный код. Установка и удаление применяются сразу.",
  "Installed scripts": "Установленные скрипты",
  "Trusted scripts can also read information on private pages when this is on.": "При включении доверенные скрипты смогут читать данные и на приватных страницах.",
  "Tracking requests blocked": "Заблокированные запросы трекеров",
  "Clean up local data": "Очистка локальных данных",
  "Choose what to remove. Deletion happens only after you confirm.": "Выберите, что удалить. Удаление начнётся только после подтверждения.",
  "Bring bookmarks and supported data from a Chromium browser.": "Перенесите закладки и совместимые данные из Chromium-браузера.",
  "Privacy documents": "Документы о приватности",
  "Enter a complete website address, for example https://example.com.": "Введите полный адрес сайта, например https://example.com.",
  "Enter a proxy address such as socks5://127.0.0.1:1080, without a username or password.": "Введите адрес прокси, например socks5://127.0.0.1:1080, без логина и пароля.",
  "Proxy error: {message}": "Ошибка прокси: {message}",
  "Proxy IP: {address}": "IP через прокси: {address}",
  "{count} blocking rules loaded; {skipped} unsupported rules skipped.": "Загружено правил блокировки: {count}; неподдерживаемых пропущено: {skipped}.",
  "Cookies and website data": "Cookies и данные сайтов",
  "Signs you out of websites. Your online accounts are not deleted.": "Выполняет выход из аккаунтов на сайтах. Сами аккаунты не удаляются.",
  "Temporary files (cache)": "Временные файлы (кэш)",
  "Remove saved page resources. Websites may load more slowly at first.": "Удаляет сохранённые ресурсы страниц. Сначала сайты могут загружаться медленнее.",
  "Saved passwords": "Сохранённые пароли",
  "Delete the local password vault and its master password.": "Удаляет локальное хранилище паролей и его мастер-пароль.",
  "Remove browsing history, saved tab sessions and blocking totals.": "Удаляет историю посещений, сохранённую сессию вкладок и статистику блокировок.",
  "Delete saved bookmarks and their folders.": "Удаляет закладки и папки с ними.",
  "Remove saved pins and their entries in the saved tab session.": "Удаляет закрепления и их записи в сохранённой сессии вкладок.",
  "Remove the list of downloads. Keep the downloaded files.": "Удаляет список загрузок. Скачанные файлы остаются.",
  "Downloaded files": "Скачанные файлы",
  "Delete unchanged files recorded by SuperSearch. Other files are kept.": "Удаляет неизменённые файлы, учтённые SuperSearch. Остальные файлы сохраняются.",
  "The browser restarts after cleanup so cookies and cached files can be removed safely.": "После очистки браузер перезапустится, чтобы безопасно удалить cookies и кэш.",
  "Start over": "Начать заново",
  "Remove all browser data and return to first-run setup.": "Удаляет все данные браузера и снова запускает первую настройку.",
  "Split-view": "Разделённый экран",
  "cookies cookie site data": "cookies cookie куки данные сайтов",
  "proxy network internet connection": "прокси сеть сети интернет подключение",
  "DNS network internet connection": "DNS ДНС сеть сети интернет подключение",
  "tor onion network internet connection": "tor тор onion онион сеть интернет подключение",
  "cookies cache passwords accounts history bookmarks downloads reset Delete pinned": "cookies куки кэш кеш пароли пароль аккаунты история закладки загрузки сброс Delete закреплённые",
  "Saved. Restart to finish applying these changes.": "Сохранено. Перезапустите браузер, чтобы завершить применение изменений.",
  "To remove website data saved earlier, use Storage.": "Чтобы удалить ранее сохранённые данные сайтов, откройте «Хранилище».",
  "Readable colors": "Читаемые цвета",
  "These colors make text hard to read. Choose colors with a stronger contrast.": "С такими цветами текст плохо читается. Выберите более контрастное сочетание.",
  "1 unsaved change": "1 несохранённое изменение",
  "1 matching setting": "Найдена 1 настройка",
  "Your public IP": "Ваш внешний IP",
  "Refresh IP address": "Обновить IP-адрес",
  "Checking…": "Проверка…",
  "Unavailable": "Недоступно",
  "Not checked yet": "Ещё не проверен",
  "Could not check the address. Check your connection and try again.": "Не удалось определить адрес. Проверьте подключение и повторите попытку.",
  "Public connection address · provided by ipify": "Внешний адрес подключения · сервис ipify",
  "Show public IP on the start page": "Показывать внешний IP на главной странице",
  "Contacts ipify through your current proxy or Tor when the start page is visible. The address stays in memory. Turn this off to avoid these requests.": "Когда открыта главная страница, обращается к ipify через текущий прокси или Tor. Адрес хранится только в памяти. Отключите, чтобы не отправлять эти запросы.",
  "Show public IP (contacts ipify)": "Показывать внешний IP (запрос к ipify)",
  "Source code": "Исходный код",
  "Security patches are backported from newer Chromium releases. The engine base version is listed separately.": "Исправления безопасности перенесены из более новых выпусков Chromium. Базовая версия движка указана отдельно."
}
```

### tests/electron_policy.test.js
```javascript
'use strict';
const assert=require('node:assert/strict');
let passed=0;
function test(name,fn){fn();passed++;console.log('PASS: '+name);}
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {origin,target,cleaned,sameParty,Filters,validSender}=require('../engine/policy');

test('navigation only accepts web addresses and local blank/start pages',()=>{
  assert.equal(target('example.org'),'https://example.org/');assert.equal(target('[::1]:8080'),'https://[::1]:8080/');
  assert.equal(target('two words'),'https://duckduckgo.com/?q=two%20words');
  assert.equal(origin('https://user:secret@example.org'),'');assert.equal(origin('file:///etc/passwd'),'');
  assert.equal(target('javascript:alert(1)'),null);assert.equal(target('https://user:secret@example.org'),null);assert.equal(target('http://intranet'),'http://intranet/');
  assert.equal(target('supersearch:start'),'supersearch:start');
});
process.on('beforeExit',()=>{assert.equal(passed,4);console.log('POLICY CHECKS OK: '+passed);});
test('HTTPS and tracking cleanup retain functional parameters',()=>{
  assert.equal(cleaned('http://example.org/a?utm_source=x&fbclid=secret&safe=ok',{https_only:true,strip_params:true}),'https://example.org/a?safe=ok');
  assert.equal(cleaned('http://localhost:123/a?test=1',{https_only:false,strip_params:true}),'http://localhost:123/a?test=1');
  assert.equal(sameParty('https://cdn.example.org','https://example.org'),true);assert.equal(sameParty('https://example.org.evil.test','https://example.org'),false);
});
test('filter exceptions win; domain rules do not match lookalike domains',()=>{
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'supersearch-rules-'));
  try{fs.writeFileSync(path.join(directory,'test.txt'),'||tracker.example^\n@@||safe.tracker.example^\n/fixture-pixel\ninvalid*$script\n');const rules=new Filters(directory);
    assert.equal(rules.blocked('https://a.tracker.example/a'),true);assert.equal(rules.blocked('https://safe.tracker.example/a'),false);assert.equal(rules.blocked('https://tracker.example.evil.test/a'),false);assert.equal(rules.blocked('https://other.example/fixture-pixel'),false);assert.ok(rules.skipped>=2);
    fs.writeFileSync(path.join(directory,'test.txt'),'||changed.example^\n@@||safe.changed.example^\n/fixture-pixel\ninvalid*$script\n');rules.reload();assert.equal(rules.blocked('https://tracker.example/a'),false);assert.equal(rules.blocked('https://changed.example/a'),true);
  }finally{fs.rmSync(directory,{recursive:true,force:true});}
});
test('only the trusted top-level browser UI is an IPC sender',()=>{
  const frame={url:'ss-app://browser/index.html'},contents={mainFrame:frame};
  assert.equal(validSender({sender:contents,senderFrame:frame},contents),true);
  assert.equal(validSender({sender:{mainFrame:frame},senderFrame:frame},contents),false);
  assert.equal(validSender({sender:contents,senderFrame:{url:frame.url}},contents),false);
  frame.url='https://example.org';assert.equal(validSender({sender:contents,senderFrame:frame},contents),false);
});
```

### tests/gui_electron.py
```python
"""Run the new engine only against temporary data and a loopback web fixture."""
import json
import os
import subprocess
import sys
import tempfile
import datetime
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import rsa
import ipaddress
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from settings.config import DEFAULTS,ROOT


def run(mode):
    with tempfile.TemporaryDirectory(prefix='supersearch-electron-test-') as temporary:
        directory=Path(temporary)/'profile';directory.mkdir()
        backup=Path(temporary)/'export.supersearch'
        (directory/'.supersearch-test-profile').write_text('temporary-test-profile')
        values=dict(DEFAULTS,onboarding_complete=True,suggestions=False,home_ip=False,confirm_close=False,
                    https_only=False,animations=False,layout_state='',window_geometry='',theme='light')
        values['ephemeral_profile']=mode!='persistent'
        values['javascript']=mode=='javascript-off'
        values['onboarding_complete']=mode not in ('onboarding','returning')
        if mode in ('onboarding','returning'):values['suggestions']=None
        (directory/'settings.json').write_text(json.dumps(values))
        key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        subject=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'localhost')])
        now=datetime.datetime.now(datetime.timezone.utc)
        certificate=(x509.CertificateBuilder().subject_name(subject).issuer_name(subject).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-datetime.timedelta(days=1)).not_valid_after(now+datetime.timedelta(days=1)).add_extension(x509.SubjectAlternativeName([x509.DNSName('localhost'),x509.IPAddress(ipaddress.ip_address('127.0.0.1'))]),critical=False).sign(key,hashes.SHA256()))
        (directory/'fixture-cert.pem').write_bytes(certificate.public_bytes(serialization.Encoding.PEM))
        (directory/'fixture-key.pem').write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.TraditionalOpenSSL,serialization.NoEncryption()))
        if mode=='returning':
            from core.backup import export_data
            source=Path(temporary)/'source';source.mkdir()
            (source/'settings.json').write_text(json.dumps(dict(values,onboarding_complete=True,theme='oled')))
            (source/'bookmarks.json').write_text('[{"url":"https://example.org","title":"Portable bookmark","folder":"Work"}]')
            export_data(source,backup,'fixture backup password')
        env=dict(os.environ,SUPERSEARCH_TEST_BACKUP_PATH=str(backup),SUPERSEARCH_ENGINE_DATA=str(directory),SUPERSEARCH_SKIP_MIGRATION='1',SUPERSEARCH_TEST_PROFILE_HOME=str(directory/'fixture-home'),SUPERSEARCH_TEST_MODE=mode)
        result=subprocess.run([sys.executable,str(ROOT/'main.py'),'--self-test'],cwd=ROOT,env=env,timeout=90)
        if result.returncode:raise SystemExit(result.returncode)
        if mode in ('backup','returning'):
            plan=json.loads((directory/'.restore-plan.json').read_text())
            restored_env=dict(env,SUPERSEARCH_TEST_MODE='restored')
            result=subprocess.run([sys.executable,str(ROOT/'main.py'),'--restore-token',plan['token'],'--self-test'],cwd=ROOT,env=restored_env,timeout=90)
            if result.returncode:raise SystemExit(result.returncode)
            assert not (directory/'.restore-plan.json').exists()


if __name__=='__main__':
    for mode in sys.argv[1:] or ['ephemeral','persistent','onboarding','javascript-off','layout','backup','returning']:
        if mode not in ('ephemeral','persistent','onboarding','javascript-off','layout','backup','returning'):raise SystemExit('Unknown test mode')
        print('Testing Electron mode: '+mode,flush=True);run(mode)
```

### tests/test_backup.py
```python
"""Encrypted portable data, untrusted archives and reversible offline replacement."""
import io
from contextlib import closing
import json
import os
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from zipfile import ZipFile
from settings.config import DEFAULTS
from core.backup import MAGIC,apply_pending,cipher,export_data,prepare_restore,unpack
from core.vault import Vault

PASSWORD='fixture backup password'


class BackupTests(unittest.TestCase):
    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory();self.addCleanup(self.temporary.cleanup)
        self.root=Path(self.temporary.name);self.source=self.root/'source';self.source.mkdir();self.target=self.root/'target';self.target.mkdir();self.file=self.root/'profile.supersearch'
        (self.source/'settings.json').write_text(json.dumps(dict(DEFAULTS,theme='dark')))
        (self.source/'bookmarks.json').write_text('[{"url":"https://example.org","title":"Private bookmark","folder":"Work"}]')
        (self.source/'history.json').write_text('[{"url":"https://example.net","title":"History"}]')
        (self.source/'userscripts').mkdir();(self.source/'userscripts/fixture.js').write_text('window.fixture=true;')
        (self.source/'chromium').mkdir();(self.source/'chromium/Cookies').write_bytes(b'never-export-session')
        (self.source/'download_files.json').write_text('[{"path":"/unrelated/file"}]')
        (self.target/'bookmarks.json').write_bytes(b'original library')
        self.validate=lambda saved:dict(DEFAULTS,**saved)

    def prepare(self,scripts=False):return prepare_restore(self.file,PASSWORD,self.target,self.validate,scripts)

    def test_roundtrip_live_sqlite_and_still_encrypted_vault(self):
        vault=Vault(self.source/'passwords.vault');vault.create('fixture master password');vault.save('https://example.org','alice','secret login');vault.lock()
        database=sqlite3.connect(self.source/'statistics.sqlite');self.addCleanup(database.close)
        database.execute('PRAGMA journal_mode=WAL');database.execute('CREATE TABLE blocks(day TEXT,domain TEXT,n INTEGER,PRIMARY KEY(day,domain))');database.execute("INSERT INTO blocks VALUES('2026-11-03','tracker.example',17)");database.commit()
        export_data(self.source,self.file,PASSWORD,database)
        self.assertNotIn(b'Private bookmark',self.file.read_bytes());self.assertNotIn(b'secret login',self.file.read_bytes())
        values=unpack(self.file,PASSWORD);self.assertNotIn('chromium/Cookies',values);self.assertNotIn('download_files.json',values)
        token=self.prepare();self.assertEqual((self.target/'bookmarks.json').read_bytes(),b'original library')
        (self.target/'chromium').mkdir();(self.target/'chromium/Cookies').write_bytes(b'old session')
        apply_pending(token,self.target)
        self.assertEqual(json.loads((self.target/'bookmarks.json').read_text())[0]['title'],'Private bookmark')
        self.assertFalse((self.target/'chromium').exists());self.assertFalse((self.target/'userscripts').exists())
        restored=Vault(self.target/'passwords.vault');restored.unlock('fixture master password');self.assertEqual(restored.entries()[0]['password'],'secret login');restored.lock()
        with closing(sqlite3.connect(self.target/'statistics.sqlite')) as db:self.assertEqual(db.execute('SELECT n FROM blocks').fetchone()[0],17)
        settings=json.loads((self.target/'settings.json').read_text());self.assertTrue(settings['onboarding_complete']);self.assertFalse(settings['tour_pending'])
        self.assertEqual((self.source/'chromium/Cookies').read_bytes(),b'never-export-session')

    def test_wrong_password_and_tampering_leave_target_untouched(self):
        export_data(self.source,self.file,PASSWORD)
        with self.assertRaisesRegex(ValueError,'incorrect or the file is damaged'):prepare_restore(self.file,'another backup password',self.target,self.validate)
        encrypted=bytearray(self.file.read_bytes());encrypted[-20]^=1;self.file.write_bytes(encrypted)
        with self.assertRaises(ValueError):self.prepare()
        self.assertEqual(list(self.target.iterdir()),[self.target/'bookmarks.json'])
        self.assertEqual((self.target/'bookmarks.json').read_bytes(),b'original library')

    def test_unsafe_archive_paths_are_rejected_after_authentication(self):
        archive=io.BytesIO()
        with ZipFile(archive,'w') as zipfile:zipfile.writestr('manifest.json','{}');zipfile.writestr('../outside','bad')
        salt=os.urandom(16);self.file.write_bytes(MAGIC+salt+cipher(PASSWORD,salt).encrypt(archive.getvalue()))
        with self.assertRaisesRegex(ValueError,'unsafe path'):self.prepare()
        self.assertFalse((self.root/'outside').exists());self.assertEqual(len(list(self.target.iterdir())),1)

    def test_failure_during_install_rolls_back_and_can_be_retried(self):
        export_data(self.source,self.file,PASSWORD);token=self.prepare();original_rename=Path.rename
        def rename(path,target):
            if path.name=='bookmarks.json' and path.parent.name.startswith('.restore-staging-'):raise OSError('fixture disk error')
            return original_rename(path,target)
        with patch('core.backup.Path.rename',rename),self.assertRaisesRegex(OSError,'fixture disk error'):apply_pending(token,self.target)
        self.assertEqual((self.target/'bookmarks.json').read_bytes(),b'original library')
        apply_pending(token,self.target);self.assertTrue(json.loads((self.target/'settings.json').read_text())['onboarding_complete'])

    def test_scripts_require_opt_in_and_requests_are_authenticated(self):
        export_data(self.source,self.file,PASSWORD);token=self.prepare(scripts=True)
        with self.assertRaises(ValueError):apply_pending('0'*48,self.target)
        self.assertEqual((self.target/'bookmarks.json').read_bytes(),b'original library')
        apply_pending(token,self.target);self.assertEqual((self.target/'userscripts/fixture.js').read_text(),'window.fixture=true;')
        self.assertFalse((self.target/'download_files.json').exists())

    def test_symlinks_and_recursive_destination_are_rejected(self):
        with self.assertRaisesRegex(ValueError,'outside'):export_data(self.source,self.source/'export.supersearch',PASSWORD)
        secret=self.root/'unrelated';secret.write_text('outside sentinel')
        (self.source/'bookmarks.json').unlink();(self.source/'bookmarks.json').symlink_to(secret)
        with self.assertRaisesRegex(ValueError,'symbolic links'):export_data(self.source,self.file,PASSWORD)
        self.assertEqual(secret.read_text(),'outside sentinel')


if __name__=='__main__':unittest.main()
```

### tests/test_customization.py
```python
"""Privacy defaults, offline home data, safe download naming and extension validation."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from zipfile import ZipFile
from settings.config import Config
from core.shortcuts import Shortcuts, DEFAULT_SHORTCUTS
from core.downloads import safe_filename, download_target
from core.extensions import extension_manifest


class CustomizationTests(unittest.TestCase):
    def test_fresh_and_migrated_defaults(self):
        with tempfile.TemporaryDirectory() as folder, patch('settings.config.DATA', Path(folder)):
            fresh = Config()
            self.assertEqual(fresh['theme'], 'light')
            self.assertEqual(fresh['language'],'en')
            self.assertTrue(fresh['confirm_close'])
            self.assertFalse(fresh['dark_sites'])
            self.assertIsNone(fresh['suggestions'])
            self.assertTrue(fresh['ephemeral_profile'])
            self.assertFalse(fresh['remember_history'])
            self.assertFalse(fresh['onboarding_complete'])
            self.assertEqual(fresh['terms_version'],'')
            path = Path(folder) / 'settings.json'
            path.write_text(json.dumps({'theme':'dark', 'dark_sites':True, 'suggestions':False}))
            migrated = Config()
            self.assertEqual(migrated['theme'], 'light')
            self.assertFalse(migrated['dark_sites'])
            self.assertFalse(migrated['suggestions'])
            migrated['theme'] = 'oled'
            migrated.save()
            self.assertEqual(Config()['theme'], 'oled')

    def test_shortcuts_can_all_be_removed_and_reordered(self):
        with tempfile.TemporaryDirectory() as folder:
            store = Shortcuts(folder)
            self.assertEqual(len(store.entries), 6)
            entry = store.new('Custom', 'https://example.org')
            store.commit([entry, store.entries[0]])
            self.assertEqual(Shortcuts(folder).entries[0], entry)
            store.commit([])
            self.assertEqual(Shortcuts(folder).entries, [])
            with self.assertRaises(ValueError):
                store.commit([dict(id='bad', title='Bad', url='javascript:alert(1)')])
            # Empty content stays empty across restarts instead of resurrecting defaults.
            self.assertEqual(Shortcuts(folder).entries, [])

    def test_home_icons_are_local(self):
        with tempfile.TemporaryDirectory() as folder:
            store = Shortcuts(folder)
            for entry in store.entries:
                self.assertTrue(store.icon_data(entry).startswith('data:image/svg+xml;base64,'))
            custom = store.new('Custom', 'https://example.net')
            self.assertTrue(store.icon_data(custom).startswith('data:'))

    def test_download_names_never_replace_existing_paths(self):
        with tempfile.TemporaryDirectory() as folder:
            directory = Path(folder)
            first = directory / 'report.pdf'
            first.write_bytes(b'original')
            second = download_target(directory, '../../report.pdf')
            self.assertEqual(second.name, 'report (1).pdf')
            third = download_target(directory, 'report.pdf', {str(second)})
            self.assertEqual(third.name, 'report (2).pdf')
            self.assertEqual(first.read_bytes(), b'original')
            self.assertEqual(safe_filename('C:\\temp\\document.txt'), 'document.txt')
            self.assertEqual(safe_filename('CON.txt'), '_CON.txt')
            self.assertNotIn('\u202e', safe_filename('pic\u202eexe.jpg'))
            self.assertNotIn('/', safe_filename('../test'))

    def test_extension_zip_validation(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'extension.zip'
            manifest = {'manifest_version':3, 'name':'Offline test', 'version':'1.0'}
            with ZipFile(path, 'w') as archive:
                archive.writestr('manifest.json', json.dumps(manifest))
            self.assertEqual(extension_manifest(path)['name'], 'Offline test')
            with ZipFile(path, 'w') as archive:
                archive.writestr('manifest.json', json.dumps(manifest))
                archive.writestr('../escape.txt', 'not allowed')
            with self.assertRaises(ValueError):
                extension_manifest(path)
            manifest['manifest_version'] = 2
            with ZipFile(path, 'w') as archive:
                archive.writestr('manifest.json', json.dumps(manifest))
            with self.assertRaises(ValueError):
                extension_manifest(path)


if __name__ == '__main__':
    unittest.main()
```

### tests/test_engine_migration.py
```python
"""Data compatibility, rollback isolation and the new local IPC service."""
import json
from contextlib import closing
import os
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from settings.config import DEFAULTS,ROOT
from core.electron_launcher import migrate
from core.vault import Vault


class EngineMigrationTests(unittest.TestCase):
    def test_snapshot_preserves_original_libraries_vault_and_sqlite(self):
        with tempfile.TemporaryDirectory() as temporary:
            source=Path(temporary)/'qt';source.mkdir();destination=source/'electron'
            (source/'settings.json').write_text(json.dumps(dict(DEFAULTS,onboarding_complete=True)))
            (source/'bookmarks.json').write_text('[{"url":"https://example.org","title":"Original"}]')
            vault=Vault(source/'passwords.vault');vault.create('fixture master password');vault.save('https://example.org','alice','fixture credential');encrypted=(source/'passwords.vault').read_bytes();vault.lock()
            database=sqlite3.connect(source/'statistics.sqlite');database.execute('CREATE TABLE blocks(day TEXT,domain TEXT,n INTEGER,PRIMARY KEY(day,domain))');database.execute("INSERT INTO blocks VALUES('2026-11-03','fixture.example',7)");database.commit();database.close()
            (source/'userscripts').mkdir();(source/'userscripts/test.js').write_text('window.fixture=true;')
            (source/'profile').mkdir();(source/'profile/Cookies').write_bytes(b'never copy a Chromium profile across engines')
            migrate(source,destination)
            self.assertEqual((source/'passwords.vault').read_bytes(),encrypted)
            copied=Vault(destination/'passwords.vault');copied.unlock('fixture master password');self.assertEqual(copied.entries()[0]['username'],'alice');copied.lock()
            self.assertFalse((destination/'profile').exists())
            with closing(sqlite3.connect(destination/'statistics.sqlite')) as database:self.assertEqual(database.execute('SELECT n FROM blocks').fetchone()[0],7)
            (destination/'bookmarks.json').write_text('[]');migrate(source,destination)
            self.assertEqual(json.loads((destination/'bookmarks.json').read_text()),[])
            self.assertEqual(json.loads((source/'bookmarks.json').read_text())[0]['title'],'Original')

    def test_local_service_settings_are_transactional_and_vault_stays_encrypted(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory=Path(temporary)
            process=subprocess.Popen([sys.executable,str(ROOT/'engine/service.py')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=dict(os.environ,SUPERSEARCH_DATA=temporary))
            sequence=0
            def call(operation,data=None):
                nonlocal sequence
                sequence+=1;process.stdin.write(json.dumps(dict(id=sequence,operation=operation,data=data or {}))+'\n');process.stdin.flush()
                reply=json.loads(process.stdout.readline());self.assertEqual(reply['id'],sequence);return reply
            try:
                initial=call('bootstrap')['result'];self.assertEqual(initial['config']['language'],'en')
                self.assertEqual(call('settings',{'proxy':'invalid proxy'})['error'],'Enter a proxy address such as socks5://127.0.0.1:1080, without a username or password.')
                self.assertFalse((directory/'settings.json').exists())
                self.assertIn('error',call('settings',{'nav_order':['<script>bad</script>']}))
                self.assertIn('error',call('settings',{'colors':{'bg':'#ffffff','panel':'#ffffff','fg':'#ffffff'}}))
                self.assertEqual(call('settings',{'theme':'dark','sidebar_position':'bottom'})['result']['theme'],'dark')
                self.assertIn('result',call('vault_create',{'password':'fixture master password'}))
                call('vault_save',{'origin':'https://example.org','username':'alice','password':'fixture credential'})
                self.assertNotIn(b'fixture credential',(directory/'passwords.vault').read_bytes())
                self.assertNotIn('password',call('vault_list')['result'][0])
                call('vault_lock');self.assertIn('error',call('vault_get',{'origin':'https://example.org','username':'alice'}))
                state=call('state')['result'];self.assertFalse(state['vault']['unlocked']);self.assertNotIn('fixture credential',json.dumps(state))
            finally:
                process.stdin.close();process.wait(timeout=10);process.stdout.close();process.stderr.close()
                self.assertEqual(process.returncode,0)


if __name__=='__main__':unittest.main()
```

### tests/test_import_maintenance.py
```python
"""Import reads only selected data; destructive cleanup is scoped and authenticated."""
import csv
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from core.importer import read_profile
from core.maintenance import execute, record_download, schedule, run_pending


class ImportMaintenanceTests(unittest.TestCase):
    def test_readonly_profile_and_explicit_csv(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            (root/'Bookmarks').write_text(json.dumps({'roots':{'bookmark_bar':{'name':'Bar','children':[{'type':'url','name':'Example','url':'https://example.org'}]}}}))
            db=sqlite3.connect(root/'History')
            db.execute('CREATE TABLE urls(url,title,last_visit_time)')
            db.execute("INSERT INTO urls VALUES('https://example.org','Example',1)")
            db.execute('CREATE TABLE downloads(target_path,received_bytes,total_bytes,start_time)')
            db.execute("INSERT INTO downloads VALUES('/tmp/example.txt',10,10,1)")
            db.commit();db.close()
            db=sqlite3.connect(root/'Cookies')
            db.execute('CREATE TABLE cookies(host_key,name,value,encrypted_value,path,expires_utc,is_secure,is_httponly)')
            db.execute("INSERT INTO cookies VALUES('.example.org','plain','value',X'','/',0,1,1)")
            db.execute("INSERT INTO cookies VALUES('.example.org','protected','',X'0102','/',0,1,1)")
            db.commit();db.close()
            before=(root/'History').read_bytes()
            csv_path=root/'passwords.csv'
            with csv_path.open('w',newline='') as stream:
                writer=csv.DictWriter(stream,fieldnames=['name','url','username','password'])
                writer.writeheader()
                writer.writerow(dict(name='Example',url='https://example.org/login',username='alice',password='test secret'))
            result=read_profile(root,['bookmarks','history','downloads','cookies'],str(csv_path))
            self.assertEqual(len(result['bookmarks']),1)
            self.assertEqual(len(result['history']),1)
            self.assertEqual(len(result['downloads']),1)
            self.assertEqual(len(result['cookies']),1)
            self.assertEqual(result['skipped_cookies'],1)
            self.assertEqual(result['passwords'][0]['username'],'alice')
            self.assertEqual((root/'History').read_bytes(),before)
            self.assertEqual(read_profile(root,[])['passwords'],[])

    def test_reset_deletes_app_data_and_only_proven_downloads(self):
        with tempfile.TemporaryDirectory() as folder:
            base=Path(folder);data=base/'data';data.mkdir()
            (data/'bookmarks.json').write_text('[]')
            (data/'passwords.vault').write_text('encrypted')
            (data/'profile').mkdir();(data/'profile/Cookies').write_text('cookie')
            owned=base/'owned.bin';owned.write_bytes(b'owned')
            unrelated=base/'unrelated.bin';unrelated.write_bytes(b'keep')
            record_download(owned,data)
            report=execute(data,['reset','download_files'])
            self.assertEqual(report['removed_downloads'],1)
            self.assertFalse(owned.exists())
            self.assertTrue(unrelated.exists())
            self.assertEqual(list(data.iterdir()),[])

    def test_modified_download_is_not_deleted(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);data=root/'data';data.mkdir()
            path=root/'file.txt';path.write_text('original')
            record_download(path,data)
            path.write_text('user replacement with different length')
            report=execute(data,['download_files'])
            self.assertEqual(report['skipped_downloads'],1)
            self.assertTrue(path.exists())

    def test_cleanup_token_and_selected_categories(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            (root/'bookmarks.json').write_text('keep')
            (root/'passwords.vault').write_text('remove')
            token=schedule(['accounts'],root)
            with self.assertRaises(ValueError):
                run_pending('wrong',root)
            self.assertTrue((root/'passwords.vault').exists())
            run_pending(token,root)
            self.assertFalse((root/'passwords.vault').exists())
            self.assertEqual((root/'bookmarks.json').read_text(),'keep')

    def test_cookie_cleanup_preserves_extensions_and_other_files(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            (root/'profile/Network').mkdir(parents=True)
            (root/'profile/Network/Cookies').write_text('remove')
            (root/'profile/Extensions').mkdir()
            (root/'profile/Extensions/manifest.json').write_text('keep')
            execute(root,['cookies'])
            self.assertFalse((root/'profile/Network/Cookies').exists())
            self.assertTrue((root/'profile/Extensions/manifest.json').exists())

    def test_individual_cleanup_never_follows_parent_symlinks(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);data=root/'data';data.mkdir()
            outside=root/'outside';outside.mkdir()
            (outside/'Cookies').write_text('keep')
            try:
                (data/'profile').symlink_to(outside,target_is_directory=True)
            except OSError:
                self.skipTest('Symlinks unavailable')
            with self.assertRaises(ValueError):
                execute(data,['cookies'])
            self.assertTrue((outside/'Cookies').exists())


if __name__=='__main__':
    unittest.main()
```

### tests/test_pins.py
```python
"""Persistent pins are explicit, independent of session saving and identity based."""
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from core.pins import PinStore
from core.session import normalize_tab
from core.maintenance import execute


def pending(identifier,url='https://example.org/',panes=None):
    return SimpleNamespace(id=identifier,pinned=True,
        pending_session={'panes':panes or [url],'active_pane':0})


class PinTests(unittest.TestCase):
    def test_restart_update_and_unpin_without_session(self):
        with tempfile.TemporaryDirectory() as folder:
            store=PinStore(folder)
            tab=pending('a')
            store.upsert(tab)
            self.assertFalse((Path(folder)/'session.json').exists())
            restored=PinStore(folder)
            self.assertEqual(restored.startup()['tabs'][0]['panes'],['https://example.org/'])
            tab.pending_session={'panes':['https://example.org/changed','about:blank'],'active_pane':1}
            restored.upsert(tab)
            latest=PinStore(folder).startup()['tabs']
            self.assertEqual(len(latest),1)
            self.assertEqual(latest[0]['active_pane'],1)
            self.assertEqual(len(latest[0]['panes']),2)
            restored.remove('a')
            self.assertIsNone(PinStore(folder).startup())

    def test_merge_deduplicates_identity_and_preserves_selection(self):
        with tempfile.TemporaryDirectory() as folder:
            store=PinStore(folder)
            store.upsert(pending('a'))
            # Two tabs may intentionally contain the same website.
            store.upsert(pending('b'))
            regular=normalize_tab(dict(id='c',panes=['supersearch:start'],pinned=True))
            session=dict(tabs=[regular,store.records[0]],active_tab=0)
            combined=store.startup(session)
            self.assertEqual([t['id'] for t in combined['tabs']],['a','b','c'])
            self.assertFalse(combined['tabs'][-1]['pinned'])
            self.assertEqual(combined['active_tab'],2)

    def test_invalid_files_and_transaction_failure(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'pinned-tabs.json'
            path.write_text(json.dumps({'tabs':[None,{},dict(id='a',panes=['javascript:alert(1)']),dict(id='a',panes=['about:blank'])]}))
            store=PinStore(folder)
            self.assertEqual(len(store.records),1)
            self.assertEqual(store.records[0]['panes'],['supersearch:start'])
            with patch('core.pins.write_json',side_effect=OSError('Read-only fixture')):
                with self.assertRaises(OSError):store.upsert(pending('new'))
            self.assertEqual([r['id'] for r in store.records],['a'])
            path.write_text('{broken')
            self.assertIsNone(PinStore(folder).startup())

    def test_selective_cleanup_removes_pin_storage(self):
        with tempfile.TemporaryDirectory() as folder:
            store=PinStore(folder)
            store.upsert(pending('a'))
            sentinel=Path(folder)/'bookmarks.json'
            sentinel.write_text('[]')
            session=Path(folder)/'session.json'
            ordinary=normalize_tab(dict(id='b',panes=['https://example.net/']))
            session.write_text(json.dumps(dict(tabs=store.records+[ordinary],active_tab=1)))
            execute(folder,['pinned_tabs'])
            self.assertIsNone(PinStore(folder).startup())
            self.assertTrue(sentinel.exists())
            self.assertEqual([t['id'] for t in json.loads(session.read_text())['tabs']],['b'])


if __name__=='__main__':unittest.main()
```

### tests/test_regressions.py
```python
"""Offline regressions: worker lifetime, authenticated vault, bookmark persistence."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from core.storage import Store
from core.vault import Vault, origin_of


class RegressionTests(unittest.TestCase):
    def test_vault_encryption_password_changes_and_origin_boundaries(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / 'passwords.vault'
            vault = Vault(path)
            with self.assertRaises(ValueError):
                vault.create('short')
            vault.create('correct horse battery staple')
            vault.save('https://example.org/login', 'alice', 'secret-never-plaintext')
            vault.save('https://example.org:443/other', 'alice', 'updated-secret')
            self.assertEqual(len(vault.entries()), 1)
            self.assertEqual(vault.entries('https://example.org')[0]['password'], 'updated-secret')
            self.assertFalse(vault.entries('https://other.example.org'))
            self.assertFalse(vault.entries('http://example.org'))
            document = path.read_text()
            self.assertNotIn('updated-secret', document)
            self.assertNotIn('alice', document)
            self.assertNotIn('correct horse', document)
            vault.lock()
            with self.assertRaises(ValueError):
                vault.entries()
            with self.assertRaises(ValueError):
                vault.unlock('wrong password')
            self.assertFalse(vault.unlocked)
            vault.unlock('correct horse battery staple')
            vault.change_password('another very long master password')
            vault.lock()
            with self.assertRaises(ValueError):
                vault.unlock('correct horse battery staple')
            vault.unlock('another very long master password')
            vault.remove('https://example.org', 'alice')
            self.assertFalse(vault.entries())
            vault.lock()
            data = json.loads(path.read_text())
            token = data['token']
            data['token'] = token[:40] + ('A' if token[40] != 'A' else 'B') + token[41:]
            path.write_text(json.dumps(data))
            with self.assertRaises(ValueError):
                vault.unlock('another very long master password')

    def test_canonical_origins(self):
        self.assertEqual(origin_of('https://Example.org:443/a?q=1'), 'https://example.org')
        self.assertEqual(origin_of('https://[::1]:8443/login'), 'https://[::1]:8443')
        self.assertNotEqual(origin_of('https://example.org:444'), origin_of('https://example.org'))
        for url in ['javascript:alert(1)', 'https://[', 'https://user:pass@example.org', 'about:blank']:
            self.assertEqual(origin_of(url), '')

    def test_bookmark_editor_updates_without_toggle(self):
        with tempfile.TemporaryDirectory() as temporary, patch('core.storage.DATA', Path(temporary)):
            store = Store()
            store.save_bookmark('https://example.org', 'First', 'Work')
            store.save_bookmark('https://example.org', 'Changed', 'Read later')
            self.assertEqual(len(store.bookmarks), 1)
            store.save_bookmark('https://example.net', 'Moved', 'Work', original_url='https://example.org')
            self.assertEqual(store.bookmarks, [{'url': 'https://example.net', 'title': 'Moved', 'folder': 'Work'}])
            saved = json.loads((Path(temporary) / 'bookmarks.json').read_text())
            self.assertEqual(saved, store.bookmarks)
            store.remove_bookmark('https://example.net')
            self.assertFalse(store.bookmarks)
            store.db.close()


if __name__ == '__main__':
    unittest.main()
```

### tests/test_runtime_errors.py
```python
"""The data service has no dependency on Qt or a second browser engine."""
import unittest
from unittest.mock import patch
from tools.check_runtime import ready


class RuntimeTests(unittest.TestCase):
    def test_runtime_requires_only_local_service_dependencies(self):
        with patch('tools.check_runtime.importlib.import_module') as load:
            self.assertTrue(ready())
            self.assertEqual([call.args[0] for call in load.call_args_list],['requests','socks','cryptography.fernet','PIL.Image'])
        with patch('tools.check_runtime.importlib.import_module',side_effect=ImportError('missing')):
            self.assertFalse(ready())


if __name__=='__main__':unittest.main()
```

### tests/test_sessions_release.py
```python
"""Version identity, explicit session storage and local browser discovery."""
import json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from core.version import APP_VERSION
from core.session import save,load,safe_url
from core.importer import discover_profiles,read_profile


class SessionReleaseTests(unittest.TestCase):
    def test_version_is_user_pinned(self):
        self.assertEqual(APP_VERSION,'26.11')

    def test_session_storage_is_opt_in_and_private_is_excluded(self):
        with tempfile.TemporaryDirectory() as folder:
            tab=SimpleNamespace(pending_session={'panes':['https://example.org/'], 'active_pane':0})
            window=SimpleNamespace(private=True,tabs=[tab],list=SimpleNamespace(currentRow=lambda:0))
            save(window,folder)
            self.assertFalse((Path(folder)/'session.json').exists())
            window.private=False
            save(window,folder)
            self.assertEqual(load(folder)['tabs'][0]['panes'],['https://example.org/'])
            (Path(folder)/'session.json').write_text('{"tabs":{},"active_tab":"bad"}')
            self.assertIsNone(load(folder))
            for url in ('javascript:alert(1)','https://user:secret@example.org','file:///private',{},42):
                self.assertEqual(safe_url(url),'supersearch:start')

    def test_detected_profiles_and_manual_root_import(self):
        with tempfile.TemporaryDirectory() as folder:
            home=Path(folder)
            root=home/'.config/google-chrome'
            profile=root/'Default'
            profile.mkdir(parents=True)
            (root/'Local State').write_text(json.dumps({'profile':{'info_cache':{'Default':{'name':'Personal'}}}}))
            (profile/'Bookmarks').write_text(json.dumps({'roots':{'bar':{'name':'Bookmarks','children':[{'type':'url','name':'Example','url':'https://example.org'}]}}}))
            with patch('core.importer.Path.home',return_value=home),patch('core.importer.sys.platform','linux'):
                found=discover_profiles()
            self.assertIn(('Chrome · Personal',str(profile)),found)
            result=read_profile(root,['bookmarks','history','downloads','cookies','preferences'])
            self.assertEqual(len(result['bookmarks']),1)
            self.assertFalse(result['history'])

if __name__=='__main__':unittest.main()
```

### tests/test_source_release.py
`````python
"""Release identity, complete source artifacts and exclusion of local private files."""
import contextlib
import hashlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile
from core.version import APP_VERSION,PACKAGE_VERSION,SOURCE_URL
from tools.export_source import ROOT,ROOT_FILES,export,sources


class SourceReleaseTests(unittest.TestCase):
    def fixture(self,directory):
        root=Path(directory)
        for name in ROOT_FILES:(root/name).write_bytes((ROOT/name).read_bytes())
        (root/'engine').mkdir()
        (root/'engine/package.json').write_bytes((ROOT/'engine/package.json').read_bytes())
        (root/'engine/ui.js').write_text("const literal = '```';\n",encoding='utf-8')
        (root/'.github/workflows').mkdir(parents=True)
        (root/'.github/workflows/check.yml').write_text('name: fixture\n',encoding='utf-8')
        return root

    def test_all_runtime_release_identity_uses_manifest(self):
        package=json.loads((ROOT/'engine/package.json').read_text())
        self.assertEqual(APP_VERSION,'26.11')
        self.assertEqual(PACKAGE_VERSION,'26.11.0')
        self.assertEqual(package['displayVersion'],APP_VERSION)
        self.assertEqual(package['version'],PACKAGE_VERSION)
        self.assertEqual(package['repository']['url'],SOURCE_URL)
        self.assertIn('SuperSearch:RELEASE.displayVersion',(ROOT/'engine/main.js').read_text())
        self.assertIn('esc(S.versions.SuperSearch)',(ROOT/'engine/ui.js').read_text())
        self.assertIn('app_version=APP_VERSION',(ROOT/'core/backup.py').read_text())

    def test_publication_excludes_profiles_hidden_files_and_symlinks(self):
        with tempfile.TemporaryDirectory() as directory:
            root=self.fixture(directory)
            private=['data/passwords.json','.runtime/runtime.json','engine/data/cookies.json',
                     'engine/.env.json','assets/.aws/credentials.json','tools/.codex/session.json',
                     'engine/node_modules/secret.json','engine/backup.supersearch','engine/passwords.vault']
            for name in private:
                path=root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text('private sentinel')
            names={path.relative_to(root).as_posix() for path in sources(root)}
            self.assertFalse(names.intersection(private))
            self.assertIn('.github/workflows/check.yml',names)
            with contextlib.redirect_stdout(io.StringIO()):archive=export(root)
            with ZipFile(archive) as package:
                self.assertFalse(any('private sentinel' in package.read(name).decode('utf-8') for name in package.namelist()))
                manifest=json.loads(package.read('SuperSearch/SOURCE_MANIFEST.json'))
                for name,digest in manifest.items():self.assertEqual(hashlib.sha256(package.read('SuperSearch/'+name)).hexdigest(),digest)
                self.assertEqual((package.getinfo('SuperSearch/run.sh').external_attr>>16)&0o777,0o755)
                full=package.read('SuperSearch/SOURCE_FULL.md').decode()
                self.assertIn("````javascript\nconst literal = '```';\n````",full)
            versioned=root/'SuperSearch-26.11-source.zip'
            self.assertEqual(archive.read_bytes(),versioned.read_bytes())
            self.assertEqual((root/'SuperSearch-26.11-source.sha256').read_text().split()[0],hashlib.sha256(versioned.read_bytes()).hexdigest())
            before=archive.read_bytes()
            with contextlib.redirect_stdout(io.StringIO()):export(root)
            self.assertEqual(archive.read_bytes(),before)

    def test_required_source_symlink_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root=self.fixture(directory);path=root/'main.py';path.unlink()
            try:path.symlink_to(root/'README.md')
            except OSError:self.skipTest('Symlinks are unavailable on this platform')
            with self.assertRaisesRegex(ValueError,'unsafe required source'):sources(root)


if __name__=='__main__':unittest.main()
`````

### tests/test_system_status.py
```python
"""Native battery readings: absence, unknown values and portable OS parsing."""
import ctypes
from pathlib import Path
from types import SimpleNamespace
import subprocess
import tempfile
import unittest
from unittest.mock import Mock,patch
from core.system_status import BatteryState,SystemPowerStatus,linux_battery,windows_battery,macos_battery,read_battery


class SystemStatusTests(unittest.TestCase):
    def test_linux_ignores_peripherals_and_missing_batteries(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            self.assertIsNone(linux_battery(root))
            def device(name,**fields):
                p=root/name;p.mkdir()
                for key,value in fields.items():(p/key).write_text(str(value))
                return p
            device('AC',type='Mains',capacity=100)
            device('mouse',type='Battery',scope='Device',capacity=25)
            device('absent',type='Battery',present=0,capacity=80)
            device('unknown',type='Battery',capacity=255)
            self.assertIsNone(linux_battery(root))
            battery=device('BAT0',type='Battery',scope='System',capacity=67,status='Discharging')
            self.assertEqual(linux_battery(root),BatteryState(67,False))
            (battery/'capacity').write_text('0')
            (battery/'status').write_text('Charging')
            self.assertEqual(linux_battery(root),BatteryState(0,True))

    def test_linux_energy_fallback_and_weighted_multiple_batteries(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            for name,now,full in [('BAT0',10,20),('BAT1',60,80)]:
                device=root/name;device.mkdir()
                for key,value in dict(type='Battery',energy_now=now,energy_full=full,status='Charging').items():
                    (device/key).write_text(str(value))
            self.assertEqual(linux_battery(root),BatteryState(70,True))

    def test_windows_flags_and_structure(self):
        self.assertEqual(ctypes.sizeof(SystemPowerStatus),12)
        def read(percent,flag,success=1):
            def fill(pointer):
                pointer._obj.BatteryLifePercent=percent
                pointer._obj.BatteryFlag=flag
                return success
            return windows_battery(SimpleNamespace(GetSystemPowerStatus=Mock(side_effect=fill)))
        self.assertEqual(read(73,8),BatteryState(73,True))
        self.assertEqual(read(0,4),BatteryState(0,False))
        for percent,flag in ((100,128),(255,1),(42,255)):
            self.assertIsNone(read(percent,flag))
        self.assertIsNone(read(50,1,0))

    def test_macos_internal_battery_and_absence(self):
        for status,charging in [('charging',True),('discharging',False),('not charging',False),('charged',False)]:
            result=SimpleNamespace(returncode=0,stdout=f"Now drawing from 'AC Power'\n -InternalBattery-0 73%; {status}; 0:45 remaining\n")
            with patch('core.system_status.subprocess.run',return_value=result) as run:
                self.assertEqual(macos_battery(),BatteryState(73,charging))
                self.assertEqual(run.call_args.args[0],['/usr/bin/pmset','-g','batt'])
                self.assertEqual(run.call_args.kwargs['timeout'],2)
        with patch('core.system_status.subprocess.run',return_value=SimpleNamespace(returncode=0,stdout="Now drawing from 'AC Power'")):
            self.assertIsNone(macos_battery())

    def test_unavailable_sensor_never_fabricates_a_percentage(self):
        with patch('core.system_status.sys.platform','darwin'),patch('core.system_status.subprocess.run',side_effect=subprocess.TimeoutExpired('pmset',2)):
            self.assertIsNone(read_battery())
        with patch('core.system_status.sys.platform','unsupported'):
            self.assertIsNone(read_battery())


if __name__=='__main__':unittest.main()
```

### tools/check_runtime.py
```python
"""Check the local data-service dependencies without Qt or any network access."""
import importlib
import sys


def ready():
    if sys.version_info<(3,10):return False
    try:
        for name in ('requests','socks','cryptography.fernet','PIL.Image'):
            importlib.import_module(name)
    except (ImportError,OSError):return False
    return True


if __name__=='__main__':raise SystemExit(0 if ready() else 1)
```

### tools/export_source.py
```python
"""Export complete, reproducible source archives without local user data."""
import hashlib
import json
import re
import shutil
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parent.parent
ROOT_FILES = ('main.py','requirements.txt','run.sh','run.bat','.gitignore','.gitattributes',
              '.editorconfig','README.md','CHANGELOG.md','LICENSE','THIRD_PARTY.md',
              'SECURITY.md','CONTRIBUTING.md')
TREES = ('core','settings','assets','tests','tools','docs','.github','engine')
SUFFIXES = {'.py','.svg','.js','.css','.html','.md','.txt','.yml','.yaml','.json'}
PRIVATE_PARTS = {'data','.venv','venv','.runtime','.aws','.codex','.agents','.git',
                 '__pycache__','node_modules','.cache','.pytest_cache','build','dist','coverage'}
ROOT_DOTFILES = {'.gitignore','.gitattributes','.editorconfig'}


def public_source(root,path):
    relative=path.relative_to(root)
    if any(part in PRIVATE_PARTS for part in relative.parts):return False
    if any(part.startswith('.') and part!='.github' for part in relative.parts):
        if relative.as_posix() not in ROOT_DOTFILES:return False
    current=root
    for part in relative.parts:
        current=current/part
        if current.is_symlink():return False
    return path.is_file()


def sources(root=ROOT):
    root=Path(root)
    result=[]
    for name in ROOT_FILES:
        path=root/name
        if not public_source(root,path):raise ValueError('Missing or unsafe required source: '+name)
        result.append(path)
    for tree in TREES:
        result += [path for path in (root/tree).rglob('*')
                   if path.suffix in SUFFIXES and public_source(root,path)]
    return sorted(set(result),key=lambda path:path.relative_to(root).as_posix())


def release_version(root):
    package=json.loads((root/'engine/package.json').read_text(encoding='utf-8'))
    version=package['displayVersion']
    if not isinstance(version,str) or not re.fullmatch(r'\d+\.\d+(?:\.\d+)?',version):
        raise ValueError('Invalid display version in engine/package.json')
    expected=version+'.0' if version.count('.')==1 else version
    if package['version']!=expected:raise ValueError('Package version and display version do not match')
    return version


def zip_entry(name,content,executable=False):
    info=ZipInfo('SuperSearch/'+name,(2026,1,1,0,0,0))
    info.compress_type=ZIP_DEFLATED
    info.create_system=3
    info.external_attr=(0o100755 if executable else 0o100644)<<16
    return info,content


def export(root=ROOT):
    root=Path(root)
    files=sources(root)
    version=release_version(root)
    blocks=[f'# SuperSearch {version} — complete project files\n\nEvery file is included in full. Runtime user data is excluded.\n\n']
    languages={'.py':'python','.js':'javascript','.css':'css','.html':'html','.json':'json',
               '.svg':'svg','.sh':'bash','.bat':'bat','.md':'markdown','.yml':'yaml','.yaml':'yaml'}
    manifest={};contents={}
    for path in files:
        name=path.relative_to(root).as_posix()
        raw=path.read_bytes();contents[name]=raw
        content=raw.decode('utf-8')
        fence='`'*max(3,1+max([len(match) for match in re.findall(r'`{3,}',content)] or [2]))
        blocks.append(f'### {name}\n{fence}{languages.get(path.suffix,"text")}\n{content.rstrip()}\n{fence}\n\n')
        manifest[name]=hashlib.sha256(raw).hexdigest()
    full=''.join(blocks).encode('utf-8')
    manifest_bytes=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode('utf-8')
    (root/'SOURCE_FULL.md').write_bytes(full)
    (root/'SOURCE_MANIFEST.json').write_bytes(manifest_bytes)
    contents.update({'SOURCE_FULL.md':full,'SOURCE_MANIFEST.json':manifest_bytes})
    archive_path=root/'SuperSearch-source.zip'
    with ZipFile(archive_path,'w',ZIP_DEFLATED) as archive:
        for name,content in sorted(contents.items()):
            info,content=zip_entry(name,content,Path(name).suffix=='.sh')
            archive.writestr(info,content)
    with ZipFile(archive_path) as archive:
        if archive.testzip() is not None:raise ValueError('Archive verification failed')
        for name,digest in manifest.items():
            if hashlib.sha256(archive.read('SuperSearch/'+name)).hexdigest()!=digest:
                raise ValueError('Source digest mismatch: '+name)
    versioned=root/f'SuperSearch-{version}-source.zip'
    shutil.copyfile(archive_path,versioned)
    digest=hashlib.sha256(versioned.read_bytes()).hexdigest()
    (root/f'SuperSearch-{version}-source.sha256').write_text(digest+'  '+versioned.name+'\n',encoding='ascii')
    print(f'Exported {len(files)} complete files for {version}. Archive and SHA-256 manifest verified.')
    return archive_path


if __name__=='__main__':export()
```

### tools/install_electron.py
```python
"""Install a pinned official Electron runtime with a source-controlled SHA-256 digest."""
import hashlib
import json
import os
import platform
import shutil
import stat
import sys
import tempfile
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import requests

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
MANIFEST=json.loads((ROOT/'engine/runtime.json').read_text())


def target():
    system={'linux':'linux','darwin':'darwin','win32':'win32'}.get(sys.platform)
    arch={'x86_64':'x64','amd64':'x64','aarch64':'arm64','arm64':'arm64'}.get(platform.machine().lower())
    value=f'{system}-{arch}'
    if value not in MANIFEST['sha256']:raise RuntimeError('Unsupported Electron platform: '+value)
    return value


def executable(directory):
    return directory/('Electron.app/Contents/MacOS/Electron' if sys.platform=='darwin' else 'electron.exe' if sys.platform=='win32' else 'electron')


def unpack(archive,directory):
    with ZipFile(archive) as package:
        for member in package.infolist():
            name=PurePosixPath(member.filename)
            if name.is_absolute() or '..' in name.parts or '\\' in member.filename:
                raise ValueError('Unsafe runtime archive path')
            output=directory.joinpath(*name.parts)
            mode=member.external_attr>>16
            if stat.S_ISLNK(mode):
                link=package.read(member).decode()
                resolved=(output.parent/link).resolve()
                if not resolved.is_relative_to(directory.resolve()):raise ValueError('Unsafe runtime symlink')
                output.parent.mkdir(parents=True,exist_ok=True);output.symlink_to(link)
            else:
                package.extract(member,directory)
                if mode and output.exists():output.chmod(mode&0o777)


def ensure():
    name=target();version=MANIFEST['electron']
    destination=ROOT/'.runtime'/f'electron-{version}-{name}'
    marker=destination/'.verified'
    if executable(destination).is_file() and marker.is_file() and marker.read_text()==MANIFEST['sha256'][name]:
        return executable(destination)
    destination.parent.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='electron-',dir=destination.parent) as folder:
        temporary=Path(folder);archive=temporary/'runtime.zip'
        url=f'https://github.com/electron/electron/releases/download/v{version}/electron-v{version}-{name}.zip'
        print(f'Downloading verified Electron {version} / Chromium {MANIFEST["chromium"]}…',file=sys.stderr,flush=True)
        digest=hashlib.sha256()
        from settings.config import config,DATA
        options=dict(config)
        selected=Path(os.environ.get('SUPERSEARCH_ENGINE_DATA',DATA/'electron'))/'settings.json'
        if selected.is_file():
            saved=json.loads(selected.read_text())
            if isinstance(saved,dict):options.update(saved)
        proxy='socks5h://127.0.0.1:9050' if options['tor'] else options['proxy'].strip().replace('socks5://','socks5h://',1)
        with requests.Session() as client:
            client.trust_env=False
            if proxy:client.proxies.update(http=proxy,https=proxy)
            with client.get(url,stream=True,timeout=(15,60)) as response:
                response.raise_for_status()
                with archive.open('wb') as stream:
                    for chunk in response.iter_content(1024*1024):
                        stream.write(chunk);digest.update(chunk)
        if digest.hexdigest()!=MANIFEST['sha256'][name]:raise ValueError('Electron archive checksum mismatch')
        extracted=temporary/'unpacked';extracted.mkdir()
        unpack(archive,extracted)
        (extracted/'.verified').write_text(digest.hexdigest())
        if not executable(extracted).is_file():raise ValueError('Incomplete Electron runtime')
        if destination.exists():shutil.rmtree(destination)
        extracted.rename(destination)
    return executable(destination)


if __name__=='__main__':print(ensure())
```

