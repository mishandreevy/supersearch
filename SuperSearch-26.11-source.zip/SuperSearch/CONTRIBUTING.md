# Contributing

Use Python 3.10 or newer. The browser is in `engine/`: the Electron controller,
isolated website preload, trusted HTML/CSS UI and private Python stdio service.
Shared storage and encrypted backups are in `core/`, and dictionaries/metadata in
`settings/`. Qt/PySide6 and an extra Node.js/npm installation are not required.

Runtime user data belongs only in `data/`. Never commit it or include it in source
archives. The downloaded engine cache in `.runtime/` also stays outside releases.
The application display version is **26.11**. Read it from `engine/package.json`;
Python, Electron, the About screen and backup metadata share that release identity.
See `docs/RELEASING.md` for source-publication steps.

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python tools/install_electron.py
.venv/bin/python tools/check_runtime.py
.venv/bin/python -m compileall -q main.py core settings engine tests tools
.venv/bin/python -m unittest discover -s tests -p 'test_*.py' -v
.venv/bin/python tests/gui_electron.py
.venv/bin/python main.py --engine-version
.venv/bin/python -m pip check
.venv/bin/python tools/export_source.py
```

Run JavaScript policy checks with the installed runtime (substitute the platform
path from `tools/install_electron.py`):

```sh
ELECTRON_RUN_AS_NODE=1 .runtime/electron-45.2.1-linux-x64/electron tests/electron_policy.test.js
```

`tests/gui_electron.py` runs isolated modes for ephemeral browsing, persistent storage/local extensions,
onboarding/tours, disabled website JavaScript, panel layout, backup and returning-user
restore. Pass mode names to run a subset. Tests use temporary profiles, local
HTTP/HTTPS fixtures and generated certificates. Certificate trust is scoped to the
fixture fingerprint inside a marked test profile. Layout checks cover both
horizontal edges, collapsed buttons, long translations and 75–175% interface scale.
On a headless Linux machine, use `xvfb-run -a` with a functioning sandbox.

All GUI tests use the Electron runtime and temporary profiles. `backup` and
`returning` modes export or select an encrypted file, check a wrong password,
stage a restore and launch a second process through the real restore-token path.
Never run restore/reset tests against actual user data. Keep the sandbox enabled;
Linux tests inspect real seccomp and NoNewPrivs flags.

For engine updates, review the official stable release, update the compiled
Electron/Chromium versions and official platform SHA-256 digests together in
`engine/runtime.json`, preserve upstream notices and run the integration tests.
A user-agent change is not an engine update. Do not silently reuse incompatible
Chromium-internal profile files.

For privacy changes, describe which network requests occur, whether they require
consent, how proxy/Tor routing is preserved and whether anything reaches disk.
For storage cleanup changes, use a temporary directory and an unrelated sentinel
file. Never test deletion against a real profile. Never log IPC request bodies,
master passwords, vault plaintext or captured form credentials.

Do not claim full anonymity, universal extension compatibility, complete OS-key
migration or secure physical erasure. Preserve dependency and asset attribution.
