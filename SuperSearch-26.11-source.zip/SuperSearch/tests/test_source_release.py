"""Release identity, complete source artifacts and exclusion of local private files."""
import contextlib
import hashlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile
from core.version import APP_VERSION,PACKAGE_VERSION,SOURCE_URL
from tools.export_source import ROOT,ROOT_FILES,export,sources


class SourceReleaseTests(unittest.TestCase):
    def fixture(self,directory):
        root=Path(directory)
        for name in ROOT_FILES:(root/name).write_bytes((ROOT/name).read_bytes())
        (root/'engine').mkdir()
        (root/'engine/package.json').write_bytes((ROOT/'engine/package.json').read_bytes())
        (root/'engine/ui.js').write_text("const literal = '```';\n",encoding='utf-8')
        (root/'.github/workflows').mkdir(parents=True)
        (root/'.github/workflows/check.yml').write_text('name: fixture\n',encoding='utf-8')
        return root

    def test_all_runtime_release_identity_uses_manifest(self):
        package=json.loads((ROOT/'engine/package.json').read_text())
        self.assertEqual(APP_VERSION,'26.11')
        self.assertEqual(PACKAGE_VERSION,'26.11.0')
        self.assertEqual(package['displayVersion'],APP_VERSION)
        self.assertEqual(package['version'],PACKAGE_VERSION)
        self.assertEqual(package['repository']['url'],SOURCE_URL)
        self.assertIn('SuperSearch:RELEASE.displayVersion',(ROOT/'engine/main.js').read_text())
        self.assertIn('esc(S.versions.SuperSearch)',(ROOT/'engine/ui.js').read_text())
        self.assertIn('app_version=APP_VERSION',(ROOT/'core/backup.py').read_text())

    def test_publication_excludes_profiles_hidden_files_and_symlinks(self):
        with tempfile.TemporaryDirectory() as directory:
            root=self.fixture(directory)
            private=['data/passwords.json','.runtime/runtime.json','engine/data/cookies.json',
                     'engine/.env.json','assets/.aws/credentials.json','tools/.codex/session.json',
                     'engine/node_modules/secret.json','engine/backup.supersearch','engine/passwords.vault']
            for name in private:
                path=root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text('private sentinel')
            names={path.relative_to(root).as_posix() for path in sources(root)}
            self.assertFalse(names.intersection(private))
            self.assertIn('.github/workflows/check.yml',names)
            with contextlib.redirect_stdout(io.StringIO()):archive=export(root)
            with ZipFile(archive) as package:
                self.assertFalse(any('private sentinel' in package.read(name).decode('utf-8') for name in package.namelist()))
                manifest=json.loads(package.read('SuperSearch/SOURCE_MANIFEST.json'))
                for name,digest in manifest.items():self.assertEqual(hashlib.sha256(package.read('SuperSearch/'+name)).hexdigest(),digest)
                self.assertEqual((package.getinfo('SuperSearch/run.sh').external_attr>>16)&0o777,0o755)
                full=package.read('SuperSearch/SOURCE_FULL.md').decode()
                self.assertIn("````javascript\nconst literal = '```';\n````",full)
            versioned=root/'SuperSearch-26.11-source.zip'
            self.assertEqual(archive.read_bytes(),versioned.read_bytes())
            self.assertEqual((root/'SuperSearch-26.11-source.sha256').read_text().split()[0],hashlib.sha256(versioned.read_bytes()).hexdigest())
            before=archive.read_bytes()
            with contextlib.redirect_stdout(io.StringIO()):export(root)
            self.assertEqual(archive.read_bytes(),before)

    def test_required_source_symlink_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root=self.fixture(directory);path=root/'main.py';path.unlink()
            try:path.symlink_to(root/'README.md')
            except OSError:self.skipTest('Symlinks are unavailable on this platform')
            with self.assertRaisesRegex(ValueError,'unsafe required source'):sources(root)


if __name__=='__main__':unittest.main()
