"""Import reads only selected data; destructive cleanup is scoped and authenticated."""
import csv
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from core.importer import read_profile
from core.maintenance import execute, record_download, schedule, run_pending


class ImportMaintenanceTests(unittest.TestCase):
    def test_readonly_profile_and_explicit_csv(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            (root/'Bookmarks').write_text(json.dumps({'roots':{'bookmark_bar':{'name':'Bar','children':[{'type':'url','name':'Example','url':'https://example.org'}]}}}))
            db=sqlite3.connect(root/'History')
            db.execute('CREATE TABLE urls(url,title,last_visit_time)')
            db.execute("INSERT INTO urls VALUES('https://example.org','Example',1)")
            db.execute('CREATE TABLE downloads(target_path,received_bytes,total_bytes,start_time)')
            db.execute("INSERT INTO downloads VALUES('/tmp/example.txt',10,10,1)")
            db.commit();db.close()
            db=sqlite3.connect(root/'Cookies')
            db.execute('CREATE TABLE cookies(host_key,name,value,encrypted_value,path,expires_utc,is_secure,is_httponly)')
            db.execute("INSERT INTO cookies VALUES('.example.org','plain','value',X'','/',0,1,1)")
            db.execute("INSERT INTO cookies VALUES('.example.org','protected','',X'0102','/',0,1,1)")
            db.commit();db.close()
            before=(root/'History').read_bytes()
            csv_path=root/'passwords.csv'
            with csv_path.open('w',newline='') as stream:
                writer=csv.DictWriter(stream,fieldnames=['name','url','username','password'])
                writer.writeheader()
                writer.writerow(dict(name='Example',url='https://example.org/login',username='alice',password='test secret'))
            result=read_profile(root,['bookmarks','history','downloads','cookies'],str(csv_path))
            self.assertEqual(len(result['bookmarks']),1)
            self.assertEqual(len(result['history']),1)
            self.assertEqual(len(result['downloads']),1)
            self.assertEqual(len(result['cookies']),1)
            self.assertEqual(result['skipped_cookies'],1)
            self.assertEqual(result['passwords'][0]['username'],'alice')
            self.assertEqual((root/'History').read_bytes(),before)
            self.assertEqual(read_profile(root,[])['passwords'],[])

    def test_reset_deletes_app_data_and_only_proven_downloads(self):
        with tempfile.TemporaryDirectory() as folder:
            base=Path(folder);data=base/'data';data.mkdir()
            (data/'bookmarks.json').write_text('[]')
            (data/'passwords.vault').write_text('encrypted')
            (data/'profile').mkdir();(data/'profile/Cookies').write_text('cookie')
            owned=base/'owned.bin';owned.write_bytes(b'owned')
            unrelated=base/'unrelated.bin';unrelated.write_bytes(b'keep')
            record_download(owned,data)
            report=execute(data,['reset','download_files'])
            self.assertEqual(report['removed_downloads'],1)
            self.assertFalse(owned.exists())
            self.assertTrue(unrelated.exists())
            self.assertEqual(list(data.iterdir()),[])

    def test_modified_download_is_not_deleted(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);data=root/'data';data.mkdir()
            path=root/'file.txt';path.write_text('original')
            record_download(path,data)
            path.write_text('user replacement with different length')
            report=execute(data,['download_files'])
            self.assertEqual(report['skipped_downloads'],1)
            self.assertTrue(path.exists())

    def test_cleanup_token_and_selected_categories(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            (root/'bookmarks.json').write_text('keep')
            (root/'passwords.vault').write_text('remove')
            token=schedule(['accounts'],root)
            with self.assertRaises(ValueError):
                run_pending('wrong',root)
            self.assertTrue((root/'passwords.vault').exists())
            run_pending(token,root)
            self.assertFalse((root/'passwords.vault').exists())
            self.assertEqual((root/'bookmarks.json').read_text(),'keep')

    def test_cookie_cleanup_preserves_extensions_and_other_files(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            (root/'profile/Network').mkdir(parents=True)
            (root/'profile/Network/Cookies').write_text('remove')
            (root/'profile/Extensions').mkdir()
            (root/'profile/Extensions/manifest.json').write_text('keep')
            execute(root,['cookies'])
            self.assertFalse((root/'profile/Network/Cookies').exists())
            self.assertTrue((root/'profile/Extensions/manifest.json').exists())

    def test_individual_cleanup_never_follows_parent_symlinks(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);data=root/'data';data.mkdir()
            outside=root/'outside';outside.mkdir()
            (outside/'Cookies').write_text('keep')
            try:
                (data/'profile').symlink_to(outside,target_is_directory=True)
            except OSError:
                self.skipTest('Symlinks unavailable')
            with self.assertRaises(ValueError):
                execute(data,['cookies'])
            self.assertTrue((outside/'Cookies').exists())


if __name__=='__main__':
    unittest.main()
