"""Version identity, explicit session storage and local browser discovery."""
import json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from core.version import APP_VERSION
from core.session import save,load,safe_url
from core.importer import discover_profiles,read_profile


class SessionReleaseTests(unittest.TestCase):
    def test_version_is_user_pinned(self):
        self.assertEqual(APP_VERSION,'26.11')

    def test_session_storage_is_opt_in_and_private_is_excluded(self):
        with tempfile.TemporaryDirectory() as folder:
            tab=SimpleNamespace(pending_session={'panes':['https://example.org/'], 'active_pane':0})
            window=SimpleNamespace(private=True,tabs=[tab],list=SimpleNamespace(currentRow=lambda:0))
            save(window,folder)
            self.assertFalse((Path(folder)/'session.json').exists())
            window.private=False
            save(window,folder)
            self.assertEqual(load(folder)['tabs'][0]['panes'],['https://example.org/'])
            (Path(folder)/'session.json').write_text('{"tabs":{},"active_tab":"bad"}')
            self.assertIsNone(load(folder))
            for url in ('javascript:alert(1)','https://user:secret@example.org','file:///private',{},42):
                self.assertEqual(safe_url(url),'supersearch:start')

    def test_detected_profiles_and_manual_root_import(self):
        with tempfile.TemporaryDirectory() as folder:
            home=Path(folder)
            root=home/'.config/google-chrome'
            profile=root/'Default'
            profile.mkdir(parents=True)
            (root/'Local State').write_text(json.dumps({'profile':{'info_cache':{'Default':{'name':'Personal'}}}}))
            (profile/'Bookmarks').write_text(json.dumps({'roots':{'bar':{'name':'Bookmarks','children':[{'type':'url','name':'Example','url':'https://example.org'}]}}}))
            with patch('core.importer.Path.home',return_value=home),patch('core.importer.sys.platform','linux'):
                found=discover_profiles()
            self.assertIn(('Chrome · Personal',str(profile)),found)
            result=read_profile(root,['bookmarks','history','downloads','cookies','preferences'])
            self.assertEqual(len(result['bookmarks']),1)
            self.assertFalse(result['history'])

if __name__=='__main__':unittest.main()
