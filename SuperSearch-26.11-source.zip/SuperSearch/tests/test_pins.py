"""Persistent pins are explicit, independent of session saving and identity based."""
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from core.pins import PinStore
from core.session import normalize_tab
from core.maintenance import execute


def pending(identifier,url='https://example.org/',panes=None):
    return SimpleNamespace(id=identifier,pinned=True,
        pending_session={'panes':panes or [url],'active_pane':0})


class PinTests(unittest.TestCase):
    def test_restart_update_and_unpin_without_session(self):
        with tempfile.TemporaryDirectory() as folder:
            store=PinStore(folder)
            tab=pending('a')
            store.upsert(tab)
            self.assertFalse((Path(folder)/'session.json').exists())
            restored=PinStore(folder)
            self.assertEqual(restored.startup()['tabs'][0]['panes'],['https://example.org/'])
            tab.pending_session={'panes':['https://example.org/changed','about:blank'],'active_pane':1}
            restored.upsert(tab)
            latest=PinStore(folder).startup()['tabs']
            self.assertEqual(len(latest),1)
            self.assertEqual(latest[0]['active_pane'],1)
            self.assertEqual(len(latest[0]['panes']),2)
            restored.remove('a')
            self.assertIsNone(PinStore(folder).startup())

    def test_merge_deduplicates_identity_and_preserves_selection(self):
        with tempfile.TemporaryDirectory() as folder:
            store=PinStore(folder)
            store.upsert(pending('a'))
            # Two tabs may intentionally contain the same website.
            store.upsert(pending('b'))
            regular=normalize_tab(dict(id='c',panes=['supersearch:start'],pinned=True))
            session=dict(tabs=[regular,store.records[0]],active_tab=0)
            combined=store.startup(session)
            self.assertEqual([t['id'] for t in combined['tabs']],['a','b','c'])
            self.assertFalse(combined['tabs'][-1]['pinned'])
            self.assertEqual(combined['active_tab'],2)

    def test_invalid_files_and_transaction_failure(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'pinned-tabs.json'
            path.write_text(json.dumps({'tabs':[None,{},dict(id='a',panes=['javascript:alert(1)']),dict(id='a',panes=['about:blank'])]}))
            store=PinStore(folder)
            self.assertEqual(len(store.records),1)
            self.assertEqual(store.records[0]['panes'],['supersearch:start'])
            with patch('core.pins.write_json',side_effect=OSError('Read-only fixture')):
                with self.assertRaises(OSError):store.upsert(pending('new'))
            self.assertEqual([r['id'] for r in store.records],['a'])
            path.write_text('{broken')
            self.assertIsNone(PinStore(folder).startup())

    def test_selective_cleanup_removes_pin_storage(self):
        with tempfile.TemporaryDirectory() as folder:
            store=PinStore(folder)
            store.upsert(pending('a'))
            sentinel=Path(folder)/'bookmarks.json'
            sentinel.write_text('[]')
            session=Path(folder)/'session.json'
            ordinary=normalize_tab(dict(id='b',panes=['https://example.net/']))
            session.write_text(json.dumps(dict(tabs=store.records+[ordinary],active_tab=1)))
            execute(folder,['pinned_tabs'])
            self.assertIsNone(PinStore(folder).startup())
            self.assertTrue(sentinel.exists())
            self.assertEqual([t['id'] for t in json.loads(session.read_text())['tabs']],['b'])


if __name__=='__main__':unittest.main()
