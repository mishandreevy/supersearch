"""Native battery readings: absence, unknown values and portable OS parsing."""
import ctypes
from pathlib import Path
from types import SimpleNamespace
import subprocess
import tempfile
import unittest
from unittest.mock import Mock,patch
from core.system_status import BatteryState,SystemPowerStatus,linux_battery,windows_battery,macos_battery,read_battery


class SystemStatusTests(unittest.TestCase):
    def test_linux_ignores_peripherals_and_missing_batteries(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            self.assertIsNone(linux_battery(root))
            def device(name,**fields):
                p=root/name;p.mkdir()
                for key,value in fields.items():(p/key).write_text(str(value))
                return p
            device('AC',type='Mains',capacity=100)
            device('mouse',type='Battery',scope='Device',capacity=25)
            device('absent',type='Battery',present=0,capacity=80)
            device('unknown',type='Battery',capacity=255)
            self.assertIsNone(linux_battery(root))
            battery=device('BAT0',type='Battery',scope='System',capacity=67,status='Discharging')
            self.assertEqual(linux_battery(root),BatteryState(67,False))
            (battery/'capacity').write_text('0')
            (battery/'status').write_text('Charging')
            self.assertEqual(linux_battery(root),BatteryState(0,True))

    def test_linux_energy_fallback_and_weighted_multiple_batteries(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            for name,now,full in [('BAT0',10,20),('BAT1',60,80)]:
                device=root/name;device.mkdir()
                for key,value in dict(type='Battery',energy_now=now,energy_full=full,status='Charging').items():
                    (device/key).write_text(str(value))
            self.assertEqual(linux_battery(root),BatteryState(70,True))

    def test_windows_flags_and_structure(self):
        self.assertEqual(ctypes.sizeof(SystemPowerStatus),12)
        def read(percent,flag,success=1):
            def fill(pointer):
                pointer._obj.BatteryLifePercent=percent
                pointer._obj.BatteryFlag=flag
                return success
            return windows_battery(SimpleNamespace(GetSystemPowerStatus=Mock(side_effect=fill)))
        self.assertEqual(read(73,8),BatteryState(73,True))
        self.assertEqual(read(0,4),BatteryState(0,False))
        for percent,flag in ((100,128),(255,1),(42,255)):
            self.assertIsNone(read(percent,flag))
        self.assertIsNone(read(50,1,0))

    def test_macos_internal_battery_and_absence(self):
        for status,charging in [('charging',True),('discharging',False),('not charging',False),('charged',False)]:
            result=SimpleNamespace(returncode=0,stdout=f"Now drawing from 'AC Power'\n -InternalBattery-0 73%; {status}; 0:45 remaining\n")
            with patch('core.system_status.subprocess.run',return_value=result) as run:
                self.assertEqual(macos_battery(),BatteryState(73,charging))
                self.assertEqual(run.call_args.args[0],['/usr/bin/pmset','-g','batt'])
                self.assertEqual(run.call_args.kwargs['timeout'],2)
        with patch('core.system_status.subprocess.run',return_value=SimpleNamespace(returncode=0,stdout="Now drawing from 'AC Power'")):
            self.assertIsNone(macos_battery())

    def test_unavailable_sensor_never_fabricates_a_percentage(self):
        with patch('core.system_status.sys.platform','darwin'),patch('core.system_status.subprocess.run',side_effect=subprocess.TimeoutExpired('pmset',2)):
            self.assertIsNone(read_battery())
        with patch('core.system_status.sys.platform','unsupported'):
            self.assertIsNone(read_battery())


if __name__=='__main__':unittest.main()
