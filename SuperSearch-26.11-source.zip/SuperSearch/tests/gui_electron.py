"""Run the new engine only against temporary data and a loopback web fixture."""
import json
import os
import subprocess
import sys
import tempfile
import datetime
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import rsa
import ipaddress
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from settings.config import DEFAULTS,ROOT


def run(mode):
    with tempfile.TemporaryDirectory(prefix='supersearch-electron-test-') as temporary:
        directory=Path(temporary)/'profile';directory.mkdir()
        backup=Path(temporary)/'export.supersearch'
        (directory/'.supersearch-test-profile').write_text('temporary-test-profile')
        values=dict(DEFAULTS,onboarding_complete=True,suggestions=False,home_ip=False,confirm_close=False,
                    https_only=False,animations=False,layout_state='',window_geometry='',theme='light')
        values['ephemeral_profile']=mode!='persistent'
        values['javascript']=mode=='javascript-off'
        values['onboarding_complete']=mode not in ('onboarding','returning')
        if mode in ('onboarding','returning'):values['suggestions']=None
        (directory/'settings.json').write_text(json.dumps(values))
        key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        subject=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'localhost')])
        now=datetime.datetime.now(datetime.timezone.utc)
        certificate=(x509.CertificateBuilder().subject_name(subject).issuer_name(subject).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-datetime.timedelta(days=1)).not_valid_after(now+datetime.timedelta(days=1)).add_extension(x509.SubjectAlternativeName([x509.DNSName('localhost'),x509.IPAddress(ipaddress.ip_address('127.0.0.1'))]),critical=False).sign(key,hashes.SHA256()))
        (directory/'fixture-cert.pem').write_bytes(certificate.public_bytes(serialization.Encoding.PEM))
        (directory/'fixture-key.pem').write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.TraditionalOpenSSL,serialization.NoEncryption()))
        if mode=='returning':
            from core.backup import export_data
            source=Path(temporary)/'source';source.mkdir()
            (source/'settings.json').write_text(json.dumps(dict(values,onboarding_complete=True,theme='oled')))
            (source/'bookmarks.json').write_text('[{"url":"https://example.org","title":"Portable bookmark","folder":"Work"}]')
            export_data(source,backup,'fixture backup password')
        env=dict(os.environ,SUPERSEARCH_TEST_BACKUP_PATH=str(backup),SUPERSEARCH_ENGINE_DATA=str(directory),SUPERSEARCH_SKIP_MIGRATION='1',SUPERSEARCH_TEST_PROFILE_HOME=str(directory/'fixture-home'),SUPERSEARCH_TEST_MODE=mode)
        result=subprocess.run([sys.executable,str(ROOT/'main.py'),'--self-test'],cwd=ROOT,env=env,timeout=90)
        if result.returncode:raise SystemExit(result.returncode)
        if mode in ('backup','returning'):
            plan=json.loads((directory/'.restore-plan.json').read_text())
            restored_env=dict(env,SUPERSEARCH_TEST_MODE='restored')
            result=subprocess.run([sys.executable,str(ROOT/'main.py'),'--restore-token',plan['token'],'--self-test'],cwd=ROOT,env=restored_env,timeout=90)
            if result.returncode:raise SystemExit(result.returncode)
            assert not (directory/'.restore-plan.json').exists()


if __name__=='__main__':
    for mode in sys.argv[1:] or ['ephemeral','persistent','onboarding','javascript-off','layout','backup','returning']:
        if mode not in ('ephemeral','persistent','onboarding','javascript-off','layout','backup','returning'):raise SystemExit('Unknown test mode')
        print('Testing Electron mode: '+mode,flush=True);run(mode)
