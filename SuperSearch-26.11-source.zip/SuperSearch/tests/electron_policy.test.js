'use strict';
const assert=require('node:assert/strict');
let passed=0;
function test(name,fn){fn();passed++;console.log('PASS: '+name);}
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {origin,target,cleaned,sameParty,Filters,validSender}=require('../engine/policy');

test('navigation only accepts web addresses and local blank/start pages',()=>{
  assert.equal(target('example.org'),'https://example.org/');assert.equal(target('[::1]:8080'),'https://[::1]:8080/');
  assert.equal(target('two words'),'https://duckduckgo.com/?q=two%20words');
  assert.equal(origin('https://user:secret@example.org'),'');assert.equal(origin('file:///etc/passwd'),'');
  assert.equal(target('javascript:alert(1)'),null);assert.equal(target('https://user:secret@example.org'),null);assert.equal(target('http://intranet'),'http://intranet/');
  assert.equal(target('supersearch:start'),'supersearch:start');
});
process.on('beforeExit',()=>{assert.equal(passed,4);console.log('POLICY CHECKS OK: '+passed);});
test('HTTPS and tracking cleanup retain functional parameters',()=>{
  assert.equal(cleaned('http://example.org/a?utm_source=x&fbclid=secret&safe=ok',{https_only:true,strip_params:true}),'https://example.org/a?safe=ok');
  assert.equal(cleaned('http://localhost:123/a?test=1',{https_only:false,strip_params:true}),'http://localhost:123/a?test=1');
  assert.equal(sameParty('https://cdn.example.org','https://example.org'),true);assert.equal(sameParty('https://example.org.evil.test','https://example.org'),false);
});
test('filter exceptions win; domain rules do not match lookalike domains',()=>{
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'supersearch-rules-'));
  try{fs.writeFileSync(path.join(directory,'test.txt'),'||tracker.example^\n@@||safe.tracker.example^\n/fixture-pixel\ninvalid*$script\n');const rules=new Filters(directory);
    assert.equal(rules.blocked('https://a.tracker.example/a'),true);assert.equal(rules.blocked('https://safe.tracker.example/a'),false);assert.equal(rules.blocked('https://tracker.example.evil.test/a'),false);assert.equal(rules.blocked('https://other.example/fixture-pixel'),false);assert.ok(rules.skipped>=2);
    fs.writeFileSync(path.join(directory,'test.txt'),'||changed.example^\n@@||safe.changed.example^\n/fixture-pixel\ninvalid*$script\n');rules.reload();assert.equal(rules.blocked('https://tracker.example/a'),false);assert.equal(rules.blocked('https://changed.example/a'),true);
  }finally{fs.rmSync(directory,{recursive:true,force:true});}
});
test('only the trusted top-level browser UI is an IPC sender',()=>{
  const frame={url:'ss-app://browser/index.html'},contents={mainFrame:frame};
  assert.equal(validSender({sender:contents,senderFrame:frame},contents),true);
  assert.equal(validSender({sender:{mainFrame:frame},senderFrame:frame},contents),false);
  assert.equal(validSender({sender:contents,senderFrame:{url:frame.url}},contents),false);
  frame.url='https://example.org';assert.equal(validSender({sender:contents,senderFrame:frame},contents),false);
});
