"""Encrypted portable data, untrusted archives and reversible offline replacement."""
import io
from contextlib import closing
import json
import os
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from zipfile import ZipFile
from settings.config import DEFAULTS
from core.backup import MAGIC,apply_pending,cipher,export_data,prepare_restore,unpack
from core.vault import Vault

PASSWORD='fixture backup password'


class BackupTests(unittest.TestCase):
    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory();self.addCleanup(self.temporary.cleanup)
        self.root=Path(self.temporary.name);self.source=self.root/'source';self.source.mkdir();self.target=self.root/'target';self.target.mkdir();self.file=self.root/'profile.supersearch'
        (self.source/'settings.json').write_text(json.dumps(dict(DEFAULTS,theme='dark')))
        (self.source/'bookmarks.json').write_text('[{"url":"https://example.org","title":"Private bookmark","folder":"Work"}]')
        (self.source/'history.json').write_text('[{"url":"https://example.net","title":"History"}]')
        (self.source/'userscripts').mkdir();(self.source/'userscripts/fixture.js').write_text('window.fixture=true;')
        (self.source/'chromium').mkdir();(self.source/'chromium/Cookies').write_bytes(b'never-export-session')
        (self.source/'download_files.json').write_text('[{"path":"/unrelated/file"}]')
        (self.target/'bookmarks.json').write_bytes(b'original library')
        self.validate=lambda saved:dict(DEFAULTS,**saved)

    def prepare(self,scripts=False):return prepare_restore(self.file,PASSWORD,self.target,self.validate,scripts)

    def test_roundtrip_live_sqlite_and_still_encrypted_vault(self):
        vault=Vault(self.source/'passwords.vault');vault.create('fixture master password');vault.save('https://example.org','alice','secret login');vault.lock()
        database=sqlite3.connect(self.source/'statistics.sqlite');self.addCleanup(database.close)
        database.execute('PRAGMA journal_mode=WAL');database.execute('CREATE TABLE blocks(day TEXT,domain TEXT,n INTEGER,PRIMARY KEY(day,domain))');database.execute("INSERT INTO blocks VALUES('2026-11-03','tracker.example',17)");database.commit()
        export_data(self.source,self.file,PASSWORD,database)
        self.assertNotIn(b'Private bookmark',self.file.read_bytes());self.assertNotIn(b'secret login',self.file.read_bytes())
        values=unpack(self.file,PASSWORD);self.assertNotIn('chromium/Cookies',values);self.assertNotIn('download_files.json',values)
        token=self.prepare();self.assertEqual((self.target/'bookmarks.json').read_bytes(),b'original library')
        (self.target/'chromium').mkdir();(self.target/'chromium/Cookies').write_bytes(b'old session')
        apply_pending(token,self.target)
        self.assertEqual(json.loads((self.target/'bookmarks.json').read_text())[0]['title'],'Private bookmark')
        self.assertFalse((self.target/'chromium').exists());self.assertFalse((self.target/'userscripts').exists())
        restored=Vault(self.target/'passwords.vault');restored.unlock('fixture master password');self.assertEqual(restored.entries()[0]['password'],'secret login');restored.lock()
        with closing(sqlite3.connect(self.target/'statistics.sqlite')) as db:self.assertEqual(db.execute('SELECT n FROM blocks').fetchone()[0],17)
        settings=json.loads((self.target/'settings.json').read_text());self.assertTrue(settings['onboarding_complete']);self.assertFalse(settings['tour_pending'])
        self.assertEqual((self.source/'chromium/Cookies').read_bytes(),b'never-export-session')

    def test_wrong_password_and_tampering_leave_target_untouched(self):
        export_data(self.source,self.file,PASSWORD)
        with self.assertRaisesRegex(ValueError,'incorrect or the file is damaged'):prepare_restore(self.file,'another backup password',self.target,self.validate)
        encrypted=bytearray(self.file.read_bytes());encrypted[-20]^=1;self.file.write_bytes(encrypted)
        with self.assertRaises(ValueError):self.prepare()
        self.assertEqual(list(self.target.iterdir()),[self.target/'bookmarks.json'])
        self.assertEqual((self.target/'bookmarks.json').read_bytes(),b'original library')

    def test_unsafe_archive_paths_are_rejected_after_authentication(self):
        archive=io.BytesIO()
        with ZipFile(archive,'w') as zipfile:zipfile.writestr('manifest.json','{}');zipfile.writestr('../outside','bad')
        salt=os.urandom(16);self.file.write_bytes(MAGIC+salt+cipher(PASSWORD,salt).encrypt(archive.getvalue()))
        with self.assertRaisesRegex(ValueError,'unsafe path'):self.prepare()
        self.assertFalse((self.root/'outside').exists());self.assertEqual(len(list(self.target.iterdir())),1)

    def test_failure_during_install_rolls_back_and_can_be_retried(self):
        export_data(self.source,self.file,PASSWORD);token=self.prepare();original_rename=Path.rename
        def rename(path,target):
            if path.name=='bookmarks.json' and path.parent.name.startswith('.restore-staging-'):raise OSError('fixture disk error')
            return original_rename(path,target)
        with patch('core.backup.Path.rename',rename),self.assertRaisesRegex(OSError,'fixture disk error'):apply_pending(token,self.target)
        self.assertEqual((self.target/'bookmarks.json').read_bytes(),b'original library')
        apply_pending(token,self.target);self.assertTrue(json.loads((self.target/'settings.json').read_text())['onboarding_complete'])

    def test_scripts_require_opt_in_and_requests_are_authenticated(self):
        export_data(self.source,self.file,PASSWORD);token=self.prepare(scripts=True)
        with self.assertRaises(ValueError):apply_pending('0'*48,self.target)
        self.assertEqual((self.target/'bookmarks.json').read_bytes(),b'original library')
        apply_pending(token,self.target);self.assertEqual((self.target/'userscripts/fixture.js').read_text(),'window.fixture=true;')
        self.assertFalse((self.target/'download_files.json').exists())

    def test_symlinks_and_recursive_destination_are_rejected(self):
        with self.assertRaisesRegex(ValueError,'outside'):export_data(self.source,self.source/'export.supersearch',PASSWORD)
        secret=self.root/'unrelated';secret.write_text('outside sentinel')
        (self.source/'bookmarks.json').unlink();(self.source/'bookmarks.json').symlink_to(secret)
        with self.assertRaisesRegex(ValueError,'symbolic links'):export_data(self.source,self.file,PASSWORD)
        self.assertEqual(secret.read_text(),'outside sentinel')


if __name__=='__main__':unittest.main()
