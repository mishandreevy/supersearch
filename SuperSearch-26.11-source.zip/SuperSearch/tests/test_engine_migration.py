"""Data compatibility, rollback isolation and the new local IPC service."""
import json
from contextlib import closing
import os
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from settings.config import DEFAULTS,ROOT
from core.electron_launcher import migrate
from core.vault import Vault


class EngineMigrationTests(unittest.TestCase):
    def test_snapshot_preserves_original_libraries_vault_and_sqlite(self):
        with tempfile.TemporaryDirectory() as temporary:
            source=Path(temporary)/'qt';source.mkdir();destination=source/'electron'
            (source/'settings.json').write_text(json.dumps(dict(DEFAULTS,onboarding_complete=True)))
            (source/'bookmarks.json').write_text('[{"url":"https://example.org","title":"Original"}]')
            vault=Vault(source/'passwords.vault');vault.create('fixture master password');vault.save('https://example.org','alice','fixture credential');encrypted=(source/'passwords.vault').read_bytes();vault.lock()
            database=sqlite3.connect(source/'statistics.sqlite');database.execute('CREATE TABLE blocks(day TEXT,domain TEXT,n INTEGER,PRIMARY KEY(day,domain))');database.execute("INSERT INTO blocks VALUES('2026-11-03','fixture.example',7)");database.commit();database.close()
            (source/'userscripts').mkdir();(source/'userscripts/test.js').write_text('window.fixture=true;')
            (source/'profile').mkdir();(source/'profile/Cookies').write_bytes(b'never copy a Chromium profile across engines')
            migrate(source,destination)
            self.assertEqual((source/'passwords.vault').read_bytes(),encrypted)
            copied=Vault(destination/'passwords.vault');copied.unlock('fixture master password');self.assertEqual(copied.entries()[0]['username'],'alice');copied.lock()
            self.assertFalse((destination/'profile').exists())
            with closing(sqlite3.connect(destination/'statistics.sqlite')) as database:self.assertEqual(database.execute('SELECT n FROM blocks').fetchone()[0],7)
            (destination/'bookmarks.json').write_text('[]');migrate(source,destination)
            self.assertEqual(json.loads((destination/'bookmarks.json').read_text()),[])
            self.assertEqual(json.loads((source/'bookmarks.json').read_text())[0]['title'],'Original')

    def test_local_service_settings_are_transactional_and_vault_stays_encrypted(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory=Path(temporary)
            process=subprocess.Popen([sys.executable,str(ROOT/'engine/service.py')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=dict(os.environ,SUPERSEARCH_DATA=temporary))
            sequence=0
            def call(operation,data=None):
                nonlocal sequence
                sequence+=1;process.stdin.write(json.dumps(dict(id=sequence,operation=operation,data=data or {}))+'\n');process.stdin.flush()
                reply=json.loads(process.stdout.readline());self.assertEqual(reply['id'],sequence);return reply
            try:
                initial=call('bootstrap')['result'];self.assertEqual(initial['config']['language'],'en')
                self.assertEqual(call('settings',{'proxy':'invalid proxy'})['error'],'Enter a proxy address such as socks5://127.0.0.1:1080, without a username or password.')
                self.assertFalse((directory/'settings.json').exists())
                self.assertIn('error',call('settings',{'nav_order':['<script>bad</script>']}))
                self.assertIn('error',call('settings',{'colors':{'bg':'#ffffff','panel':'#ffffff','fg':'#ffffff'}}))
                self.assertEqual(call('settings',{'theme':'dark','sidebar_position':'bottom'})['result']['theme'],'dark')
                self.assertIn('result',call('vault_create',{'password':'fixture master password'}))
                call('vault_save',{'origin':'https://example.org','username':'alice','password':'fixture credential'})
                self.assertNotIn(b'fixture credential',(directory/'passwords.vault').read_bytes())
                self.assertNotIn('password',call('vault_list')['result'][0])
                call('vault_lock');self.assertIn('error',call('vault_get',{'origin':'https://example.org','username':'alice'}))
                state=call('state')['result'];self.assertFalse(state['vault']['unlocked']);self.assertNotIn('fixture credential',json.dumps(state))
            finally:
                process.stdin.close();process.wait(timeout=10);process.stdout.close();process.stderr.close()
                self.assertEqual(process.returncode,0)


if __name__=='__main__':unittest.main()
