"""Offline regressions: worker lifetime, authenticated vault, bookmark persistence."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from core.storage import Store
from core.vault import Vault, origin_of


class RegressionTests(unittest.TestCase):
    def test_vault_encryption_password_changes_and_origin_boundaries(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / 'passwords.vault'
            vault = Vault(path)
            with self.assertRaises(ValueError):
                vault.create('short')
            vault.create('correct horse battery staple')
            vault.save('https://example.org/login', 'alice', 'secret-never-plaintext')
            vault.save('https://example.org:443/other', 'alice', 'updated-secret')
            self.assertEqual(len(vault.entries()), 1)
            self.assertEqual(vault.entries('https://example.org')[0]['password'], 'updated-secret')
            self.assertFalse(vault.entries('https://other.example.org'))
            self.assertFalse(vault.entries('http://example.org'))
            document = path.read_text()
            self.assertNotIn('updated-secret', document)
            self.assertNotIn('alice', document)
            self.assertNotIn('correct horse', document)
            vault.lock()
            with self.assertRaises(ValueError):
                vault.entries()
            with self.assertRaises(ValueError):
                vault.unlock('wrong password')
            self.assertFalse(vault.unlocked)
            vault.unlock('correct horse battery staple')
            vault.change_password('another very long master password')
            vault.lock()
            with self.assertRaises(ValueError):
                vault.unlock('correct horse battery staple')
            vault.unlock('another very long master password')
            vault.remove('https://example.org', 'alice')
            self.assertFalse(vault.entries())
            vault.lock()
            data = json.loads(path.read_text())
            token = data['token']
            data['token'] = token[:40] + ('A' if token[40] != 'A' else 'B') + token[41:]
            path.write_text(json.dumps(data))
            with self.assertRaises(ValueError):
                vault.unlock('another very long master password')

    def test_canonical_origins(self):
        self.assertEqual(origin_of('https://Example.org:443/a?q=1'), 'https://example.org')
        self.assertEqual(origin_of('https://[::1]:8443/login'), 'https://[::1]:8443')
        self.assertNotEqual(origin_of('https://example.org:444'), origin_of('https://example.org'))
        for url in ['javascript:alert(1)', 'https://[', 'https://user:pass@example.org', 'about:blank']:
            self.assertEqual(origin_of(url), '')

    def test_bookmark_editor_updates_without_toggle(self):
        with tempfile.TemporaryDirectory() as temporary, patch('core.storage.DATA', Path(temporary)):
            store = Store()
            store.save_bookmark('https://example.org', 'First', 'Work')
            store.save_bookmark('https://example.org', 'Changed', 'Read later')
            self.assertEqual(len(store.bookmarks), 1)
            store.save_bookmark('https://example.net', 'Moved', 'Work', original_url='https://example.org')
            self.assertEqual(store.bookmarks, [{'url': 'https://example.net', 'title': 'Moved', 'folder': 'Work'}])
            saved = json.loads((Path(temporary) / 'bookmarks.json').read_text())
            self.assertEqual(saved, store.bookmarks)
            store.remove_bookmark('https://example.net')
            self.assertFalse(store.bookmarks)
            store.db.close()


if __name__ == '__main__':
    unittest.main()
