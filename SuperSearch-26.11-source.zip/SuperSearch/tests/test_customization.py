"""Privacy defaults, offline home data, safe download naming and extension validation."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from zipfile import ZipFile
from settings.config import Config
from core.shortcuts import Shortcuts, DEFAULT_SHORTCUTS
from core.downloads import safe_filename, download_target
from core.extensions import extension_manifest


class CustomizationTests(unittest.TestCase):
    def test_fresh_and_migrated_defaults(self):
        with tempfile.TemporaryDirectory() as folder, patch('settings.config.DATA', Path(folder)):
            fresh = Config()
            self.assertEqual(fresh['theme'], 'light')
            self.assertEqual(fresh['language'],'en')
            self.assertTrue(fresh['confirm_close'])
            self.assertFalse(fresh['dark_sites'])
            self.assertIsNone(fresh['suggestions'])
            self.assertTrue(fresh['ephemeral_profile'])
            self.assertFalse(fresh['remember_history'])
            self.assertFalse(fresh['onboarding_complete'])
            self.assertEqual(fresh['terms_version'],'')
            path = Path(folder) / 'settings.json'
            path.write_text(json.dumps({'theme':'dark', 'dark_sites':True, 'suggestions':False}))
            migrated = Config()
            self.assertEqual(migrated['theme'], 'light')
            self.assertFalse(migrated['dark_sites'])
            self.assertFalse(migrated['suggestions'])
            migrated['theme'] = 'oled'
            migrated.save()
            self.assertEqual(Config()['theme'], 'oled')

    def test_shortcuts_can_all_be_removed_and_reordered(self):
        with tempfile.TemporaryDirectory() as folder:
            store = Shortcuts(folder)
            self.assertEqual(len(store.entries), 6)
            entry = store.new('Custom', 'https://example.org')
            store.commit([entry, store.entries[0]])
            self.assertEqual(Shortcuts(folder).entries[0], entry)
            store.commit([])
            self.assertEqual(Shortcuts(folder).entries, [])
            with self.assertRaises(ValueError):
                store.commit([dict(id='bad', title='Bad', url='javascript:alert(1)')])
            # Empty content stays empty across restarts instead of resurrecting defaults.
            self.assertEqual(Shortcuts(folder).entries, [])

    def test_home_icons_are_local(self):
        with tempfile.TemporaryDirectory() as folder:
            store = Shortcuts(folder)
            for entry in store.entries:
                self.assertTrue(store.icon_data(entry).startswith('data:image/svg+xml;base64,'))
            custom = store.new('Custom', 'https://example.net')
            self.assertTrue(store.icon_data(custom).startswith('data:'))

    def test_download_names_never_replace_existing_paths(self):
        with tempfile.TemporaryDirectory() as folder:
            directory = Path(folder)
            first = directory / 'report.pdf'
            first.write_bytes(b'original')
            second = download_target(directory, '../../report.pdf')
            self.assertEqual(second.name, 'report (1).pdf')
            third = download_target(directory, 'report.pdf', {str(second)})
            self.assertEqual(third.name, 'report (2).pdf')
            self.assertEqual(first.read_bytes(), b'original')
            self.assertEqual(safe_filename('C:\\temp\\document.txt'), 'document.txt')
            self.assertEqual(safe_filename('CON.txt'), '_CON.txt')
            self.assertNotIn('\u202e', safe_filename('pic\u202eexe.jpg'))
            self.assertNotIn('/', safe_filename('../test'))

    def test_extension_zip_validation(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'extension.zip'
            manifest = {'manifest_version':3, 'name':'Offline test', 'version':'1.0'}
            with ZipFile(path, 'w') as archive:
                archive.writestr('manifest.json', json.dumps(manifest))
            self.assertEqual(extension_manifest(path)['name'], 'Offline test')
            with ZipFile(path, 'w') as archive:
                archive.writestr('manifest.json', json.dumps(manifest))
                archive.writestr('../escape.txt', 'not allowed')
            with self.assertRaises(ValueError):
                extension_manifest(path)
            manifest['manifest_version'] = 2
            with ZipFile(path, 'w') as archive:
                archive.writestr('manifest.json', json.dumps(manifest))
            with self.assertRaises(ValueError):
                extension_manifest(path)


if __name__ == '__main__':
    unittest.main()
