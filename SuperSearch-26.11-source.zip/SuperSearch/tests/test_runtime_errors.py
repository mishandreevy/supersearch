"""The data service has no dependency on Qt or a second browser engine."""
import unittest
from unittest.mock import patch
from tools.check_runtime import ready


class RuntimeTests(unittest.TestCase):
    def test_runtime_requires_only_local_service_dependencies(self):
        with patch('tools.check_runtime.importlib.import_module') as load:
            self.assertTrue(ready())
            self.assertEqual([call.args[0] for call in load.call_args_list],['requests','socks','cryptography.fernet','PIL.Image'])
        with patch('tools.check_runtime.importlib.import_module',side_effect=ImportError('missing')):
            self.assertFalse(ready())


if __name__=='__main__':unittest.main()
