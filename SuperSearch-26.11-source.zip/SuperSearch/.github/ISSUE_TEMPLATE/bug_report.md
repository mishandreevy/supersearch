---
name: Bug report
about: Describe a reproducible problem in SuperSearch
---

**SuperSearch version and operating system**

Copy the versions from Settings → About or `python main.py --engine-version`.

**Steps to reproduce**

1.
2.
3.

**Expected behavior**

**Actual behavior**

**Relevant logs or screenshots**

Remove personal information first. Do not attach browser profiles, backups,
vaults, passwords, cookies, private URLs or browsing history. For a security issue,
read SECURITY.md before posting technical details publicly.
